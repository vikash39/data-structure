//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*
 * @file
 *
 *   This file contains the declaration for the Extension getTd4COO_CodeBase
 *
 */
#ifndef GETTD4COO_CODEBASE_HXX
#define GETTD4COO_CODEBASE_HXX

#include <extensions/td4_common.hxx>

 //#include "D:\LB\Ter_Source\Ter_Source\Build\ServerSideCustomization\SourceCode\libTD4teradyne\source\incl\common\teradyne_common.h"
#include "common\teradyne_constants.h"
#include "common\teradyne_trace.h"
#include <libtd4teradyne_exports.h>

#ifdef __cplusplus
extern "C" {
#endif

	extern TD4TERADYNE_API int getTd4COO_CodeBase(METHOD_message_t* msg, va_list args);

#ifdef __cplusplus
}
#endif

#include <libtd4teradyne_undef.h>

#endif  // GETTD4COO_CODEBASE_HXX
