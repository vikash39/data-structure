/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                  Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_constants.h          
#      Module          :           libTD4teradyne.dll          
#      Description     :           Constants Header file        
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  07-Oct-2014                       Vivek                              Initial Creation
#  05-Nov-2014                       Haripriya                          Added Constants for DivpartRevision Postaction
#  11-Nov-2014                       Vijayasekhar                       Added Constants for Discipline specific edit forms
#  13-Nov-2014                       Haripriya                          Added Constants for VMRepresents and VendorPart Relation
#  14-Nov-2014                       Vijayasekhar                       Added Constants for CAD,CAE,PAD,SIMULATION,MAP form related attributes
#																		respective item revision types
#  26-Dec-2014						 Haripriya						    Added errorConstants for base divisional part check
#  08-Jan-2015						 Kameshwaran						Added Constants For Create and Modification Model forms.
#  13-Jan-2015						 Kameshwaran 						Added TD_CHECK_IN_MSG_ERROR error message.
#  16-Jan-2015						 Kameshwaran						Added Constans for attributes (td4ControllingBussUnit and td4ControllingBussUnitCre) and changed the macro name for workflow initiate on post action.
#  28-Jan-2015                       Vijayasekhar                       Added TD_COMMPARTREQ_TPN_ERROR, TD_DESCR_ATTR and attributes related to Commmercial part request 
#  28-Jan-2015						 Haripriya						    Added Constans for Notification and preference.
#  02-Feb-2015						 Haripriya						    Added Constans for Mail Related Preference.
#  09-Feb-2015						 Haripriya						    Added Constans for Revision Mismatch check.
#  09-Feb-2015						 Selvi						        Added Constans for Latest Item Revision query.
#  16-Feb-2015						 Haripriya						    Added Constans for DivPartMap Form Precondition.
#  16-Feb-2015						 Haripriya						    Added Constans for Semicolon.
#  18-Feb-2015						 Vijayasekhar						Added Constans related to Commodity level 1 form
#  19-Feb-2015						 Haripriya						    Added Constans for Initiate Workflow Postaction.
#  24-Feb-2015						 Haripriya						    Added Constans for CommercialPart.
#  05-Mar-2015						 Kameshwaran						Added Constants for Standand/Release ECN revision.
#  05-Mar-2015						 Haripriya						    Modified Constans for DivpartRevision.
#  06-Mar-2015						 Kameshwaran D						Added Constants for Create and Modify Request Objects
#  11-Mar-2015						 Haripriya						    Added Constants DivisionalPartMapForm
#  13-Mar-2015						 Haripriya						    Added Constants For DivisionalPart ItemId
#  12-Mar-2015                       Vijayasekhar                    	Added constants related to handlers Teradyne-AssignStatus,Teradyne-AssignStatusOnDesignDoc and Teradyne-StandardECNValidation
#  16-Mar-2015						 Selvi						        Added Constans for Related to ECN Summary report function.
#  17-Mar-2015						 Kameshwaran D						Added Constants for ECN Revision which are TD_ECN_TYPE_ATTR and TD_ITEM_STATUS_ATTR
#  17-Mar-2015						 Haripriya  						Added Constants for Teradyne-ReviewerMatrix Handler
#  18-Mar-2015						 Haripriya						    Added TD_DBA_ROLE_CONSTANT Constants.
#  18-Mar-2015                       Vijayasekhar                    	Added constants related to handlers Teradyne-RevStampCalculation and Teradyne-ReleaseECNValidations.
#  18-Mar-2015						 Haripriya  						Added Constants for Teradyne-PopulateTechReviewer,Teradyne-PopulateTechReviewerProtobom
#  20-Mar-2015                       Vijayasekhar                    	Added constants related to handlers Teradyne-ProtoBOMEcnValidations, Teradyne-ProtoBOMECNSetRevStamp, Teradyne-DeviationAcknowledgeTask
#																		and Teradyne_IsObjectOwnerSameAsTheProcessInitator
#  23-Mar-2015						 Kameshwaran D						Added constants for Disconitnous Doc attribute and VMReperesnt relation , PCN revision workflow.
#  24-Mar-2015						 Haripriya  						Added Constants for Teradyne-EffectivityAssignment
#  26-Mar-2015						 Haripriya  						Added Constants for Teradyne-AssignDynamicparticipant
#  30-Mar-2015                       Vijayasekhar                    	Added constanst related to Teradyne-SetDate
#  30-Mar-2015						 Haripriya						    Added TD_SPACE_CONSTANT Constants.
#  01-Apr-2015                       Haripriya                    	    Added TD_MAP_MODL_CRE_FORM_TYPE Constants.
#  10-Apr-2015					 	 Kameshwaran D						Added Constant for perferred Status attribute
#  15-Apr-2015						 Haripriya						    Added Constants for Generating ECN Report
#  16-Apr-2015						 Vijayasekhar						Added constants related to Teradyne-GenDeviationReport handler
#  17-Apr-2015						 Selvi						        Added Constans for Related to ECN Summary report function.
#  17-Apr-2015						 Haripriya						    Added Constans for TeradyneRevisionScheme.
#  17-Apr-2015						 Kameshwaran D						Added Constants for TD_ENGG_CONTROL_FLAG_ATTR
#  20-Apr-2015						 Haripriya						    Added Constans for TD_PRODUCT_SUPPORT_ENGG_ATTR.
#  21-Apr-2015                       Selvi                              Added Constans for TD_ECN_REPORT_TEMP_DIR_PREFTD_ECN_REPORT_FILE_LOC
#  22-Apr-2015                       Selvi                              Removed Constans for TD_ECN_REPORT_FILE_LOC
#  22-Apr-2015                       Vijayasekhar                    	Added constants for the deviation report error and changed the existing constants
#  22-Apr-2015						 Kameshwaran D						Added constant for TD_SUGGEST_REV_ID_ERROR
#  23-Apr-2015						 Haripriya						    Added Constans for TD_REQ_TECH_REVIEWERS_LIST_ATTR,TD_REQ_CB_REVIEWERS_LIST_ATTR.
#  24-Apr-2015						 Selvi						        Added constants related to Teradyne-CreateExcemptionForm handler
#  24-Apr-2015						 Haripriya						    Added Constans for TD_PLANNER_ATTR,TD_DESIGN_DOC_COORDINATOR_ATTR.
#  27-Apr-2015						 Selvi						        Added constants for SubstanceCompilanceResult
#  28-Apr-2015                       Vijayasekhar                    	Added constants related to StandardECNValidation handler
#  29-Apr-2015                       Vijayasekhar                    	Added constants TD_DEVIATION_NOTICE_REV_TYPE and TD_DISCON_DOC_REV_TYPE
#  30-Apr-2015						 Haripriya						    Added Constans for Teradyne-CreateCmplChkForm,Teradyne-UpdateCmplAttrs handlers.
#  04-May-2015                       Vijayasekhar                    	Added constants TD_DEVIATION_NOTICE_REV_TYPE and TD_DISCON_DOC_REV_TYPE
#  05-May-2015                       Vijayasekhar                    	Added constants TD_PRODUCTION_STATUS_ERROR, TD_ITEM_STATUS_ERROR_PROTOBOM and Removed the relation constant TD_PCBA_DESIGN_DOC_REL_NAME
#																		Added relation constant TD_PART_TOBE_DISCON_REL
#  05-May-2015						 Haripriya						    Added constants for teradyne_change_all_started_to_suspend_resume handlers.
#  05-May-2015						 Haripriya						    Added constants for TD_DESIGN_DOC_COORDINATOR_RELEASE_ATTR
#  06-May-2015						 Haripriya						    Removed unused Error constants 
#  07-May-2015                       Vijayasekhar						Added constants related to updatesupplier handler
#  07-May-2015                       Haripriya                    	    Added TASK_SUSPENDED_STATE,TD_CHANGE_ADMIN_ATTR Constants 
#  07-May-2015						 Selvi							    Added more constants for ECN Process History
#  12-May-2015					     Vijayasekhar                       Added constant TD_REV_TAG_ATTR
#  21-May-2015					     Haripriya                          Added error constants for Release ECN Validation
#  27-May-2015						 Selvi							    Added constants for DIVPart Itemid Generation.
#  04-Jun-2015					     Vijayasekhar                       Added constants related to the handler Teradyne-CreateCmplChkForm and Post action TD4_postaction_on_create_Scp0PartToSubsCmplResultRel
#  10-Jun-2015                       Haripriya                    	    Modified TD_PREFERRED_STATUS_ATTR Constants
#  16-Jun-2015                       Haripriya                    	    Added TD_FND_NEXT_ID_ATTR Constants  
#  23-Jun-2015					     Vijayasekhar                       Added constant for the path C:\Temp and removed constants related to that
#  23-Jun-2015                       Haripriya                    	    Added TD_PROTOBOM_ECN_PLANNER_ERROR Constants 
#  07-Jul-2015                       Vijayasekhar                  	    Added TD_COMM_PARTS_ATTR Constants 
#  05-Aug-2015                       Haripriya                    	    Added Error Constants for Teradyne-SolutionItems-ORG-Check rule handler
#  12-Aug-2015                       Haripriya                    	    Added Constants for Name counter
#  14-Aug-2015                       Haripriya                    	    Added Error Constants for Teradyne-Check-SolutionItems rule handler
#  25-Aug-2015                       Haripriya                    	    Added TD_ITAR_FORM_TYPE Constants.
#  30-Sep-2015                       Manimaran                          Added TD_NOT_LATEST_REV_ERROR constant.
#  07-oct-2015                       Deepachitra                        Added TD_CHECK_IN_MSG_LEN_ERROR Error Message
#  08-Oct-2015                       Manimaran                          Modified TD_BL_REMARKS
#  14-Oct-2015                       Manimaran                          Removed TD_CHECK_IN_MSG_LEN_ERROR
#  28-Oct-2015                       Manimaran                          Added TD_CHECK_SOLUTIONITEM_WORKING_ECN_ERROR constant.
#  12-Nov-2015                       Manimaran                          Added TD_OR_CONSTANT, TD_ICM0_SM05_ATTR, TD_ICM0_SM01_ATTR, TD_SUPPLIER_RATINGS_ATTR, TD_IMAN_CLASSIFICATION_REL_NAME constants.
#  19-Nov-2015                       Manimaran                          Added TD_SYNOPSIS_ATTR constant.
#  24-Nov-2015                       Manimaran                          Added TD_EFF_DATE_TIME_ERROR constant.
#  11-Dec-2015                       Manimaran                          Added constants related to BOM Import functionality.
#  17-Dec-2015						 janani							    Added constants regarding CSV file validation handler.
#  22-Dec-2015                       Manimaran                          Added TD_IMPCT_ITEM_NOT_REVISED_ERROR and TD_SLASH_CONSTANT constants.
#  23-Dec-2015                       Manimaran                          Added TD_REVISE_ADDRESS_LIST_PREF, TD_NO_ITEMS_UNDER_IMPACTED_ITEMS_FOLDER_ERROR constants and modified TD_DIVPART_REV_MISMATCH_MAIL_BODY constant.
#  27-Dec-2015                       Manimaran                          Added TASK_COMPLETE_STATE constant.
#  29-Dec-2015						 Kameshwaran 						Recorrected TD_TEMP_PATH value
#  25-Mar-2016                       Haripriya                          Added TD_BOM_INVALID_CHILD_TYPE_ERROR error constant.
#  04-May-2016                       Haripriya                          Added TD_IMPCT_SOL_SAME_ITEM_ERROR error constant.
#  01-Aug-2016						 Kameshwaran						Added TD_ECN_TILE_NOTICE_STATUS Notice summary report constant.
#  04-Aug-2016						 Kameshwaran						Added TD_NON_ACTIVE_SEQ_ATTACH_ERROR non-active seq attach under Project relation.
#  17-Aug-2016						 Haripriya							Added TD_ECN_MAT_IMPACT_STD,TD_ECN_MAT_IMPACT_PROTOBOM property constants and TD_MATL_IMP_UPDATE_FORM_TYPE type constants.
#  31-Jan-2017						 Karl Reimann						Added TD_PART_TYPE_ATTR, TD_PCB_PCBA_ADDRESS_LIST_PREF
#  07-May-2018						 Marjorie							Added TD_OPS_TASK_FORM_TYPE, TD_OPSTASK_WF_PREF
#  07-May-2018						 Marjorie							Added TD_OPS_TASK_INCORRECT_ROLE_OR_GROUP_ERROR, TD_OPSTASK
#  30-May-2018						 Marjorie							Added TD_DESIGN_DOCUMENT_REV_MASTER_ATTR, TD_REVISION_ATTR
#  05-Jun-2018						 Marjorie							Added TD_NO_DESDOC_DESCRIPTION_ERROR
#  22-Jun-2018						 Marjorie							Added TD_DES_DOC_TYPE1_ATTR, TD_DES_DOC_TYPE2_ATTR, TD_DES_DOC_TYPE3_ATTR
#  21-Jun-2021						 Anudeep Nadig C N					Added TD_PCBA
#  05-July-2021						 Anudeep Nadig C N					Added TD_PCB
#  05-July-2021                      Vikash B                           Added TD_ITEM_INACTIVE_STATUS, TD_INACTIVE_PRO
#  22-Oct-2021                       Vikash B                           Added TD_ATTACH_DESIGN_DOC_REV_ERROR
#  $HISTORY$                    
#  =================================================================================================*/  

#ifndef TERADYNE_CONSTANTS_H
#define TERADYNE_CONSTANTS_H

//Constants for Error base
#define TERADYNE_ERROR_BASE													(EMH_USER_error_base+100)
#define TERADYNE_UNKNOWN_ERROR												(TERADYNE_ERROR_BASE + 1)
#define TERADYNE_PROJECT_FORM_WITH_NAME_EXISTS_ERROR						(TERADYNE_ERROR_BASE + 2)
#define TD_REV_ID_ERROR														(TERADYNE_ERROR_BASE + 3)
#define TD_REASON_ATTR_NOT_FILLED_ERROR										(TERADYNE_ERROR_BASE + 4)
#define TD_PARTCATEGORY_NOT_LISTED_ERROR									(TERADYNE_ERROR_BASE + 5)
#define TD_STD_DESC_UNKOWN_ERROR											(TERADYNE_ERROR_BASE + 6)
#define TERADYNE_DIVPARTMAP_FORM_WITH_NAME_EXISTS_ERROR						(TERADYNE_ERROR_BASE + 7)
#define TD_VMREPRESENTS_CREATE_REL_ERROR								    (TERADYNE_ERROR_BASE + 8)
#define TD_VMREPRESENTS_DELETE_REL_ERROR								    (TERADYNE_ERROR_BASE + 9)
#define TD_VENDOR_PART_CREATE_REL_ERROR										(TERADYNE_ERROR_BASE + 10)
#define TD_VENDOR_PART_DELETE_REL_ERROR										(TERADYNE_ERROR_BASE + 11)
#define TD_PREF_VALUE_NULL_ERROR										    (TERADYNE_ERROR_BASE + 12)
#define TD_CHECK_IN_MSG_ERROR												(TERADYNE_ERROR_BASE + 13)
#define TD_COMMPARTREQ_TPN_ERROR											(TERADYNE_ERROR_BASE + 14)
#define TD_DIV_BASE_PART_ERROR												(TERADYNE_ERROR_BASE + 15)
#define TD_DIV_PART_REV_FORMAT_ERROR										(TERADYNE_ERROR_BASE + 16)
#define TD_DIV_PART_IMPACTED_ITEM_ERROR										(TERADYNE_ERROR_BASE + 17)
#define TD_DIV_PART_MAP_FORM_ERROR										    (TERADYNE_ERROR_BASE + 18)
#define TD_DIV_PART_ITEM_ID_ERROR										    (TERADYNE_ERROR_BASE + 19)
#define TD_DATASET_DESIGNDOC_ERROR											(TERADYNE_ERROR_BASE + 20)
#define TD_REVIEWER_MANDATORY_ERROR											(TERADYNE_ERROR_BASE + 21)
#define TD_PRODUCTION_STATUS_ERROR											(TERADYNE_ERROR_BASE + 22)
#define TD_NO_DATE_RANGE													(TERADYNE_ERROR_BASE + 23)
#define TD_NO_REV_ID_ERROR													(TERADYNE_ERROR_BASE + 24)
#define TD_ASSEMBLY_ERROR													(TERADYNE_ERROR_BASE + 25)
#define TD_ITEM_STATUS_ERROR												(TERADYNE_ERROR_BASE + 26)
#define TD_CURRUSER_OWNUSER_ERROR											(TERADYNE_ERROR_BASE + 27)
#define TD_BOM_CHILDREN_ERROR												(TERADYNE_ERROR_BASE + 28)
#define TD_DEVIATION_REPORT_ERROR										    (TERADYNE_ERROR_BASE + 29)
#define TD_SUGGEST_REV_ID_ERROR												(TERADYNE_ERROR_BASE + 30)
#define TD_BOM_PRODUCTION_ERROR												(TERADYNE_ERROR_BASE + 31)
#define TD_EFF_DATE_ERROR													(TERADYNE_ERROR_BASE + 32)
#define TD_ITEM_STATUS_ERROR_PROTOBOM										(TERADYNE_ERROR_BASE + 33)
#define TD_DESIGNDOC_ERROR											        (TERADYNE_ERROR_BASE + 34)
#define TD_DESIGNDOC_REL_ERROR											    (TERADYNE_ERROR_BASE + 35)
#define TD_DIV_PART_ASSIGN_ITEM_ID_ERROR								    (TERADYNE_ERROR_BASE + 36)
#define TD_PROTOBOM_ECN_PLANNER_ERROR								        (TERADYNE_ERROR_BASE + 37)
#define TD_MISSING_ORG_FORM_ERROR											(TERADYNE_ERROR_BASE + 38)
#define TD_MISSING_ORG_NAME_ERROR											(TERADYNE_ERROR_BASE + 39)
#define TD_CHECK_SOLUTIONITEM_ERROR											(TERADYNE_ERROR_BASE + 40)
#define TD_NOT_LATEST_REV_ERROR											    (TERADYNE_ERROR_BASE + 41)
#define TD_CHECK_SOLUTIONITEM_WORKING_ECN_ERROR								(TERADYNE_ERROR_BASE + 42)
#define TD_EFF_DATE_TIME_ERROR								                (TERADYNE_ERROR_BASE + 43)
#define TD_CSVLOG_ERROR         								            (TERADYNE_ERROR_BASE + 44)
#define TD_IMPCT_ITEM_NOT_REVISED_ERROR                                     (TERADYNE_ERROR_BASE + 45)
#define TD_NO_ITEMS_UNDER_IMPACTED_ITEMS_FOLDER_ERROR                       (TERADYNE_ERROR_BASE + 46)
#define TD_BOM_IMPORT_ERROR         								        (TERADYNE_ERROR_BASE + 47)
#define TD_BOM_INVALID_CHILD_TYPE_ERROR         							(TERADYNE_ERROR_BASE + 48)
#define TD_IMPCT_SOL_SAME_ITEM_ERROR         								(TERADYNE_ERROR_BASE + 49)
#define	TD_NON_ACTIVE_SEQ_ATTACH_ERROR										(TERADYNE_ERROR_BASE + 50)
#define	TD_MISSING_DISC_SPEC_FORM_ERROR										(TERADYNE_ERROR_BASE + 51)
#define	TD_ITEM_EXIST_IN_WORKFLOW_ERROR										(TERADYNE_ERROR_BASE + 52)
#define	TD_DIV_PART_REV_NOT_IN_SCHEMA_ERROR									(TERADYNE_ERROR_BASE + 53)
#define	TD_OPS_TASK_INCORRECT_ROLE_OR_GROUP_ERROR							(TERADYNE_ERROR_BASE + 54)
#define	TD_OPS_TASK_MULTIPLE_REVIEWER_ERROR									(TERADYNE_ERROR_BASE + 55)
#define TD_NO_MARKETING_RESOURCE_ERROR										(TERADYNE_ERROR_BASE + 56)
#define TD_NO_DESDOC_DESCRIPTION_ERROR										(TERADYNE_ERROR_BASE + 57)
#define TD_EFF_DATE_EQ_TIME_ERROR											(TERADYNE_ERROR_BASE + 58)
#define TD_NO_MANUFACTURER_ERROR											(TERADYNE_ERROR_BASE + 59)
#define TD_NO_MANUFACTURER_PART_ERROR										(TERADYNE_ERROR_BASE + 60)
#define TD_NO_COMMODITY_LEVEL_CODES_ERROR									(TERADYNE_ERROR_BASE + 61)
#define TD_NO_DESCRIPTION_ERROR												(TERADYNE_ERROR_BASE + 62)
#define TD_NO_COMMENTS_ERROR												(TERADYNE_ERROR_BASE + 63)
#define TD_PART_NOT_CLASSIFIED_ERROR										(TERADYNE_ERROR_BASE + 64)
#define TD_NOT_NXT_ON_NXT_ECN_ERROR											(TERADYNE_ERROR_BASE + 65)
#define TD_NXT_ON_NOT_NXT_ECN_ERROR											(TERADYNE_ERROR_BASE + 66)
#define TD_PROTO_PART_ERROR													(TERADYNE_ERROR_BASE + 67)
#define TD_DUPLICATE_ORGS_ERROR												(TERADYNE_ERROR_BASE + 68)
#define TD_NO_SOLUTION_ITEMS_ERROR											(TERADYNE_ERROR_BASE + 69)
#define TD_DATASET_MISSING_FOR_DESIGN_DOC                                   (TERADYNE_ERROR_BASE + 70)
#define TD_SUPP_ADD_REQ_MISSING_COMMODITY_GROUP_MANAGER                     (TERADYNE_ERROR_BASE + 71)
#define TD_SUPP_ADD_REQ_MISSING_COMMODITY_ENGINEER                          (TERADYNE_ERROR_BASE + 72)
#define TD_SUPP_ADD_REQ_MISSING_COMMODITY_MANAGER                           (TERADYNE_ERROR_BASE + 73)
#define TD_SUPP_ADD_REQ_MISSING_LEVEL_OF_ASSESSMENT                         (TERADYNE_ERROR_BASE + 74)
#define TD_INVALID_CHAR								                        (TERADYNE_ERROR_BASE + 75)
#define TD_VALIDATE_TEXT_SPACES								                (TERADYNE_ERROR_BASE + 76)
#define TD_CANCEL_REASON_REQUIRED							                (TERADYNE_ERROR_BASE + 77)
#define TD_SOLUTION_ITEM_MISSING_DIV_PART							        (TERADYNE_ERROR_BASE + 78)
#define TD_VALIDATE_ECNS_WITH_DESDOC										(TERADYNE_ERROR_BASE + 79)
#define TD_ATTACH_DESIGN_DOC_REV_ERROR                                      (TERADYNE_ERROR_BASE + 92)
#define TERADYNE_BOMIMPORT_ERROR_BASE										(EMH_USER_error_base + 200)
#define TD_ITEM_NOT_FOUND_ERROR                                             (TERADYNE_BOMIMPORT_ERROR_BASE)
#define TD_ITEM_NOT_DIV_PART_ERROR                                          (TERADYNE_BOMIMPORT_ERROR_BASE + 1)
#define TD_DIV_PART_LATEST_REV_RELEASED_ERROR                               (TERADYNE_BOMIMPORT_ERROR_BASE + 2)
#define TD_DIV_PART_LATEST_REV_NO_WRITE_ACCESS_ERROR                        (TERADYNE_BOMIMPORT_ERROR_BASE + 3)
#define TD_DIVPART_LATESTREV_CHECKEDOUT_ERROR                               (TERADYNE_BOMIMPORT_ERROR_BASE + 4)
#define TD_DIVPART_LATESTREV_IN_BOMIMPORT_WF_ERROR                          (TERADYNE_BOMIMPORT_ERROR_BASE + 5)
#define TD_CONSUMER_ROLE_ERROR												(TERADYNE_ERROR_BASE + 80)
#define TD_PRODUCTION_ON_RELEASE_ECN_ERROR									(TERADYNE_ERROR_BASE + 81)
#define TD_PRE_PRODUCTION_ON_PRE_PROD_RELEASE_ECN_ERROR						(TERADYNE_ERROR_BASE + 82)
#define UR_LIFECYCLE_ATTRB_ERROR											(TERADYNE_ERROR_BASE + 128)
#define TD_COMM_PART_PARTCATEGORY_ERROR										(TERADYNE_ERROR_BASE + 140)
#define TD_SEND_TO_CE_NOT_VALID_ERROR                                       (EMH_USER_error_base + 241)
#define TD_CE_RESPONSIBLE_NOT_VALID_ERROR                                   (EMH_USER_error_base + 242)
#define TD_SEND_TO_ENG_NOT_VALID_ERROR                                      (EMH_USER_error_base + 243)
#define TD_ENG_NOT_VALID_ERROR											    (EMH_USER_error_base + 244)
#define TD_UNABLE_TO_COMPLETE_COMMPARTREQ_ERROR								(TERADYNE_ERROR_BASE + 81)
#define TD_DATE_INVALID_ERROR											    (EMH_USER_error_base + 248)
#define TD_DATE_DIFF_INVALID_ERROR											(EMH_USER_error_base + 253)
#define TD_REPAIR_LOCATION_INVALID_ERROR									(EMH_USER_error_base + 254)
#define TD_COMM_PART_PARTCATEGORY_ERROR										(TERADYNE_ERROR_BASE + 140)
#define TD_COMM_PART_REQ_URVENDOR_TDMANUFACTURER_ERROR						(TERADYNE_ERROR_BASE + 151)
#define TD_NOT_VALID_NXT_ORG											    (EMH_USER_error_base + 300)
#define	TD_INACTIVE_DIV_PART_ATTACH_ERROR									(TERADYNE_ERROR_BASE + 90)
// Contants
#define TD_DIV_PART_ITEM_ID_SUFFIX											"-00"
#define TD_HYPHEN_CONSTANT													'-'
#define TD_SEMICOLON_CONSTANT												";"
#define TD_DOT_CONSTANT														'.'
#define TD_COMMA_CONSTANT												    ","
#define TD_SPACE_CONSTANT												    " "
#define TD_SLASH_CONSTANT												    "/"
#define TD_NOT_LISTED_CONSTANT												"Not Listed"
#define TD_PUID_CONSTANT													"puid"
#define TD_DEFAULT_PROCESS_DESCRIPTION										"This is an automated message for initiating workflow process"
#define TD_RIGHT_SHIFT_ARROW_CONSTANT										"->"
#define TD_ADMIN_ROLE_CONSTANT                                              "Business ADMIN.CM ADMIN.Admin"
#define TD_DATE_YMD_CONSTANT												"%Y-%m-%d %H:%M:%S"
#define TD_DATE_MDY_CONSTANT												"%m/%d/%Y %H:%M:%S" 
#define TD_DATE_DMY_CONSTANT												"%d-%b-%Y"
#define TD_EFF_DATE_CONSTANT												"%d-%m-%Y"
#define TD_DIVPART_PARTCATEGORY_MAIL_SUBJECT								"A Divisional Part Could not be Created "
#define TD_DIVPART_REV_MISMATCH_MAIL_SUBJECT								"Teradyne Revision Mismatch"
#define TD_DIVPART_REV_NOT_IN_REV_RULE_SUBJECT								"Teradyne Revision not in Scheme"
#define TD_REASSIGN_NOTIFICATION_SUBJECT                                    "A task has been assigned to you"
#define TD_DIVPART_REV_MISMATCH_MAIL_BODY                                   "Unable to revise. Assigned Revision is not as per the Teradyne Scheme :"
#define TD_DIVPART_REV_NOT_IN_REV_RULE_BODY                                 "Unable to revise. This revision is not in the Teradyne Scheme, contact Change Admin :"
#define TD_ITEM_QUERY												        "Latest Item Revision..."
#define TD_GENERAL_QUERY												    "General..."
#define TD_TASKS_PERFORM_FOLDER											    "TasksToPerform"
#define TD_TASK_INBOX													    "TaskInbox"
#define TD_POM_EPM_TASKINBOX_QRY										    "QryEPMTaskinTaskInbox"
#define TD_TYPE_INPUT														"Type"
#define TD_ITEMID_INPUT														"Item ID"
#define TD_NAME_INPUT                                                       "Name"
#define TD_STATUS_INPUT														"Release Status"
#define TD_REL_STATUS_NAME													"TD4Released"
#define TD_DBA_ROLE_CONSTANT                                                "dba.DBA"
#define TD_WF_AUDIT_SIGNOFF												    "TER_ECN_AuditReport_Query"
#define TD_QRY_JOB_NAME														"Job Name"
#define TD_PROCESS_TEMPLATE_NAME											"Process Template Name"
#define TD_TEMP_PATH														"C:\\temp\\"
#define TD_OR_CONSTANT                                                      "|"
#define TD_EPMTASK_TYPE                                                     "EPMTask"
#define TD_EPMCONDITION_TYPE                                                "EPMConditionTask"
#define TD_EPMDOTASK_TYPE                                                   "EPMDoTask"
#define TD_BOM_IMPORT_LOG_FILE_NAME_FORMAT_PREF                             "Teradyne_BOMImport_LogFile_Prefix"
#define TD_BOM_IMPORT_REDO_FILE_NAME_FORMAT_PREF                            "Teradyne_BOMImport_RedoFile_Name_Format"
#define TD_PART_MOD_REQ_COMM_ENG_JOB										"Commodity Support Engineer Review"
#define TD_PART_MODIFY_REQUEST_OBJECT_NAME                                  "Part Modify Request"
#define TD_DESIGN_DOCUMENT_QUERY                                            "TER_DESIGN_DOCUMENT"
#define TD_FORM_NAME_QUERY                                                  "TER_FORM_NAME" 
#define TD_OBSOLETE															"Obsolete"
#define TD_REMOVED															"Removed"
#define TD_MULTI_USA														"Multi USA"
#define TD_MULTI_NON_USA													"Multi non-USA"
#define	TD_USA																"United States of America"
#define TD_VIRGIN_ISLANDS													"Virgin Islands (US)"
#define TD_GUAM																"Guam"
#define TD_NORTHERN_MARIANA_ISLANDS											"Northern Mariana Islands"
#define TD_AMERICAN_SAMOA													"American Samoa"
#define TD_PUERTO_RICO														"Puerto Rico"
#define	TD_US_MINOR_OUTLYING_ISLANDS										"United States Minor Outlying Islands"

#ifdef WNT
    #define PATH_SEPERATOR   "\\"
#else
    #define PATH_SEPERATOR   "/"
#endif


//Constants for attributes
#define TD_ITEM_REVISION_ID                                                 "item_revision_id"
#define TD_HTS_ATTR															"td4HTS"
#define TD_ECCN_ATTR														"td4ECCN"
#define TD_ITAR_PART                                                        "td4ItarPart"
#define TD_HTS_DEF_ATTR														"td4HTSDefault"
#define TD_ECCN_DEF_ATTR													"td4ECCNDefault"
#define TD_PREFIX_ATTR														"td4Prefix"
#define TD_SUFFIX_ATTR														"td4Suffix"
#define TD_PART_TYPE_ATTR													"td4PartType"
#define TD_FREE_FORM_DESC_ATTR												"td4FreeFormDescription"
#define TD_STANDARD_DESC_ATTR												"td4StandardDescription"
#define TD_PART_CATEGORY_ATTR												"td4PartCategory"
#define TD_ITEM_ID_ATTR														"item_id"
#define TD_ITEM_REV_ID_ATTR													"item_revision_id"
#define TD_PART_SUBCATEGORY_ATTR											"td4PartSubCategory"
#define TD_DOCUMENT_TYPE_ATTR												"td4DocumentType"
#define TD_DATAFILE_PROP													"data_file"
#define TD_OBJECT_NAME_ATTR													"object_name"
#define TD_SEQUENCE_ID_ATTR												    "sequence_id"
#define TD_OBJECT_TYPE_ATTR													"object_type"
#define TD_ACTIVE_SEQUENCE_ATTR												"active_seq"
#define TD_VD_CHNG_RESN_ATTR												"td4VendorChangeReason"
#define TD_CHG_HSTRY_ATTR													"td4ChangeHistory"
#define TD_FORMAT_CHANGE_REASON_HISTORY                                     "td4FormatChangeHistory"
#define TD_CHNG_RESN_ATTR													"td4ChangeReason"
#define TD_VD_CHNG_RESN_ATTR												"td4VendorChangeReason"
#define TD_CAD_MDL_NEED_ATTR							                    "td4CADModelNeeded"
#define TD_CAE_MDL_NEED_ATTR							                    "td4CAEModelNeeded"
#define TD_MAP_NEED_ATTR												    "td4MAPNeeded"
#define TD_PAD_STK_NEED_ATTR											    "td4PadstackNeeded"
#define TD_SMLN_MDL_NEED_ATTR											    "td4SimulationModelNeeded"
#define TD_CONTRL_BUSS_UNIT													"td4ControllingBussUnit"
#define TD_CONTRL_BUS_UNIT													"td4ControllingBusUnit"
#define TD_CONTRL_BUSS_UNIT_CRE												"td4ControllingBussUnitCre"
#define TD_DESCR_ATTR													    "td4Description"
#define TD_TPN_REQ_FORM_ATTR											    "td4TPNForReqForm"
#define TD_MANUFACTURE_1_ATTR											    "td4Manufacturer1"
#define TD_MANUFACTURE_2_ATTR											    "td4Manufacturer2"
#define TD_MANUFACTURE_3_ATTR											    "td4Manufacturer3"
#define TD_MANUFACTURE_PAER_1_ATTR										    "td4MfrPartNumber1"
#define TD_MANUFACTURE_PAER_2_ATTR										    "td4MfrPartNumber2"
#define TD_MANUFACTURE_PAER_3_ATTR										    "td4MfrPartNumber3"
#define TD_PROJECT_NAME_ATTR											    "td4ProjectName"
#define TD_ASSIGN_CMD_SUP_ENGG_ATTR											"td4AssignCommdSuprtEnggn"
#define TD_COMMODITY_LEVEL_1												"td4CommodityLevel1"
#define TD_COMMODITY_LEVEL_2												"td4CommodityLevel2"
#define TD_COMMODITY_LEVEL_3												"td4CommodityLevel3"
#define TD_PRIMARY_PROJECT													"td4PrimaryProject"
#define TD_OTHER_IMPACTED_PRJ												"td4ImpactedProjects"
#define TD_REVIEWER_INSTRC_URL												"td4ReviewersInstructionUrl"
#define TD_IPC_FILE_COUNT													"td4IPCFileCount"
#define TD_CAD_MODEL_NAME_CRE_ATTR											"td4CADModelNameCre"
#define TD_CAE_MODEL_NAME_CRE_ATTR											"td4CAEModelNameCre"
#define TD_PAD_MODEL_NAME_CRE_ATTR											"td4PadstackNameCre"
#define TD_SIMULATION_MODEL_NAME_CRE_ATTR									"td4SimulationModelNameCre"
#define TD_MAP_MODEL_NAME_CRE_ATTR											"td4MAPModlNameCre"
#define TD_MAP_MODL_CRE_FORM_TYPE										    "TD4MAPModlCreForm"
#define TD_CAD_MODEL_NAME_ATTR												"td4CADModelName"
#define TD_CAE_MODEL_NAME_ATTR												"td4CAEModelName"
#define TD_PAD_MODEL_NAME_ATTR												"td4PadstackName"
#define TD_SIMULATION_MODEL_NAME_ATTR										"td4SimulationModelName"
#define TD_MAP_MODEL_NAME_ATTR												"td4MAPModlName"
#define TD_BL_ITEM_ID_ATTR													"bl_item_item_id"
#define TD_BL_ITEM_REV_ID_ATTR												"bl_rev_item_revision_id"
#define TD_ECN_TYPE_ATTR													"td4ECNType"
#define TD_ITEM_STATUS_ATTR													"td4ItemStatus"
#define TD_PCN_CLASS_ATTR													"td4PCNClass"
#define TD_REASON_ATTR													    "td4Reason"
#define TD_PUP_NO_ATTR													    "td4PupNumber"
#define TD_PRIMARY_PROJ_ATTR												"td4PrimaryProject"
#define TD_EST_SCRAP_COST_ATTR												"td4EstScrapCost"
#define TD_GCS_FIELD_RETURNS_ATTR											"td4GCSFieldReturns"
#define TD_REQ_GCS_REWORK_ATTR												"td4ReqGCSRework"
#define TD_IMPACTED_PROJS_ATTR												"td4ImpactedProjects"
#define TD_MARKETING_ATTR													"td4Marketing"
#define TD_FINANCE_ATTR													    "td4Finance"
#define TD_ERT_ATTR												            "td4ERT"
#define TD_GCS_PLANNER_ATTR												    "td4GCSPlanner"
#define TD_GCS_REPAIR_TECH_ATTR											    "td4GCSRepairTechnician"
#define TD_REQ_TECH_REVIEWERS_ATTR											"td4ReqdTechReviewersList"
#define TD_REQ_TECHNICAL_REVIEWERS_ATTR										"td4ReqTechnicalReviewer"
#define TD_OBSERVERS_LIST_ATTR												"td4ObserversList"
#define TD_REQ_CB_REVIEWERS_ATTR											"td4ReqdCBReviewersList"
#define TD_REV_STAMP_ATTR													"td4RevStamp" 
#define TD_UPD_MIN_SHIP_REV_ATTR											"td4UpdMinShipRev"  
#define TD_DESIGN_DOC_WORK_REQ_ATTR										    "td4DesignDocWorkReq"
#define TD_DESIGN_DOC_COORDINATOR_ATTR										"td4DesgnDocCoordinator"
#define TD_PLANNER_ATTR												        "td4Planners"
#define TD_OBSERVER_ATTR												    "td4Observer"
#define TD_PROTO_TYPE_ATTR													"Prototype"   
#define TD_ADD_ACK_USERS_ATTR												"td4AddAckUsers"   
#define TD_ENG_SENT_TO_ATTR													"td4EngineerSentTo"   
#define TD_PREFERRED_STATUS_ATTR											"preferred_status"
#define TD_INTERNAL_PART_STATUS_ATTR										"td4InternalPartStatus"
#define TD_PRIMARY_PROJ_PLANNER_ATTR										"td4PrimaryProjectPlanner"
#define TD_SPECIALIZED_REVIEWERS_ATTR										"td4SpecializedReviewers"
#define TD_ECN_NULL_ATTR													"NULL"
#define TD_ENGG_CONTROL_FLAG_ATTR											"td4CommdEnggnFlag"
#define TD_PRODUCT_SUPPORT_ENGG_ATTR										"td4ProductSupportGroupCB"
#define TD_REQ_TECH_REVIEWERS_LIST_ATTR									    "td4ReqdTechReviewerUserList"
#define TD_REQ_CB_REVIEWERS_LIST_ATTR									    "td4ReqdCBReviewersUserList"
#define TD_MAX_PROCESS_ATTR										            "td4MaximumProcessTemp"
#define TD_DURATION_MAX_ATTR										        "td4DurationAtMaxProcessTemp"
#define TD_MOISTURE_SENSITIVITY_ATTR										"td4MoistureSensitivity"
#define TD_ATTACHMENT_FINISH_ATTR										    "td4AttachmentFinish"
#define TD_PART_DETAILS_ATTR										        "scp0part_details"
#define TD_REGULATION_NAME_ATTR										        "scp0regulation_name"
#define TASK_START_STATE										            "Started"
#define TASK_RESUME_STATE										            "resume"
#define TASK_SUSPEND_STATE										            "suspend"
#define TD_DESIGN_DOC_COORDINATOR_RELEASE_ATTR                              "td4DesignDocCoordinator"
#define TD_COMM_LVL1_EFFECT_ATTR											"td4CommdLvl1Effect"
#define TD_NEW_SUPPLIER_ATTR												"td4NewSupplier"
#define TD_OLD_SUPPLIER_ATTR												"td4OldSupplier"
#define TASK_SUSPENDED_STATE										        "Suspended"
#define TD_CHANGE_ADMIN_ATTR                                                "td4ChangeAdmin"
#define TD_REV_TAG_ATTR														"bl_revision"
#define TD_SENT_TO_COMPL_ATTR												"td4SentToCmpl"
#define TD_SCP_STATUS_DISPLY_ATTR											"scp0status_display_name"
#define TD_ROHS_COMMPLT_STATUS_ATTR											"td4ROHSCompliantStatus"
#define TD_LICENSE_LEVEL                                                     "license_level"
#define TD_GENERAL_TASK_TYPE                                                 "td4TaskType"
//#define TD_FND_NEXT_ID_ATTR											        "fnd0_next_id"
#define TD_SAFETY_LICENSE_ATTR											    "td4SafetyLicense"
#define TD_ROHS_COMPLIANT_STATUS_ATTR										"td4ROHSCompliantStatus"
#define TD_PRODUCT_SAFETY_ATTR											    "td4ProductSafety"
#define TD_WF_PERFORM_FOLDER											    "Tasks To Perform"
#define TD_SEARCH_NAME													    "Name"
#define TD_ORG_FORM_ATTR													"td4OrgName"
#define TD_ICM0_SM05_ATTR                                                   "sm05"
#define TD_ICM0_SM01_ATTR                                                   "sm01"
#define TD_SUPPLIER_RATINGS_ATTR                                            "td4SupplierRatings"
#define TD_SYNOPSIS_ATTR                                                    "td4Synopsis"
#define TD_ITEMID_ATTR                                                      "td4ItemID"
#define TD_REVID_ATTR                                                       "td4RevID"
#define TD_UPDATEBOM_ATTR                                                   "td4UpdateBOM"
#define TD_PROCESS_STAGE_LIST_ATTR                                          "process_stage_list"
#define TD_ORG_FILE_NAME_ATTR                                               "original_file_name"
#define TD_FILE_EXT_ATTR                                                    "file_ext"
#define TD_REFO_FILE_ATTR													"td4RedoFile"
#define TASK_COMPLETE_STATE										            "Completed"
#define TD_ECN_MAT_IMPACT_STD 												"td4MaterialImpact"
#define TD_ECN_MAT_IMPACT_PROTOBOM 											"td4MatlImpact"
#define TD_OWNER															"owning_user"
#define TD_FND_ALL_WORKFLOWS                                                "fnd0AllWorkflows"
#define TD_FND_STARTED_WORKFLOWS                                            "fnd0StartedWorkflowTasks"   
#define TD_DES_DOC_TYPE1_ATTR	                                            "td4DesDocType1"       
#define TD_DES_DOC_TYPE2_ATTR	                                            "td4DesDocType2"         
#define TD_DES_DOC_TYPE3_ATTR	                                            "td4DesDocType3"  
#define TD_IS_CONCEPT_PART                                                  "td4IsConceptPart"
#define TD_PRODUCTION_TYPE_ATTR                                             "Production"
#define TD_PRE_PRODUCTION_TYPE_ATTR                                         "Pre-Production"
#define TD_REJECTION_COMMENTS                                               "td4RejectionComments"
#define TD_VENDOR_REFERENCE_ATTR											"vm0vendor_ref"        
#define TD_CREATION_DATE													"creation_date"
#define TD_MODIFIED_DATE													"last_mod_date"
#define TD_UNIT_OF_MEASURE_TAG												"uom_tag"
#define TD_AWC_SIGNOFF_TASKS                                                "td4AWCSignOffTsks"
#define TD_DESC_ATTR                                                        "td4Description"
#define TD_COMMODITY_PART_REQUESTS                                          "td4CommPartRequests"
#define TD_UPDATED_FROM_AWC                                                 "td4UpdatedFromAWC"    
#define TD_SALES_OPTION                                                     "td4SalesOption" 
#define TD_CHANGE_REASON_AUTHOR                                             "td4ChangeReasonAuthor"
#define TD_CHANGE_REASON_DATE                                               "td4ChangeReasonDate"
#define TD_CHANGE_REASON_COMMENT                                            "td4ChangeReasonComment" 
#define TD_CHANGE_REASON_SORT_KEY                                           "changeReasonSortKey"
#define	TD_COUNTRY_OF_ORIGIN												"td4_Country_of_Origin"
#define	TD_COUNTRY_OF_ORIGIN_CODE											"td4_Country_of_Origin_Code"
#define TD_MEU_ASSESSMENT_TAG												"td4MEU_Assessment_tag"
#define TD_VMREPRESENTS														"VMRepresents"
#define TD_PREFERRED_STATUS													"td4PreferredStatus"
#define TD_COUNTRY_OF_ORIGIN_LIST											"td4_Country_of_Origin_List"
#define TD_COO_CODE															"td4COO_Code"
#define TD_CE_REVIEW														"td4SendtoCEreview"
#define TD_ENG_REVIEW														"td4SendtoENGreview"
#define TD_CE_RESPONSIBLE													"td4ResponsibleCE"
#define TD_ROUTE_TO_HDD														"td4RouteToHDD"
#define TD_ROUTE_TO_NXT														"td4RouteToNXT"
#define TD_ROUTE_TO_STD														"td4RouteToSTD"
#define TD_ROUTE_TO_STG														"td4RouteToSTG"
#define TD_ROUTE_TO_UR														"td4RouteToUR"
#define TD_PCBA                                                             "Printed Circuit Board Assembly (PCBA)"
#define TD_PCB																"Bare PCB"
#define TD_UR_VENDOR_ATTR													"td4urvendor"
#define TD_REMOVED_DATE														"td4removeddate"

//Constants for Types
#define TD_DIV_PART_MAP_FORM_TYPE											"TD4DivPartMapForm"
#define TD_DIV_PART_MAP_FORM_STORAGE										"TD4DivPartMapFormStorage"
#define TD_TRADE_COMPL_FORM_TYPE										    "TD4TradeComplForm"
#define TD_ORACLE_ORG_FORM_TYPE												"TD4OracleORGForm"
#define TD_SAFETY_FORM_TYPE													"TD4SafetyForm"
#define TD_SBM_FORM_TYPE													"TD4SBMForm"
#define TD_DFM_FORM_TYPE													"TD4DFMForm"
#define TD_PROJECT_FORM_TYPE												"TD4ProjectForm"
#define TD_PROJECT_FORM_STORAGE												"TD4ProjectFormStorage"
#define TD_WORKSPACEOBJECT_TYPE												"WorkspaceObject"
#define TD_FORM_CLASS														"Form"
#define TD_NAME_COUNTER_CLASS												"NameCounter"
#define TD_RELIABILITY_FORM_TYPE					                        "TD4ReliabilityForm"
#define TD_CHANGEADMIN_FORM_TYPE											"TD4ChgAdminForm"
#define TD_CHANGEHISTORY_FORM_TYPE											"TD4ChangeHistoryForm"
#define TD_ADDITIONAL_REVIEWER_FORM_TYPE									"TD4AdditionalReviewersForm"
#define TD_COMM_PART_REQ_REV												"TD4CommPartReqRevision"
#define TD_COMM_PART_REV													"TD4CommPartRevision"
#define TD_COMM_PART													    "TD4CommPart"
#define TD_DESIGN_DOCUMENT_REV_MASTER_ATTR									"TD4DesignDocRevisionMaster"
#define TD_DIV_PART_REV														"TD4DivPartRevision"
#define TD_DIV_PART															"TD4DivPart"
#define TD_MFG_PART_REV                                                     "TD4MfgPartRevision"
#define TD_MFG_PART                                                         "TD4MfgPart"
#define TD_VENDOR															"Vendor"
#define TD_VENDOR_REV														"Vendor Revision"
#define TD_OPS_TASK_REV														"TD4OPSTaskRevision"
#define TD_GENERAL_TASK_REV                                                 "TD4GeneralTaskRevision"
#define TD_TAG_MDL_CRE_REQ_REV												"TD4TAGModlCreReqRevision"
#define TD_DTG_MDL_MOD_REQ_REV												"TD4DTGModlModReqRevision"
#define TD_TAG_MDL_MOD_REQ_REV												"TD4TAGModlModReqRevision"
#define TD_PART_MOD_REQ_REV												    "TD4PartModifyReqRevision"
#define TD_FLDR_TYPE														"Folder"
#define TD_COMMODITY_FORM_TYPE												"TD4CommLevel1Form"
#define TD_CMPL_REGULATION_TYPE												"Scp0Regulation"
#define TD_EXEMPTION_FORM_TYPE												"Scp0ApplyExemptForm"
#define TD_DEVIATION_NOTICE_REV_TYPE										"TD4DeviateNoticeRevision"
#define TD_DISCON_DOC_REV_TYPE												"TD4DisconDocRevision"
#define TD_SUPP_TRANSFER_REQ_REV_TYPE										"TD4SuppPartTransRevision"
#define TD_ITAR_FORM_TYPE										            "TD4ITARForm"
#define TD_TER_CSV                                                          "TD4TER_CSV"
#define TD_TEXT_DTYPE										                "Text"
#define TD_MATL_IMP_UPDATE_FORM_TYPE										"TD4MaterialImpactUpdateForm"
#define TD_PCN_REQ_REV_TYPE                                                 "TD4PCNRequestRevision"
#define TD_OPSTASK															"TD4OPSTask"
#define TD_PART_MODIFY_REQ_REV                                               "TD4PartModifyReqRevision"
#define TD_REQUESTORS_DIV													"td4RequestorsDivision"
#define TD_VIS_STRUCTURE_CONTEXT                                            "VisStructureContext"
#define TD_SUPPLIER_ADD_REQ_REV                                             "TD4SuppAddReqRevision" 
#define TD_MANUFACTURER_PART_MASTER                                         "ManufacturerPart Master"
//Constants for AM
#define TD_WRITE_PRIVILEGE                                                  "WRITE"

//Constants for ITAR
#define TD_ITAR_PRO_VALU                                                    "ITAR"

//Constants for Apply Exemption forms
#define TD_EXEMPTION_FORM_Name												"Apply Exemption - "
#define TD_REGULATION_VERSION												"scp0version"
#define TD_EXEMPTION_FORM_UID												"scp0regulation_uid"

//Constants for SUBSCMPL Result
#define TD_SUBCMPL_LATEST_RESULT											"scp0LatestResults"
#define TD_SUBCMPL_RESULT_TYPE												"Scp0SubstanceCmplResult"
#define TD_PART_SUBCMPL_RESULT_REL											"Scp0PartToSubsCmplResult"

//Constants for create model forms
#define TD_CAD_MODL_CRE_FORM_TYPE											"TD4CADModlCreForm"
#define TD_CAE_MODL_CRE_FORM_TYPE											"TD4CAEModlCreForm"
#define TD_SIMUL_MODL_CRE_FORM_TYPE											"TD4SimulModlCreForm"
#define TD_PAD_STACK_MODL_CRE_FORM_TYPE										"TD4PADStackModlCreForm"
//Constants for modification model forms
#define TD_CAD_MODL_MDF_FORM_TYPE											"TD4CADModlMdfForm"
#define TD_CAE_MODL_MDF_FORM_TYPE											"TD4CAEModlMdfForm"
#define TD_SIMUL_MODL_MDF_FORM_TYPE											"TD4SimulModlMdfForm"
#define TD_PAD_STACK_MODL_MDF_FORM_TYPE										"TD4PADStackModlMdfForm"
#define TD_SND_TO_CMPL_CHK_FORM_TYPE										"Scp0SndToCmplChkForm"
#define TD_MAP_MODL_FORM_TYPE												"TD4MAPModlForm"
#define TD_DATASET_TYPE														"Dataset"
#define TD_DESIGN_DOC_TYPE													"TD4DesignDoc"
#define TD_DESIGN_DOC_REV_TYPE												"TD4DesignDocRevision"
#define TD_GENERAL_DOC_REV_TYPE												"TD4GeneralDocRevision"
#define TD_SBM_FORM_STORAGE													"TD4SBMFormStorage"

//Cosntants for Organisation
#define TD_OPS_GROUP_NAME													"OPS.Teradyne"
#define TD_OPS_GROUP_NAME2													"OPS"
#define TD_COMM_SUPPORT_ENGG_ROLE											"Commodity Support Engineer"
#define TD_COMM_ENGG_ROLE													"Commodity Engineer"
#define TD_ROHS_COORDINATOR_ROLE											"RoHS Coordinator"
#define TD_DBA_GROUP														"dba"
#define TD_CM_ADMIN_GROUP													"dba"
#define TD_CHANGE_ADMIN_GROUP                                                "CM ADMIN.Business ADMIN.Teradyne"
#define TD_CONSUMER_ROLE													"Consumer"
//Constants for Relation name
#define TD_DIS_SPEC_REL_NAME												"TD4DisciplineSpecificRel"
#define TD_ORG_REL_NAME														"TD4OracleOrgRel"
#define TD_DEFAULT_ORG_NAME													"td4DefaultOrg"
#define TD_IMAN_SPEC_REL_NAME												"IMAN_specification"
#define TD_IMPACTED_ITEM_REL_NAME											"CMHasImpactedItem"
#define TD_COMMODITY_LVL1_REL_NAME											"TD4CommodityLevel1Rel"
#define TD_SOLUTION_ITEMS_REL_NAME											"CMHasSolutionItem"
#define TD_ATTACHES_REL_NAME												"TC_Attaches"
#define	TD_PROJECT_REL_NAME													"TD4ProjectRel"
#define	TD_ADDITIONAL_REVIEWER_REL_NAME										"TD4AdditionalReviewersRel"
#define	TD_VENDOR_REPERESENTS_REL_NAME										"VMRepresents"
#define TD_REF_MATERIAL_REL                                                 "TD4RefMaterialRel"
#define TD_ITAR_REL                                                         "TD4ITARRel"
#define TD_PART_TOBE_DISCON_REL                                             "TD4PartToBeDiscontinuedRel"
#define TD_VENDOR_PART_REL_NAME                                             "TC_vendor_part_rel"
#define TD_PCBA_DESIGN_DOC_REL_NAME                                         "TD4PCBADesignDocumentsRel"
#define TD_CM_SOLUTION_TO_IMPACTED_REL_NAME                                 "CMSolutionToImpacted"
#define TD_IMAN_CLASSIFICATION_REL_NAME                                     "IMAN_classification"
#define TD_REQ_RESULTS_IN_PART_REL											"TD4RequestResultsInPartRel"
#define TD_PART_MODIFIED_BY_REL                                             "TD4PartModifiedByRel"
#define TD_PART_TO_BE_MODIFIED_REL                                          "TD4PartToBeModifiedRel"
#define TD_IMAN_MASTER_FORM_REL_NAME                                        "IMAN_master_form"   
#define TD_COMMERCIAL_PART_REQUEST_REL                                      "TD4CommPartReqRel"   
#define TD_SIGNOFF_TASKS_REL                                                "TD4SignOffTaskRel"

//Constants for Preference name
#define TD_T4O_ITEM_PUSH_WF_PREF											"TD4_T4O_Item_Push_WF_Template"
#define TD_TAGDTGMODELREQUEST_WF_PREF										"TD4_TagDTGModelRequest_WF_Template"
#define TD_PARTMODREQ_WF_PREF												"TD4PartModReqRevision_default_workflow_template"
#define TD_PARTMODIFYREQUEST_WF_PREF										"TD4_PartModifyRequest_WF_Template"
#define TD_COMMERCIALPARTREQUEST_WF_PREF									"TD4_CommericalPartRequest_WF_Template"
#define TD_T4O_ORGEXTEND_WF_PREF										    "TD4_T4O_OrgExtend_WF_Template"
#define TD_VMREPRESENTS_CREATE_PREF										    "TD4_VMRepresents_creator"
#define	TD_STAND_ECN_REL_WF_PREF											"TD4StandardECNRevision_WF_Template"
#define	TD_RELEASE_ECN_REL_WF_PREF											"TD4ReleaseECNRevision_WF_Template"
#define	TD_DEVIATIE_NOTICE_REV_WF_PREF										"TD4DeviateNoticeRevision_WF_Template"
#define	TD_PROTOBOM_ECN_REV_WF_PREF											"TD4ProtoBOMECNRevision_WF_Template"
#define	TD_PROTOPART_ECN_REV_WF_PREF									    "TD4ProtoPartECNRevision_WF_Template"
#define	TD_PCN_REQUEST_REV_WF_PREF											"TD4PCNRequestRevision_WF_Template"
#define	TD_SUPPL_PART_TRANSC_REV_WF_PREF									"TD4SuppPartTransRevision_WF_Template"
#define TD_COMMDTY_ENGG_TRANSFER_REQ_WF_PREF								"TD4ComEnggTranRqRevision_WF_Template"
#define TD_OPSTASK_WF_PREF													"TD4OPSTask_WF_Template"
#define TD_GENERALTASK_WF_PREF                                              "TD4GeneralTask_WF_Template"
#define TD_ESI_ERROR_WF_PREF												"TD4ESIError_WF_Template"
#define TD_SCRAP_REWORK_WF_PREF												"TD4SCRAPREWORK_WF_Template"
#define TD_TERADYNE_REV_PREF                                                "TD4TeradyneRevisionScheme"
#define TD_VMREPRESENTS_DELETE_PREF										    "TD4_VMRepresents_delete"
#define TD_VENDOR_PART_CREATE_PREF											"TD4_VendorPart_creator"
#define TD_PART_CATEGORY_EMAIL_PREF										    "TD4EmailAddForNotListed"
#define TD_MAIL_SERVER_PREF		                                            "Mail_server_name"
#define TD_MAIL_PORT_PREF		                                            "Mail_server_port"
#define TD_REVIEWERS_INSTRUCTION_URL_PREF									"TD4_Reviewers_Instruction_Url"
#define TD_CB_REVIEWER_MATRIX_PREF		                                    "TD4_CB_Reviewer_Matrix"
#define TD_ECN_REPORT_TEMP_DIR_PREF											"TD4_ECNReport_Temp_Dir"
#define TD_AUTO_CMPLCHECK_REGULATION										"TD4_Auto_CmplCheck_regulations"
#define	TD_VENDOR_PART_CMPL_ATTR_WF_PREF									"TD4MfgPartUpdateCmplAttr_WF_Template"
#define TD_BOM_IMPORT_WF_PREF                                               "Teradyne_BOMImport_WorkflowName"
#define	TD_BOMCSV_FINDNO_PREF									            "Teradyne_BOMCSVFile_FindNo_Mandatory"
#define	TD_BOMCSV_QTYREFDES_PREF											"Teradyne_Quantity_RefDes_Relation"
#define	TD_BOMCSV_ZERO_QTY_PREF											    "Teradyne_Quantity_Zero"
#define	TD_BOMCSV_ALLOWED_PARTS_PREF										"Teradyne_Allowed_BOM_Types"
#define TD_BOMCSV_COLUMN_NAME_PREF											"Teradyne_BOMCSVFile_Column_Names"
#define TD_REVISE_ADDRESS_LIST_PREF                                         "TD4Revise_Address_List"
#define TD_PCB_PCBA_ADDRESS_LIST_PREF										"TD4PCB_PCBA_Address_List"
#define TD_SUPPLIER_ADD_REQ_REV_WF_PREF                                     "TD4SuppAddReqRevision_WF_Template"      
#define TD_INVALID_CHAR_PREF		                                        "Teradyne_Invalid_Characters"

#define	UR_STAND_ECN_REL_WF_PREF											"UR_StandardECNWF_Template" 
#define	UR_RELEASE_ECN_WF_PREF											 	"UR_ReleaseECNWF_Template"
#define	UR_RELEASE_LIFECYCLE_ECN_WF_PREF									"UR_ReleaseLifecycleWF_Template"
#define	UR_COMM_PART_REQUEST_WF_PREF										"UR_CommericalPartRequestWF_Template"

#define TD_UR_REV_PREF														"TD4URRevisionScheme"

#define TD_LIFE_CYCLE_STATUS												"td4LifecycleStatus"


//work space objects
#define TD_CMPL_REG_FLDR													"Compliance Regrade"
#define TD_VENDOR_PART_CMPL_FLDR											"Vendor Part Compliance"

//Constants for dynamic URL
#define TD_DYNC_SVR_URL														"TD4DynamicServerURL"
#define TD_DYNC_URL_STR														"TD4DynamicURLParameterString"
#define TD_URL															    "td4Url"
#define TD_ACTIVEWORKSPACE_HOSTING_RAC_URL                                  "ActiveWorkspaceHosting.RAC.URL"
//Enviroment Variable
#define TD_TC_BIN_PATH_ENV													"TC_BIN"
#define TD_TC_ROOT_PATH_ENV													"TC_ROOT"

//Cosntants for ECN Summary Report
#define TD_ECN_REPORT_FILE_NAME												"SummaryReport"
#define TD_ECN_REPORT_FILE_EXT												"xls"
#define TD_ECN_TITLE														"Title"
#define TD_ECN_TITLE_VAL 													"ECN Summary Report"
#define TD_ECN_REPORT_TITLE 												"Report Date"
#define TD_ECN_COLTIT_NO													"ECN Number"
#define TD_ECN_COLTIT_TYPE													"ECN Type"
#define TD_ECN_COLTIT_CREATOR												"Creator"
#define TD_ECN_COLTIT_CREATION_DATE											"Creation Date"
#define TD_ECN_COLTIT_CLOSURE_DATE											"Closure Date"
#define TD_ECN_COLTIT_PR_NO													"Problem Report Number"
#define TD_ECN_COLTIT_SYNOP													"Synopsis"
#define TD_ECN_COLTIT_CN													"Product Change Notice"
#define TD_ECN_COLTIT_PRIMARY_PRJ											"Primary Project"
#define TD_ECN_COLTIT_PRIORITY												"Priority"
#define TD_ECN_COLTIT_REASON												"Reason"
#define TD_ECN_COLTIT_DESC													"Description of Change"
#define TD_ECN_COLTIT_PROPOSED_SOLU											"Proposed Solution"
#define TD_ECN_COLTIT_REWORK_INSTR_SUMM										"Rework Instructions Summary"
#define TD_ECN_COLTIT_EST_RWK_COST											"Estimated Rework Cost"
#define TD_ECN_COLTIT_EST_SCRAP_COST										"Estimated Scrap Cost"
#define TD_ECN_COLTIT_MATL_IMP												"Material Impact"
#define TD_ECN_COLTIT_GCS_INV												"Does this ECN require rework of GCS Inventory?"
#define TD_ECN_COLTIT_REWORK_GCS_FIELD										"Does this ECN require rework of GCS Field Returns?"
#define TD_ECN_COLTIT_PUP_NO												"PUP Number"
#define TD_ECN_COLTIT_DEPT_NO												"Department Number"
#define TD_ECN_COLTIT_REV_STAMP												"Rev Stamp"
#define TD_ECN_COLTIT_UPD_MIN_SHIP_REV										"Update Min Shippable Revision?"
#define TD_ECN_COLTIT_OTHER_IP												"Other Impacted Projects"
#define TD_ECN_RELATED_PROP_TITLE											"ECN Object Properties"
#define TD_ECN_IMP_REL_TITLE												"Impacted Items"
#define TD_ECN_SOL_REL_TITLE												"Solution Items"
#define TD_PART_WARNINGS													"Warnings"
#define TD_ECN_SAFETY_TITLE_VAL												"ECN Safety Report"
#define TD_ECN_SAFETY_FILE_NAME												"SafetyReport"
#define TD_ECN_ROHS_TITLE_VAL												"ECN RoHS Report"
#define TD_ECN_ROHS_FILE_NAME												"RohsReport"
#define TD_INACTIVE_PRO                                                     "Inactive"

//Cosntants for ECR Property
#define TD_ITEM_INACTIVE_STATUS                                             "td4ItemStatus"
#define TD_ECN_TYPE															"TD4StandardECN"
#define TD_STD_ECN_REV_TYPE													"TD4StandardECNRevision"
#define TD_PROTOBOM_ECN_REV_TYPE											"TD4ProtoBOMECNRevision"
#define TD_PROTOPART_ECN_REV_TYPE											"TD4ProtoPartECNRevision"
#define TD_REL_ECN_REV_TYPE													"TD4ReleaseECNRevision"
#define TD_ECN_OWN_USER														"owning_user"
#define TD_ECN_PR_NO														"td4PRNumber"
#define TD_ECN_REL_NAME														"CMImplements"
#define TD_ECN_SYNOP														"object_name"
#define TD_ECN_CN															"td4PCNClass"
#define TD_ECN_PRIMARY_PRJ													"td4PrimaryProject"
#define TD_ECN_PRIORITY														"CMImplPriority"
#define TD_ECN_REASON														"td4Reason"						
#define TD_ECN_DESC															"td4Description"					
#define TD_ECN_PROPOSED_SOLU												"td4ProposedSolution"			
#define TD_ECN_REWORK_INSTR_SUMM											"td4ReworkInstructionSummary"	
#define TD_ECN_EST_RWK_COST													"td4EstReworkCost"				
#define TD_ECN_EST_SCRAP_COST												"td4EstScrapCost"				
#define TD_ECN_MATL_IMP														"td4MatlImpact"
#define TD_ECN_GCS_INV														"td4ReqGCSRework"
#define TD_ECN_REWORK_GCS_FIELD												"td4GCSFieldReturns"
#define TD_ECN_PUP_NO														"td4PupNumber"
#define TD_ECN_DEPT_NO														"td4ChargeAccNumber"
#define TD_ECN_REV_STAMP													"td4RevStamp"
#define TD_ECN_UPD_MIN_SHIP_REV												"td4UpdMinShipRev"
#define TD_ECN_OTHER_IP														"td4ImpactedProjects"
#define TD_ECN_SUPP_DOC_NAME												"ref_list"
#define TD_OBJECT_STRING												    "object_string"
#define TD_OBJECT_DESC_ATTR													"object_desc"
#define TD_REVISION_ATTR													"revision"
#define TD_START_DATE												        "creation_date"
#define TD_STD_ECN_STATUS_TYPE											    "TD4Released"
#define TD_ECN_CLOSURE_STATUS_ATTR										    "CMClosure"
#define TD_CLOSURE_DATE_ATTR												"date_released"		
#define TD_PART_TYPE_PCBA													"PCBA"
#define TD_PART_TYPE_HLA													"HLA(Instrument)"
#define TD_PART_REV_STAMP													"td4TeradyneRevStamp"
#define TD_PART_MIN_SHIPPABLE_REV											"td4MinShipRev"
#define TD_ECN_MATL_IMP_STD													"td4MaterialImpact"
#define TD_ECN_REPORT_XLS_FILE_EXT											"xls"
#define TD_ECN_REPORT_XLSX_FILE_EXT											"xlsx"
#define TD_CO_REQ_AUTHOR												    "td4CoRqAuthor"	
#define TD_COMM_PARTS_ATTR												    "commercialparts"	
#define TD_ITEM_MASTER_TAG_ATTR												"item_master_tag"
#define TD_APPLIES_ESI_ATTR													"td4AppliesToESI"
#define TD_COMPONENT_COMMODITY_TYPE                                         "td4ComponentCommodityType"
#define TD_SUPPRESS_AUTO_WATERMARK											"td4SuppressAutoWatermark"

//General Task Object
#define TD_ASSIGNEE                                                         "td4Assignee"      
#define TD_REJECT_HISTORY                                                   "td4RejectHistory"
#define TD_CANCELLED                                                        "td4Canceled"
#define TD_CANCEL_REASON                                                    "td4CancelReason"  
#define TD_CANCEL_HISTORY                                                   "td4CancelHistory"
//Cosntants for Impacted and solution Item Property
#define TD_IMPSOL_NAME														"Number"
#define TD_IMPSOL_DESC														"Description"
#define TD_IMPSOL_TYPE														"Type"
#define TD_IMPSOL_REV														"Revision"
#define TD_IMPSOL_REV_STAMP													"REV Stamp"
#define TD_IMPSOL_MIN_SHIPPABLE_REV											"Min Shippable Rev"
#define TD_ECR_IMPREL_NAME													"CMHasImpactedItem"
#define TD_ECR_SOLREL_NAME													"CMHasSolutionItem"
#define TD_ECR_REF_NAME														"CMReferences"
#define TD_ECR_REL_NAME													    "TD4RefMaterialRel,CMReferences"
#define TD_DIFFITEM_RESULT													"Compare Results"
#define TD_DIFFITEM_RESULT_WIDTH											"25"
#define TD_DIFFITEM_NAME													"Name"
#define TD_DIFFITEM_NAME_WIDTH												"25"
#define TD_DIFFITEM_DESC_WIDTH												"35"
#define TD_IMPSOL_ROHS_STATUS												"ROHS Compliant Status"
//#define TD_DIFFITEM_DESC													"Name"
#define TD_DIFFITEM_SEQNO													"Find Number"
#define TD_DIFFITEM_SEQNO_WIDTH												"10"
#define TD_DIFFITEM_QTY														"Quantity"
#define TD_DIFFITEM_QTY_WIDTH												"10"
#define TD_DIFFITEM_REMARKS													"Remarks"
#define TD_DIFFITEM_REMARKS_WIDTH											"10"
#define TD_DIFFITEM_REFDES_FROM												"From"
#define TD_DIFFITEM_REFDES_FROM_WIDTH										"10"
#define TD_DIFFITEM_REFDES_TO												"To"
#define TD_DIFFITEM_REFDES_TO_WIDTH											"10"
#define TD_DIFFITEM_REFDES_DELTA											"Delta"
#define TD_DIFFITEM_REFDES_DELTA_WIDTH										"20"
#define TD_DIFFITEM_DEFAULT_WIDTH_1											"35"
#define TD_DIFFITEM_DEFAULT_WIDTH_2											"10"
#define TD_DIFFITEM_ADD														"Added"
#define TD_DIFFITEM_DEL														"Deleted"
#define TD_DIFFITEM_CHANGE													"Changed"
#define TD_DIFFITEM_TITLE													"BOM Changes"
#define TD_DIFFITEM_HEADER_1												"BOM Changes for "
#define TD_ADDITEM_HEADER_1												    "ITEMS ADDED TO "
#define TD_DIFFITEM_HEADER_2												"Ref Designators"
#define TD_DIFFITEM_PART													"Part"
#define TD_ECN_PROCESS_HISTORY_TITLE										"Process History"
#define TD_ECN_PROCESS_TASKNAME												"Task Name"
#define TD_ECN_PROCESS_DECISION												"Signoff Decision"
#define TD_ECN_PROCESS_PERFORMER											"Performer"
#define TD_ECN_PROCESS_START_DATE											"Start Date"
#define TD_ECN_PROCESS_END_DATE												"End Date"
#define TD_ECN_PROCESS_COMMENTS												"Comments"
#define TD_ECN_PROCESS_TASKNAME_VAL											"parent_taskDisp"
#define TD_ECN_PROCESS_DECISION_VAL											"fnd0SignoffDecision"
#define TD_ECN_PROCESS_PERFORMER_VAL										"fnd0UserId"
#define TD_ECN_PROCESS_START_DATE_VAL										"fnd0StartDate"
#define	TD_ECN_PROCESS_END_DATE_VAL											"fnd0LoggedDate"	
#define	TD_ECN_PROCESS_COMMENTS_VAL											"fnd0SignoffComments"
#define TD_ECN_SUPP_DOC_TITLE												"Supporting Documents"
#define TD_APPROVE_STR														"Approved"
#define TD_REJECT_STR														"Rejected"
#define TD_NO_DECISION														"No_Decision"
#define TD_EFF_TITLE														"Effectivity"
#define TD_EFF_TYPE															"Class"
#define TD_UNIT_EFF_TYPE													"Unit Effectivity"
#define TD_DATE_EFF_TYPE													"Date Effectivity"
#define TD_TABLE_ROW_HEADER_VALUE                                           "ROW-Header&value"
#define TD_TABLE_HEADER                                                     "TableHeading"
#define TD_TABLE_COL_HEADER_VALUE                                           "COL-Header&value"
#define TD_TABLE_EMPTY_CHANGE												"Table for Empty Change"
#define TD_TABLE_STATIC_TEXT												"Static Text"
#define TD_TABLE_NONE_VALUE													"NONE"
#define TD_NO_BOM_CHANGE													"NO BOM CHANGE"
#define TD_NO_BOM													        "None"
#define TD_NO_BOM_CHANGE_TEXT												"None - Revision Change only to reflect lower level part changes (co-req)"
#define TD_ECN_CLOSURE_OPEN_STATUS											 "Open"
#define TD_ECN_CLOSURE_CLOSED_STATUS										 "Closed"
#define TD_ECN_CLOSURE_STATUS_COL_VALUE										 "Determined when ECN is Incorporated"
#define TD_BOOL_VALUE_TRUE													"TRUE"
#define TD_BOOL_VALUE_FALSE													"FALSE"
#define TD_ECN_VALUE_FOR_TRUE												 "Yes"
#define TD_ECN_VALUE_FOR_FALSE												 "No"
#define TD_HEADING_TYPE_1													 2
#define TD_HEADING_TYPE_2													 3
#define SEQ_LEN																 4
#define QTY_LEN																 15
#define FILE_LEN															 100
#define FILE_CONTENT_LEN													 5000
#define DECISION_SIZE														 8
#define TD_MAX_REF_DESG														 2000

// Constants for BOMLine attribute
#define TD_BL_REF_DESIG_ATTR												"bl_ref_designator"
#define TD_BL_ITEM_ID_ATTR													"bl_item_item_id"
#define TD_BL_QUANTITY														"bl_quantity"
#define TD_BL_REVISION														"bl_revision"
#define TD_BL_SEQ_NO														"bl_sequence_no"
#define TD_BL_UOM															"bl_uom"
#define TD_BL_ITEMREV														"bl_rev_item_revision_id"
#define TD_BL_ITEM_NAME														"bl_item_object_name"
#define TD_BL_REMARKS														"TD4Remarks"
#define TD_BL_OBJECT_TYPE													"bl_item_object_type"
#define TD_BL_REMOVED														"Prior Revision of BOM contained Safety ID Part and was removed from new version of BOM"
#define TD_BL_ADDED															"Current Version of BOM has a new Safety Part"

// Constants for ECN Report
#define TD_DATASETTYPE														"MSExcelX"
#define TD_DATASETTYPE_DISPLAY_NAME										    "MS ExcelX"
#define TD_BINARY_FORMATTYPE												"BINARY"
#define TD_TEXT_FORMATTYPE													"TEXT"
#define TD_NAMED_REFERENCE													"excel"
#define TD_DATASETTYPE_CSV                                                  "TD4TER_CSV"
#define TD_CSV_REFNAME										                "TD4CSV"

// Constant Text
#define TD_ECN_REPORT_STEXT_SUPPDOCS										"These are the Red-Line Drawings, ECN Justification, Additional Rework Instructions, etc. that are the Change Information Items found in the Dependent Items section of the ECN"
#define TD_ECN_REPORT_STEXT_BOMCHANGES										"* ' -> ' indicates change in value. e.g. 4->3 indicates value changed from 4 to 3; ->3 indicates a change from no value to 3"
#define TD_ECN_CLOSURE_STATUS												"This is not a released version of the ECN - Do Not Build or Order to"
#define TD_ECN_TILE_NOTICE_STATUS											"NOTICE:This ECN is releasing parts from Prototype directly to Production"
								
#define TD_ECN_MATIMP_VALUE_PHASEIN											"Phase In"						
#define TD_ECN_MATIMP_VALUE_NEXTBUILD										"Next Build"						
#define TD_ECN_MATIMP_VALUE_NEXTBUY											"Next Buy"							
#define TD_ECN_MATIMP_VALUE_REWORKALL										"Rework All"						
#define TD_ECN_MATIMP_VALUE_REWORKSOMEMATERIAL								"Rework Some Material"			
#define TD_ECN_CLOSURE_VALUE_REWORKALL_PRIORT								"Rework All - prior to customer shipment"

#define TD_ECN_MATIMP_NONE													""
#define TD_ECN_MATIMP_PHASEIN												"Implement changes on ECN per the effectivity date."
#define TD_ECN_MATIMP_NEXTBUILD												"Supplier to ship pre Revision on PO. Implementation: ECN should be implemented the next time that the manufacturing step that first uses the item begins a new build. The ECN should be implemented as soon as possible without interrupting the current manufacturing flow. If there is scrap, this must be agreed to and budgeted for. Open PO revs should be changed based on integration with supplier as to when they can ship."
#define TD_ECN_MATIMP_NEXTBUY												"Implementation: ECN will be implemented the next time that the item is purchased from a vendor. The ECN should be implemented as soon as possible without having to scrap any materials that has already been purchased that does not have the change. It's OK to receive either revision, current or new. Next PO's go as new rev, no change to open PO's."
#define TD_ECN_MATIMP_REWORKALL	 											"ECN should be implemented on all WIP and inventory without impacting shipment schedule. Shipments should be made based on PO revision."
#define TD_ECN_MATIMP_REWORKSOMEMATERIAL									"Implementation: ECN should be implemented only on the material specified in the ECN (the specific material will be included in the rework instruction Summary Section). Buyer to work to understand cut-in and update PO's accordingly."
#define TD_ECN_CLOSURE_REWORKALL_PRIORTOCUSTOMERSHIPMENT					"All WIP and inventory must be reworked per the ECN prior to shipping. Buyer/Planner needs to work with supplier to understand impact to production and ship schedules. PO's should be updated with new revisions before any shipments made."

#define TD_UR																"UR"

// for ESI 
#define TD_NXT																"NXT"

#define TD_ES_URL_PREF														"TERADYNE_ES_URL_PREF"
#define TD_ESI_ITEM_CREATE_WF_PREF											"TD4_ESI_Item_Create_WF_Template"
#define TD_ESI_ITEM_UPDATE_WF_PREF											"TD4_ESI_Item_Update_WF_Template"

#define TD_PART_TO_RESOLVE_REL												"TD4PartToResolveRel"

// for ESI Events
#define TD_PART_CREATED_EVENT												"PartCreated"
#define TD_PART_UPDATED_EVENT												"PartUpdated"
#define TD_PART_RELEASED_EVENT												"PartReleased"
#define TD_PART_REVISED_EVENT												"PartRevised"
#define TD_BOM_PUSHED_EVENT                                                 "BOMPushed"   
#define TD_AVL_PUSHED_EVENT                                                 "AVLPushed"

//for reports
#define TD_DEVIATION_REPORT_ID												"DeviationReport"
#define TD_TC																"Teamcenter"
#define TD_DEVIATION_STYLE_SHEET											"deviation_report_excel.xsl"
#define TD_DEVIATION_REPORT													"DeviationReport"
#define TD_DEVIATION_REPORT_NAME											"Deviation Summary Report"

//for Name Counter
#define TD_DIV_PART_MID_NAME_COUNTER										"TD4DivPartIDNR1_6"
#define TD_DIV_PART_PREFIX_NAME_COUNTER										"TD4DivPartIDNR0_0"
#define TD_NEXT_ID_ATTR														"td4NextId"

#define	TD_PART_MSD_DECL_REV												"Scp0PartMSDDeclRevision"


#define TD_COMMODITY_PART_REQUEST                                           "Commodity Part Request"

//WORKFLOW TASKS
#define TD_TASK_SUPPLIER_ADD_COORDINATOR_WORK                               "Supplier Add Coordinator Work"
#define TD_TASK_COMMODITY_ENGINEER_REVIEW                                   "perform-signoffs-Commodity Engineer Review"


// WORKFLOW TEMPLATES
#define TD_WF_STANDARD_ECN                                                  "TER_StandardChangeECNWF"
#define TD_WF_RELEASE_ECN                                                   "TER_ReleaseECNWF"
#define TD_WF_PROTOBOM_ECN                                                  "TER_ProtoBOMECNWF"
#define TD_WF_PROTOPART_ECN                                                 "TER_ProtoPartECNWF"

// SUPPLIER ADD REQUEST REVISION PROPERTIES
#define TD_COMMODITY_GROUP_MANAGER                                          "td4CommodityGroupManager"
#define TD_COMMODITY_ENGINEER                                               "td4RespCommEng"
#define TD_COMMODITY_MANAGER                                                "td4RespCommMgr"
#define TD_LEVEL_OF_ASSESSMENT                                              "td4LevelOfAssessment"
#define TD_CANCEL_SUPPLIER_ADD_REQUEST                                      "td4Cancel"

#define TD_PDF_REF															"PDF_Reference"
#define	TD_WM_TEMP_DIR														"TERADYNE_WM_TEMP_DIR_PREF"
#define	TD_WM_ADD_APP														"TERADYNE_WM_ADD_APP_PREF"
#define	TD_WM_TEXT															"TERADYNE_WM_TEXT_PREF"
#define	TD_WM_REMOVE_APP													"TERADYNE_WM_REMOVE_APP_PREF"

// UR ATTRibute RELEASE ECN

#define TD_ECN_FOR_ATTR														"td4ECNFor"
#define TD_ECN_LIFE_CYCLE_STATUS_ATTR										"td4LifecycleStatus"


#define TD_UR_ADMIN_GRP_CONSTANT											"CM ADMIN.Business ADMIN.UR"
#define TD_UR_RD_GRP_CONSTANT												"R&D.UR"

// UR WORKFLOW HANDLERS


#define TD_DIV_PART_MAP_FORM_PART_TYPE_ERROR (EMH_USER_error_base+229)

#define TD_Revise_ImpacteItem_TO_SolutioItem (EMH_USER_error_base+230)
#define TD_Design_DOC_with_Dataset_missing (EMH_USER_error_base+231)
#define TD_Diff_Status (EMH_USER_error_base+232)
#define TD_BOM_Child_Missing (EMH_USER_error_base+233)
#define TD_BOM_Status (EMH_USER_error_base+234)
#define TD_BOM_INVALID_CHILD_TYPE (EMH_USER_error_base+235)
#define TD_NO_OLD_REVISION (EMH_USER_error_base+236)
#define TD_Diff_Status3 (EMH_USER_error_base+237)
#define TD_BOM_INVALID_CHILD_VALUE (EMH_USER_error_base+238)
#define TD_Diff_Value_than_ECN (EMH_USER_error_base+239)

#define TD_COMM_PART_ITEM_ID_NTFOUND_ERROR (EMH_USER_error_base+245)
#define TD_DIV_PART_NUMBER_DIGIT_MIR_ERROR (EMH_USER_error_base+246)
#define TD_SOLUTION_ITEM_MISSING_DIV_COMM_PART (EMH_USER_error_base+247)
#define TD_BOM_Child_UESD_MULTIPLE_TIMES (EMH_USER_error_base+249)
#define TD_BOM_QUANTITY_REFERENCE_DESIGNATOR (EMH_USER_error_base+250)
#define TD_DOC_REVISION_ATTACHED (EMH_USER_error_base+252)

// UR 

#define TD_UR_SEMIFINISHED                                                  "Semi-Finished"
#define TD_UR_FINISHED                                                      "Finished Good"
#define TD_UR_INTANGIBLE                                                    "Intangible"
#define TD_UR_COMPONENT                                                     "Component"

#define TD_UR_SEVEN_PATTERN													"NNNNNNN"
#define TD_UR_SIX_PATTERN													"NNNNNN"

#endif
