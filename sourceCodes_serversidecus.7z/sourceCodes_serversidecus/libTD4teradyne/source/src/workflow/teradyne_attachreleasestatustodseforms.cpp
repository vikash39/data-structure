/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_attachreleasestatustodseforms.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-AttachReleaseStatusToDSEForms action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  24-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_attachreleasestatustodseforms
#  24-Apr-2015                       Vijayasekhar                    	Added code changes to get the reviced parts from Solution Items folder
#  07-May-2015						 Vijayasekhar                    	Added condition to check the suitable target objects
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_attachreleasestatustodseforms
 * Description				: This function will release all the DSE forms of the previous Revisions(In imapacted Items folder) of Solution Items folder.
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					:
 ******************************************************************************/
int teradyne_attachreleasestatustodseforms(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iRevs					= 0,
		iPrevRevForms			= 0,
		iSolutionItems			= 0;
	tag_t *tAttaches			= NULL,
		  *tRevs				= NULL,
		  *tPrevRevForms		= NULL,
		  *tSolutionItems		= NULL;
	char *pcAttachType			= NULL;

	const char * __function__ = "teradyne_attachreleasestatustodseforms";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {
				
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE)) {
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iSolutionItems, &tSolutionItems), TD_LOG_ERROR_AND_THROW);
					char *pcObjectType = NULL;
					for (int k = 0; k < iSolutionItems; k++) {
						iStatus = WSOM_ask_object_type2(tSolutionItems[k], &pcObjectType);
						if (tc_strcmp(pcObjectType, TD_DIV_PART_REV) == 0) {
							TERADYNE_TRACE_CALL(iStatus = teradyne_list_all_revisions_from_revtag(tSolutionItems[k], &iRevs, &tRevs), TD_LOG_ERROR_AND_THROW);
							for (int j = 0; j < iRevs && iRevs > 1; j++) {


								if (tRevs[j] == tSolutionItems[k]) {

									TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tRevs[j - 1], TD_DIS_SPEC_REL_NAME, &iPrevRevForms, &tPrevRevForms), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = teradyne_add_release_status_to_objects(iPrevRevForms, tPrevRevForms), TD_LOG_ERROR_AND_THROW);
									break;
								}
							}
							Custom_free(tRevs);
							Custom_free(tPrevRevForms);
						}
						Custom_free(pcObjectType);
					}
				}
				Custom_free(pcAttachType);
				Custom_free(tSolutionItems);	
			}
		}
	}
	catch (...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	Custom_free(tPrevRevForms);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}