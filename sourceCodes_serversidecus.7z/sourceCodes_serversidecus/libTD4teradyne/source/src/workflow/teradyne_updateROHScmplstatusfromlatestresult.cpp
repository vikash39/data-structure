/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_updateROHScmplstatusfromlatestresult.cpp 
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-UpdateROHSCmplStatusFromLatestResult action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
# 19-Jun-2015						Vijayasekhar						Initial creation(Added the function definitions teradyne_updateROHScmplstatusfromlatestresult
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_updateROHScmplstatusfromlatestresult
 * Description				: Will update the ROHS compliance status on Vendor part for the handler Teradyne-UpdateROHSCmplStatusFromLatestResult
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Gets the target attachments process only for Vendor parts
 *							: 2. Gets the latest Substance compliance result object and get the status attribute and updates that value on ROHS compliance status on Vendor Part
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_updateROHScmplstatusfromlatestresult(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iSubstanceCmplRslts		= 0;
	tag_t *tAttaches			= NULL,
		  *tSubstanceCmplRslts	= NULL;
	char *pcTargetType			= NULL,
		 *pcStatusVal			= NULL;
		
	const char * __function__ = "teradyne_updateROHScmplstatusfromlatestresult";
	TERADYNE_TRACE_ENTER();

	try {

		if(msg.task != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcTargetType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcTargetType, TD_MFG_PART)) {
				
					//Gets the latest result object
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tags(tAttaches[i], TD_SUBCMPL_LATEST_RESULT, &iSubstanceCmplRslts, &tSubstanceCmplRslts), TD_LOG_ERROR_AND_THROW);
					if(iSubstanceCmplRslts > 0 && tSubstanceCmplRslts[0] != NULLTAG) {
						//Gets the status attribute from the latest result object
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSubstanceCmplRslts[0], TD_SCP_STATUS_DISPLY_ATTR, &pcStatusVal), TD_LOG_ERROR_AND_THROW);
						if(pcStatusVal != NULL) {
							//Updates the status attribute on ROHS compliance status on Vendor part
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tAttaches[i], TD_ROHS_COMMPLT_STATUS_ATTR, pcStatusVal),TD_LOG_ERROR_AND_THROW);
						}
					}
					Custom_free(pcTargetType);
				}
				Custom_free(tSubstanceCmplRslts);
				Custom_free(pcStatusVal);
			}
		}
	}catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}