/*=================================================================================================                    
#                Copyright (c) 2019 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_has_change_management_access.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-HasChangeManagementAccess handler
#      Project         :           libTD4teradyne          
#      Author          :                    

#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_has_change_management_access
 * Description				: This function check if the logged in user has an access to Change Management,Usually author license level has access to Change Management
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:1. 
 *							 2.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int  teradyne_has_change_management_access(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iCount              = 0,
		iValCount           = 0;

	tag_t *tAttaches			= NULL,
		  *tReferences          = NULL,
		  *tActuatedInterActive = NULL,
		  tAttrId				= NULLTAG,
		  tClassId				= NULLTAG,
		  *tObjects				= NULL;

	
	
	char *pcAttachType			= NULL,
		*pcUserName		      	= NULL,
		 *pcEventType			= NULL;
	char *pcPropName			= NULL,
		 *pcClassName			= NULL;

	 char *pcTaskName                    = NULL;
	 char *pcTypeName					= NULL;
	 tag_t tUser					= NULLTAG;
	 tag_t tOwningUser = NULL;
	 int license_level =0;
	 bool bIsNull				= false,
		 bIsEmpty				= false;
		

	const char * __function__    = "teradyne_has_change_management_access";
	TERADYNE_TRACE_ENTER();

	try
	{
		
		if(msg.task != NULLTAG){
		     
		    
			TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcUserName, &tUser), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_class_of_instance(tUser, &tClassId), TD_LOG_ERROR_AND_THROW);
		    TERADYNE_TRACE_CALL(iStatus = POM_name_of_class(tClassId, &pcClassName), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_attr_id_of_attr(TD_LICENSE_LEVEL, pcClassName, &tAttrId), TD_LOG_ERROR_AND_THROW);
			if(tAttrId != NULLTAG){
			   TERADYNE_TRACE_CALL(iStatus = POM_ask_attr_int(tUser, tAttrId, &license_level, &bIsNull, &bIsEmpty), TD_LOG_ERROR_AND_THROW);
			}

		    if(license_level ==0){
			  TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, EPM_RESULT_True), TD_LOG_ERROR_AND_THROW);
			}else{
			   TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, EPM_RESULT_False), TD_LOG_ERROR_AND_THROW);
			}
			
	    }
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}