/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_set_releasestatus_ECN.cpp        
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-SubmitCommPartRevToT4O action handler
#      Project         :           libTD4teradyne          
#      Author          :                    
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_is_controlling_bus_unit_UR
 * Description				: 
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : 
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. 
 * NOTES					: 
 ******************************************************************************/
int teradyne_is_controlling_bus_unit_UR(EPM_action_message_t msg) 
{
	int iStatus					= ITK_ok,
		iReferences				= 0,
		iCount					= 0,
		n						= 0,
		argnumber				= 0;

	tag_t *tAttaches			= NULL,
		  *tReferences          = NULL,
		  *tObjects				= NULL;
	
	char *pcAttachType			= NULL,
		*pcProjAttr				= NULL,
		*pcCBU					= NULL,
		*arg_name				= NULL,
		*arg_value				= NULL,
		*UR_value				= NULL;

	bool isURProject = false;

	const char * __function__ = "teradyne_is_controlling_bus_unit_UR";
	TERADYNE_TRACE_ENTER();

	try 
	{
		if(msg.task != NULLTAG) 
		{ 
			argnumber = TC_number_of_arguments(msg.arguments);
			for (n = 0; n < argnumber; n++)
			{
				TERADYNE_TRACE_CALL(iStatus = ITK_ask_argument_named_value(TC_next_argument(msg.arguments), &arg_name, &arg_value), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(arg_name, "Controlling-Bus-Unit") == 0)
				{
					UR_value = arg_value;
				}
			}
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_REL_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE ) || !tc_strcmp(pcAttachType, TD_PROTOPART_ECN_REV_TYPE )) 
				{
					
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i],TD_PRIMARY_PROJECT,&pcProjAttr),TD_LOG_ERROR_AND_THROW);				   

					if(tc_strlen(pcProjAttr) > 0)
					{
						tag_t projectTag = NULLTAG;
						
						TERADYNE_TRACE_CALL(iStatus =teradyne_get_object_tag(pcProjAttr,TD_PROJECT_FORM_TYPE,&projectTag),TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(projectTag,TD_CONTRL_BUSS_UNIT,&pcCBU),TD_LOG_ERROR_AND_THROW);

						if(tc_strcmp(pcCBU, UR_value)==0)
						{
							isURProject = true;
							break;
						}
					
					}
					
				}
			}

			if(isURProject)
			{
				TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, EPM_RESULT_True), TD_LOG_ERROR_AND_THROW);
			}
			else 
			{
				TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, EPM_RESULT_False), TD_LOG_ERROR_AND_THROW);
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcCBU);
	Custom_free(pcProjAttr);
	Custom_free(pcAttachType);
	Custom_free(tAttaches);
	Custom_free(arg_name);
	Custom_free(arg_value);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}