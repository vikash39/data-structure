/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_reviewermatrix.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne_ReviewerMatrix action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  10-Mar-2015                       Haripriya                    	    Initial Creation
#  20-Apr-2015						 Haripriya						    Modified PUP_attr value.
#  22-Apr-2015                       Haripriya                          Modified teradyne_set_techreviewer_value
#  23-Apr-2015                       Haripriya                    	    Modified the teradyne_set_techreviewer_value function to update ReqdTechReviewerUserList and ReqdCBReviewersUserList
#  29-Apr-2015                       Haripriya                    	    Modified the function to do for StandardECN Revision.
#  07-May-2015                       Haripriya                    	    Modified Change Admin Value with constants
#  03-Jul-2015					     Haripriya                    	    Modified teradyne_set_techreviewer_value function to check whether part type value is empty or not.
#  20-Jul-2015					     Selvi                      	    Modified code to add ProductSafety value into ReqdCBReviewersList based on SafetyLicense.
#  21-Jul-2015					     Haripriya                      	Modified code to insert values in order while merging the vectors.
#  25-Sep-2015                       Deepachitra                        Modified code to set values in Required technical reviewer user list Attribute.
#  12-Nov-2015                       Manimaran                          Moved the function teradyne_convert_vector_to_array to teradyne_common.cpp file.
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>
#include <algorithm>

/*******************************************************************************
 * Function Name			: teradyne_reviewermatrix
 * Description				: This function will Update Required Technical Reviewer and CB Reviewer Value in StandardECN Revision 
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Searches the DivpartRevision in Solution Items Folder
 *							  2. If DivpartRevision is Found ,Gets the PartType Value and creates the Preference as TD4_$PartType_ReviewerMatrix.
 *							  3. Gets the Primary Project and Other impacted Projects value in Standard ECN Revision and Searches the Reviewer as 
 *                               per the role,if mandatory field is empty need to throw an error.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_reviewermatrix(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0,
		iCBPrefcount        = 0,
		iFound              = 0,
		iprocess            = 0;

	 double dScrapCost      = 0.0;

	 bool bGCSValue         = false,
		  bReqGCSValue      = false,
		  bcheck            = false,
		  bSafety			= false;

	char **pcCBprefval     = NULL,
		 *pcAttachType     = NULL;

	string szStdEcn_Attr[]  = {TD_PCN_CLASS_ATTR,TD_REASON_ATTR,TD_PUP_NO_ATTR};

	tag_t *tAttachtag       = {NULLTAG};
    tag_t projectTag        =NULLTAG; 

	 vector<string> CBreviewerValues,
		            impprojValues,
					MarketingValues,
					ERTValues,
					FinanceValues,
					GCSTechValues,
					CBrevieweruserValues,
					GCSPlannerValues,
					ProductSafetyValues;

	std::map<string,string> strECNPropNameValueMap,strPropNameValueMap;

	const char * __function__    = "teradyne_reviewermatrix" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG) 
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment,&iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) == 0)
				{
					//calling function to primaryproject and Impacted Project values
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_primary_imapacted_project_values( tAttachtag[i],impprojValues),TD_LOG_ERROR_AND_THROW);
					
					//calling function to get value of attribute td4SafetyLicense from SolutionItems.
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_safety_value( tAttachtag[i], bSafety),TD_LOG_ERROR_AND_THROW);
					
					//calling function to set ReqTechnicalreviewerList Value.
					TERADYNE_TRACE_CALL(iStatus = teradyne_set_techreviewer_value( tAttachtag[i], impprojValues),TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = teradyne_get_prop_value_from_primary_project(tAttachtag[i],strPropNameValueMap,TD_CHANGE_ADMIN_ATTR),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus= teradyne_setproperty_value(tAttachtag[i],TD_CHANGE_ADMIN_ATTR,strPropNameValueMap.find(TD_CHANGE_ADMIN_ATTR)->second),TD_LOG_ERROR_AND_THROW);
				    
					std::list<string> strECNAttrList( szStdEcn_Attr, szStdEcn_Attr + sizeof(szStdEcn_Attr) / sizeof(string) );
					//calling function to get StandardECNRevision property values
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tAttachtag[i],strECNAttrList,strECNPropNameValueMap),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tAttachtag[i],TD_EST_SCRAP_COST_ATTR,&dScrapCost),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttachtag[i],TD_GCS_FIELD_RETURNS_ATTR,&bGCSValue),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttachtag[i],TD_REQ_GCS_REWORK_ATTR,&bReqGCSValue),TD_LOG_ERROR_AND_THROW);
				    
					TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_values(TD_CB_REVIEWER_MATRIX_PREF,&iCBPrefcount,&pcCBprefval),TD_LOG_ERROR_AND_THROW);

					//Initialising the Vector with Role Name given in Preference
					MarketingValues.push_back("MARKETING:");
					GCSPlannerValues.push_back("GCS Planner:");
					GCSTechValues.push_back("GCS Repair Technician:");
					ERTValues.push_back("ERT:");
					FinanceValues.push_back(" Finance:");
					ProductSafetyValues.push_back("Product Safety:");

					for(int iPfCnt = 0; iPfCnt < iCBPrefcount;++iPfCnt)
					{
						string szPropertyname   ="Change Board";
						string szPropname		="";
						string szPropvalue = pcCBprefval[iPfCnt];
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_propname_from_Preference( szPropvalue,CBreviewerValues,szPropname,bcheck),TD_LOG_ERROR_AND_THROW);
			            
						//Finding the project and getting the Reviewer Values as in the Preference
						for(int k=0;k<impprojValues.size();++k)
						{
							//TERADYNE_TRACE_CALL(iStatus = WSOM_find2(impprojValues.at(k).c_str(),&iFound,&tProjTag),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus =teradyne_get_object_tag(impprojValues.at(k).c_str(),TD_PROJECT_FORM_TYPE,&projectTag),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,szPropname,CBreviewerValues,szPropertyname,bcheck),TD_LOG_ERROR_AND_THROW);
					        
							if(iprocess == 0)
							{
								bool bcheck =false;
								if(!tc_strcmp((strECNPropNameValueMap.find(TD_PCN_CLASS_ATTR)->second).c_str(),"Class I") || !tc_strcmp((strECNPropNameValueMap.find(TD_PCN_CLASS_ATTR)->second).c_str(),"Class II") )
								{
									TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,TD_MARKETING_ATTR,MarketingValues,"",bcheck),TD_LOG_ERROR_AND_THROW);
								}
								if(dScrapCost> 5000 )
								{
									TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,TD_FINANCE_ATTR,FinanceValues,"",bcheck),TD_LOG_ERROR_AND_THROW);
								}
								if(!tc_strcmp((strECNPropNameValueMap.find(TD_REASON_ATTR)->second).c_str(),"Safety") )
								{
									TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,TD_ERT_ATTR,ERTValues,"",bcheck),TD_LOG_ERROR_AND_THROW);
								}
								if(((strECNPropNameValueMap.find(TD_PUP_NO_ATTR)->second).length() > 0))
								{
									TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,TD_PRODUCT_SUPPORT_ENGG_ATTR,GCSPlannerValues,"",bcheck),TD_LOG_ERROR_AND_THROW);
								}
								if(((strECNPropNameValueMap.find(TD_PUP_NO_ATTR)->second).length() > 0) || (bReqGCSValue == 1) || (bGCSValue == 1))
								{
									TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,TD_GCS_PLANNER_ATTR,GCSPlannerValues,"",bcheck),TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,TD_GCS_REPAIR_TECH_ATTR,GCSTechValues," ",bcheck),TD_LOG_ERROR_AND_THROW);
								}
								if (bSafety)
								{
									TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,TD_PRODUCT_SAFETY_ATTR,ProductSafetyValues,"",bcheck),TD_LOG_ERROR_AND_THROW);
								}
							}
							
						}	
						 iprocess++;
					}
				    
					//Calling Function to Combine CBreviewerValues vector Values with MarketingValues,ERTValues,FinanceValues,GCSTechValues,GCSPlannerValues
					TERADYNE_TRACE_CALL(iStatus =teradyne_merge_vectors( CBreviewerValues,MarketingValues),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_merge_vectors( CBreviewerValues,ERTValues),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_merge_vectors( CBreviewerValues,FinanceValues),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_merge_vectors( CBreviewerValues,GCSTechValues),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_merge_vectors( CBreviewerValues,GCSPlannerValues),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_merge_vectors( CBreviewerValues,ProductSafetyValues),TD_LOG_ERROR_AND_THROW);

					char **pcCBreviewerarray   = NULL,**pcCBrevieweruserarray = NULL;

					//Converting vector to char** array and Setting Value on Standard ECN Revision
					TERADYNE_TRACE_CALL(iStatus =teradyne_convert_vector_to_array( CBreviewerValues,&pcCBreviewerarray),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_set_arrayproperty_value(tAttachtag[i],TD_REQ_CB_REVIEWERS_ATTR,(int)CBreviewerValues.size(),pcCBreviewerarray),TD_LOG_ERROR_AND_THROW);
					Custom_free(pcCBreviewerarray);	
					for(int j=0;j<CBreviewerValues.size();j++)
					{
						size_t pos = CBreviewerValues.at(j).find(":");
						if(pos == -1)
						{
							CBrevieweruserValues.push_back(CBreviewerValues.at(j));
						}
					}
					//getting Unique Preference Values
					sort(CBrevieweruserValues.begin(),CBrevieweruserValues.end());
					vector<string>::iterator it = std::unique(CBrevieweruserValues.begin(),CBrevieweruserValues.end());
					CBrevieweruserValues.erase(it,CBrevieweruserValues.end());
					//Converting vector to char** array and Setting Value on Standard ECN Revision
					TERADYNE_TRACE_CALL(iStatus =teradyne_convert_vector_to_array( CBrevieweruserValues,&pcCBrevieweruserarray),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus =teradyne_set_arrayproperty_value(tAttachtag[i],TD_REQ_CB_REVIEWERS_LIST_ATTR,(int)CBrevieweruserValues.size(),pcCBrevieweruserarray),TD_LOG_ERROR_AND_THROW);
					Custom_free(pcCBrevieweruserarray);
				}
			    Custom_free(pcAttachType);
			}
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(tAttachtag);
    Custom_free(pcCBprefval);
	CBreviewerValues.clear();
	MarketingValues.clear();
	ERTValues.clear();
	FinanceValues.clear();
	GCSTechValues.clear();
	GCSPlannerValues.clear();
	impprojValues.clear();
	CBrevieweruserValues.clear();
	ProductSafetyValues.clear();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_merge_vectors
 * Description				: Combine one vector into another vector
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : vMergeVector   (O)	     - vector<string>
 *							  vsinglevector  (I)         - vector<string>
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_merge_vectors( vector<string> &vMergeVector,vector<string> vsinglevector)
{

	int iStatus					= ITK_ok;

	vector<string> vsinglevectoruserValues,
		           vsinglevectorValues;

	const char * __function__ = "teradyne_merge_vectors";
	TERADYNE_TRACE_ENTER();

	try 
	{
		if(vsinglevector.size() > 1)
		{
			//getting Unique Vector Values
			sort(vsinglevector.begin(),vsinglevector.end());
			vector<string>::iterator itr = std::unique(vsinglevector.begin(),vsinglevector.end());
			vsinglevector.erase(itr,vsinglevector.end());
		
			for(int j=0;j<vsinglevector.size();j++)
			{
				size_t pos = vsinglevector.at(j).find(":");
				if(pos == -1)
				{
					vsinglevectoruserValues.push_back(vsinglevector.at(j));
				}
				else
				{
					vsinglevectorValues.push_back(vsinglevector.at(j));
				}
			}
			vMergeVector.insert(vMergeVector.end(),vsinglevectorValues.begin(),vsinglevectorValues.end());
			vMergeVector.insert(vMergeVector.end(),vsinglevectoruserValues.begin(),vsinglevectoruserValues.end());
		}
	} 
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	vsinglevectorValues.clear();
	vsinglevectoruserValues.clear();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_set_techreviewer_value
 * Description				: Setting td4ReqdTechReviewersList in ECN Revision
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tAttachtag   (I)	    - tag_t
 *							  vimpprojValues  (I)   - vector<string>
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_set_techreviewer_value( tag_t tAttachtag, vector<string> vimpprojValues)
{

	int iStatus			    = ITK_ok,
		iRefCount           = 0,
		iprefcount          = 0,
		iFound              = 0;

	 bool bcheck            = false;

	char *pcDivPartAttr     = NULL,
		 **pcprefval        = NULL,
		 *pcTypeName        = NULL;
	
	tag_t  tRelationTag      = NULLTAG,
		  *tRefListTag      = {NULLTAG};

	tag_t projectTag        =NULLTAG; 
	vector<string> PrefValues,
		            techreviewerValues,
					 techrevieweruserValues;
	 char *pcObjectType		= NULL;

	const char * __function__ = "teradyne_set_techreviewer_value";
	TERADYNE_TRACE_ENTER();

	try 
	{
		//Getting Parts under Solution Item Folder
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_SOLUTION_ITEMS_REL_NAME,&tRelationTag),TD_LOG_ERROR_AND_THROW);			
		TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tAttachtag,tRelationTag,&iRefCount,&tRefListTag ),TD_LOG_ERROR_AND_THROW);
		for(int j = 0; j < iRefCount; j++)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type( tRefListTag[j], &pcTypeName), TD_LOG_ERROR_AND_THROW);
			if(tc_strcmp(pcTypeName,TD_DIV_PART_REV)==0)
			{
				//Building the preference based on TD_PART_TYPE_ATTR
				string szpref ="";
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRefListTag[j],TD_PART_TYPE_ATTR,&pcDivPartAttr),TD_LOG_ERROR_AND_THROW);
				if( (pcDivPartAttr != NULL) && (tc_strlen(pcDivPartAttr) > 0) )
				{
					szpref.append("TD4_").append(pcDivPartAttr).append("_Reviewer_Matrix");
					TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_values(szpref.c_str(),&iprefcount,&pcprefval),TD_LOG_ERROR_AND_THROW);
						
				}
				for(int iTempPref=0;iTempPref<iprefcount;iTempPref++)
				{
						PrefValues.push_back(pcprefval[iTempPref]);
				}
				Custom_free(pcprefval);
				Custom_free(pcDivPartAttr);
			}
			Custom_free(pcTypeName);
		}
		//getting Unique Preference Values
		sort(PrefValues.begin(),PrefValues.end());
		vector<string>::iterator it = std::unique(PrefValues.begin(),PrefValues.end());
		PrefValues.erase(it,PrefValues.end());

		for(int iPfCnt = 0; iPfCnt < PrefValues.size();++iPfCnt)
		{
			vector<string> CoRqValues;
			string szPropname		="";
			string szPropvalue = PrefValues.at(iPfCnt);
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_propname_from_Preference( szPropvalue,techreviewerValues,szPropname,bcheck),TD_LOG_ERROR_AND_THROW);
			//Finding the project and getting the Reviewer Values as in the Preference
			for(int k=0;k<vimpprojValues.size();k++)
			{
                string szPropertyName="Tech";
				TERADYNE_TRACE_CALL(iStatus =teradyne_get_object_tag(vimpprojValues.at(k).c_str(),TD_PROJECT_FORM_TYPE,&projectTag),TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus =teradyne_get_arrayproperty_value(projectTag,szPropname,techreviewerValues,szPropertyName,bcheck),TD_LOG_ERROR_AND_THROW);
			}
		    
        }	
		char **pctechreviewerarray   = NULL,**pctechrevieweruserarray = NULL;
		//Converting vector to char** array and Setting Value on Standard ECN Revision
		TERADYNE_TRACE_CALL(iStatus =teradyne_convert_vector_to_array( techreviewerValues,&pctechreviewerarray),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus =teradyne_set_arrayproperty_value(tAttachtag,TD_REQ_TECH_REVIEWERS_ATTR,(int)techreviewerValues.size(),pctechreviewerarray),TD_LOG_ERROR_AND_THROW);
	
        Custom_free(pctechreviewerarray);
		for(int i=0;i<techreviewerValues.size();i++)
		{
			size_t pos = techreviewerValues.at(i).find(":");
			string szTechrevval=techreviewerValues.at(i);
	        if((szTechrevval.compare("Observer:"))==0)
			{
				for(int ts=i+1;ts<techreviewerValues.size();ts++)
				{
					size_t pos1 = techreviewerValues.at(ts).find(":");
					if(pos1 == -1)
				           i++;
					else
					  	break;
				}
				continue;
			}
			if(pos == -1)
			{
				techrevieweruserValues.push_back(techreviewerValues.at(i));
			}
		}
		
		//getting Unique Preference Values
		sort(techrevieweruserValues.begin(),techrevieweruserValues.end());
		vector<string>::iterator itr = std::unique(techrevieweruserValues.begin(),techrevieweruserValues.end());
		techrevieweruserValues.erase(itr,techrevieweruserValues.end());
		//Converting vector to char** array and Setting Value on Standard ECN Revision
		TERADYNE_TRACE_CALL(iStatus =teradyne_convert_vector_to_array( techrevieweruserValues,&pctechrevieweruserarray),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus =teradyne_set_arrayproperty_value(tAttachtag,TD_REQ_TECH_REVIEWERS_LIST_ATTR,(int)techrevieweruserValues.size(),pctechrevieweruserarray),TD_LOG_ERROR_AND_THROW);
		Custom_free(pctechrevieweruserarray);
	}
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_safety_value
 * Description				: Setting td4ReqdCBReviewersList  in ECN Revision
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tAttachtag   (I)	    - tag_t
 *							  vimpprojValues  (I)   - vector<string>
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 * NOTES					:
 ******************************************************************************/
int teradyne_get_safety_value( tag_t tAttachtag, bool &bSafety)
{

	int iStatus			    = ITK_ok,
		iSecCount           = 0;

	char *pcSecObjType     = NULL,
		 *pcPropVal        = NULL;

	tag_t *tSecObjects     = {NULLTAG},	      
		   tPrevRev	   = NULLTAG;

	vector<string> PrefValues,
		           techreviewerValues,
				   techrevieweruserValues;

	const char * __function__ = "teradyne_get_safety_value";
	TERADYNE_TRACE_ENTER();

			try 
	{
		//Getting Parts under Solution Item Folder
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttachtag, TD_SOLUTION_ITEMS_REL_NAME, &iSecCount, &tSecObjects), TD_LOG_ERROR_AND_THROW);
		for(int j = 0; j < iSecCount; j++) 
		{
			if(pcPropVal != NULL) pcPropVal = NULL;		
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecObjects[j], &pcSecObjType), TD_LOG_ERROR_AND_THROW);
			if((tc_strcmp(pcSecObjType, TD_DIV_PART_REV) == 0) || (tc_strcmp(pcSecObjType, TD_COMM_PART_REV) == 0))
			{ 				
				//checking the part has SafetyLicense as true
				TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tSecObjects[j], TD_DIS_SPEC_REL_NAME, TD_SAFETY_FORM_TYPE, 0, TD_SAFETY_LICENSE_ATTR, &pcPropVal), TD_LOG_ERROR_AND_THROW);
				if(pcPropVal == NULL)
				{
					//Check for the attribute in previous revision
					if(tPrevRev != NULLTAG) tPrevRev = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(tSecObjects[j], &tPrevRev),TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_pri_sec_object_propvalue(tPrevRev, TD_DIS_SPEC_REL_NAME, TD_SAFETY_FORM_TYPE, 0, TD_SAFETY_LICENSE_ATTR, &pcPropVal), TD_LOG_ERROR_AND_THROW);
				}
				if(pcPropVal != NULL && ((tc_strcmp(pcPropVal, "Yes") == 0) || (tc_strcmp(pcPropVal, "True") == 0))) 
				{
					bSafety = true;
					break;
				}				
				Custom_free(pcPropVal);
			}
			Custom_free(pcSecObjType);
		}
        Custom_free(tSecObjects);
	}
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
