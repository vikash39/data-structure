/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_revise_to_solution_item.cpp        
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-ReviseToSolutionItem action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  02-Jun-2015                       Haripriya                    	    Initial Creation
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>
#include <ecm\ecm.h>

/*******************************************************************************
 * Function Name			: teradyne_revise_to_solution_item
 * Description				: This function will revise the teradyne parts which are available in References attachment 
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Gets the teradyne parts from the reference attachments
 *							  2. Revises the parts and related the new revision to the target attachement with "Solution Items" Relation
 *							  3. Relates the latest revision with previous revision with CMSolutionToImpacted relation
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_revise_to_solution_item(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttaches	        = 0,
		iRefAttaches        = 0;
	char *pcObjectType		= NULL,
		 *pcTargetType		= NULL;
	tag_t *tRefAttaches     = NULL,
		  *tAttaches        = NULL,
		  tNewRevision		= NULLTAG;

	const char * __function__    = "teradyne_revise_to_solution_item" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if(msg.task != NULLTAG) 
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment,&iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcTargetType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcTargetType, TD_STD_ECN_REV_TYPE)) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_reference_attachment,&iRefAttaches, &tRefAttaches), TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < iRefAttaches; j++) 
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tRefAttaches[j], &pcObjectType), TD_LOG_ERROR_AND_THROW);
						if(!tc_strcmp(pcObjectType, TD_DIV_PART_REV)) 
						{	
							//Revising the part
							TERADYNE_TRACE_CALL(iStatus = ITEM_copy_rev(tRefAttaches[j],NULL,&tNewRevision), TD_LOG_ERROR_AND_THROW);
							if(tNewRevision != NULLTAG) {
								
								TERADYNE_TRACE_CALL(iStatus = teradyne_create_relation(TD_ECR_SOLREL_NAME, tAttaches[i],tNewRevision), TD_LOG_ERROR_AND_THROW);
								//Creating CMSolutionToImpacted relation between latest and previous revisions
								TERADYNE_TRACE_CALL(iStatus = teradyne_create_relation(TD_CM_SOLUTION_TO_IMPACTED_REL_NAME, tNewRevision,tRefAttaches[j]), TD_LOG_ERROR_AND_THROW);
							}
						}	
						Custom_free(pcObjectType);
					}
				}
				Custom_free(pcTargetType);
			}
		}
	}
	catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	Custom_free(tRefAttaches);
	
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_create_relation
 * Description				: Creates the relation
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : pcRelType   (I)	- Relation type name const char *
 *							  tPrimary  (I)      - Primary object tag_t
 *							  tSecondary  (I)      - Secondary object tag_t
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					:
 ******************************************************************************/
int teradyne_create_relation(const char* pcRelType, tag_t tPrimary, tag_t tSecondary)
{
	int iStatus			    = ITK_ok;
	tag_t tRelType			= NULLTAG,
		  tRelation			= NULLTAG;

	const char * __function__    = "teradyne_create_relation" ;
	TERADYNE_TRACE_ENTER();
	
	try {
		TERADYNE_TRACE_CALL ( iStatus = GRM_find_relation_type(pcRelType,&tRelType), TD_LOG_ERROR_AND_THROW);	
		if(tRelType != NULLTAG) {
		
			TERADYNE_TRACE_CALL ( iStatus = GRM_create_relation(tPrimary,tSecondary,tRelType,NULLTAG,&tRelation), TD_LOG_ERROR_AND_THROW);		
			if(tRelation != NULLTAG) {
			
				TERADYNE_TRACE_CALL ( iStatus = GRM_save_relation(tRelation), TD_LOG_ERROR_AND_THROW);
			}
		}
	}
	catch(...) {
		
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	return iStatus;
}