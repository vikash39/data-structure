/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_updatesupplierinformation.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-UpdateSupplierInformation action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  07-May-2015                       Vijayasekhar						Added function definition teradyne_updatesupplierinformation, teradyne_search_SBMForms_using_commodity_level1
#  14-May-2015                       Vijayasekhar						Modified input parameters for VMS_change_vendor api
#  10-Jun-2015                       Vijayasekhar						Modified the definition teradyne_vndr_part_comm_part_update_status setting the preferred status from relation tag instead of Vendor part revision
#  07-Jul-2015                       Vijayasekhar						Modified function teradyne_vndr_part_comm_part_update_status name and checked the Preferred status attribute value while changing the vendor
#  03-Sept-2016						 Nino/Karl							Modified teradyne_updatesupplierinformation, allow obsolete to be included in part transfer, obsolete will remain obsolete in new supplier
#  13-Sept-2016						 Karl								Modified teradyne_updatesupplierinformation, handle requests where the end result will be creating a duplicate vendor part(fix is to avoid creating duplicate vendor part and use existing)
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_updatesupplierinformation
 * Description				: Updates the supplier information6
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *							
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_updatesupplierinformation(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iRows					= 0,
		iVendorParts			= 0,
		iReturnedVParts			= 0;
	tag_t *tAttaches			= NULL,
		  tSbmForm				= NULLTAG,
		  tPartTag				= NULLTAG,
		  *tVendorParts			= NULL,
		  tOldVendor			= NULLTAG,
		  tNewVendor			= NULLTAG,
		  tVendorFound			= NULLTAG,
		  tVendorPartFound		= NULLTAG;
	void*** pvQueryResults		= NULL;
	char **pcOldPartIds			= NULL, 
		 **pcNewPartIds			= NULL, 
		 **pcNotes				= NULL,
		 *pcPartType			= NULL,
		 *pcObjectType			= NULL;

	string strPropNamesArr[]	= {TD_COMM_LVL1_EFFECT_ATTR, TD_OLD_SUPPLIER_ATTR, TD_NEW_SUPPLIER_ATTR};
	
	map<string,string> strPropNameValueMap;
	list<string> strAttrList( strPropNamesArr, strPropNamesArr + sizeof(strPropNamesArr) / sizeof(string) );

	
	const char * __function__ = "teradyne_updatesupplierinformation";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) {

			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {
		
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_SUPP_TRANSFER_REQ_REV_TYPE)) {
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tAttaches[i], strAttrList, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
					if(strPropNameValueMap.size() > 0) {
						//Getting the object tags for Old Vendor and New Vendor
						TERADYNE_TRACE_CALL(iStatus = ITEM_find_item(strPropNameValueMap[TD_OLD_SUPPLIER_ATTR].c_str(), &tOldVendor), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = ITEM_find_item(strPropNameValueMap[TD_NEW_SUPPLIER_ATTR].c_str(), &tNewVendor), TD_LOG_ERROR_AND_THROW);
						//Gets the sbm forms that has Commodity Level 1 attribute as same as Part Revision
						TERADYNE_TRACE_CALL(iStatus = teradyne_search_SBMForms_using_commodity_level1((char*)strPropNameValueMap[TD_COMM_LVL1_EFFECT_ATTR].c_str(), &iRows, &pvQueryResults), TD_LOG_ERROR_AND_THROW);
						for(int j = 0; j < iRows; j++) {
					
							tSbmForm = (*((tag_t*)pvQueryResults[j][0]));
							//Gets  primary objects of type Commercial Part Revision and Divisional Part Revision
							if(tPartTag != NULLTAG) { tPartTag = NULLTAG; }
							TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tSbmForm, TD_DIS_SPEC_REL_NAME, "", 1, &tPartTag), TD_LOG_ERROR_AND_THROW);
							if(tPartTag != NULLTAG) {
							
								TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPartTag, &pcPartType),TD_LOG_ERROR_AND_THROW);
								if(!tc_strcmp(pcPartType, TD_COMM_PART_REV) || !tc_strcmp(pcPartType, TD_DIV_PART_REV)) { 
									//Gets the Vendor Parts attached to the Teradyne part
									TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tPartTag, TD_VENDOR_REPERESENTS_REL_NAME, &iVendorParts, &tVendorParts), TD_LOG_ERROR_AND_THROW);
									for(int m = 0; m < iVendorParts; m++)
									{
										char *pcPrefStatusVal	= NULL;
										tVendorFound			= NULLTAG;
										TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tVendorParts[m], TD_VENDOR_PART_REL_NAME, TD_VENDOR, 0, &tVendorFound), TD_LOG_ERROR_AND_THROW);
										if(tVendorFound != NULLTAG && tVendorFound == tOldVendor)
										{
											TERADYNE_TRACE_CALL(iStatus = teradyne_vndr_part_comm_part_update_status(tPartTag, tVendorParts[m], "", true, &pcPrefStatusVal), TD_LOG_ERROR_AND_THROW);
											if(pcPrefStatusVal == NULL || tc_strlen(pcPrefStatusVal) <= 0 || tc_strcmp(pcPrefStatusVal,"Obsolete") == 0)
											{
												int iTerParts = 0; tag_t *tTerParts = NULL;
												TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tags(tVendorParts[m], TD_COMM_PARTS_ATTR, &iTerParts, &tTerParts), TD_LOG_ERROR_AND_THROW);
												vector<string> strPrefStatusVec;
												strPrefStatusVec.clear();
												for(int terPartCount = 0; terPartCount < iTerParts; ++terPartCount)
												{
													string strPrefVal = "BLANK";
													char *pcPrefStatusVal2 = NULL;
													TERADYNE_TRACE_CALL(iStatus = teradyne_vndr_part_comm_part_update_status(tTerParts[terPartCount], tVendorParts[m], "", true, &pcPrefStatusVal2), TD_LOG_ERROR_AND_THROW);
													if(pcPrefStatusVal2 != NULL && tc_strlen(pcPrefStatusVal2) > 0)
													{
														strPrefVal = pcPrefStatusVal2;
													}
													strPrefStatusVec.push_back(strPrefVal);
													TERADYNE_TRACE_CALL(iStatus = teradyne_delete_relation(tTerParts[terPartCount], tVendorParts[m], TD_VENDOR_REPERESENTS_REL_NAME), TD_LOG_ERROR_AND_THROW);
													Custom_free(pcPrefStatusVal2);
												}
												TERADYNE_TRACE_CALL(iStatus = VMS_change_vendor(NULLTAG, &tVendorParts[m], tNewVendor, 1, &iReturnedVParts, &pcOldPartIds, &pcNewPartIds, &pcNotes), TD_LOG_ERROR_AND_THROW);
												for(int terPartCount = 0; terPartCount < iTerParts; ++terPartCount)
												{
													tag_t tRepRelation = NULLTAG;
													TERADYNE_TRACE_CALL(iStatus = VMS_relate_vendor_part_to_comm_part(tTerParts[terPartCount], tVendorParts[m], NULL, &tRepRelation), TD_LOG_ERROR_AND_THROW);
													if(!strPrefStatusVec.empty() && strPrefStatusVec.at(terPartCount).compare("BLANK") != 0)
													{
														TERADYNE_TRACE_CALL(iStatus = teradyne_vndr_part_comm_part_update_status(tTerParts[terPartCount], tVendorParts[m], strPrefStatusVec.at(terPartCount)), TD_LOG_ERROR_AND_THROW);
													}
												}
												TERADYNE_TRACE_CALL(iStatus = teradyne_vndr_part_comm_part_update_status(tPartTag, tVendorParts[m], "Removed"), TD_LOG_ERROR_AND_THROW);
												if(tVendorFound != NULLTAG) tVendorFound = NULLTAG;
												if(tVendorPartFound != NULLTAG) tVendorPartFound = NULLTAG;
												TERADYNE_TRACE_CALL(iStatus = teradyne_get_object_from_item_id(pcOldPartIds[0], TD_MFG_PART, TD_VENDOR_PART_REL_NAME, TD_VENDOR, tNewVendor, &tVendorFound, &tVendorPartFound), TD_LOG_ERROR_AND_THROW);

												bool duplicateRelation = false;
												for(int k = 0; k < iVendorParts; k++)
												{
													if(tVendorPartFound == tVendorParts[k])
													{
														duplicateRelation = true;
													}
												}

												if(tVendorPartFound && !(duplicateRelation))
												{
													tag_t tRepRelation = NULLTAG;
													if (strcmp(pcPrefStatusVal, "Obsolete") == 0)
													{
														TERADYNE_TRACE_CALL(iStatus = VMS_relate_vendor_part_to_comm_part(tPartTag, tVendorPartFound, "Obsolete", &tRepRelation), TD_LOG_ERROR_AND_THROW);
													}
													else
													{
														TERADYNE_TRACE_CALL(iStatus = VMS_relate_vendor_part_to_comm_part(tPartTag, tVendorPartFound, NULL, &tRepRelation), TD_LOG_ERROR_AND_THROW);
													}
												}
												else if (tVendorPartFound && duplicateRelation)
												{
													if (strcmp(pcPrefStatusVal, "Obsolete") == 0)
													{
													TERADYNE_TRACE_CALL(iStatus = teradyne_vndr_part_comm_part_update_status(tPartTag, tVendorPartFound, "Obsolete"), TD_LOG_ERROR_AND_THROW);
													}
													else
													{
													TERADYNE_TRACE_CALL(iStatus = teradyne_vndr_part_comm_part_update_status(tPartTag, tVendorPartFound, ""), TD_LOG_ERROR_AND_THROW);
													}
												}
												Custom_free(tTerParts);
											}	
										}
										Custom_free(pcOldPartIds);
										Custom_free(pcNewPartIds);
										Custom_free(pcNotes);
										Custom_free(pcPrefStatusVal);
									}
									Custom_free(pcPartType);
								}
							}
							Custom_free(tVendorParts);
						}
					}
				}
				Custom_free(pvQueryResults);
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_search_SBMForms_using_commodity_level1
 * Description				: Will search the SBM forms that matches the commodity level 1 attribute
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : pcCommodityLvl	(I) - Commodity level1 attribute value char*
 *							: iRows(O) -  count int
 *							: pvQueryResults(OF) - pvQueryResults void****
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_search_SBMForms_using_commodity_level1(char* pcCommodityLvl, int* iRows, void**** pvQueryResults) {
	
	//Declartion and Initialization of Local Variables
	int iStatus					= ITK_ok;
	char* pcEnquiryID			= "Search Parts with Commodity Level 1 Value";
	const char* cpSelectAttrs[] = {"puid"};
	const int iActiveSeq		= 0;
	char *pcFormType            = TD_SBM_FORM_TYPE, 
		 **pcCBreviewerarray    = NULL;
	int iTotalCols				= 0;

	vector<string> pcCommLvl1Vec;

	const char* __function__ = "teradyne_search_SBMForms_using_commodity_level1";
	TERADYNE_TRACE_ENTER();

	try
	{
		if(pcCommodityLvl != NULL) {
			//tokenizing the string
			pcCommLvl1Vec = teradyne_generate_tokens(pcCommodityLvl, ",");
			TERADYNE_TRACE_CALL(iStatus = teradyne_convert_vector_to_array(pcCommLvl1Vec, &pcCBreviewerarray), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL( iStatus = POM_enquiry_create(pcEnquiryID), TD_LOG_ERROR_AND_THROW );
			TERADYNE_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs(pcEnquiryID, TD_FORM_CLASS, 1, cpSelectAttrs ),TD_LOG_ERROR_AND_THROW );
			TERADYNE_TRACE_CALL( iStatus = POM_enquiry_set_string_value ( pcEnquiryID, "CommodityLvl1", (int)pcCommLvl1Vec.size(), (const char**)pcCBreviewerarray, POM_enquiry_bind_value ),TD_LOG_ERROR_AND_THROW );
			TERADYNE_TRACE_CALL( iStatus = POM_enquiry_set_string_value ( pcEnquiryID, "formType", 1, (const char**)&pcFormType, POM_enquiry_bind_value ),TD_LOG_ERROR_AND_THROW );
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_int_value( pcEnquiryID,"active_seq_val", 1,&iActiveSeq, POM_enquiry_const_value),TD_LOG_ERROR_AND_THROW );
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_join_expr(pcEnquiryID,"join_expr",TD_WORKSPACEOBJECT_TYPE,TD_PUID_CONSTANT,POM_enquiry_equal,TD_FORM_CLASS,TD_PUID_CONSTANT),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_join_expr(pcEnquiryID,"join_expr1",TD_FORM_CLASS,TD_DATAFILE_PROP, POM_enquiry_equal,TD_SBM_FORM_STORAGE,TD_PUID_CONSTANT),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_attr_expr (pcEnquiryID, "expr1", TD_SBM_FORM_STORAGE, TD_COMMODITY_LEVEL_1, POM_enquiry_in, "CommodityLvl1"),TD_LOG_ERROR_AND_THROW);	
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_attr_expr (pcEnquiryID, "expr2", TD_WORKSPACEOBJECT_TYPE, TD_OBJECT_TYPE_ATTR, POM_enquiry_equal, "formType"),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_attr_expr (pcEnquiryID, "expr3", TD_WORKSPACEOBJECT_TYPE, TD_ACTIVE_SEQUENCE_ATTR, POM_enquiry_not_equal, "active_seq_val"),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_expr( pcEnquiryID,"expr4", "expr1",POM_enquiry_and,"expr2"),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_expr( pcEnquiryID,"expr5", "expr4",POM_enquiry_and,"expr3"),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_expr( pcEnquiryID,"expr6", "expr5",POM_enquiry_and,"join_expr"),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_expr( pcEnquiryID,"expr7", "expr6",POM_enquiry_and,"join_expr1"),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_where_expr (pcEnquiryID, "expr7"),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_execute (pcEnquiryID, iRows, &iTotalCols, pvQueryResults),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL( iStatus = POM_enquiry_delete(pcEnquiryID),TD_LOG_ERROR_AND_THROW );
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
		POM_enquiry_delete(pcEnquiryID);
	}
	Custom_free(pcCBreviewerarray);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_vndr_part_comm_part_update_status
 * Description				: Related the Vendor Part and Commercial Parts
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tCommPart	(I) - Commercial part revision tag_t
 *							: tVendorPart(I) - Vendor part revision tag_t
 *							: strPrefStatus(I) - preferred status attribute value string 
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_vndr_part_comm_part_update_status(tag_t tCommPart, tag_t tVendorPart, string strPrefStatus, bool bGetVal, char **pcPrefStatus) {

	int iStatus					= ITK_ok;
	tag_t tRelationTypeTag		= NULLTAG,
		  tRelationTag			= NULLTAG;

	const char * __function__ = "teradyne_vndr_part_comm_part_update_status";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VENDOR_REPERESENTS_REL_NAME,&tRelationTypeTag),TD_LOG_ERROR_AND_THROW);			
		TERADYNE_TRACE_CALL(iStatus=GRM_find_relation(tCommPart,tVendorPart,tRelationTypeTag,&tRelationTag),TD_LOG_ERROR_AND_THROW);
		if(tRelationTag != NULLTAG) {
			
			if(bGetVal)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRelationTag, TD_PREFERRED_STATUS_ATTR, pcPrefStatus), TD_LOG_ERROR_AND_THROW);
			}
			else 
			{
				if(strPrefStatus.length() > 0 && strPrefStatus.compare("") != 0) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRelationTag, TD_PREFERRED_STATUS_ATTR, strPrefStatus), TD_LOG_ERROR_AND_THROW);
				}
				else if(strPrefStatus.compare("") == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRelationTag, TD_PREFERRED_STATUS_ATTR, ""), TD_LOG_ERROR_AND_THROW);
				}
			}
				
		}

	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_get_object_from_item_id
 * Description				: Will get the object from the item id
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : pcItemId	(I) - item id const char*
 *							: tReqObjectType	(I) -  Object type const char*
 *							: pcRelName	(I) - Relation Name const char*
 *							: pcRelatedObjType	(I) - Related Object type const char*
 *							: tObjFound(O) - found object tag_t*
 *							: tFoundItem  (O) - found Item tag_t*
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_get_object_from_item_id(const char* pcItemId, const char* tReqObjectType, const char* pcRelName, const char* pcRelatedObjType, tag_t tVendorToCompare, tag_t* tObjFound, tag_t* tFoundItem) {

	int iStatus					= ITK_ok, 
		iItems					= 0;
	tag_t *tItems				= NULL;
	char *pcItemType			= NULL;

	const char * __function__ = "teradyne_get_object_from_item_id";
	TERADYNE_TRACE_ENTER();

	try {
		
		TERADYNE_TRACE_CALL(iStatus = ITEM_find(pcItemId, &iItems, &tItems), TD_LOG_ERROR_AND_THROW);
		for(int i = 0; i < iItems; i++) { 
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItems[i], &pcItemType), TD_LOG_ERROR_AND_THROW);
			if(!tc_strcmp(pcItemType, tReqObjectType)) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tItems[i], pcRelName, pcRelatedObjType, 0, tObjFound), TD_LOG_ERROR_AND_THROW);
				if(*tObjFound != NULLTAG && *tObjFound == tVendorToCompare) {
					*tFoundItem = tItems[i];
					break;
				}
			}
			Custom_free(pcItemType);
		}
											
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(pcItemType);
	Custom_free(tItems);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}