/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_assignstatus.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-AssignStatus action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  12-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_assignstatus and teradyne_add_release_status_to_objects
#  16-Apr-2015                       Haripriya                    	    Modified function teradyne_add_release_status_to_objects to apply release status to each object separately.
#  22-Apr-2015                       Haripriya                    	    Replaced TC_Attaches relation with TD_REF_MATERIAL_REL.
#  28-Apr-2015                       Vijayasekhar                    	Added code changes to relase BOM for the parts
#  07-May-2015						 Vijayasekhar                    	Added condition to check the suitable target objects
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_assignstatus
 * Description				: This function will release all the Parts and Documents in the Solution Items folder of an ECN
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Will get the parts and documents attached to the relation Solution Items and Datasets attached to the Files folder
 *							  2. Will create a release status instance for each Part and Document and add the release status to all the parts, documents,datasets and BOM.
 * NOTES					: 
 ******************************************************************************/
int teradyne_assignstatus(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iCount					= 0,
		iAttaches				= 0,
		iDataset				= 0,
		iBomCount				= 0;
	tag_t *tObjects				= NULL,
		  tReleased				= NULLTAG,
		  *tAttaches			= NULL,
		  *tDataset				= NULL,
		  *tBomViewRevs			= NULL,
		  tItemRev				= NULLTAG;
	char *pcAttachType			= NULL;

	const char * __function__ = "teradyne_assignstatus";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) {

			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) { 

				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOPART_ECN_REV_TYPE)) {
				
					//Getting the all the parts and documents from the solution Items folder and add release status to them
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iCount, &tObjects), TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < iCount; j++) {
						//Creates release status instance
						if(tReleased != NULLTAG)  tReleased = NULLTAG;
						TERADYNE_TRACE_CALL(iStatus = RELSTAT_create_release_status(TD_REL_STATUS_NAME, &tReleased), TD_LOG_ERROR_AND_THROW);
						if(tReleased != NULLTAG) {

							TERADYNE_TRACE_CALL(iStatus = RELSTAT_add_release_status(tReleased, 1, &tObjects[j], true), TD_LOG_ERROR_AND_THROW);
							//Gets all the Datasets in Files folder add release status to them for parts which are released
							TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tObjects[j], TD_REF_MATERIAL_REL, &iDataset, &tDataset), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = RELSTAT_add_release_status(tReleased, iDataset, tDataset,true), TD_LOG_ERROR_AND_THROW);
							//Get all the BOM view revisions and release them
							TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tObjects[j], &iBomCount, &tBomViewRevs), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = RELSTAT_add_release_status(tReleased, iBomCount, tBomViewRevs,true), TD_LOG_ERROR_AND_THROW);
						}
						Custom_free(tDataset);
						Custom_free(tBomViewRevs);
					}
				}
				Custom_free(pcAttachType);
				Custom_free(tObjects);
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_add_release_status_to_objects
 * Description				: Will add the release status to the input objects
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : iCount (I)  - No of objects int
 *							: tag_t (I)   - List of objects tag_t*
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_add_release_status_to_objects(int iCount, tag_t *tObjects) {

	int iStatus					= ITK_ok;

	const char * __function__ = "teradyne_add_release_status_to_objects";
	TERADYNE_TRACE_ENTER();

	try {
			for(int i=0;i<iCount;i++)
			{
				tag_t tReleased				= NULLTAG;

				TERADYNE_TRACE_CALL(iStatus = RELSTAT_create_release_status(TD_REL_STATUS_NAME, &tReleased), TD_LOG_ERROR_AND_THROW);
				if(tReleased != NULLTAG) 
				{
					TERADYNE_TRACE_CALL(iStatus = RELSTAT_add_release_status(tReleased, 1, &tObjects[i], true), TD_LOG_ERROR_AND_THROW);
				}
			}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}