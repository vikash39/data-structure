/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_updatingteradynepartswithcomplianceattributes.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-UpdateCmplAttrs action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  30-Mar-2015                       Haripriya                          Initial Creation
#  29-May-2015						 Kameshwaran D						Code is moved to common.cpp inside function teradyne_UpdateTerPartRevComplAtr               	    Initial Creation
#  10-Jun-2015						 Haripriya						    Code is modified as per the latest requirement
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_updatingteradynepartswithcomplianceattributes
 * Description				: This handler Updates TER part Revision with compliance attributes
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					: 
 *************************************  *****************************************/
int teradyne_updatingteradynepartswithcomplianceattributes(EPM_action_message_t msg)
{
	int iStatus					= ITK_ok,
		iAttachCount            = 0,
		iPriObjCount            = 0;
		
	char *pcattachtype          = NULL;

	tag_t *tAttaches            = NULL,
		   tRelationTypeTag     = NULLTAG,
		   *tPriObjTag          = NULL;

	const char * __function__ = "teradyne_updatingteradynepartswithcomplianceattributes";

	try 
	{	
		if(msg.task != NULLTAG) 
		{
			 //Getting all the Attachments from Target folder
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus =teradyne_ask_object_type(tAttaches[i],&pcattachtype),TD_LOG_ERROR_AND_THROW);
				//Checking whether the object type is VendorPart
				if(tc_strcmp(pcattachtype,TD_MFG_PART) == 0)
				{
					//Getting all the Teradyne Parts under CommercialParts PseudoFolder
					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VENDOR_REPERESENTS_REL_NAME,&tRelationTypeTag),TD_LOG_ERROR_AND_THROW);			
					TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tAttaches[i],tRelationTypeTag,&iPriObjCount,&tPriObjTag),TD_LOG_ERROR_AND_THROW);

					for(int j = 0; j < iPriObjCount; j++) 
					{
						tag_t tLatestRev = NULLTAG,*tstatusTag	= {NULLTAG};
						char *pcRelStatusType       = NULL, *pcObjectType = NULL;
						int iRelCnt = 0;
						
						//Check for Type If Commercial Part check if latest working if Divisional Part check if latest release else continue; loop
							
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPriObjTag[j], &pcObjectType),TD_LOG_ERROR_AND_THROW);
						
						if(tc_strcmp(pcObjectType,TD_DIV_PART_REV) == 0) 
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_latest_rev_from_rev(tPriObjTag[j], &tLatestRev), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = WSOM_ask_release_status_list(tLatestRev,&iRelCnt,&tstatusTag),TD_LOG_ERROR_AND_THROW);
							
							for(int i=0; i < iRelCnt; i++) 
							{
								
								TERADYNE_TRACE_CALL(iStatus = RELSTAT_ask_release_status_type(tstatusTag[i], &pcRelStatusType) ,TD_LOG_ERROR_AND_THROW);
								if(tc_strcmp(pcRelStatusType, TD_REL_STATUS_NAME) == 0) 
								{
									TERADYNE_TRACE_CALL(iStatus = teradyne_updateComplianceAttributes(tRelationTypeTag,tLatestRev), TD_LOG_ERROR_AND_THROW);
								}
							}
						} 
						else if (tc_strcmp(pcObjectType,TD_COMM_PART_REV) == 0) 
						{
							TERADYNE_TRACE_CALL(iStatus = teradyne_latest_rev_from_rev(tPriObjTag[j], &tLatestRev), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_updateComplianceAttributes(tRelationTypeTag,tLatestRev), TD_LOG_ERROR_AND_THROW);
						}
					
						Custom_free(pcObjectType);
						Custom_free(pcRelStatusType);
					}
				}
			}
		}
	}
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(tAttaches);
	Custom_free(pcattachtype);
	Custom_free(tPriObjTag);
	
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

int teradyne_updateComplianceAttributes(tag_t tRelationTypeTag, tag_t tLatestRev) 
{
	int iStatus	= ITK_ok,
		iSecObjCount            = 0;
	
	tag_t	*tSecObjTag          = NULL;
	
	map<string,string> strPropNameValueMap;

	vector<double> vMaxProcValues,vMaxDurValues;
    vector<string> vMoistureValues,vAttValues;

	bool bMoisture               = false;
	
	string strTerPart_Attr[]    = {TD_MAX_PROCESS_ATTR,TD_DURATION_MAX_ATTR,TD_MOISTURE_SENSITIVITY_ATTR,TD_ATTACHMENT_FINISH_ATTR};

	string szMoisture           = "";

	string szattfin  = "";

	const char * __function__ = "teradyne_updateComplianceAttributes";

	try 
	{	
		//Getting all the Vendor Parts under VendorParts PseudoFolder
		TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tLatestRev,tRelationTypeTag,&iSecObjCount,&tSecObjTag),TD_LOG_ERROR_AND_THROW);
		for(int k = 0; k < iSecObjCount; k++) 
		{
			tag_t tRelationTag = NULLTAG;
			char *pcPrefStatus = NULL;
		
			//Getting the relation between VendorPart and TeradynePart.
			TERADYNE_TRACE_CALL(iStatus=GRM_find_relation(tLatestRev,tSecObjTag[k],tRelationTypeTag,&tRelationTag),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus=AOM_ask_value_string(tRelationTag,TD_PREFERRED_STATUS_ATTR,&pcPrefStatus),TD_LOG_ERROR_AND_THROW);
		
			//if preferred_status value is null then updating properties in Teradyne Part Revision
			if( (tc_strlen(pcPrefStatus) == 0) || (tc_strcmp(pcPrefStatus,"Obsolete") == 0) )
			{
				list<string> strAttrList( strTerPart_Attr, strTerPart_Attr + sizeof(strTerPart_Attr) / sizeof(string) );
				//Getting all the Properties from VendorPart
				TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tSecObjTag[k], strAttrList, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);
			
				//Inserting Values into Vector
				vMaxProcValues.push_back(atoi(strPropNameValueMap.find(TD_MAX_PROCESS_ATTR)->second.c_str()));
				vMaxDurValues.push_back(atoi(strPropNameValueMap.find(TD_DURATION_MAX_ATTR)->second.c_str()));
				vAttValues.push_back(strPropNameValueMap.find(TD_ATTACHMENT_FINISH_ATTR)->second);
				if(strPropNameValueMap.find(TD_ATTACHMENT_FINISH_ATTR)->second.length()==0)
				{
					bMoisture =true;
				}
				if(strPropNameValueMap.find(TD_MOISTURE_SENSITIVITY_ATTR)->second.length()>0)
				{
					szMoisture=strPropNameValueMap.find(TD_MOISTURE_SENSITIVITY_ATTR)->second;
				}
								
				if((szMoisture.compare("Does not meet") == 0) || (szMoisture.compare("Not Applicable") == 0) )
				{
					//Do Nothing
				}
				else if(szMoisture.length()>0 )
				{
					vMoistureValues.push_back(szMoisture);
				}
								
			}
		
			Custom_free(pcPrefStatus);
		}
	
		stringstream DurValue,ProcValue; 
		POM_AM__set_application_bypass(true);
		//If Vectors are not empty teradynePartRevision Properties are Updating
		if(!vMaxProcValues.empty())
		{
			sort(vMaxProcValues.begin(),vMaxProcValues.end());
			ProcValue << vMaxProcValues.front();
			TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tLatestRev,TD_MAX_PROCESS_ATTR,ProcValue.str()),TD_LOG_ERROR_AND_THROW);
			vMaxProcValues.clear();
		}
		if(!vMaxDurValues.empty())
		{
			sort(vMaxDurValues.begin(),vMaxDurValues.end());
			DurValue << vMaxDurValues.front();
			TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tLatestRev,TD_DURATION_MAX_ATTR,DurValue.str()),TD_LOG_ERROR_AND_THROW);
			vMaxDurValues.clear();
		}
		if(!vMoistureValues.empty())
		{
			sort(vMoistureValues.begin(),vMoistureValues.end());
			TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tLatestRev,TD_MOISTURE_SENSITIVITY_ATTR,vMoistureValues.back().c_str()),TD_LOG_ERROR_AND_THROW);
			vMoistureValues.clear();
		}
		else
		{
			TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tLatestRev,TD_MOISTURE_SENSITIVITY_ATTR,"UNKNOWN"),TD_LOG_ERROR_AND_THROW);
		}
		if(!vAttValues.empty())
		{
			sort(vAttValues.begin(),vAttValues.end());
			vector<string>::iterator it = std::unique(vAttValues.begin(),vAttValues.end());
			vAttValues.erase(it,vAttValues.end());
			if(vAttValues.size()==1)
			{
				szattfin=vAttValues.front();
			}
			else
			{
				szattfin="MIXED";
			}
			TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tLatestRev,TD_ATTACHMENT_FINISH_ATTR,szattfin.c_str()),TD_LOG_ERROR_AND_THROW);		
			vAttValues.clear();
		}
		if(bMoisture)
		{
			TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tLatestRev,TD_ATTACHMENT_FINISH_ATTR,"UNKNOWN"),TD_LOG_ERROR_AND_THROW);		
		}
		POM_AM__set_application_bypass(false);
	
	}
	catch(...) 
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }

	Custom_free(tSecObjTag);
	
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}