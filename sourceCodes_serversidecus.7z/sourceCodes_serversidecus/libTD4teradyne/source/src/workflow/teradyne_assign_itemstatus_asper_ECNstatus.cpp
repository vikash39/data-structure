/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_assign_itemstatus_asper_ECNstatus.cpp        
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-AssignItemStatus action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  17-Mar-2015						Kameshwaran D						Intital creation
#  29-Apr-2015                      Vijayasekhar                    	Added condition to check target attachments of type ReleaseECN
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_assign_itemstatus_asper_ECNstatus
 * Description				: This function set the Effective date on ECN and Part
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Find the td4ECNtype atrribute value.
 *							  2. Get the Teradyne parts in solution folder
 *							  3. If Type is Pre-production/Production then set 
 *							  4. Change admin form attribute "Item status" accordingly in teradyne parts
 * NOTES					: 
 ******************************************************************************/
int teradyne_assign_itemstatus_asper_ECNstatus(EPM_action_message_t msg)
{

	int iStatus					= ITK_ok,
		iCount					= 0;

	tag_t *tAttaches			= NULL,
		  tRelationTag			= NULLTAG,
		  tSecObj				= NULLTAG;
	char *pcObjectType			= NULL;
	string strReleECNAttr[]		= {TD_ECN_TYPE_ATTR},
		   strECNType			= "";

	std::map<string,string> strReleaseECNValueMap;

	std::vector<tag_t>	tVecTerPart;

	const char * __function__ = "teradyne_assign_itemstatus_asper_ECNstatus";
	TERADYNE_TRACE_ENTER();

	try{
		
		if(msg.task != NULLTAG) 
		{ 
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iCount; i++) 
			{
				std::list<string> strReleECNAttrList( strReleECNAttr, strReleECNAttr + sizeof(strReleECNAttr) / sizeof(string) );
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE)) {//checking for the target object of type Release ECN
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tAttaches[i],strReleECNAttrList,strReleaseECNValueMap),TD_LOG_ERROR_AND_THROW);

					if(strReleaseECNValueMap.size() > 0)
					{
						//Assign td4ECNType value here 
						strECNType.assign(strReleaseECNValueMap.find(TD_ECN_TYPE_ATTR)->second);
					}

					//Check is ECN type is Preproduction / Production
					if(strECNType == "PreProduction Release" || strECNType == "Production Release")
					{
						string strECNTypeChgAdmin = "";
						size_t iVecSize = 0;

						//Since Both the LOV is different here we set accordingly
						if(strECNType == "PreProduction Release") strECNTypeChgAdmin = "Pre-Production";
						else if(strECNType == "Production Release") strECNTypeChgAdmin = "Production";

						//Get all the teradyne parts from the Solution item folder
						TERADYNE_TRACE_CALL(iStatus = teradyne_getteradynpart_in_solution_folder(tAttaches[i],&tVecTerPart), TD_LOG_ERROR_AND_THROW);

						iVecSize = tVecTerPart.size();

						if( iVecSize > 0 )
						{
							//This loop is to find
							for ( int iCount = 0;iCount < iVecSize ;iCount++ )
							{		
								//To get the Change admin form from Teradyne parts
								TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tVecTerPart.at(iCount), TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, &tSecObj), TD_LOG_ERROR_AND_THROW);

								//Update the td4Itemstatus value in change admin form
								TERADYNE_TRACE_CALL(iStatus= teradyne_setproperty_value(tSecObj,TD_ITEM_STATUS_ATTR,strECNTypeChgAdmin), TD_LOG_ERROR_AND_THROW);
							}
						}
					}
				}
				Custom_free(pcObjectType);
			}
		}
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}

/*******************************************************************************
 * Function Name			: teradyne_getteradynpart_in_solution_folder
 * Description				: This function get teradyne part in solution folder of ECN
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Get all items in solution folder
 *							  2. check the item is a teradyne part or not
 *							  3. If yes then push into vector 
 *							  4. will return a vector consist of teradyne parts.
 * NOTES					: 
 ******************************************************************************/
int teradyne_getteradynpart_in_solution_folder(tag_t tRevTag,std::vector<tag_t>	*tVecTeradyneParts)
{
	int iStatus					= ITK_ok,
		iObjCount				= 0;

	tag_t tRelationTag			= NULLTAG,
		  *tFindObjTag			= NULL;

	char *pcTypeName = NULL;

	const char * __function__ = "teradyne_getteradynpart_in_solution_folder";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get realtion tag for solution items
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_SOLUTION_ITEMS_REL_NAME,&tRelationTag),TD_LOG_ERROR_AND_THROW);	
		//List all the Teradyne part under solution item folder
		TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tRevTag,tRelationTag,&iObjCount,&tFindObjTag),TD_LOG_ERROR_AND_THROW);

		for(int iPos = 0 ; iPos < iObjCount ; iPos++)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tFindObjTag[iPos],&pcTypeName),TD_LOG_ERROR_AND_THROW);

			string strPcTypName(pcTypeName);

			if( (strPcTypName.compare(TD_DIV_PART_REV) == 0) || (strPcTypName.compare(TD_COMM_PART_REV) == 0) )
			{
				tVecTeradyneParts->push_back(tFindObjTag[iPos]);
			}
			
		}

	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}

	}

	Custom_free(tFindObjTag);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}

