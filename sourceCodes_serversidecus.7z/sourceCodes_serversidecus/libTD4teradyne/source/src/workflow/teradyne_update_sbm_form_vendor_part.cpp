/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_update_sbm_form_vendor_part.cpp       
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-UpdateTERPartInternalStatus action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  20-Mar-2015						Kameshwaran D						intital creation
#  05-May-2015					    Vijayasekhar                    	Added condition to check the suitable target objects
#  11-May-2015					    Vijayasekhar                    	Added warning message.
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>
#include <Windows.h>
/*******************************************************************************
 * Function Name			: teradyne_update_sbm_form_vendor_part
 * Description				: This function to update the Internal part status attribute of SBM form
 *							  of teradyne part under vendor part.
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. 
 * NOTES					: 
 ******************************************************************************/
int teradyne_update_sbm_form_vendor_part(EPM_action_message_t msg) {
	int iStatus					= ITK_ok,
		iCount					= 0,
		iUpdateStatus			= 2;

	tag_t *tAttaches			= NULL;
	char *pcAttachType			= NULL;

	const char * __function__	= "teradyne_update_sbm_form_vendor_part";
	
	TERADYNE_TRACE_ENTER();

	try {
			if(msg.task != NULLTAG) { 

				//MessageBox(NULL,(LPCWSTR)L"The workflow is now identifying the Teradyne parts this vendor part is related to. This may take some time and you will be unable to perform any other work while this is in progress.", (LPCWSTR)L"Warning", MB_ICONWARNING | MB_OK );
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iCount, &tAttaches), TD_LOG_ERROR_AND_THROW);
				for(int i = 0; i < iCount; i++) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcAttachType, TD_DISCON_DOC_REV_TYPE)) { 
					
						TERADYNE_TRACE_CALL(iStatus = teradyne_part_related_to_vendor_part_operation(tAttaches[i],iUpdateStatus),TD_LOG_ERROR_AND_THROW);
					}
					Custom_free(pcAttachType);
				}
			}
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(tAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;

}