/*=================================================================================================
#                Copyright (c) 2014 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_genECNSummaryReport.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains functions related to Teradyne-GenerateECNSummaryReport action handler,
#								   which is used to create ECN-summary report.
#      Project         :           libTD4teradyne
#      Author          :           Selvanayaki
#  =================================================================================================
#  Date                              Name                               Description of Change
#  25-Nov-2014                       Selvanayaki                    	Added function definitions teradyne_genECNSummaryReport
#  15-Apr-2015                       Haripriya                    	    Modified the function to set POM Bypass.
#  06-May-2015                       Selvanayaki                    	Modified the code to support ProcessHistory.
#  02-Aug-2015                       Selvanayaki                    	Modified the code to support ECNType of ReleaseECN.
#  25-Aug-2015                       Haripriya                    	    Modified the teradyne_get_ECNRelationPropertyattrvalue fn to get td4StandardDescription and td4description value for DivpartRevision and CommpartRevision respectively.
#  27-Aug-2015                       Haripriya                    	    Modified the teradyne_write_excelfile fn to delete excel file in pcECNReportFileLoc
#  04-Sep-2015                       Haripriya                    	    Modified the teradyne_get_ECN_effectivity fn in tokenising the start date of the effectivity
#  15-Sep-2015                       Haripriya                    	    Modified the teradyne_get_ECNRelationPropertyattrvalue fn.
#  16-Sep-2015                       Manimaran                          Added TD_OBJECT_TYPE_ATTR to strECNDocColVal[].
#  23-Sep-2015                       Manimaran                          Modified the teradyne_write_excelfile function to fix BOM compare issue.
#  25-Sep-2015                       Manimaran                          Commented the code to convert xls to xlsx.
#  08-Oct-2015                       Manimaran                          Modified the code to use Single level (with reference designator) mode for BOM compare.
#  16-Oct-2015                       Manimaran                          Modified the code to display only the effectivity start date in the summary report.
#  27-Oct-2015                       Manimaran                          Added function definition teradyne_get_description.
#  19-Nov-2015                       Manimaran                          Modified the code to list the delta reference designator values in the summary report.
#  01-Mar-2016                       Manimaran                          Modified the code to compare with previous revision if there is an assembly in the solution items folder of Release ECN.
#  25-Mar-2016                       Haripriya                    	    Modified the teradyne_get_description fn to get OOTB description for object type other than Divisional and commercial part revision.
#  20-Apr-2016                       Manimaran                          Modified the code to skip BOM compare for Release ECN.
#  02-Aug-2016						 Kameshwaran					  	Added Notice to summary report if sol item is prototype for Release ECN.
#  02-Aug-2016						 Kameshwaran						Modified Char[] -> String accomodate larger string in report.
#  09-Aug-2016                       Manimaran                          Added code to release the ecn summary report dataset.
#  24-Aug-2016						 Haripriya						    Modified teradyne_write_excelfile function to get itemstatus property only for DivpartRevision under SolutionItem Folder
#  19-Sep-2016                       Rodji                              Added functionality for sorting process history report
#  23-Sep-2016                       Manimaran                          Added td4ECNType check for ReleaseECN Revision.
#  15-Jan-2018                       Marjorie                           Modified function teradyne_update_htmlcontentPair to display leading zero in MinShip/RevStamp in ECN summary.
#  $HISTORY$
#  =================================================================================================*/
#include <workflow/teradyne_handlers.h>


typedef map<string, string> MapProcessHistory;

struct ProcessHistoryComparator {
	bool operator()(MapProcessHistory processOne, MapProcessHistory processTwo) {
		return (processOne.find(TD_ECN_PROCESS_END_DATE_VAL)->second < processTwo.find(TD_ECN_PROCESS_END_DATE_VAL)->second);
	}
};


string cHtMLFileContent = "";
/*******************************************************************************
 * Function Name			: teradyne_genECNSummaryReport
 * Description				: This function will populates the action handler
 *							  Teradyne-GenerateECNSummaryReport
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to workflow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 *
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_genECNSummaryReport(EPM_action_message_t msg)
{
	int iStatus = ITK_ok;
	int	iImpObjCount = 0;
	int	iDocObjCount = 0;
	int	iSolObjCount = 0;
	int	iAttachCount = 0;
	int iAttrCnt = 0;

	tag_t *ptAttaches = NULL;
	tag_t tSecObjs = NULLTAG;
	tag_t tRelationTag = NULLTAG;
	tag_t *tImpObjFoundTag = NULL;
	tag_t *tSolObjFoundTag = NULL;
	tag_t *tDocObjFoundTag = NULL;
	tag_t tObjFound = NULLTAG;

	char *pcTypeName = NULL;
	char *pcECNClosureStsValue = NULL;
	char *pcAttrValue = NULL;
	char *pcECNTypeValue = NULL;

	string szECNName = "";
	string strImpandSolItmColVal[] = { TD_ITEM_ID_ATTR,TD_OBJECT_DESC_ATTR,TD_OBJECT_TYPE_ATTR,TD_ITEM_REV_ID_ATTR, TD_PART_REV_STAMP, TD_PART_MIN_SHIPPABLE_REV };
	string strECNDocColVal[] = { TD_ECN_SUPP_DOC_NAME,TD_OBJECT_DESC_ATTR,TD_OBJECT_TYPE_ATTR };
	string strECNReportAttr[] = { TD_ECN_COLTIT_NO,TD_ECN_COLTIT_TYPE,TD_ECN_COLTIT_CREATOR,TD_ECN_COLTIT_PR_NO,TD_ECN_COLTIT_SYNOP,TD_ECN_COLTIT_CN,TD_ECN_COLTIT_PRIMARY_PRJ,TD_ECN_COLTIT_PRIORITY,TD_ECN_COLTIT_REASON,TD_ECN_COLTIT_DESC,TD_ECN_COLTIT_PROPOSED_SOLU,TD_ECN_COLTIT_REWORK_INSTR_SUMM,TD_ECN_COLTIT_EST_RWK_COST,TD_ECN_COLTIT_EST_SCRAP_COST,TD_ECN_COLTIT_MATL_IMP,TD_ECN_COLTIT_GCS_INV,TD_ECN_COLTIT_REWORK_GCS_FIELD,TD_ECN_COLTIT_PUP_NO,TD_ECN_COLTIT_DEPT_NO,TD_ECN_COLTIT_REV_STAMP,TD_ECN_COLTIT_UPD_MIN_SHIP_REV,TD_ECN_COLTIT_OTHER_IP };
	string strECNAttr[] = { TD_ITEM_ID_ATTR,TD_OBJECT_TYPE_ATTR,TD_ECN_OWN_USER,TD_ECN_PR_NO,TD_ECN_SYNOP,TD_ECN_CN,TD_ECN_PRIMARY_PRJ,TD_ECN_PRIORITY,TD_ECN_REASON,TD_ECN_DESC,TD_ECN_PROPOSED_SOLU,TD_ECN_REWORK_INSTR_SUMM,TD_ECN_EST_RWK_COST,TD_ECN_EST_SCRAP_COST,TD_ECN_MATL_IMP_STD,TD_ECN_GCS_INV,TD_ECN_REWORK_GCS_FIELD,TD_ECN_PUP_NO,TD_ECN_DEPT_NO,TD_ECN_REV_STAMP,TD_ECN_UPD_MIN_SHIP_REV,TD_ECN_OTHER_IP };
	int iRELECNAttrIndex[12] = { 3,5,8,10,11,12,13,14,15,16,17,20 };
	int iBOMECNAttrIndex[7] = { 3,5,10,15,16,17,21 };

	std::map<string, string> strECNPropNameValueMap;
	std::map<string, string> strECNRelationPropValueMap;

	vector<string> resPropValVec;
	vector<string> resImpValVec;
	vector<string> resSolValVec;
	vector<string> resECNDocValVec;
	vector<string> resECNProcessVec;
	vector<string> resECNEffVec;

	const char * __function__ = "teradyne_genECNSummaryReport";
	TERADYNE_TRACE_ENTER();

	try {
		if (msg.task != NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
			for (int i = 0; i < iAttachCount; i++)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
				//request will be processed for the below specified item revisions
				if (pcTypeName != NULL && ((tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_PROTOPART_ECN_REV_TYPE) == 0)))
				{
					if (tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0)
					{
						strECNAttr[1].assign(TD_ECN_TYPE_ATTR);
						for (iAttrCnt = 0; iAttrCnt < 12; iAttrCnt++)
						{
							strECNAttr[iRELECNAttrIndex[iAttrCnt]].assign(TD_ECN_NULL_ATTR);
						}
					}

					if (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0)
					{
						for (iAttrCnt = 0; iAttrCnt < 7; iAttrCnt++)
						{
							strECNAttr[iBOMECNAttrIndex[iAttrCnt]].assign(TD_ECN_NULL_ATTR);
						}
						strECNAttr[14].assign(TD_ECN_MATL_IMP);
					}

					std::list<string> strAttrList(strECNAttr, strECNAttr + sizeof(strECNAttr) / sizeof(string));

					//calling function to get ECN Related Properties and value	
					setgNULLPropertyExecution(true);
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptAttaches[i], strAttrList, strECNPropNameValueMap), TD_LOG_ERROR_AND_THROW);
					setgNULLPropertyExecution(false);
					if (strECNPropNameValueMap.size() > 0)
					{
						szECNName.assign(strECNPropNameValueMap.find(TD_ITEM_ID_ATTR)->second);
						int iTypesize = (int)strAttrList.size();
						for (iAttrCnt = 0; iAttrCnt < iTypesize; iAttrCnt++)
						{
							if ((strECNAttr[iAttrCnt] == TD_ECN_EST_RWK_COST) || (strECNAttr[iAttrCnt] == TD_ECN_EST_SCRAP_COST))
							{
								string sTemp = "$";
								sTemp.append(strECNPropNameValueMap.find(strECNAttr[iAttrCnt])->second);
								resPropValVec.push_back(sTemp);
							}
							else if (strECNAttr[iAttrCnt] == TD_OBJECT_TYPE_ATTR)
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(ptAttaches[i], strECNAttr[iAttrCnt].c_str(), &pcAttrValue), TD_LOG_ERROR_AND_THROW);
								resPropValVec.push_back(pcAttrValue);
								Custom_free(pcAttrValue);
							}
							else
								resPropValVec.push_back(strECNPropNameValueMap.find(strECNAttr[iAttrCnt])->second);
						}
					}
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptAttaches[i], TD_ECN_CLOSURE_STATUS_ATTR, &pcECNClosureStsValue), TD_LOG_ERROR_AND_THROW);

					std::list<string> strECNRelationAttrList(strImpandSolItmColVal, strImpandSolItmColVal + sizeof(strImpandSolItmColVal) / sizeof(string));


					if (pcTypeName != NULL && ((tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_PROTOPART_ECN_REV_TYPE) == 0)))
					{
						//calling functions to get list of Impacted Items
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_ECNRelationPropertyattrvalue(ptAttaches[i], TD_ECR_IMPREL_NAME, strECNRelationAttrList, pcECNClosureStsValue, &iImpObjCount, &tImpObjFoundTag, resImpValVec), TD_LOG_ERROR_AND_THROW);
					}

					//calling functions to get list of Solution Items
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_ECNRelationPropertyattrvalue(ptAttaches[i], TD_ECR_SOLREL_NAME, strECNRelationAttrList, pcECNClosureStsValue, &iSolObjCount, &tSolObjFoundTag, resSolValVec), TD_LOG_ERROR_AND_THROW);

					//calling functions to get list of ECN supporting Documents
					std::list<string> strECNSupportingDocAttrList(strECNDocColVal, strECNDocColVal + sizeof(strECNDocColVal) / sizeof(string));
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_ECNRelationPropertyattrvalue(ptAttaches[i], TD_ECR_REL_NAME, strECNSupportingDocAttrList, "", &iDocObjCount, &tDocObjFoundTag, resECNDocValVec), TD_LOG_ERROR_AND_THROW);

					//calling functions to get list of ECN Process History
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_ECN_processhistory(msg.task, ptAttaches[i], resECNProcessVec), TD_LOG_ERROR_AND_THROW);

					//calling functions to get list of ECN Effectivity			
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_ECN_effectivity((char *)szECNName.c_str(), ptAttaches[i], resECNEffVec), TD_LOG_ERROR_AND_THROW);

					//functions to create and write content in Excel file.
					TERADYNE_TRACE_CALL(iStatus = teradyne_write_excelfile(ptAttaches[i], (char *)szECNName.c_str(), strECNReportAttr, resPropValVec, resImpValVec, resSolValVec, resECNDocValVec, resECNProcessVec, resECNEffVec, iImpObjCount, iSolObjCount, tImpObjFoundTag, tSolObjFoundTag, pcECNClosureStsValue), TD_LOG_ERROR_AND_THROW);

					Custom_free(tImpObjFoundTag);
					Custom_free(tSolObjFoundTag);
					Custom_free(tDocObjFoundTag);
					Custom_free(pcTypeName);
					Custom_free(pcECNTypeValue);
					Custom_free(pcECNClosureStsValue);
				}
				szECNName.clear();
				strECNPropNameValueMap.clear();
				strECNRelationPropValueMap.clear();
				resPropValVec.clear();
				resImpValVec.clear();
				resSolValVec.clear();
				resECNProcessVec.clear();
				resECNEffVec.clear();
			}
			Custom_free(ptAttaches);
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_write_excelfile
* Description		: Validating PartCategory & PartSubcategory
*                     attribute in DivPartRevision
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : Gets the PartCategory & PartSubcategory Value
*                     from DivisionalPartRevision and checks
*                     whether the value has NOTLISTED AND UNKNOWN Value
*                     and ifnot concatenates the value with hypen .
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_write_excelfile(tag_t tTargetObject, char *pcECNID, std::string strECNReportAttr[], std::vector<string> resPropValVec,
	std::vector<string> resImpValVec, std::vector<string> resSolValVec, std::vector<string> resECNDocValue, std::vector<string> resECNPRocessValue, std::vector<string> resECNEffVec,
	int iImpObjCount, int iSolObjCount, tag_t *tImpObjFoundTag, tag_t *tSolObjFoundTag, char *pcECNClosureStsValue)
{
	int iStatus = ITK_ok;
	int iAttrCnt = 0;
	int iTypesize = 0;

	char *cHtLFilePath = NULL;
	//char *cHtMLFileContent					= NULL;		
	char *pcECNProcess = NULL;
	char *pcSolItemid = NULL;
	char *pcImpItemid = NULL;
	char *pcDatasetID = NULL;
	char *pcECNReportFileLoc = NULL;
	char *pcTypeName = NULL;

	string strCurTimeStamp = "";
	string pcChangeID = "";
	string pcObjectID = "";
	string strOutXlsxPath = "";

	FILE *fHtMLFile = NULL;

	string strTerPart_Attr[] = { TD_ITEM_STATUS_ATTR };
	string strImpandSolItmColName[] = { TD_IMPSOL_NAME,TD_IMPSOL_DESC,TD_IMPSOL_TYPE,TD_IMPSOL_REV,TD_IMPSOL_REV_STAMP,TD_IMPSOL_MIN_SHIPPABLE_REV };
	string strImpandSolItmColNameWidth[] = { TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_2,TD_DIFFITEM_DEFAULT_WIDTH_2,TD_DIFFITEM_DEFAULT_WIDTH_2 };
	string strECNSupportingDocColName[] = { TD_DIFFITEM_NAME,TD_IMPSOL_DESC };
	string strECNSupportingDocColNameWidth[] = { TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1 };
	string strECNProcessColName[] = { TD_ECN_PROCESS_TASKNAME,TD_ECN_PROCESS_DECISION,TD_ECN_PROCESS_PERFORMER,TD_ECN_PROCESS_START_DATE,TD_ECN_PROCESS_END_DATE,TD_ECN_PROCESS_COMMENTS };
	string strECNProcessColNameWidth[] = { TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_2,TD_DIFFITEM_DEFAULT_WIDTH_2,TD_DIFFITEM_DEFAULT_WIDTH_2 };
	string strChangesColAttr[] = { TD_DIFFITEM_RESULT,TD_DIFFITEM_NAME,TD_IMPSOL_DESC,TD_DIFFITEM_SEQNO,TD_DIFFITEM_QTY,TD_DIFFITEM_REMARKS,TD_DIFFITEM_REFDES_FROM,TD_DIFFITEM_REFDES_TO,TD_DIFFITEM_REFDES_DELTA };
	string strECNEffColName[] = { TD_DIFFITEM_NAME,TD_EFF_TYPE,TD_ECN_PROCESS_START_DATE };
	string strChangesColAttrWidth[] = { TD_DIFFITEM_RESULT_WIDTH,TD_DIFFITEM_NAME_WIDTH,TD_DIFFITEM_DESC_WIDTH,TD_DIFFITEM_SEQNO_WIDTH,TD_DIFFITEM_QTY_WIDTH,TD_DIFFITEM_REMARKS_WIDTH,TD_DIFFITEM_REFDES_FROM_WIDTH,TD_DIFFITEM_REFDES_TO_WIDTH,TD_DIFFITEM_REFDES_DELTA_WIDTH };
	string strECNEffColNameWidth[] = { TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1,TD_DIFFITEM_DEFAULT_WIDTH_1 };
	string strConvrtXlsCmd = "";

	tag_t tImpitemtag = NULLTAG;
	tag_t tSolitemtag = NULLTAG;
	bool bNoticeFlag = "true";
	date_t curdate;

	vector<string> resBLDiffValue;

	bool  bObjectfound = false;

	char* __function__ = "teradyne_write_excelfile";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tTargetObject, &pcTypeName), TD_LOG_ERROR_AND_THROW);

		// MEM allocation of File
		cHtLFilePath = (char*)MEM_alloc(FILE_LEN * sizeof(char));
		pcObjectID.assign(TD_ECN_TITLE_VAL); pcObjectID.append(": "); pcObjectID.append(pcECNID);
		//getting current date and time
		TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp(TD_DATE_YMD_CONSTANT, strCurTimeStamp, curdate), TD_LOG_ERROR_AND_THROW);

		//Frame Html file content
		cHtMLFileContent.assign("<HTML xmlns:DBE=\"http://www.sdrc.com/metaphase/cf11bd\">\n<HEAD>\n</HEAD>\n<BODY><CENTER><FONT></FONT></CENTER><BR>");
		std::list<string> strImpandSolItmRAttrList(strImpandSolItmColName, strImpandSolItmColName + sizeof(strImpandSolItmColName) / sizeof(string));
		std::list<string> strImpandSolItmColWidthList(strImpandSolItmColNameWidth, strImpandSolItmColNameWidth + sizeof(strImpandSolItmColNameWidth) / sizeof(string));

		//updating Main Block in file
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_headingblock((char*)pcObjectID.c_str(), TD_HEADING_TYPE_1), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen("", false), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair(TD_ECN_TITLE, TD_ECN_TITLE_VAL, TD_TABLE_ROW_HEADER_VALUE, strImpandSolItmRAttrList, strImpandSolItmColWidthList, resImpValVec), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair(TD_ECN_REPORT_TITLE, (char*)strCurTimeStamp.c_str(), TD_TABLE_ROW_HEADER_VALUE, strImpandSolItmRAttrList, strImpandSolItmColWidthList, resImpValVec), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(false), TD_LOG_ERROR_AND_THROW);

		//updating ECN Related Propeties
		if (tc_strcmp(pcECNClosureStsValue, TD_ECN_CLOSURE_OPEN_STATUS) == 0) {
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_headingblock(TD_ECN_CLOSURE_STATUS, TD_HEADING_TYPE_1), TD_LOG_ERROR_AND_THROW);
		} else { 
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_headingblock(TD_ECN_RELATED_PROP_TITLE, TD_HEADING_TYPE_1), TD_LOG_ERROR_AND_THROW);
		}

		//Find ReleaseECN holds itemRev of Prototype then set Notice header
		if ((tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0))
		{
			char *pcECNType = NULL;
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tTargetObject, TD_ECN_TYPE_ATTR, &pcECNType), TD_LOG_ERROR_AND_THROW);
			for (int jCnt = 0; jCnt < iSolObjCount; jCnt++)
			{
				/**/
				if (bNoticeFlag) {//Need to add only one time if any prototype is found
					string strterItmStatus = "";
					char *pcSolTypeName = NULL;
					std::map<string, string>		strTerPropValueMap;

					list<string> strAttrLst(strTerPart_Attr, strTerPart_Attr + sizeof(strTerPart_Attr) / sizeof(string));
					//Added typecheck
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSolObjFoundTag[jCnt], &pcSolTypeName), TD_LOG_ERROR_AND_THROW);
					//Getting ItemStatus value only for DivisionalPartRevision unser Solution Item Folder
					if (tc_strcmp(pcSolTypeName, TD_DIV_PART_REV) == 0)
					{
						//Get the Item Status attribute value from teradyne part under solution folder
						TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tSolObjFoundTag[jCnt], strAttrLst, strTerPropValueMap), TD_LOG_ERROR_AND_THROW);

						strterItmStatus.assign(strTerPropValueMap.find(TD_ITEM_STATUS_ATTR)->second);
					}

					if ((strterItmStatus.compare("Prototype") == 0) && (tc_strcmp(pcECNType, "Production Release") == 0))
					{
						//Set Prototype Warning NOTICE header in report file
						cHtMLFileContent.append("\n<BR>");
						TERADYNE_TRACE_CALL(iStatus = teradyne_html_headingblock(TD_ECN_TILE_NOTICE_STATUS, TD_HEADING_TYPE_1), TD_LOG_ERROR_AND_THROW);
						cHtMLFileContent.append("\n<BR>");
						bNoticeFlag = "false";
						break;
					}
					Custom_free(pcSolTypeName);
				}
			}
			Custom_free(pcECNType);
		}

		TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen("", false), TD_LOG_ERROR_AND_THROW);
		iTypesize = (int)resPropValVec.size();
		for (iAttrCnt = 0; iAttrCnt < iTypesize; iAttrCnt++)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair((char*)strECNReportAttr[iAttrCnt].c_str(), (char*)resPropValVec[iAttrCnt].c_str(), TD_TABLE_ROW_HEADER_VALUE, strImpandSolItmRAttrList, strImpandSolItmColWidthList, resImpValVec), TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(false), TD_LOG_ERROR_AND_THROW);

		//updating Impacted Relation information
		if (resImpValVec.size() > 0)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen(TD_ECN_IMP_REL_TITLE, true), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair("", "", TD_TABLE_COL_HEADER_VALUE, strImpandSolItmRAttrList, strImpandSolItmColWidthList, resImpValVec), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(true), TD_LOG_ERROR_AND_THROW);
		} else { TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair(TD_ECN_IMP_REL_TITLE,TD_TABLE_NONE_VALUE, TD_TABLE_NONE_VALUE,strImpandSolItmRAttrList, strImpandSolItmColWidthList,resImpValVec),TD_LOG_ERROR_AND_THROW); }

		//updating Solution Related inform
		if (resSolValVec.size() > 0)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen(TD_ECN_SOL_REL_TITLE, true), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair("", "", TD_TABLE_COL_HEADER_VALUE, strImpandSolItmRAttrList, strImpandSolItmColWidthList, resSolValVec), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(true), TD_LOG_ERROR_AND_THROW);
		} else { TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair(TD_ECN_SOL_REL_TITLE,TD_TABLE_NONE_VALUE, TD_TABLE_NONE_VALUE, strImpandSolItmRAttrList, strImpandSolItmColWidthList,resImpValVec),TD_LOG_ERROR_AND_THROW); }


		//updating ECN Supporting Document list
		if (resECNDocValue.size() > 0)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_headingblock(TD_ECN_SUPP_DOC_TITLE, TD_HEADING_TYPE_2), TD_LOG_ERROR_AND_THROW);
			std::list<string> strECNSupportingDocColList(strECNSupportingDocColName, strECNSupportingDocColName + sizeof(strECNSupportingDocColName) / sizeof(string));
			std::list<string> strECNSupportingDocColWidthList(strECNSupportingDocColNameWidth, strECNSupportingDocColNameWidth + sizeof(strECNSupportingDocColNameWidth) / sizeof(string));
			TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair("", TD_ECN_REPORT_STEXT_SUPPDOCS, TD_TABLE_STATIC_TEXT, strECNSupportingDocColList, strECNSupportingDocColWidthList, resECNDocValue), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen("", false), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair("", "", TD_TABLE_COL_HEADER_VALUE, strECNSupportingDocColList, strECNSupportingDocColWidthList, resECNDocValue), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(true), TD_LOG_ERROR_AND_THROW);
		} else { TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair(TD_ECN_SUPP_DOC_TITLE,TD_TABLE_NONE_VALUE, TD_TABLE_NONE_VALUE,strImpandSolItmRAttrList, strImpandSolItmRAttrList, resECNDocValue),TD_LOG_ERROR_AND_THROW); }


		//updating ECN Effecctivity List
		if (resECNEffVec.size() > 0)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen(TD_EFF_TITLE, true), TD_LOG_ERROR_AND_THROW);
			std::list<string> strECNEffColList(strECNEffColName, strECNEffColName + sizeof(strECNEffColName) / sizeof(string));
			std::list<string> strECNEffColWidthList(strECNEffColNameWidth, strECNEffColNameWidth + sizeof(strECNEffColNameWidth) / sizeof(string));
			TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair("", "", TD_TABLE_COL_HEADER_VALUE, strECNEffColList, strECNEffColWidthList, resECNEffVec), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(true), TD_LOG_ERROR_AND_THROW);
		} else { TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair(TD_EFF_TITLE,TD_TABLE_NONE_VALUE, TD_TABLE_NONE_VALUE,strImpandSolItmRAttrList,strImpandSolItmColWidthList, resECNEffVec),TD_LOG_ERROR_AND_THROW); }


		//updating BOM Line information related to difference between impacted and solution Item
		if ((iImpObjCount > 0) || (iSolObjCount > 0))
		{
			std::list<string> strchangesColAttrList(strChangesColAttr, strChangesColAttr + sizeof(strChangesColAttr) / sizeof(string));
			std::list<string> strchangesColWidthList(strChangesColAttrWidth, strChangesColAttrWidth + sizeof(strChangesColAttrWidth) / sizeof(string));

			TERADYNE_TRACE_CALL(iStatus = teradyne_html_headingblock(TD_DIFFITEM_TITLE, TD_HEADING_TYPE_1), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair("", TD_ECN_REPORT_STEXT_BOMCHANGES, TD_TABLE_STATIC_TEXT, strchangesColAttrList, strchangesColWidthList, resBLDiffValue), TD_LOG_ERROR_AND_THROW);
			for (int jCnt = 0; jCnt < iSolObjCount; jCnt++)
			{
				//getting item tag and id of Solution Item
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSolObjFoundTag[jCnt], &tSolitemtag), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_id2(tSolitemtag, &pcSolItemid), TD_LOG_ERROR_AND_THROW);

				char *pcSolitemTypeName = NULL;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSolObjFoundTag[jCnt], &pcSolitemTypeName), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(pcSolitemTypeName, TD_DIV_PART_REV) != 0) {
					Custom_free(pcSolitemTypeName);
					continue;
				}
				Custom_free(pcSolitemTypeName);

				if (!pcChangeID.empty())
					pcChangeID.clear();

				pcChangeID.assign(TD_DIFFITEM_HEADER_1); pcChangeID.append(pcSolItemid);
				bObjectfound = false;
				for (int iCnt = 0; iCnt < iImpObjCount; iCnt++)
				{
					//getting item tag and id of Impacted Item
					TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tImpObjFoundTag[iCnt], &tImpitemtag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = ITEM_ask_id2(tImpitemtag, &pcImpItemid), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(pcImpItemid, pcSolItemid) == 0)
					{
						char *pcImpitemTypeName = NULL;
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tImpObjFoundTag[iCnt], &pcImpitemTypeName), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(pcImpitemTypeName, TD_DIV_PART_REV) != 0) {
							Custom_free(pcImpitemTypeName);
							continue;
						}
						Custom_free(pcImpitemTypeName);

						if (!resBLDiffValue.empty())
							resBLDiffValue.clear();

						iStatus = teradyne_list_bvr_diffs(tImpObjFoundTag[iCnt], tSolObjFoundTag[jCnt], resBLDiffValue);
						if (iStatus == 1)
						{
							iStatus = 0;
							TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen("", false), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair((char *)pcChangeID.c_str(), TD_NO_BOM_CHANGE_TEXT, TD_NO_BOM_CHANGE, strchangesColAttrList, strchangesColWidthList, resBLDiffValue), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(false), TD_LOG_ERROR_AND_THROW);
						}
						if (resBLDiffValue.size() <= 0)
						{
							Custom_free(pcImpItemid);
							bObjectfound = true;
							break;
						}

						TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen("", false), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair((char *)pcChangeID.c_str(), TD_DIFFITEM_HEADER_2, TD_TABLE_HEADER, strchangesColAttrList, strchangesColWidthList, resBLDiffValue), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair("", "", TD_TABLE_COL_HEADER_VALUE, strchangesColAttrList, strchangesColWidthList, resBLDiffValue), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(false), TD_LOG_ERROR_AND_THROW);

						bObjectfound = true;
						Custom_free(pcImpItemid);
						break;
					}
					Custom_free(pcImpItemid);
				}
				//updating BOM Line information related to solution Item which is not available in Impacted Item Folder
				if (!bObjectfound)
				{
					if (!resBLDiffValue.empty())
						resBLDiffValue.clear();

					char *pcECNTypeName = NULL;
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tTargetObject, &pcECNTypeName), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(pcECNTypeName, TD_REL_ECN_REV_TYPE) != 0) {
						tag_t tPrevRev = NULLTAG;
						bool bStatus = false;
						TERADYNE_TRACE_CALL(iStatus = teradyne_find_prev_revision(tSolObjFoundTag[jCnt], &tPrevRev), TD_LOG_ERROR_AND_THROW);
						if (tPrevRev != NULLTAG) {
							//Compare with previous revision if there is an assembly in the solution items folder of Release ECN
							iStatus = teradyne_list_bvr_diffs(tPrevRev, tSolObjFoundTag[jCnt], resBLDiffValue);
							if (iStatus == 1)
							{
								iStatus = 0;
								TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen("", false), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair((char *)pcChangeID.c_str(), TD_NO_BOM_CHANGE_TEXT, TD_NO_BOM_CHANGE, strchangesColAttrList, strchangesColWidthList, resBLDiffValue), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(false), TD_LOG_ERROR_AND_THROW);
								bStatus = true;
							}
						} else {
							TERADYNE_TRACE_CALL(iStatus = teradyne_update_solitem_BL_only(tSolObjFoundTag[jCnt], resBLDiffValue), TD_LOG_ERROR_AND_THROW);
						}
						if (!bStatus) {
							if (resBLDiffValue.size() > 0)
							{
								TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen("", false), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair((char *)pcChangeID.c_str(), TD_DIFFITEM_HEADER_2, TD_TABLE_HEADER, strchangesColAttrList, strchangesColWidthList, resBLDiffValue), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair("", "", TD_TABLE_COL_HEADER_VALUE, strchangesColAttrList, strchangesColWidthList, resBLDiffValue), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(false), TD_LOG_ERROR_AND_THROW);
							}
						}
					}
					Custom_free(pcECNTypeName);
				}
				Custom_free(pcSolItemid);
			}
		}

		//updating ECN Process History
		pcECNProcess = (char *)MEM_alloc((int)(tc_strlen(pcECNID) + 20) * sizeof(char));
		sprintf(pcECNProcess, "%s %s", pcECNID, TD_ECN_PROCESS_HISTORY_TITLE);
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_headingblock(pcECNProcess, TD_HEADING_TYPE_1), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagopen("", false), TD_LOG_ERROR_AND_THROW);
		std::list<string> strECNProcessColAttrList(strECNProcessColName, strECNProcessColName + sizeof(strECNProcessColName) / sizeof(string));
		std::list<string> strECNProcessColWidthList(strECNProcessColNameWidth, strECNProcessColNameWidth + sizeof(strECNProcessColNameWidth) / sizeof(string));
		TERADYNE_TRACE_CALL(iStatus = teradyne_update_htmlcontentPair("", "", TD_TABLE_COL_HEADER_VALUE, strECNProcessColAttrList, strECNProcessColWidthList, resECNPRocessValue), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_html_tabletagclose(false), TD_LOG_ERROR_AND_THROW);

		//write html content in xls file,
		TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_ECN_REPORT_TEMP_DIR_PREF, TC_preference_site, 0, &pcECNReportFileLoc), TD_LOG_ERROR_AND_THROW);
		pcDatasetID = (char *)MEM_alloc((int)(tc_strlen(pcECNID) + 20) * sizeof(char));
		sprintf(pcDatasetID, "%s-%s", pcECNID, TD_ECN_REPORT_FILE_NAME);
		sprintf(cHtLFilePath, "%s\\%s-%s.%s", pcECNReportFileLoc, pcECNID, TD_ECN_REPORT_FILE_NAME, TD_ECN_REPORT_XLS_FILE_EXT);

		fHtMLFile = fopen(cHtLFilePath, "w");
		fprintf(fHtMLFile, "%s", cHtMLFileContent.c_str());
		fprintf(fHtMLFile, "\n</HTML>");
		fclose(fHtMLFile);

		//converting the report to xlsx by using vb script
		//TERADYNE_TRACE_CALL(iStatus = teradyne_convert_xls2xlsx(cHtLFilePath, strOutXlsxPath), TD_LOG_ERROR_AND_THROW);
		if (tc_strlen(cHtLFilePath) > 0)
		{
			//Create and attach dataset under ECN Revision
			TERADYNE_TRACE_CALL(iStatus = teradyne_find_and_create_dataset(cHtLFilePath, tTargetObject, pcDatasetID), TD_LOG_ERROR_AND_THROW);
			DeleteFileA(cHtLFilePath);
			//DeleteFileA(strOutXlsxPath.c_str());
		}
		Custom_free(cHtLFilePath);
		Custom_free(pcECNProcess);
		Custom_free(pcDatasetID);
		Custom_free(pcECNReportFileLoc);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_get_ECNRelationPropertyattrvalue
* Description		: Validating PartCategory & PartSubcategory
*                     attribute in DivPartRevision
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_get_ECNRelationPropertyattrvalue(tag_t ptAttaches, char *cECNRelName, std::list<string> strECNRelationAttrList, char *pcECNClosureStsValue, int *iImpObjCount, tag_t **tImpObjFoundTag, vector<string> &resPropValVec)
{
	int iStatus = ITK_ok;
	int iObjCount = 0;

	tag_t tRelationTag = NULLTAG;

	char *pcPartCategoryValue = NULL;
	char *pcObjectType = NULL;


	string strImpandSolItmColValDesDoc[] = { TD_ITEM_ID_ATTR,TD_OBJECT_DESC_ATTR,TD_OBJECT_TYPE_ATTR,TD_ITEM_REV_ID_ATTR,TD_DOCUMENT_TYPE_ATTR,TD_PROJECT_NAME_ATTR };

	std::map<string, string> strECNRelationPropValueMap;
	std::map<string, string> strDesDocPropValueMap;

	vector<string> resPropVec;
	vector<string> vecRelString;

	char* __function__ = "teradyne_get_ECNRelationPropertyattrvalue";
	TERADYNE_TRACE_ENTER();

	try
	{
		//for desdocs only
		std::list<string> strECNRelationAttrListDesDoc(strImpandSolItmColValDesDoc, strImpandSolItmColValDesDoc + sizeof(strImpandSolItmColValDesDoc) / sizeof(string));

		POM_AM__set_application_bypass(true);

		vecRelString = teradyne_generate_tokens(cECNRelName, ",");
		if (vecRelString.size() > 0)
		{
			for (int iVector = 0; iVector < vecRelString.size(); iVector++)
			{
				tag_t *tObjFoundTag = { NULLTAG };
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(vecRelString[iVector].c_str(), &tRelationTag), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(ptAttaches, tRelationTag, &iObjCount, &tObjFoundTag), TD_LOG_ERROR_AND_THROW);
				if (iObjCount > 0)
				{
					//function to get ECN Impacted and Solution Item Properties and values	
					for (int i = 0; i < iObjCount; i++)
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObjFoundTag[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(pcObjectType, TD_DESIGN_DOC_REV_TYPE) == 0 || tc_strcmp(pcObjectType, TD_GENERAL_DOC_REV_TYPE) == 0)
						{
							setgNULLPropertyExecution(true);
							TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tObjFoundTag[i], strECNRelationAttrListDesDoc, strDesDocPropValueMap), TD_LOG_ERROR_AND_THROW);
							setgNULLPropertyExecution(false);
							if (strECNRelationPropValueMap.size() > 0) {
								strECNRelationPropValueMap.clear();
							}
							strECNRelationPropValueMap.insert(strDesDocPropValueMap.begin(), strDesDocPropValueMap.end());
						}
						else
						{
							setgNULLPropertyExecution(true);
							TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tObjFoundTag[i], strECNRelationAttrList, strECNRelationPropValueMap), TD_LOG_ERROR_AND_THROW);
							setgNULLPropertyExecution(false);
						}

						if (strECNRelationPropValueMap.size() > 0)
						{
							string szObjType = strECNRelationPropValueMap.find(TD_OBJECT_TYPE_ATTR)->second;
							if ((szObjType.length() > 0) && (tc_strcmp(szObjType.c_str(), TD_COMM_PART_REV) == 0))
							{
								char *pcdescription = NULL;
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObjFoundTag[i], TD_DESCR_ATTR, &pcdescription), TD_LOG_ERROR_AND_THROW);
								strECNRelationPropValueMap.find(TD_OBJECT_DESC_ATTR)->second.assign(pcdescription);
								Custom_free(pcdescription);
							}
							if ((szObjType.length() > 0) && (tc_strcmp(szObjType.c_str(), TD_DIV_PART_REV) == 0))
							{
								char *pcdescription = NULL;
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObjFoundTag[i], TD_STANDARD_DESC_ATTR, &pcdescription), TD_LOG_ERROR_AND_THROW);
								strECNRelationPropValueMap.find(TD_OBJECT_DESC_ATTR)->second.assign(pcdescription);
								Custom_free(pcdescription);
							}
							std::list<string> strAttributeList = (tc_strcmp(pcObjectType, TD_DESIGN_DOC_REV_TYPE) == 0 || tc_strcmp(pcObjectType, TD_GENERAL_DOC_REV_TYPE) == 0) ? strECNRelationAttrListDesDoc : strECNRelationAttrList;
							for (std::list<string>::iterator it = strAttributeList.begin(); it != strAttributeList.end(); it++)
							{
								if (((string)*it).empty())
									continue;

								if (tc_strcmp(strECNRelationPropValueMap.find(*it)->first.c_str(), TD_OBJECT_TYPE_ATTR) == 0)
								{
									char *pcAttrValue = NULL;
									TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_value(tObjFoundTag[i], ((string)*it).c_str(), &pcAttrValue), TD_LOG_ERROR_AND_THROW);
									strECNRelationPropValueMap.find(*it)->second.assign(pcAttrValue);
									Custom_free(pcAttrValue);
								}

								if ((tc_strcmp(cECNRelName, TD_ECR_IMPREL_NAME) == 0) || (tc_strcmp(cECNRelName, TD_ECR_SOLREL_NAME) == 0))
								{
									if (tc_strcmp(pcObjectType, TD_DESIGN_DOC_REV_TYPE) == 0 || tc_strcmp(pcObjectType, TD_GENERAL_DOC_REV_TYPE) == 0)
									{
										if ((tc_strcmp(strECNRelationPropValueMap.find(*it)->first.c_str(), TD_PROJECT_NAME_ATTR) == 0) || (tc_strcmp(strECNRelationPropValueMap.find(*it)->first.c_str(), TD_DOCUMENT_TYPE_ATTR) == 0))
										{
											if (tc_strlen(strECNRelationPropValueMap.find(*it)->second.c_str()) > 0)
												strECNRelationPropValueMap.find(*it)->second.assign("");
										}
									}
									else
									{
										TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObjFoundTag[i], TD_PART_TYPE_ATTR, &pcPartCategoryValue), TD_LOG_ERROR_AND_THROW);
										if ((tc_strcmp(pcPartCategoryValue, TD_PART_TYPE_PCBA) == 0) || (tc_strcmp(pcPartCategoryValue, TD_PART_TYPE_HLA) == 0))
										{
											if ((tc_strcmp(strECNRelationPropValueMap.find(*it)->first.c_str(), TD_PART_REV_STAMP) == 0) || (tc_strcmp(strECNRelationPropValueMap.find(*it)->first.c_str(), TD_PART_MIN_SHIPPABLE_REV) == 0))
											{
												if ((tc_strcmp(cECNRelName, TD_ECR_IMPREL_NAME) == 0) && (tc_strlen(strECNRelationPropValueMap.find(*it)->second.c_str()) <= 0))
													strECNRelationPropValueMap.find(*it)->second.assign(TD_TABLE_NONE_VALUE);

												if ((tc_strcmp(cECNRelName, TD_ECR_SOLREL_NAME) == 0) && (tc_strlen(strECNRelationPropValueMap.find(*it)->second.c_str()) <= 0) && (tc_strcmp(pcECNClosureStsValue, TD_ECN_CLOSURE_OPEN_STATUS) == 0))
												{
													strECNRelationPropValueMap.find(*it)->second.assign(TD_ECN_CLOSURE_STATUS_COL_VALUE);
												}
												else if ((tc_strcmp(cECNRelName, TD_ECR_SOLREL_NAME) == 0) && (tc_strlen(strECNRelationPropValueMap.find(*it)->second.c_str()) <= 0) && (tc_strcmp(pcECNClosureStsValue, TD_ECN_CLOSURE_CLOSED_STATUS) == 0))
												{
													strECNRelationPropValueMap.find(*it)->second.assign(TD_TABLE_NONE_VALUE);
												}
											}
											if(pcPartCategoryValue != NULL)
												Custom_free(pcPartCategoryValue);
										}
									}

								}
								string valueTobeInserted = strECNRelationPropValueMap.find(*it)->second;
								TC_write_syslog("\nINFO : valueTobeInserted: %s ", valueTobeInserted.c_str());
								resPropValVec.push_back(valueTobeInserted);
								valueTobeInserted = "";
							}
						}
					}
					*iImpObjCount = iObjCount;
					*tImpObjFoundTag = tObjFoundTag;
				}
			}
		}

		POM_AM__set_application_bypass(false);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
		POM_AM__set_application_bypass(false);
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_update_htmlcontentPair
* Description		: will update html table content with value
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  columname   (I)	   - Column
*					   columvalue	(I)	   - Property value vector
*					   cHtMLFileContent  (I)    - Propery value array
*					   value  (I)    - Propery value array
*					   strColAttr  (I)    - Propery value array
*					   resValVec (I)	   - Response vector of property values
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_update_htmlcontentPair(char *columname, char *columvalue, char* value, std::list<string> strColAttr, std::list<string> strColwidthAttr, std::vector<string> resValVec)
{
	//Declartion and Initialization of Local Variables
	int iColHeaderSize = 0;
	int iTypesize = 0;
	int iStart = 0;
	int iStatus = ITK_ok;

	string columvalue1;

	char* __function__ = "teradyne_update_htmlcontentPair";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tc_strcmp(value, TD_TABLE_ROW_HEADER_VALUE) == 0)
		{
			cHtMLFileContent.append("\n<TR>");
			cHtMLFileContent.append("\n<TD bgcolor=#C0C0C0><B>");
			cHtMLFileContent.append(columname); cHtMLFileContent.append("<B></TD>");
			cHtMLFileContent.append("\n<TD align=\"left\">");

			if (tc_strcasecmp(columvalue, TD_BOOL_VALUE_TRUE) == 0)
				cHtMLFileContent.append(TD_ECN_VALUE_FOR_TRUE);
			else if (tc_strcasecmp(columvalue, TD_BOOL_VALUE_FALSE) == 0)
				cHtMLFileContent.append(TD_ECN_VALUE_FOR_FALSE);
			else
				cHtMLFileContent.append(columvalue);

			cHtMLFileContent.append("</TD>");
			if ((tc_strcmp(columname, TD_ECN_COLTIT_MATL_IMP) == 0) && (tc_strlen(columvalue) > 0))
			{
				columvalue1.assign("");
				if (tc_strcmp(columvalue, TD_ECN_MATIMP_VALUE_PHASEIN) == 0)
					columvalue1.assign(TD_ECN_MATIMP_PHASEIN);
				if (tc_strcmp(columvalue, TD_ECN_MATIMP_VALUE_NEXTBUILD) == 0)
					columvalue1.assign(TD_ECN_MATIMP_NEXTBUILD);
				if (tc_strcmp(columvalue, TD_ECN_MATIMP_VALUE_NEXTBUY) == 0)
					columvalue1.assign(TD_ECN_MATIMP_NEXTBUY);
				if (tc_strcmp(columvalue, TD_ECN_MATIMP_VALUE_REWORKALL) == 0)
					columvalue1.assign(TD_ECN_MATIMP_REWORKALL);
				if (tc_strcmp(columvalue, TD_ECN_MATIMP_VALUE_REWORKSOMEMATERIAL) == 0)
					columvalue1.assign(TD_ECN_MATIMP_REWORKSOMEMATERIAL);
				if (tc_strcmp(columvalue, TD_ECN_CLOSURE_VALUE_REWORKALL_PRIORT) == 0)
					columvalue1.assign(TD_ECN_CLOSURE_REWORKALL_PRIORTOCUSTOMERSHIPMENT);

				cHtMLFileContent.append("\n<TD align=\"left\">"); cHtMLFileContent.append(columvalue1.c_str()); cHtMLFileContent.append("</TD>");
			}
			cHtMLFileContent.append("\n</TR>");
		}
		else if (tc_strcmp(value, TD_NO_BOM_CHANGE) == 0)
		{
			cHtMLFileContent.append("\n<TR> \n<TH align=\"left\" COLSPAN=1 bgcolor=#C0C0C0><B>"); cHtMLFileContent.append(columname); cHtMLFileContent.append("<B></TH>");
			cHtMLFileContent.append("\n</TR>");
			cHtMLFileContent.append("\n<TR> \n<TD align=\"left\" nowrap>"); cHtMLFileContent.append(columvalue); cHtMLFileContent.append("</TD>");
			cHtMLFileContent.append("\n</TR>");
		}
		else if (tc_strcmp(value, TD_TABLE_HEADER) == 0)
		{
			cHtMLFileContent.append("\n<TR>");
			cHtMLFileContent.append("\n<TH align=\"left\" COLSPAN=6 bgcolor=#C0C0C0><B>"); cHtMLFileContent.append(columname); cHtMLFileContent.append("<B></TH>");
			cHtMLFileContent.append("\n<TH COLSPAN=3 bgcolor=#C0C0C0><B>"); cHtMLFileContent.append(columvalue); cHtMLFileContent.append("<B></TH>");
			cHtMLFileContent.append("\n</TR>");
		}
		else if (tc_strcmp(value, TD_TABLE_STATIC_TEXT) == 0)
		{
			cHtMLFileContent.append("\n<TABLE border=\"2\" align=\"Top\" width=\"90%\">");
			cHtMLFileContent.append("\n<TR>");
			cHtMLFileContent.append("\n<TD COLSPAN=3 nowrap><B>"); cHtMLFileContent.append(columvalue); cHtMLFileContent.append("<B></TD>");
			cHtMLFileContent.append("\n</TR>");
			cHtMLFileContent.append("\n</TABLE>");
			if (tc_strcasecmp(columvalue, TD_ECN_REPORT_STEXT_BOMCHANGES) == 0)
				cHtMLFileContent.append("\n<BR><BR>");
		}
		else if (tc_strcmp(value, TD_TABLE_NONE_VALUE) == 0)
		{
			cHtMLFileContent.append("\n<H3>"); cHtMLFileContent.append(columname); cHtMLFileContent.append("<BR>"); cHtMLFileContent.append(columvalue);  cHtMLFileContent.append("</H3>");
		}
		else
		{
			cHtMLFileContent.append("\n<TR>");
			iColHeaderSize = (int)strColAttr.size();
			for (std::list<string>::iterator it = strColAttr.begin(), itwidth = strColwidthAttr.begin(); it != strColAttr.end(), itwidth != strColwidthAttr.end(); it++, itwidth++)
			{
				if (((string)*it).empty())
					continue;

				cHtMLFileContent.append("\n<TH bgcolor=#C0C0C0 height=\"40%\" width=\""); cHtMLFileContent.append(((string)*itwidth).c_str()); cHtMLFileContent.append("%\">"); cHtMLFileContent.append(((string)*it).c_str());  cHtMLFileContent.append("</TH>");
			}
			cHtMLFileContent.append("\n</TR>");
			if (resValVec.size() > 0)
			{
				iTypesize = (int)resValVec.size();
				iStart = 0;
				for (int iAttrCnt = iStart; iAttrCnt < iTypesize; iAttrCnt++)
				{
					cHtMLFileContent.append("\n<TR>");
					for (int iAttrCnt1 = 0; iAttrCnt1 < iColHeaderSize; iAttrCnt1++)
					{
						if ((iAttrCnt1 == 0 || (iAttrCnt1 == 1) || (iAttrCnt1 == 4) || (iAttrCnt1 == 5)) && (resValVec[iStart].substr(0, 1) == "0"))
							cHtMLFileContent.append("\n<TD align=\"left\" style=\"mso-number-format:\\@\">");
						else
							cHtMLFileContent.append("\n<TD align=\"left\">");

						cHtMLFileContent.append(resValVec[iStart].c_str()); cHtMLFileContent.append("</TD>");
						iStart++;
					}
					iAttrCnt = iStart;
					cHtMLFileContent.append("\n</TR>");
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_html_headingblock
* Description		: Function used to create html heading block
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_html_headingblock(char* HeadingValue, int iHeadingType)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	char* __function__ = "teradyne_html_headingblock";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (iHeadingType == 3)
		{
			cHtMLFileContent.append("\n<H3>");
			cHtMLFileContent.append(HeadingValue);
			//cHtMLFileContent.append("</H3>"); 
		}
		else
		{
			cHtMLFileContent.append("\n<H2>");
			cHtMLFileContent.append(HeadingValue);
			cHtMLFileContent.append("</H2>");
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_html_tabletagopen
* Description		: Function used to open the table tag of html
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_html_tabletagopen(char* HeadingValue, bool bAddHeader)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	char* __function__ = "teradyne_html_tabletagopen";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (bAddHeader)
		{
			cHtMLFileContent.append("\n<H3>");
			cHtMLFileContent.append(HeadingValue);
			cHtMLFileContent.append("\n<TABLE border=\"2\" align=\"center\" width=\"90%\">");
		}
		else
		{
			cHtMLFileContent.append("\n<TABLE border=\"2\" align=\"center\" width=\"90%\">");
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_html_tabletagclose
* Description		: Function used to close the table tag of html
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_html_tabletagclose(bool bAddHeaderclose)
{
	//Declartion and Initialization of Local Variables
	int   iStatus = ITK_ok;

	char* __function__ = "teradyne_html_tabletagclose";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (!bAddHeaderclose)
		{
			cHtMLFileContent.append("\n</TABLE>\n<BR>\n<BR>\n<BR>");
		}
		else
		{
			cHtMLFileContent.append("\n</H3></TABLE>\n<BR>\n<BR>\n<BR>");
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_update_solitem_BL_only
* Description		:
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_update_solitem_BL_only(tag_t  tSolrevtag, vector<string> &resDiffVec)
{
	int  iStatus = ITK_ok,
		ichildCount = 0,
		iChildIncr = 0;

	tag_t tWindow = NULLTAG,
		tSolitemtag = NULLTAG,
		tline = NULLTAG,
		*tchildLines = NULL;

	string strBomLineAttr[] = { TD_BL_ITEM_ID_ATTR,TD_BL_SEQ_NO,TD_BL_QUANTITY,TD_BL_REMARKS,TD_BL_REF_DESIG_ATTR };

	std::map<string, string> strBomLineValueMap;

	char* __function__ = "teradyne_update_solitem_BL_only";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (!resDiffVec.empty())
			resDiffVec.clear();

		TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSolrevtag, &tSolitemtag), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&tWindow), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(tWindow, tSolitemtag, tSolrevtag, NULLTAG, &tline), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tline, &ichildCount, &tchildLines), TD_LOG_ERROR_AND_THROW);

		if (ichildCount == 0)
		 {	TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow),TD_LOG_ERROR_AND_THROW); return iStatus;}

		std::list<string> strBomLineAttrList(strBomLineAttr, strBomLineAttr + sizeof(strBomLineAttr) / sizeof(string));

		for (iChildIncr = 0; iChildIncr < ichildCount; iChildIncr++)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tchildLines[iChildIncr], strBomLineAttrList, strBomLineValueMap), TD_LOG_ERROR_AND_THROW);

			char *pcDescription = NULL;

			TERADYNE_TRACE_CALL(iStatus = teradyne_get_description(tchildLines[iChildIncr], &pcDescription), TD_LOG_ERROR_AND_THROW);

			if (strBomLineValueMap.size() > 0)
			{
				resDiffVec.push_back(TD_DIFFITEM_ADD);
				resDiffVec.push_back(strBomLineValueMap.find(TD_BL_ITEM_ID_ATTR)->second);
				resDiffVec.push_back(pcDescription);
				resDiffVec.push_back(strBomLineValueMap.find(TD_BL_SEQ_NO)->second);
				if ((tc_strlen(strBomLineValueMap.find(TD_BL_QUANTITY)->second.c_str())) <= 0)
				{
					resDiffVec.push_back("1");
				} else { resDiffVec.push_back(strBomLineValueMap.find(TD_BL_QUANTITY)->second);}
				resDiffVec.push_back(strBomLineValueMap.find(TD_BL_REMARKS)->second);
				resDiffVec.push_back("");
				resDiffVec.push_back(strBomLineValueMap.find(TD_BL_REF_DESIG_ATTR)->second);
				resDiffVec.push_back("");
			}
			Custom_free(pcDescription);
		}
		TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow), TD_LOG_ERROR_AND_THROW);

		Custom_free(tchildLines);
	}

	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	//Custom_free(tchildLines);
	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_list_bvr_diffs
* Description		: Function used to create report of Bomline Comaprison
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_list_bvr_diffs(tag_t  tImprevtag, tag_t  tSolrevtag, vector<string> &resDiffVec)
{
	int  iStatus = ITK_ok,
		NO_BOM_CHNAGES = 1,
		iDiffCount1 = 0,
		iDiffCount2 = 0,
		*iDiffflags1 = 0,
		*iDiffflags2 = 0,
		iReportlength = 0,
		ichildCount1 = 0,
		ichildCount2 = 0;

	tag_t tWindow1 = NULLTAG,
		tWindow2 = NULLTAG,
		tImpitemtag = NULLTAG,
		tSolitemtag = NULLTAG,
		tline1 = NULLTAG,
		tline2 = NULLTAG,
		tCompare = NULLTAG,
		tdesc = NULLTAG,
		*tDiffLines1 = NULLTAG,
		*tDiffLines2 = NULLTAG,
		*tReportitems = NULLTAG,
		*tchildLines1 = NULL,
		*tchildLines2 = NULL;

	char **cReportlines = NULL;

	string strBomLineAttr[] = { TD_BL_ITEM_ID_ATTR,TD_BL_SEQ_NO,TD_BL_QUANTITY,TD_BL_REMARKS,TD_BL_REF_DESIG_ATTR };

	std::map<string, string> strBomLineValueMap;

	vector<string> resDiffVecs;

	char* __function__ = "teradyne_list_bvr_diffs";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (!resDiffVec.empty())
			resDiffVec.clear();

		//Getting rev tag of Impacted and Solution Item
		TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tImprevtag, &tImpitemtag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSolrevtag, &tSolitemtag), TD_LOG_ERROR_AND_THROW);

		//Create BOM windows and set their top lines
		TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&tWindow1), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(tWindow1, tImpitemtag, tImprevtag, NULLTAG, &tline1), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = BOM_create_window(&tWindow2), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = BOM_set_window_top_line(tWindow2, tSolitemtag, tSolrevtag, NULLTAG, &tline2), TD_LOG_ERROR_AND_THROW);

		//Ask Child lines of top lines
		TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tline1, &ichildCount1, &tchildLines1), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_child_lines(tline2, &ichildCount2, &tchildLines1), TD_LOG_ERROR_AND_THROW);

		if ((ichildCount1 <= 0) && (ichildCount2 <= 0))
		{
			TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow1), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow2), TD_LOG_ERROR_AND_THROW);
			return iStatus;
		}

		/* compare */
		TERADYNE_TRACE_CALL(iStatus = BOM_compare_execute(NULLTAG, tline1, tline2, "IMAN_bcm_single_level_ref", BOM_compare_output_report), TD_LOG_ERROR_AND_THROW);
		iStatus = BOM_compare_report(tCompare, &iReportlength, &cReportlines, &tReportitems);
		if (iStatus == 46059)
		{
			EMH_clear_errors();
			Custom_free(tchildLines1);
			Custom_free(tchildLines2);
			Custom_free(tReportitems);
			Custom_free(cReportlines);
			return NO_BOM_CHNAGES;
		}

		TERADYNE_TRACE_CALL(iStatus = BOM_compare_list_diffs(tline1, &iDiffCount1, &tDiffLines1, &iDiffflags1), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = BOM_compare_list_diffs(tline2, &iDiffCount2, &tDiffLines2, &iDiffflags2), TD_LOG_ERROR_AND_THROW);

		if ((iDiffCount1 > 0) || (iDiffCount2 > 0))
		{
			char  *pcDiffLines1ID = NULL;
			char  *pcDiffLines2ID = NULL;

			vector<string> itemIDVec;

			for (int j = 0; j < iDiffCount1; j++) {
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDiffLines1[j], TD_BL_ITEM_ID_ATTR, &pcDiffLines1ID), TD_LOG_ERROR_AND_THROW);
				itemIDVec.push_back(pcDiffLines1ID);
			}
			Custom_free(pcDiffLines1ID);

			std::list<string> strBomLineAttrList(strBomLineAttr, strBomLineAttr + sizeof(strBomLineAttr) / sizeof(string));
			for (int i = 0; i < iDiffCount2; i++)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tDiffLines2[i], TD_BL_ITEM_ID_ATTR, &pcDiffLines2ID), TD_LOG_ERROR_AND_THROW);

				bool itemFound = false;

				if (itemIDVec.size() > 0) {
					for (int k = 0; k < itemIDVec.size(); k++) {
						if (tc_strcmp(pcDiffLines2ID, itemIDVec[k].c_str()) == 0) {
							itemFound = true;
							break;
						}
					}
				}
				Custom_free(pcDiffLines2ID);

				//Getting Added Item
				if (BOM_cmp_added(iDiffflags2[i]) && !itemFound)
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tDiffLines2[i], strBomLineAttrList, strBomLineValueMap), TD_LOG_ERROR_AND_THROW);

					char *pcDescription = NULL;

					TERADYNE_TRACE_CALL(iStatus = teradyne_get_description(tDiffLines2[i], &pcDescription), TD_LOG_ERROR_AND_THROW);

					if (strBomLineValueMap.size() > 0)
					{
						resDiffVec.push_back(TD_DIFFITEM_ADD);
						resDiffVec.push_back(strBomLineValueMap.find(TD_BL_ITEM_ID_ATTR)->second);
						resDiffVec.push_back(pcDescription);
						resDiffVec.push_back(strBomLineValueMap.find(TD_BL_SEQ_NO)->second);

						if ((tc_strlen(strBomLineValueMap.find(TD_BL_QUANTITY)->second.c_str())) <= 0)
						{
							resDiffVec.push_back("1");
						} else {
							resDiffVec.push_back(strBomLineValueMap.find(TD_BL_QUANTITY)->second);
						}

						resDiffVec.push_back(strBomLineValueMap.find(TD_BL_REMARKS)->second);
						resDiffVec.push_back("");
						resDiffVec.push_back(strBomLineValueMap.find(TD_BL_REF_DESIG_ATTR)->second);
						resDiffVec.push_back(strBomLineValueMap.find(TD_BL_REF_DESIG_ATTR)->second);
					}
					Custom_free(pcDescription);
				}
			}
			//Getting Changed and Deleted Item
			if (iDiffCount1 > 0)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_bomline_attr_value(iDiffCount1, iDiffCount2, tDiffLines1, tDiffLines2, strBomLineAttrList, resDiffVecs), TD_LOG_ERROR_AND_THROW);
				resDiffVec.insert(resDiffVec.end(), resDiffVecs.begin(), resDiffVecs.end());
			}
		}

		TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow1), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = BOM_close_window(tWindow2), TD_LOG_ERROR_AND_THROW);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	Custom_free(cReportlines);
	Custom_free(tDiffLines1);
	Custom_free(tDiffLines2);
	Custom_free(tchildLines1);
	Custom_free(tchildLines2);
	Custom_free(tReportitems);

	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_get_bomline_attr_value
* Description		: Getting Bom line Attribute value
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_get_bomline_attr_value(int iChildrenCount1, int iChildrenCount2, tag_t *ptChildrens1, tag_t *ptChildrens2, std::list<string> strBomLineAttrList, vector<string> &resDiffVec)
{
	int iStatus = ITK_ok;
	int iChildIncr1 = 0;
	int iChildIncr2 = 0;

	char  *pcBLItemID1 = NULL;
	char  *pcBLItemID2 = NULL;
	string  strQty = "";

	logical isLogicalAttribute = false;

	std::map<string, string> strBomLineValueMap1, strBomLineValueMap2;

	vector<string> test;

	std::string strQty1, strRefDes1, strRefDes2;
	std::string strQty2, strRefDesDelta;

	char* __function__ = "teradyne_get_bomline_attr_value";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (!resDiffVec.empty())
			resDiffVec.clear();

		if (!strBomLineValueMap1.empty())
			strBomLineValueMap1.clear();

		if (!strBomLineValueMap2.empty())
			strBomLineValueMap2.clear();

		for (iChildIncr1 = 0; iChildIncr1 < iChildrenCount1; iChildIncr1++)
		{
			isLogicalAttribute = false;
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptChildrens1[iChildIncr1], TD_BL_ITEM_ID_ATTR, &pcBLItemID1), TD_LOG_ERROR_AND_THROW);
			for (iChildIncr2 = 0; iChildIncr2 < iChildrenCount2; iChildIncr2++)
			{
				strQty = "";
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptChildrens2[iChildIncr2], TD_BL_ITEM_ID_ATTR, &pcBLItemID2), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(pcBLItemID1, pcBLItemID2) == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptChildrens1[iChildIncr1], strBomLineAttrList, strBomLineValueMap1), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptChildrens2[iChildIncr2], strBomLineAttrList, strBomLineValueMap2), TD_LOG_ERROR_AND_THROW);

					char *pcDescription = NULL;

					TERADYNE_TRACE_CALL(iStatus = teradyne_get_description(ptChildrens2[iChildIncr2], &pcDescription), TD_LOG_ERROR_AND_THROW);

					//Getting changed BOM Lines attributes
					if ((strBomLineValueMap2.size() > 0) && (strBomLineValueMap1.size() > 0))
					{
						strRefDesDelta = "";
						resDiffVec.push_back(TD_DIFFITEM_CHANGE);
						resDiffVec.push_back(strBomLineValueMap2.find(TD_BL_ITEM_ID_ATTR)->second);
						resDiffVec.push_back(pcDescription);
						resDiffVec.push_back(strBomLineValueMap2.find(TD_BL_SEQ_NO)->second);

						//Manipulating Quantity values
						if ((tc_strlen(strBomLineValueMap1.find(TD_BL_QUANTITY)->second.c_str())) <= 0)
						{
							strQty1.assign("1");
						   } else { strQty1.assign(strBomLineValueMap1.find(TD_BL_QUANTITY)->second.c_str() ); } 
						if ((tc_strlen(strBomLineValueMap2.find(TD_BL_QUANTITY)->second.c_str())) <= 0)
						{
							strQty2.assign("1");
						   } else { strQty2.assign(strBomLineValueMap2.find(TD_BL_QUANTITY)->second.c_str()); }

						//Manipulating Ref Designator attribute values
						strRefDes1.assign(strBomLineValueMap1.find(TD_BL_REF_DESIG_ATTR)->second);
						strRefDes2.assign(strBomLineValueMap2.find(TD_BL_REF_DESIG_ATTR)->second);

						if (strRefDes1 != strRefDes2) {

							int iPackedLinesCount1 = 0;
							tag_t *tpackedLines1 = NULL;
							char *pcRefDesValue1 = NULL;
							vector<string> vecResDef1;

							TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_packed_lines(ptChildrens1[iChildIncr1], &iPackedLinesCount1, &tpackedLines1), TD_LOG_ERROR_AND_THROW);

							for (int c1 = 0; c1 < iPackedLinesCount1; c1++) {
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tpackedLines1[c1], TD_BL_REF_DESIG_ATTR, &pcRefDesValue1), TD_LOG_ERROR_AND_THROW);
								string strRefDesvalue1(pcRefDesValue1);
								vecResDef1.push_back(strRefDesvalue1);
							}
							Custom_free(tpackedLines1);
							Custom_free(pcRefDesValue1);

							int iPackedLinesCount2 = 0;
							tag_t *tpackedLines2 = NULL;
							char *pcRefDesValue2 = NULL;
							vector<string> vecResDef2;

							TERADYNE_TRACE_CALL(iStatus = BOM_line_ask_packed_lines(ptChildrens2[iChildIncr2], &iPackedLinesCount2, &tpackedLines2), TD_LOG_ERROR_AND_THROW);

							for (int c2 = 0; c2 < iPackedLinesCount2; c2++) {
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tpackedLines2[c2], TD_BL_REF_DESIG_ATTR, &pcRefDesValue2), TD_LOG_ERROR_AND_THROW);
								string strRefDesvalue2(pcRefDesValue2);
								vecResDef2.push_back(strRefDesvalue2);
							}
							Custom_free(tpackedLines2);
							Custom_free(pcRefDesValue2);

							TERADYNE_TRACE_CALL(iStatus = BOM_line_unpack(ptChildrens1[iChildIncr1]), TD_LOG_ERROR_AND_THROW);

							char *pcRefDesValue3 = NULL;
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptChildrens1[iChildIncr1], TD_BL_REF_DESIG_ATTR, &pcRefDesValue3), TD_LOG_ERROR_AND_THROW);
							string strRefDesvalue3(pcRefDesValue3);

							TERADYNE_TRACE_CALL(iStatus = BOM_line_unpack(ptChildrens2[iChildIncr2]), TD_LOG_ERROR_AND_THROW);

							char *pcRefDesValue4 = NULL;
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptChildrens2[iChildIncr2], TD_BL_REF_DESIG_ATTR, &pcRefDesValue4), TD_LOG_ERROR_AND_THROW);
							string strRefDesvalue4(pcRefDesValue4);

							vecResDef1.push_back(strRefDesvalue3);
							vecResDef2.push_back(strRefDesvalue4);

							Custom_free(pcRefDesValue3);
							Custom_free(pcRefDesValue4);

							sort(vecResDef1.begin(), vecResDef1.end());
							vector<string>::iterator it1 = std::unique(vecResDef1.begin(), vecResDef1.end());
							vecResDef1.erase(it1, vecResDef1.end());

							sort(vecResDef2.begin(), vecResDef2.end());
							vector<string>::iterator it2 = std::unique(vecResDef2.begin(), vecResDef2.end());
							vecResDef2.erase(it2, vecResDef2.end());

							vector<string> vecResult1;
							set_difference(vecResDef1.begin(), vecResDef1.end(), vecResDef2.begin(), vecResDef2.end(), back_inserter(vecResult1));

							for (int r1 = 0; r1 < vecResult1.size(); r1++) {
								if (strRefDesDelta != "") {
									strRefDesDelta = strRefDesDelta + "," + vecResult1[r1];
								   } else {
									strRefDesDelta = vecResult1[r1];
								}
							}

							vector<string> vecResult2;
							set_difference(vecResDef2.begin(), vecResDef2.end(), vecResDef1.begin(), vecResDef1.end(), back_inserter(vecResult2));

							for (int r2 = 0; r2 < vecResult2.size(); r2++) {
								if (strRefDesDelta != "") {
									strRefDesDelta = strRefDesDelta + "," + vecResult2[r2];
								   } else {
									strRefDesDelta = vecResult2[r2];
								}
							}

							vecResDef1.clear();
							vecResDef2.clear();
							vecResult1.clear();
							vecResult2.clear();
						}

						if (strQty1 > strQty2)
						{
							strQty = strQty.append(strQty1).append("->").append(strQty2);
						   } else if (strQty2 > strQty1)  // 1 ->2 : r1 ->r1, r2
						{
							strQty = strQty.append(strQty1).append("->").append(strQty2);
						   } else {
							strQty = strQty2;
						}

						resDiffVec.push_back(strQty);
						resDiffVec.push_back(strBomLineValueMap2.find(TD_BL_REMARKS)->second);
						resDiffVec.push_back(strBomLineValueMap1.find(TD_BL_REF_DESIG_ATTR)->second);
						resDiffVec.push_back(strBomLineValueMap2.find(TD_BL_REF_DESIG_ATTR)->second);
						resDiffVec.push_back(strRefDesDelta);
						isLogicalAttribute = true;
						Custom_free(pcBLItemID2);
						break;
					}
					Custom_free(pcDescription);
				}
				Custom_free(pcBLItemID2);
			}
			if (!isLogicalAttribute)
			{
				//Getting Deleted BOM Lines attributes
				TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(ptChildrens1[iChildIncr1], strBomLineAttrList, strBomLineValueMap1), TD_LOG_ERROR_AND_THROW);

				char *pcDescription = NULL;

				TERADYNE_TRACE_CALL(iStatus = teradyne_get_description(ptChildrens1[iChildIncr1], &pcDescription), TD_LOG_ERROR_AND_THROW);

				if (strBomLineValueMap1.size() > 0)
				{
					resDiffVec.push_back(TD_DIFFITEM_DEL);
					resDiffVec.push_back(strBomLineValueMap1.find(TD_BL_ITEM_ID_ATTR)->second);
					resDiffVec.push_back(pcDescription);
					resDiffVec.push_back(strBomLineValueMap1.find(TD_BL_SEQ_NO)->second);
					if ((tc_strlen(strBomLineValueMap1.find(TD_BL_QUANTITY)->second.c_str())) <= 0)
					{
						resDiffVec.push_back("1");
					 } else { resDiffVec.push_back(strBomLineValueMap1.find(TD_BL_QUANTITY)->second);}
					resDiffVec.push_back(strBomLineValueMap1.find(TD_BL_REMARKS)->second);
					resDiffVec.push_back(strBomLineValueMap1.find(TD_BL_REF_DESIG_ATTR)->second);
					resDiffVec.push_back("");
					resDiffVec.push_back("");
				}
				Custom_free(pcDescription);
			}
			Custom_free(pcBLItemID1);
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_get_ECN_processhistory
* Description		: Function used to get Reviewer name, decision and comments from review task
*					  of current workflow on ECN Revision
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_get_ECN_processhistory(tag_t tTask, tag_t tObject, vector<string> &resECNProcessVec)
{
	int iStatus = ITK_ok;
	int iCount = 0;
	int iTask = 0;


	char *pcJobName = NULL;
	char *pcTempalteName = NULL;
	char *pcSDate = NULL;
	char *pcEDate = NULL;

	tag_t tjobtag = NULLTAG;
	tag_t tRoottask = NULLTAG;
	tag_t *tProcessTags = NULLTAG;

	date_t dStartDate;
	date_t dEndDate;

	string strECNPHistoryColVal[] = { TD_ECN_PROCESS_TASKNAME_VAL,TD_ECN_PROCESS_DECISION_VAL,TD_ECN_PROCESS_PERFORMER_VAL,TD_ECN_PROCESS_START_DATE_VAL,TD_ECN_PROCESS_END_DATE_VAL,TD_ECN_PROCESS_COMMENTS_VAL };

	std::map<string, string> strPropNameValueMap;
	std::map<string, string> strECNProcessValueMap;
	string strJobName;

	set<MapProcessHistory, ProcessHistoryComparator> setMapProcessHistory;

	char* __function__ = "teradyne_get_ECN_processhistory";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (!resECNProcessVec.empty())
			resECNProcessVec.clear();

		if (!setMapProcessHistory.empty()) {
			setMapProcessHistory.clear();
		}

		TERADYNE_TRACE_CALL(iStatus = EPM_ask_job(tTask, &tjobtag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(tjobtag, &tRoottask), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tjobtag, TD_OBJECT_NAME_ATTR, &pcJobName), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRoottask, TD_OBJECT_NAME_ATTR, &pcTempalteName), TD_LOG_ERROR_AND_THROW);


		string workflowTemplate(pcTempalteName);
		int iIndexWorkflow = 0;
		tag_t *pcFindAllWorkflows = { NULLTAG };
		char *pcObjectString = NULL;
		if ((workflowTemplate.compare(TD_WF_PROTOBOM_ECN) != 0) || (workflowTemplate.compare(TD_WF_RELEASE_ECN) != 0) || (workflowTemplate.compare(TD_WF_STANDARD_ECN)) != 0 || (workflowTemplate.compare(TD_WF_PROTOPART_ECN)) != 0) {
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tags(tObject, TD_FND_ALL_WORKFLOWS, &iIndexWorkflow, &pcFindAllWorkflows), TD_LOG_ERROR_AND_THROW);
			for (int iCount = 0; iCount < iIndexWorkflow; iCount++) {
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(pcFindAllWorkflows[iCount], TD_OBJECT_STRING, &pcObjectString), TD_LOG_ERROR_AND_THROW);
				string ecnWorkflowTemplate(pcObjectString);

				if ((ecnWorkflowTemplate.compare(TD_WF_PROTOBOM_ECN) == 0) || (ecnWorkflowTemplate.compare(TD_WF_RELEASE_ECN) == 0) || (ecnWorkflowTemplate.compare(TD_WF_STANDARD_ECN) == 0) || (ecnWorkflowTemplate.compare(TD_WF_PROTOPART_ECN) == 0)) {

					TERADYNE_TRACE_CALL(iStatus = EPM_ask_job(pcFindAllWorkflows[iCount], &tjobtag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(tjobtag, &tRoottask), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tjobtag, TD_OBJECT_NAME_ATTR, &pcJobName), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRoottask, TD_OBJECT_NAME_ATTR, &pcTempalteName), TD_LOG_ERROR_AND_THROW);
					break;
				}

				Custom_free(pcObjectString);
			}
		}



		strJobName.assign(tc_strtok(pcJobName, ";")); strJobName.append("*");
		strPropNameValueMap.insert(::make_pair((string)TD_QRY_JOB_NAME, strJobName));
		strPropNameValueMap.insert(::make_pair((string)TD_PROCESS_TEMPLATE_NAME, (string)pcTempalteName));
		TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry(TD_WF_AUDIT_SIGNOFF, strPropNameValueMap, &iCount, &tProcessTags), TD_LOG_ERROR_AND_THROW);

		std::list<string> strAttrList(strECNPHistoryColVal, strECNPHistoryColVal + sizeof(strECNPHistoryColVal) / sizeof(string));

		for (iTask = 0; iTask < iCount; iTask++)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tProcessTags[iTask], strAttrList, strECNProcessValueMap), TD_LOG_ERROR_AND_THROW);
			MapProcessHistory mapProcessHistory = strECNProcessValueMap;
			setMapProcessHistory.insert(mapProcessHistory);

		}




		for (set<MapProcessHistory, ProcessHistoryComparator>::iterator it = setMapProcessHistory.begin(); it != setMapProcessHistory.end(); ++it) {

			MapProcessHistory mapProcessHistory = *it;

			resECNProcessVec.push_back(mapProcessHistory.find(strECNPHistoryColVal[0])->second);
			resECNProcessVec.push_back(mapProcessHistory.find(strECNPHistoryColVal[1])->second);
			resECNProcessVec.push_back(mapProcessHistory.find(strECNPHistoryColVal[2])->second);

			TERADYNE_TRACE_CALL(iStatus = DATE_convert_format_date_to_date_t((char *)mapProcessHistory.find(strECNPHistoryColVal[3])->second.c_str(), TD_DATE_YMD_CONSTANT, &dStartDate), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string(dStartDate, TD_DATE_DMY_CONSTANT, &pcSDate), TD_LOG_ERROR_AND_THROW);
			resECNProcessVec.push_back(pcSDate);

			TERADYNE_TRACE_CALL(iStatus = DATE_convert_format_date_to_date_t((char *)mapProcessHistory.find(strECNPHistoryColVal[4])->second.c_str(), TD_DATE_YMD_CONSTANT, &dEndDate), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string(dEndDate, TD_DATE_DMY_CONSTANT, &pcEDate), TD_LOG_ERROR_AND_THROW);
			resECNProcessVec.push_back(pcEDate);

			resECNProcessVec.push_back(mapProcessHistory.find(strECNPHistoryColVal[5])->second);

			Custom_free(pcSDate);
			Custom_free(pcEDate);
		}
		Custom_free(pcJobName);
		Custom_free(pcTempalteName);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_get_ECN_effectivity
* Description		: Function used to get effectivity from
*					  released Status of ECN Revision
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_get_ECN_effectivity(char *pcECNID, tag_t tObject, vector<string> &resECNEffVec)
{
	int   iStatus = ITK_ok;
	int   iStatuscount = 0;
	int   iEff = 0;
	int   iEffcount = 0;
	int   iRelStatus = 0;
	int   iEffDateCount = 0;

	char *pcStatustype = NULL;
	char *pcAttrValue = NULL;
	char *pcECNIDValue = NULL;

	tag_t *tEfflist = NULL;
	tag_t *tStatuslist = NULL;

	date_t *tEffStartDateTime;

	WSOM_range_type_t range_type;
	WSOM_open_ended_status_t  	open_ended;

	char* __function__ = "teradyne_get_ECN_processhistory";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (!resECNEffVec.empty())
			resECNEffVec.clear();

		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_OBJECT_STRING, &pcECNIDValue), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = WSOM_ask_release_status_list(tObject, &iStatuscount, &tStatuslist), TD_LOG_ERROR_AND_THROW);
		if (iStatuscount > 0)
		{
			for (iRelStatus = 0; iRelStatus < iStatuscount; iRelStatus++)
			{
				TERADYNE_TRACE_CALL(iStatus = RELSTAT_ask_release_status_type(tStatuslist[iRelStatus], &pcStatustype), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(pcStatustype, TD_STD_ECN_STATUS_TYPE) == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = WSOM_status_ask_effectivities(tStatuslist[iRelStatus], &iEffcount, &tEfflist), TD_LOG_ERROR_AND_THROW);
					if (iEffcount > 0)
					{
						TERADYNE_TRACE_CALL(iStatus = WSOM_eff_ask_dates(tStatuslist[iRelStatus], tEfflist[iEffcount - 1], &iEffDateCount, &tEffStartDateTime, &open_ended), TD_LOG_ERROR_AND_THROW);
						int iStartDate = (iEffDateCount % 2 == 0) ? (iEffDateCount - 2) : (iEffDateCount - 1);
						TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string(tEffStartDateTime[iStartDate], "%m/%d/%Y", &pcAttrValue), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = WSOM_eff_ask_range_type(tStatuslist[iRelStatus], tEfflist[0], &range_type), TD_LOG_ERROR_AND_THROW);

						resECNEffVec.push_back(tc_strtok(pcECNIDValue, "-"));

						if (range_type == 1)
							resECNEffVec.push_back(TD_UNIT_EFF_TYPE);
						else if (range_type == 2)
							resECNEffVec.push_back(TD_DATE_EFF_TYPE);

						if ((pcAttrValue != NULL) && (tc_strlen(pcAttrValue) > 0))
						{
							string szAttrValue(pcAttrValue);

							resECNEffVec.push_back(szAttrValue);
						}

						Custom_free(pcAttrValue);

						Custom_free(tEfflist);
						Custom_free(tEffStartDateTime);
					}
				}
				Custom_free(pcStatustype);
			}
		}
		Custom_free(tStatuslist);
		Custom_free(pcECNIDValue);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_find_and_create_dataset
* Description		: if Dataset found with input name then replace namedref only else
*                     create and attach dataset under ECN Revision with attaches relation
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_find_and_create_dataset(char *cFileName, tag_t tTargetObject, char *pcDatasetID)
{
	int iStatus = ITK_ok;
	int	iObjCount = 0;

	tag_t tNewDataset = NULLTAG;
	tag_t *tObjFoundTag = NULL;
	tag_t tRelationTag = NULLTAG;

	char *pcDOCObjectType = NULL;
	char *pcDOCObjectName = NULL;

	AE_reference_type_t tagRefType = AE_ASSOCIATION;

	bool isDatasetFound = false;

	char* __function__ = "teradyne_find_and_create_dataset";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_REF_MATERIAL_REL, &tRelationTag), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tTargetObject, tRelationTag, &iObjCount, &tObjFoundTag), TD_LOG_ERROR_AND_THROW);
		for (int i = 0; i < iObjCount; i++)
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObjFoundTag[i], TD_OBJECT_TYPE_ATTR, &pcDOCObjectType), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObjFoundTag[i], TD_OBJECT_NAME_ATTR, &pcDOCObjectName), TD_LOG_ERROR_AND_THROW);

			if ((tc_strcmp(pcDOCObjectType, TD_DATASETTYPE) == 0) && (tc_strcmp(pcDOCObjectName, pcDatasetID) == 0))
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_find_and_replace_namedRef(TD_BINARY_FORMATTYPE, cFileName, TD_NAMED_REFERENCE, tagRefType, tObjFoundTag[i], tTargetObject), TD_LOG_ERROR_AND_THROW);

				isDatasetFound = true;

				Custom_free(pcDOCObjectType);

				Custom_free(pcDOCObjectName);
				break;
			}

			Custom_free(pcDOCObjectType);
			Custom_free(pcDOCObjectName);
		}
		if (!isDatasetFound)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_create_and_attach_dataset(pcDatasetID, "", TD_DATASETTYPE, TD_BINARY_FORMATTYPE, cFileName, TD_NAMED_REFERENCE, TD_REF_MATERIAL_REL, tagRefType, tTargetObject, &tNewDataset), TD_LOG_ERROR_AND_THROW);
			tag_t tReleased = NULLTAG;
			TERADYNE_TRACE_CALL(iStatus = RELSTAT_create_release_status(TD_REL_STATUS_NAME, &tReleased), TD_LOG_ERROR_AND_THROW);
			if (tReleased != NULLTAG) {
				TERADYNE_TRACE_CALL(iStatus = RELSTAT_add_release_status(tReleased, 1, &tNewDataset, true), TD_LOG_ERROR_AND_THROW);
			}
		}

		Custom_free(tObjFoundTag);
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_find_and_replace_namedRef
* Description		: Replace namedref in given input Dataset
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tRevTag  (I)                  - objecttag
*                      strPropNameValueMap (I)       - Attribute value in Map
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_find_and_replace_namedRef(char *cFormatName, char *cDatasetRefName, char *cReferenceName, AE_reference_type_t ref_type, tag_t tagDataset, tag_t tTargetObject)
{
	int   iStatus = ITK_ok;

	tag_t tagFileTag = NULLTAG;
	tag_t tagReferencedObj = NULLTAG;

	IMF_file_t file_desc;

	AE_reference_type_t RefType;

	char* __function__ = "teradyne_find_and_replace_namedRef";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tc_strcmp(cFormatName, TD_BINARY_FORMATTYPE) == 0)
		{
			TERADYNE_TRACE_CALL(iStatus = IMF_import_file(cDatasetRefName, NULL, SS_BINARY, &tagFileTag, &file_desc), TD_LOG_ERROR_AND_THROW);
		}
		else
		{
			TERADYNE_TRACE_CALL(iStatus = IMF_import_file(cDatasetRefName, NULL, SS_TEXT, &tagFileTag, &file_desc), TD_LOG_ERROR_AND_THROW);
		}
		if (tagFileTag != NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus = IMF_close_file(file_desc), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tagFileTag), TD_LOG_ERROR_AND_THROW);
			POM_AM__set_application_bypass(true);

			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tTargetObject, true), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tagDataset, true), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AE_ask_dataset_named_ref2(tagDataset, cReferenceName, &RefType, &tagReferencedObj), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AE_replace_dataset_named_ref2(tagDataset, tagReferencedObj, cReferenceName, ref_type, tagFileTag), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tagDataset), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tagDataset, false), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tTargetObject, false), TD_LOG_ERROR_AND_THROW);
			POM_AM__set_application_bypass(false);
		}
	}
	catch (...)
	{
		AOM_refresh(tagDataset, false);
		POM_AM__set_application_bypass(false);
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_get_description
* Description		: Div Part Revision - get td4StandardDescription value
*                     Commercial Part Revision - get td4Description value
*
* REQUIRED HEADERS	:
* INPUT PARAMS		:  tBOMLineTag  (I)        - BOM line tag
*                      pcDescription (OF)      - td4StandardDescription or td4Description value
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_get_description(tag_t tBOMLineTag, char **pcDescription)
{
	int   iStatus = ITK_ok;

	tag_t tItemRev = NULLTAG;

	char *pcObjectType = NULL;

	char* __function__ = "teradyne_get_description";

	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tBOMLineTag, TD_REV_TAG_ATTR, &tItemRev), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tItemRev, &pcObjectType), TD_LOG_ERROR_AND_THROW);

		if (tc_strcmp(pcObjectType, TD_DIV_PART_REV) == 0) {
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRev, TD_STANDARD_DESC_ATTR, pcDescription), TD_LOG_ERROR_AND_THROW);
		} else if (tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0) {
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRev, TD_DESCR_ATTR, pcDescription), TD_LOG_ERROR_AND_THROW);
		} else {
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tItemRev, TD_OBJECT_DESC_ATTR, pcDescription), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcObjectType);

	return iStatus;
}
