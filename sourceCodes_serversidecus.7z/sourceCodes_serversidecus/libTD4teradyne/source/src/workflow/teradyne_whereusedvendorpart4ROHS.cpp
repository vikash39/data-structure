/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_whereusedvendorpart4ROHS.cpp 
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-WhereUsedVendorPart4ROHS action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
# 20-Apr-2015						Kameshwaran D						Initial creation	
#  18-May-2015						Haripriya						    Added type check condition
#  18-May-2015						Haripriya						    Added type check condition   
#  12-Jun-2015						Haripriya						    Modified function to copy terpart complianceregrade folder
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_whereusedvendorpart4ROHS
 * Description				: This function will get where used parts for the action handler 
 *							  Teradyne-whereusedvendpart4ROHS                           
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_whereusedvendorpart4ROHS(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttachCount			= 0;
		
	tag_t *ptAttaches			= NULL,
		  tFolder				= NULLTAG;

	char *pcAttachType          = NULL;
		 
	std::vector<tag_t>			tTeradynePartVec;
	const char * __function__ = "teradyne_whereusedvendorpart4ROHS";
	TERADYNE_TRACE_ENTER();

	try {
			//Checks whether "Compliance Regrade" folder present in dba group ,if not create it under dba group
			TERADYNE_TRACE_CALL(iStatus = teradyne_check_and_create_complaince_regrade_folder(&tFolder), TD_LOG_ERROR_AND_THROW);

			if(msg.task != NULLTAG) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);

				for(int i = 0; i < iAttachCount; i++) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcAttachType,TD_MFG_PART)) 
					{ 
					//Get the  Teradyne Part related to Vendor part 
						TERADYNE_TRACE_CALL(iStatus = teradyne_get_teradyne_part_related_to_vendor_part(ptAttaches[i],&tTeradynePartVec), TD_LOG_ERROR_AND_THROW);

						size_t iTerVecSize = tTeradynePartVec.size();
						for ( int iTeraPos  = 0 ; iTeraPos < iTerVecSize ; iTeraPos++)
						{
							//Geting the where used parts of the Item revision and will get copy to the created folder.
							TERADYNE_TRACE_CALL(iStatus = teradyne_check_given_object_in_folder(tFolder,tTeradynePartVec[iTeraPos]), TD_LOG_ERROR_AND_THROW);
						}
					}
					Custom_free(pcAttachType);
				}
			}
		}catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}
	
	
	Custom_free(ptAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_get_teradyne_part_related_to_vendor_part
 * Description				: This function will get teradyne part related to Vendor part
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					:
 ******************************************************************************/
int teradyne_get_teradyne_part_related_to_vendor_part(tag_t tTargetTag, vector<tag_t> *tTeradynePartVec)
{
	int	 iStatus				= ITK_ok,
		 iObjCount				= 0;

	tag_t *tFindTeraObjTag		= {NULLTAG},
		  tRelationType			= NULLTAG;

	const char * __function__	= "teradyne_get_teradyne_part_related_to_vendor_part";
	TERADYNE_TRACE_ENTER();

	try {
			//Get relation type based on VMRepresents relation
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VENDOR_REPERESENTS_REL_NAME,&tRelationType),TD_LOG_ERROR_AND_THROW);

			//Get the primary object which are in VMRepresents relation
			TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tTargetTag,tRelationType,&iObjCount,&tFindTeraObjTag),TD_LOG_ERROR_AND_THROW);

			for(int iSecPos = 0 ; iSecPos < iObjCount ; iSecPos++)
			{
				char*	ObjTerType			= NULL;

				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tFindTeraObjTag[iSecPos],&ObjTerType),TD_LOG_ERROR_AND_THROW);

				//Check the object are Divisional Part revision /Commercial Part revision only.
				string strObjTer(ObjTerType);
				if(strObjTer.compare(TD_DIV_PART_REV) == 0 ||  strObjTer.compare(TD_COMM_PART_REV) == 0 )
				{
					tTeradynePartVec->push_back(tFindTeraObjTag[iSecPos]);
				}
			}
		}catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}
	
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}