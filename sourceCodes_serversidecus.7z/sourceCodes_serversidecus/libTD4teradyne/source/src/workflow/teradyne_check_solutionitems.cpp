/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_check_solutionitems.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-SolutionItems-ORG-Check rule handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  14-Aug-2015                      Haripriya                    	Added function definitions teradyne_check_solutionitems.
#  28-Oct-2015                      Manimaran                       Modified the code to check if the same item revision exists in more than one working ECN revisions.
#  04-May-2016                      Haripriya                       Modified the code to check release status from latest sequence.
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>


/*******************************************************************************
 * Function Name			: teradyne_check_solutionitems
 * Description				: Validate itemRev under Solution item has the relation already
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					: 
 ******************************************************************************/
EPM_decision_t teradyne_check_solutionitems(EPM_rule_message_t msg) 
{
	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iSecCount               = 0,
		n_references            = 0,
		*levels                 = NULL;

	char *tSecObjectType		= NULL,
		 *pcObjectType			= NULL,
		 *pcItemId			    = NULL,
		 *pcEcnCBU				= NULL,
		 *pcCBU					= NULL,
		 *pcRevID               = NULL,
		 *pcECNId               = NULL,
		 **relation_type_name   = NULL;

	tag_t *tAttaches			= {NULLTAG},
		  *tSecObjects			= {NULLTAG},
          tItemSecObject        = NULLTAG,
		  *reference_tags		= {NULLTAG};

	EPM_decision_t epmDecision  = EPM_go;


	const char * __function__ = "teradyne_check_solutionitems";
	TERADYNE_TRACE_ENTER();

	try 
	{
		//Getting target attachments from the roottask.
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
		for(int i = 0; i < iAttaches; i++) 
		{
			//Validating Object type and works for StandardECNRevision,ProtoBOMECNRevision,ReleaseECNRevision
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);

			if( (tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcObjectType, TD_PROTOPART_ECN_REV_TYPE) == 0 ) )
			{

				bool  foundDivPartRevisionNSolutionItem = false;
				char *pcSolutionObjectType = NULL;
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i],TD_ITEM_ID_ATTR, &pcECNId), TD_LOG_ERROR_AND_THROW);
				//Getting the Parts under solution item Folder
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iSecCount, &tSecObjects), TD_LOG_ERROR_AND_THROW);
					
				    if (iSecCount == 0){
						epmDecision = EPM_nogo;
						TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_NO_SOLUTION_ITEMS_ERROR), TD_LOG_ERROR_AND_THROW);
						iStatus = TD_NO_SOLUTION_ITEMS_ERROR;
						throw (EPM_decision_t)TD_NO_SOLUTION_ITEMS_ERROR;
					}


					for(int j = 0; j < iSecCount; j++) 
					{
						TERADYNE_TRACE_CALL(iStatus = WSOM_where_referenced2(tSecObjects[j],1, &n_references, &levels,&reference_tags, &relation_type_name), TD_LOG_ERROR_AND_THROW); 
						TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSecObjects[j],&tItemSecObject), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL ( iStatus = ITEM_ask_id2(tItemSecObject,&pcItemId),TD_LOG_ERROR_AND_THROW );
						TERADYNE_TRACE_CALL ( iStatus = ITEM_ask_rev_id2(tSecObjects[j],&pcRevID),TD_LOG_ERROR_AND_THROW );
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecObjects[j], &pcSolutionObjectType), TD_LOG_ERROR_AND_THROW);
						string szitemid ="";
						string szObjtype ="";
						szitemid.append(pcItemId).append("/").append(pcRevID);
						szObjtype.append(pcObjectType);
						szObjtype.erase(0,3);


						if (tc_strcmp(pcSolutionObjectType,TD_DIV_PART_REV)==0) {
						   foundDivPartRevisionNSolutionItem = true;
						}


						for(int k=1;k<n_references;k++)
						{
							char  *pcReferTypeName= NULL;
							string szcombined="";
							char *pcRefECNId= NULL;
							string szECNObjtype ="";

							TERADYNE_TRACE_CALL(iStatus =teradyne_ask_object_type(reference_tags[k],&pcReferTypeName),TD_LOG_ERROR_AND_THROW);
							szECNObjtype.append(pcReferTypeName);
							szECNObjtype.erase(0,3);
							if( (tc_strcmp(pcReferTypeName, TD_STD_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcReferTypeName, TD_REL_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcReferTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0) || (tc_strcmp(pcReferTypeName, TD_PROTOPART_ECN_REV_TYPE) == 0 ) )
							{
								bool bLatestSeq = true;
								TERADYNE_TRACE_CALL(iStatus = ITEM_rev_sequence_is_latest (reference_tags[k],&bLatestSeq), TD_LOG_ERROR_AND_THROW);
								if(!bLatestSeq){
									continue;
								}

								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(reference_tags[k],TD_ITEM_ID_ATTR, &pcRefECNId), TD_LOG_ERROR_AND_THROW);

								if ((tc_strcmp(pcECNId,pcRefECNId)==0) && (tc_strcmp(pcObjectType,pcReferTypeName)==0)) {
									continue;
								}
							
								tag_t  tECNRelStatusTag     = NULLTAG;
								TERADYNE_TRACE_CALL(iStatus = teradyne_get_release_status_tag(reference_tags[k], &tECNRelStatusTag), TD_LOG_ERROR_AND_THROW);
								if (tECNRelStatusTag == NULLTAG) {
									epmDecision = EPM_nogo;
									TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s5(EMH_severity_error, TD_CHECK_SOLUTIONITEM_WORKING_ECN_ERROR, szitemid.c_str(), szECNObjtype.c_str(), pcRefECNId, szObjtype.c_str(), pcECNId), TD_LOG_ERROR_AND_THROW);
									throw (EPM_decision_t)TD_CHECK_SOLUTIONITEM_WORKING_ECN_ERROR;
								}

							
							}
							if((tc_strcmp(relation_type_name[k],TD_SOLUTION_ITEMS_REL_NAME)==0)  &&((tc_strcmp(pcReferTypeName, TD_REL_ECN_REV_TYPE) == 0) || (tc_strcmp(pcReferTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0) || (tc_strcmp(pcReferTypeName, TD_PROTOPART_ECN_REV_TYPE) == 0)) && ( (tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE) == 0 ))) 
							{
								epmDecision = EPM_nogo;
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s5(EMH_severity_error,TD_CHECK_SOLUTIONITEM_ERROR,szitemid.c_str(),szECNObjtype.c_str(),pcRefECNId,szObjtype.c_str(),pcECNId), TD_LOG_ERROR_AND_THROW);
					            throw (EPM_decision_t)TD_CHECK_SOLUTIONITEM_ERROR;
							}
							else if((tc_strcmp(relation_type_name[k],TD_SOLUTION_ITEMS_REL_NAME)==0)  &&(tc_strcmp(pcReferTypeName, TD_REL_ECN_REV_TYPE) == 0 ) && ( (tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE) == 0 || tc_strcmp(pcObjectType, TD_PROTOPART_ECN_REV_TYPE) == 0 ))) 
							{
								epmDecision = EPM_nogo;
								TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s5(EMH_severity_error,TD_CHECK_SOLUTIONITEM_ERROR,szitemid.c_str(),szECNObjtype.c_str(),pcRefECNId,szObjtype.c_str(),pcECNId), TD_LOG_ERROR_AND_THROW);
					            throw (EPM_decision_t)TD_CHECK_SOLUTIONITEM_ERROR;
							}
							else if((tc_strcmp(relation_type_name[k],TD_SOLUTION_ITEMS_REL_NAME)==0)  &&(tc_strcmp(pcReferTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0 || tc_strcmp(pcReferTypeName, TD_PROTOPART_ECN_REV_TYPE) == 0    ) && ( (tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) == 0 ))) 
							{
								tag_t  tECNStatusTag     = NULLTAG;
								TERADYNE_TRACE_CALL(iStatus = teradyne_get_release_status_tag(tSecObjects[j],&tECNStatusTag), TD_LOG_ERROR_AND_THROW);
								if(tECNStatusTag == NULLTAG)
								{
									epmDecision = EPM_nogo;
									TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s5(EMH_severity_error,TD_CHECK_SOLUTIONITEM_ERROR,szitemid.c_str(),szECNObjtype.c_str(),pcRefECNId,szObjtype.c_str(),pcECNId), TD_LOG_ERROR_AND_THROW);
									 throw (EPM_decision_t)TD_CHECK_SOLUTIONITEM_ERROR;
								}
							}
							Custom_free(pcReferTypeName);
							Custom_free(pcRefECNId);
					}

					TERADYNE_TRACE_CALL(iStatus = teradyne_get_cbu_from_project(tAttaches[i], TD_PRIMARY_PROJECT,&pcEcnCBU),TD_LOG_ERROR_AND_THROW);
				
					if(!tc_strcmp(pcEcnCBU,TD_NXT))
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecObjects[j], &tSecObjectType), TD_LOG_ERROR_AND_THROW);
						//allow only DivPart's CBU to be check, skip if other
						if(tc_strcmp(tSecObjectType,TD_DIV_PART_REV)) 
						{
							continue;
						}
						pcCBU = "";
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecObjects[j],TD_CONTRL_BUSS_UNIT_CRE,&pcCBU), TD_LOG_ERROR_AND_THROW);
						
						if(tc_strcmp(pcCBU, "") == 0){
						     TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecObjects[j],TD_CONTRL_BUSS_UNIT,&pcCBU), TD_LOG_ERROR_AND_THROW);
						}
						
						
						if(tc_strcmp(pcCBU,pcEcnCBU)) 
						{
							epmDecision = EPM_nogo;
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_NOT_NXT_ON_NXT_ECN_ERROR, szitemid.c_str()), TD_LOG_ERROR_AND_THROW);
							throw (EPM_decision_t)TD_NOT_NXT_ON_NXT_ECN_ERROR;
						}
					} 
					else 
					{
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecObjects[j], &tSecObjectType), TD_LOG_ERROR_AND_THROW);
						//allow only DivPart's CBU to be check, skip if other
						if(tc_strcmp(tSecObjectType,TD_DIV_PART_REV)) 
						{
							continue;
						}
						pcCBU = "";
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecObjects[j],TD_CONTRL_BUSS_UNIT_CRE,&pcCBU), TD_LOG_ERROR_AND_THROW);


						if(tc_strcmp(pcCBU, "") == 0){
						     TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecObjects[j],TD_CONTRL_BUSS_UNIT,&pcCBU), TD_LOG_ERROR_AND_THROW);
						}
						

						if(!tc_strcmp(pcCBU,TD_NXT)) 
						{
							epmDecision = EPM_nogo;
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TD_NXT_ON_NOT_NXT_ECN_ERROR, szitemid.c_str()), TD_LOG_ERROR_AND_THROW);
							throw (EPM_decision_t)TD_CHECK_SOLUTIONITEM_WORKING_ECN_ERROR;
						}			
					}

					Custom_free(levels);
					Custom_free(reference_tags);
					Custom_free(relation_type_name);
					Custom_free(pcCBU);
					Custom_free(pcItemId);
				}
				Custom_free(tSecObjectType);
				Custom_free(tSecObjects);
				Custom_free(pcSolutionObjectType);


				if (!foundDivPartRevisionNSolutionItem) {
					epmDecision = EPM_nogo;
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_SOLUTION_ITEM_MISSING_DIV_PART), TD_LOG_ERROR_AND_THROW);
					throw (EPM_decision_t)TD_SOLUTION_ITEM_MISSING_DIV_PART;
				}


				}
			Custom_free(pcObjectType);
			Custom_free(pcECNId);
		}
	}
	catch(...) 
	{

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);

	return epmDecision;
}
