/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_change_all_started_to_suspend_resume.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-change-all-started-to-suspend-resume action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  04-May-2015                       Haripriya                    	    Initial Creation
#  07-May-2015                       Haripriya                    	    Added task action to resume action
#  26-June-2015                      Haripriya                    	    Suspended Select-signoff and perform signoff task.
#  03-Jul-2015					     Haripriya                    	    Removed asking groupmembers for the given Review Task.
#  14-Jul-2015					     Haripriya                    	    Modified the Respparty Value as the Logged in User.
#  17-Jul-2015					     Haripriya                    	    Suspending or resuming action is performed by POM calls.
#  27-Jul-2015					     Selvi                    			Added function to Insert and remove task form TasksToPerform folder of users when its go for resume and suspended state.
#  23-Mar-2016					     Haripriya                    	    Modified teradyne_insert_task_into_folder function to insert the task after checking whether it is already in that folder
#  02-May-2016                       Manimaran                          Modified the code to recalculate Task duration, due date of Technical Review and CCB Review perform signoff tasks when the ECN is resubmitted.
#  03-May-2016                       Manimaran                          Modified the code to suspend/resume a condition task.
#  14-Jul-2016                       Manimaran                          Modified the code to clear off all decisions and set to "No Decision" when the ECN is resubmitted.
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_change_all_started_to_suspend_resume
 * Description				: This function will Assign Change the task state to suspended or resume based on action argument.
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:1. Read the arguments "-action","-task"  in task and action argument is mandatory.
 *							 2. For the given task ,given action is performed.
 *
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_change_all_started_to_suspend_resume(EPM_action_message_t msg)
{
	int iStatus			    = ITK_ok,
		iAttachCount        = 0,
		isubtaskCnt         = 0,
		isustaskcount       = 0;

	tag_t *tAttachtag       = {NULLTAG},
		   tjobtag          = NULLTAG,
		   troottask        = NULLTAG,
		   tsubtask         = NULLTAG,
		   tPerformtask     = NULLTAG,
		   *tReviewsubtask  = {NULLTAG},
		   *tsusptask       = {NULLTAG};

   char *pctaskaction       = NULL,
	    *pctaskname         = NULL,
	    *pctaskTypename		= NULL,
   	    *pcTypeName         = NULL;	
   char *pcUsername=NULL;

   		EPM_state_t state;
		char *statestring=NULL;

   	 vector<string> ReviewerTaskValues;

	const char * __function__    = "teradyne_change_all_started_to_suspend_resume" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		//read the handler arguments
		teradyne_get_handler_opts(msg.arguments,
		"-action", &pctaskaction,
		"-task", &pctaskname,
		NULL);

		if(pctaskaction != NULL) 
		{
			//Getting target attachments
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttachCount; i++) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
				//request will be processed for the below specified item revisions
				if(pcTypeName != NULL && ((tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0) ||(tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0)))
				{
					tag_t tUserTag=NULLTAG;
					//Current Logged in User Value
					TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcUsername,&tUserTag),TD_LOG_ERROR_AND_THROW);
					Custom_free(pcUsername);
					
					TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task (msg.task,&troottask), TD_LOG_ERROR_AND_THROW);
					if(pctaskname != NULL)
					{
						char *pch = strtok (pctaskname,",");
						while (pch != NULL)
						{
							ReviewerTaskValues.push_back(pch);
							pch = strtok (NULL, ",");
						}
					}
					//If the Given action is suspend,then suspending the given task perform-signoff task
					if(!ReviewerTaskValues.empty())
					{
						for(int i=0;i<ReviewerTaskValues.size();i++)
						{
							TERADYNE_TRACE_CALL(iStatus = EPM_ask_sub_task(troottask,ReviewerTaskValues.at(i).c_str(),&tsubtask), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus =EPM_ask_sub_tasks(tsubtask,&isubtaskCnt,&tReviewsubtask) , TD_LOG_ERROR_AND_THROW); 
							for (int i = 0; i < isubtaskCnt; i++) {
								
								TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tReviewsubtask[i], &pctaskTypename), TD_LOG_ERROR_AND_THROW);
								if (strcmp(pctaskTypename, "EPMPerformSignoffTask") == 0) {
									
									TERADYNE_TRACE_CALL(iStatus = EPM_ask_state(tReviewsubtask[i], &state), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = EPM_ask_state_string2(state, &statestring), TD_LOG_ERROR_AND_THROW);
									
								}

							}
							/*if(isubtaskCnt == 2)
							{
								TERADYNE_TRACE_CALL(iStatus =EPM_ask_state(tReviewsubtask[1],&state),TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus =EPM_ask_state_string2(state,&statestring),TD_LOG_ERROR_AND_THROW); 
							}*/
							if((tc_strcmp(pctaskaction,TASK_SUSPEND_STATE)==0) || (tc_strcmp(pctaskaction,TASK_RESUME_STATE)==0))
							{
								for(int icnt=0;icnt<isubtaskCnt;icnt++)
								{
									tag_t tattrTag=NULLTAG;
									bool bismodifiable= true;
									bool bisloaded= true;
									TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tReviewsubtask[icnt], &pctaskTypename), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus =POM_attr_id_of_attr("state_value","EPMTask",&tattrTag),TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tReviewsubtask[icnt],&bismodifiable),TD_LOG_ERROR_AND_THROW);
									if(!bismodifiable)
									{
										TERADYNE_TRACE_CALL(iStatus=POM_refresh_instances_any_class (1,&tReviewsubtask[icnt],POM_modify_lock),TD_LOG_ERROR_AND_THROW);				
									}
									TERADYNE_TRACE_CALL(iStatus=POM_is_loaded (tReviewsubtask[icnt],&bisloaded),TD_LOG_ERROR_AND_THROW);
									if(!bisloaded)
									{
										TERADYNE_TRACE_CALL(iStatus=POM_load_instances_any_class (1,&tReviewsubtask[icnt],POM_modify_lock),TD_LOG_ERROR_AND_THROW);				
									}
									if((tc_strcmp(statestring,TASK_START_STATE)==0) && (tc_strcmp(pctaskaction,TASK_SUSPEND_STATE)==0))
									{
										TERADYNE_TRACE_CALL(iStatus =POM_set_attr_int(1,&tReviewsubtask[icnt],tattrTag,128),TD_LOG_ERROR_AND_THROW);
										
										//Callimg function to delete tasks from Tasks to Perform folder which are in suspended state.
										TERADYNE_TRACE_CALL(iStatus = teradyne_delete_task_from_folder (tReviewsubtask[icnt]),TD_LOG_ERROR_AND_THROW);
									}
									else if((tc_strcmp(statestring,TASK_SUSPENDED_STATE)==0) && (tc_strcmp(pctaskaction,TASK_RESUME_STATE)==0))
									{
										if (tc_strcmp(pctaskTypename, "EPMSelectSignoffTask") == 0)
										{
											TERADYNE_TRACE_CALL(iStatus = POM_set_attr_int(1, &tReviewsubtask[icnt], tattrTag, 8), TD_LOG_ERROR_AND_THROW);
										}
										else if (tc_strcmp(pctaskTypename, "EPMPerformSignoffTask") == 0)
										{
											TERADYNE_TRACE_CALL(iStatus =POM_set_attr_int(1,&tReviewsubtask[icnt],tattrTag,4),TD_LOG_ERROR_AND_THROW);
											
											//Recalculate Task duration, due date of Technical Review and CCB Review perform signoff tasks when the ECN is resubmitted.
											char *taskName = NULL;
											TERADYNE_TRACE_CALL(iStatus = EPM_ask_name2(tsubtask, &taskName), TD_LOG_ERROR_AND_THROW);

											if ((tc_strcmp(taskName, "Technical Review")==0) || (tc_strcmp(taskName, "CCB Review")==0)) {
												POM_AM__set_application_bypass(true);
												TERADYNE_TRACE_CALL(iStatus = EPM_set_task_duration(tReviewsubtask[icnt], 0, 0, 3, 0, 0), TD_LOG_ERROR_AND_THROW);

												struct timeb timebuffer ;
												ftime( &timebuffer ) ;

												time_t t = timebuffer.time ;
												struct tm *pttm = localtime( &t ) ;
												pttm -> tm_mday += 3;

												time_t tt = mktime(pttm) ;
												struct tm *ptm = localtime( &tt ) ;

												date_t 	due_date;
												due_date.year = ptm -> tm_year + 1900 ;
												due_date.month = ptm -> tm_mon;
												due_date.day = ptm -> tm_mday;
												due_date.hour = ptm -> tm_hour;
												due_date.minute = ptm -> tm_min;
												due_date.second = ptm -> tm_sec;
												TERADYNE_TRACE_CALL(iStatus = EPM_set_task_due_date(tReviewsubtask[icnt], due_date), TD_LOG_ERROR_AND_THROW);
												POM_AM__set_application_bypass(false);
											}
											Custom_free(taskName);

											//Callimg function to insert tasks into "Tasks to Perform" folder which it goes for resume state.
											TERADYNE_TRACE_CALL(iStatus = teradyne_find_task_reviewers (tReviewsubtask[icnt]),TD_LOG_ERROR_AND_THROW);
										}
									}
									TERADYNE_TRACE_CALL(iStatus = POM_save_instances(1, &tReviewsubtask[icnt], true),TD_LOG_ERROR_AND_THROW);
									if(!bismodifiable)
									{
										TERADYNE_TRACE_CALL(iStatus=POM_refresh_instances_any_class (1,&tReviewsubtask[icnt],POM_no_lock),TD_LOG_ERROR_AND_THROW);
									}

									//Clear off all decisions and set to "No Decision" when the ECN is resubmitted.
									if((tc_strcmp(statestring, TASK_SUSPENDED_STATE) == 0) && (tc_strcmp(pctaskaction, TASK_RESUME_STATE) == 0) && (tc_strcmp(pctaskTypename, "EPMPerformSignoffTask") == 0)) {
										int iSignoffAttCount;
										tag_t* tSignoffAttachments;

										TERADYNE_TRACE_CALL(iStatus = EPM_ask_attachments(tReviewsubtask[icnt], EPM_signoff_attachment, &iSignoffAttCount, &tSignoffAttachments), TD_LOG_ERROR_AND_THROW);

										EPM_signoff_decision_t decision;
										char *pcComments = NULL;
										date_t decisionDate;
										for (int i = 0; i < iSignoffAttCount; i++) {
											TERADYNE_TRACE_CALL(iStatus = EPM_ask_signoff_decision(tSignoffAttachments[i], &decision, &pcComments, &decisionDate), TD_LOG_ERROR_AND_THROW);

											if(decision != EPM_no_decision) {
												tag_t tMember = NULLTAG;
												SIGNOFF_TYPE_t memberType;
												string strComments(pcComments);

												POM_AM__set_application_bypass(true);
												TERADYNE_TRACE_CALL(iStatus = EPM_ask_signoff_member(tSignoffAttachments[i], &tMember, &memberType), TD_LOG_ERROR_AND_THROW);
												TERADYNE_TRACE_CALL(iStatus = EPM_initialize_signoff(tSignoffAttachments[i], tMember), TD_LOG_ERROR_AND_THROW);
												TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tSignoffAttachments[i], "comments", strComments), TD_LOG_ERROR_AND_THROW);
												POM_AM__set_application_bypass(false);
											}
										}
										Custom_free(tSignoffAttachments);
										Custom_free(pcComments);
									}
								}
								Custom_free(statestring);

								//Suspend/Resume a condition task
								if (isubtaskCnt == 0) {
									EPM_state_t taskState;
									char *pcStateString = NULL;

									TERADYNE_TRACE_CALL(iStatus =EPM_ask_state(tsubtask, &taskState), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus =EPM_ask_state_string2(taskState, &pcStateString), TD_LOG_ERROR_AND_THROW);

									tag_t tAttrTag=NULLTAG;
									bool bIsModifiable= true;
									bool bIsLoaded= true;
									TERADYNE_TRACE_CALL(iStatus =POM_attr_id_of_attr("state_value", "EPMTask", &tAttrTag), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tsubtask, &bIsModifiable), TD_LOG_ERROR_AND_THROW);

									if(!bIsModifiable)
									{
										TERADYNE_TRACE_CALL(iStatus=POM_refresh_instances_any_class (1, &tsubtask, POM_modify_lock), TD_LOG_ERROR_AND_THROW);
									}

									TERADYNE_TRACE_CALL(iStatus = POM_is_loaded (tsubtask, &bIsLoaded), TD_LOG_ERROR_AND_THROW);

									if(!bIsLoaded)
									{
										TERADYNE_TRACE_CALL(iStatus = POM_load_instances_any_class (1, &tsubtask, POM_modify_lock), TD_LOG_ERROR_AND_THROW);
									}

									if((tc_strcmp(pcStateString, TASK_START_STATE)==0) && (tc_strcmp(pctaskaction, TASK_SUSPEND_STATE)==0))
									{
										//tag_t userTag = NULLTAG;
										//TERADYNE_TRACE_CALL(iStatus = EPM_ask_responsible_party(troottask, &userTag), TD_LOG_ERROR_AND_THROW);
										//TERADYNE_TRACE_CALL(iStatus = EPM_assign_responsible_party(tsubtask, userTag), TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = POM_set_attr_int(1, &tsubtask, tAttrTag, 128),TD_LOG_ERROR_AND_THROW);									

										TERADYNE_TRACE_CALL(iStatus = teradyne_delete_task_from_folder(tsubtask), TD_LOG_ERROR_AND_THROW);
									}
									else if((tc_strcmp(pcStateString, TASK_SUSPENDED_STATE)==0) && (tc_strcmp(pctaskaction, TASK_RESUME_STATE)==0))
									{

										//char taskName;
										TERADYNE_TRACE_CALL(iStatus = POM_set_attr_int(1, &tsubtask, tAttrTag, 4), TD_LOG_ERROR_AND_THROW);
										//TERADYNE_TRACE_CALL(iStatus = AOM_ask_name(tsubtask, taskName), TD_LOG_ERROR_AND_THROW);


										tag_t tResponsibleParty = NULLTAG;
										TERADYNE_TRACE_CALL(iStatus = EPM_ask_responsible_party(tsubtask, &tResponsibleParty), TD_LOG_ERROR_AND_THROW);

										char *pcUserName = NULL;
										char *pcUserID = NULL;
										string strPersonName;
										TERADYNE_TRACE_CALL(iStatus=SA_ask_user_identifier2 (tResponsibleParty, &pcUserID),TD_LOG_ERROR_AND_THROW);
										TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tResponsibleParty, &pcUserName),TD_LOG_ERROR_AND_THROW);

										strPersonName.assign(pcUserName);
										strPersonName.append(" ");
										strPersonName.append("(");
										strPersonName.append(pcUserID);
										strPersonName.append(")");

										TERADYNE_TRACE_CALL(iStatus = teradyne_insert_task_into_folder(strPersonName, tsubtask),TD_LOG_ERROR_AND_THROW);
										Custom_free(pcUserID);
										Custom_free(pcUserName);
									}

									TERADYNE_TRACE_CALL(iStatus = POM_save_instances(1, &tsubtask, true), TD_LOG_ERROR_AND_THROW);

									if(!bIsModifiable)
									{
										TERADYNE_TRACE_CALL(iStatus = POM_refresh_instances_any_class (1, &tsubtask, POM_no_lock), TD_LOG_ERROR_AND_THROW);
									}
								}
							}
							Custom_free(tReviewsubtask);
							
						}
					}
					else
					{
						//If the Given action is resume,finding all the suspended task task and resuming that task.
						TERADYNE_TRACE_CALL(iStatus = EPM_ask_job (msg.task,&tjobtag), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = EPM_ask_tasks (tjobtag,EPM_suspended,&isustaskcount,&tsusptask), TD_LOG_ERROR_AND_THROW);
						for(int j=0;j<isustaskcount;j++)
						{
							tag_t tattrTag=NULLTAG;
							bool bismodifiable= true;
							bool bisloaded= true;
							TERADYNE_TRACE_CALL(iStatus =POM_attr_id_of_attr("state_value","EPMTask",&tattrTag),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus=POM_modifiable(tsusptask[j],&bismodifiable),TD_LOG_ERROR_AND_THROW);
							if(!bismodifiable)
							{
								TERADYNE_TRACE_CALL(iStatus=POM_refresh_instances_any_class (1,&tsusptask[j],POM_modify_lock),TD_LOG_ERROR_AND_THROW);				
							}
							TERADYNE_TRACE_CALL(iStatus=POM_is_loaded (tsusptask[j],&bisloaded),TD_LOG_ERROR_AND_THROW);
							if(!bisloaded)
							{
								TERADYNE_TRACE_CALL(iStatus=POM_load_instances_any_class (1,&tsusptask[j],POM_modify_lock),TD_LOG_ERROR_AND_THROW);				
							}
							TERADYNE_TRACE_CALL(iStatus =POM_set_attr_int(1,&tsusptask[j],tattrTag,4),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = POM_save_instances(1, &tsusptask[j], true),TD_LOG_ERROR_AND_THROW);
							if(!bismodifiable)
							{
								TERADYNE_TRACE_CALL(iStatus=POM_refresh_instances_any_class (1,&tsusptask[j],POM_no_lock),TD_LOG_ERROR_AND_THROW);				
							}
										
						}
						Custom_free(tsusptask);
					}
				}
			}
		}
	}
	catch(...)
    {
		POM_AM__set_application_bypass(false);
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(pctaskTypename);
	Custom_free(pcTypeName);
	Custom_free(tAttachtag);
	ReviewerTaskValues.clear();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
* Function Name  	: teradyne_find_task_reviewers
* Description		: 
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  tReviewsubtask  (I)                  - objecttag
*                     
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*                     
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_find_task_reviewers(tag_t tReviewsubtask)
{
	int iStatus				= ITK_ok,  
		iUserCount			= 0, 
		irespoolCount		= 0, 
		iCount				= 0;

	tag_t *tProcessTags		= NULL,
			*tUser			= NULL,
			*trespoolUser	= NULL, 
			tResPoolGroup	= NULLTAG, 
			tResPoolRole	= NULLTAG,
			tParentGroup	= NULLTAG, 
			ttopParentGroup	= NULLTAG;

	char *pcsubTaskName		= NULL,
			*pcPersonName	= NULL, 
			*pcRespnsbleParty= NULL, 
			*pcRole			= NULL,
			*pcGroup		= NULL,
			*pcParentGroup	= NULL;

	string sTaskObjectName;
	logical islogicalSubGroup = false;
	
	char* __function__ = "teradyne_find_task_reviewers";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tReviewsubtask,TD_OBJECT_NAME_ATTR, &pcsubTaskName),TD_LOG_ERROR_AND_THROW);

		//getting users from Review Task
		TERADYNE_TRACE_CALL(iStatus = EPM_ask_task_reviewers_users(tReviewsubtask,&iUserCount, &tUser),TD_LOG_ERROR_AND_THROW);		
		if (iUserCount > 0)
		{											
			for(int iCnt=0; iCnt<iUserCount; iCnt++)
			{
				TERADYNE_TRACE_CALL(iStatus=SA_ask_user_identifier2 (tUser[iCnt],&pcRespnsbleParty),TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tUser[iCnt],&pcPersonName),TD_LOG_ERROR_AND_THROW);
				
				sTaskObjectName.assign("*(");
				sTaskObjectName.append(pcRespnsbleParty);
				sTaskObjectName.append(")*");
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_insert_task_into_folder(sTaskObjectName, tReviewsubtask),TD_LOG_ERROR_AND_THROW);
				Custom_free(pcRespnsbleParty);
				Custom_free(pcPersonName);
			}
		}

		//getting ResourcePool from Review Task			
		TERADYNE_TRACE_CALL(iStatus = EPM_ask_task_reviewers_resource_pool(tReviewsubtask,&irespoolCount, &trespoolUser),TD_LOG_ERROR_AND_THROW);
		if (irespoolCount > 0)
		{			
			for(int iResCnt=0; iResCnt<irespoolCount; iResCnt++)
			{
				TERADYNE_TRACE_CALL(iStatus = EPM_ask_resource_pool_group_role(trespoolUser[iResCnt], &tResPoolGroup, &tResPoolRole, &islogicalSubGroup),TD_LOG_ERROR_AND_THROW);
				if (tResPoolGroup != NULLTAG)
				{
					TERADYNE_TRACE_CALL(iStatus = SA_ask_group_name2(tResPoolGroup,&pcGroup),TD_LOG_ERROR_AND_THROW);	
					sTaskObjectName.assign(pcGroup);
					TERADYNE_TRACE_CALL(iStatus = SA_ask_group_parent(tResPoolGroup,&tParentGroup),TD_LOG_ERROR_AND_THROW);	
					if (tParentGroup != NULLTAG)
					{	
						TERADYNE_TRACE_CALL(iStatus = SA_ask_group_name2(tParentGroup,&pcParentGroup),TD_LOG_ERROR_AND_THROW);
						sTaskObjectName.append(".");
						sTaskObjectName.append(pcParentGroup);
						TERADYNE_TRACE_CALL(iStatus = SA_ask_group_parent(tParentGroup, &ttopParentGroup),TD_LOG_ERROR_AND_THROW);	
						if (ttopParentGroup != NULLTAG)
						{
							sTaskObjectName.append("*");
						}
						Custom_free(pcParentGroup);
					}	
					Custom_free(pcGroup);
				}
													
				if (tResPoolRole != NULLTAG)
				{
					TERADYNE_TRACE_CALL(iStatus = SA_ask_role_name2(tResPoolRole,&pcRole),TD_LOG_ERROR_AND_THROW);
					sTaskObjectName.append("/");
					sTaskObjectName.append(pcRole);
					Custom_free(pcRole);
				}								
																
				TERADYNE_TRACE_CALL(iStatus = teradyne_insert_task_into_folder(sTaskObjectName, tReviewsubtask),TD_LOG_ERROR_AND_THROW);
			}
		}	
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_insert_task_into_folder
* Description		: 
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  tTask  (I)                  - objecttag
*                      sTaskObjectName (I)       - Attribute value in Map
*                   
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*                     
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_insert_task_into_folder (std::string sTaskObjectName, tag_t tTask)
{
	int iStatus				= ITK_ok;  
	int iCount				= 0;
	int iTask				= 0;
	int iCnt				= 0;

	tag_t *tProcessTags = NULL;
	  
	std::map<string,string> strPropNameValueMap;

	char* __function__ = "teradyne_insert_task_into_folder";
	TERADYNE_TRACE_ENTER();

	try
	{
		strPropNameValueMap.insert(::make_pair(TD_TYPE_INPUT, TD_WF_PERFORM_FOLDER));
		strPropNameValueMap.insert(::make_pair(TD_SEARCH_NAME, sTaskObjectName));
		TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry(TD_GENERAL_QUERY, strPropNameValueMap, &iCount, &tProcessTags),TD_LOG_ERROR_AND_THROW);
																
		for (iCnt=0; iCnt<iCount; iCnt++)
		{
			POM_AM__set_application_bypass(true);
			
			int iTaskCnt = 0,iTaskFound = 0;
			tag_t *tTaskList={NULLTAG};

			TERADYNE_TRACE_CALL(iStatus = FL_ask_references(tProcessTags[iCnt],FL_fsc_as_ordered, &iTaskCnt, &tTaskList), TD_LOG_ERROR_AND_THROW);	
			if(iTaskCnt > 0 )
			{
				for(int i = 0; i < iTaskCnt; i++)
				{
						
					if(tTask == tTaskList[i]) 
					{
						iTaskFound++;
					}
				}
				Custom_free(tTaskList);
			}
			if((iTaskFound == 0) || (iTaskCnt == 0))
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tProcessTags[iCnt], true), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = FL_insert(tProcessTags[iCnt], tTask, 0), TD_LOG_ERROR_AND_THROW);		
				TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tProcessTags[iCnt]), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tProcessTags[iCnt], false), TD_LOG_ERROR_AND_THROW);		
			}
			POM_AM__set_application_bypass(false);
		}
	}
	catch(...)
	{
		AOM_refresh(tProcessTags[iCnt], false);		
		POM_AM__set_application_bypass(false);
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
* Function Name  	: teradyne_delete_task_from_folder
* Description		: 
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  tReviewsubtask  (I)                  - objecttag
*                   
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 
*                     
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int teradyne_delete_task_from_folder (tag_t tReviewsubtask)
{
	int iStatus				= ITK_ok;  
	int iCount				= 0;
	int iCnt				= 0;
	int irows				= 0;
	int icols				= 0;
	int iresult				= 0;
	int iNoofRef			= 0;

	const char *select_attr_list[1];
	char *foldertypes[]		=	{TD_TASKS_PERFORM_FOLDER};
	char* taskName=NULL;

	tag_t task_tag			= NULLTAG,
		  *tReference		= NULL,
		  *folderlist		= NULL;	
		
	void*** result;
		  
	std::map<string,string> strPropNameValueMap;

	char* __function__ = "teradyne_delete_task_from_folder";
	TERADYNE_TRACE_ENTER();

	try
	{
		select_attr_list[0]="puid";
		task_tag = tReviewsubtask;	
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(task_tag,"object_name", &taskName), TD_LOG_ERROR_AND_THROW);
		POM_enquiry_create(TD_POM_EPM_TASKINBOX_QRY);
		POM_enquiry_set_distinct(TD_POM_EPM_TASKINBOX_QRY,true);
		POM_enquiry_add_select_attrs(TD_POM_EPM_TASKINBOX_QRY,TD_TASK_INBOX,1,select_attr_list);
		POM_enquiry_set_string_value(TD_POM_EPM_TASKINBOX_QRY,"exp1",1,(const char**)foldertypes,POM_enquiry_const_value);
		POM_enquiry_set_attr_expr(TD_POM_EPM_TASKINBOX_QRY,"expr_type",TD_TASK_INBOX,TD_OBJECT_TYPE_ATTR,POM_enquiry_in,"exp1");
		POM_enquiry_set_tag_value(TD_POM_EPM_TASKINBOX_QRY,"exp2",1,&task_tag,POM_enquiry_bind_value);
		POM_enquiry_set_attr_expr(TD_POM_EPM_TASKINBOX_QRY,"expr_content",TD_TASK_INBOX,"contents",POM_enquiry_equal,"exp2");
		POM_enquiry_set_expr(TD_POM_EPM_TASKINBOX_QRY,"expr_combined","expr_type",POM_enquiry_and,"expr_content");
		POM_enquiry_set_where_expr(TD_POM_EPM_TASKINBOX_QRY,"expr_combined");
		POM_enquiry_execute(TD_POM_EPM_TASKINBOX_QRY,&irows,&icols,&result);

		if (irows != 0)
		{
			folderlist = (tag_t *) MEM_alloc ( irows * sizeof(tag_t));
			for (iresult = 0; iresult < irows; iresult++) 
			{
				folderlist[iresult] = *((tag_t *)result[iresult][0]);

				char *foldername = NULL;
				WSOM_ask_object_id_string( folderlist[iresult], &foldername);

				logical valid = true;
				AM__set_application_bypass(true);
				POM_AM__set_application_bypass(true);
				
				TERADYNE_TRACE_CALL(iStatus = FL_ask_references(folderlist[iresult],FL_fsc_as_ordered, &iNoofRef, &tReference), TD_LOG_ERROR_AND_THROW);
				if (iNoofRef > 0)
				{	
					
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(folderlist[iresult], true), TD_LOG_ERROR_AND_THROW);					
					iStatus = FL_remove(folderlist[iresult], task_tag);
					if (iStatus != ITK_ok)
						iStatus = EMH_clear_errors();

					TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(folderlist[iresult]), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(folderlist[iresult], false), TD_LOG_ERROR_AND_THROW);
					
					
				}
				AM__set_application_bypass(false);
				POM_AM__set_application_bypass(false);
				
				Custom_free(foldername);
			}											
		}
		POM_enquiry_delete (TD_POM_EPM_TASKINBOX_QRY);
	}
	catch(...)
	{
		AOM_refresh(folderlist[iresult], false);
		AM__set_application_bypass(false);
		POM_AM__set_application_bypass(false);
		
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}