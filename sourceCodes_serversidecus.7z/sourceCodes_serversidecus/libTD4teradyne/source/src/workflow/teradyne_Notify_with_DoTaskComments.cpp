/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_Notify_with_DoTaskComments.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains functions related to Teradyne-send-notify-with-comment action handler
#      Project         :           libTD4teradyne
#      Author          :           Gurunathan S
#  =================================================================================================
#  Date                              Name                               Description of Change
#
#
#  $HISTORY$
#  =================================================================================================*/
#include <workflow/teradyne_handlers.h>
std::string teradyneBuildNotificationSubject(EPM_action_message_t msg, string reviewerName);
std::string teradyneBuildNotificationBodyContentComment(EPM_action_message_t msg, string commentEmail);


typedef map<string, string> MapSignOff;

struct SignOffComparator {
	bool operator()(MapSignOff signOffOne, MapSignOff signOffTwo) {
		return (signOffOne.find("lastModifiedDate")->second > signOffTwo.find("lastModifiedDate")->second);
	}
};
/*******************************************************************************
 * Function Name			: teradyne_Notify_with_DoTaskComments
 * Description				: This function will Sends a notification with comments taken from CSE workset Do task.
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 *
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_Notify_with_DoTaskComments(EPM_action_message_t msg)
{
	int iStatus = ITK_ok,
		iAttaches = 0,
		wrkfwcount = 0,
		iSubTaskCount = 0;

	tag_t tOwner = NULL,
		*tAttaches = NULL,
		*wrkfw_tag = NULL,
		*ptSubTasks = NULL;


	string strMailFilePath = "",
		subject = "";

	char *pcObjectType = NULL,
		*pcNotificationReceiverEmail = NULL,
		*subtaskname = NULL,
		*pccomments = NULL,
		*pcOwnerName = NULL;

	set<MapSignOff, SignOffComparator> setMapSignOff;

	date_t  	decisionDateSignoff;

	const char * __function__ = "teradyne_Notify_with_DoTaskComments";
	TERADYNE_TRACE_ENTER();

	try
	{

		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
		for (int i = 0; i < iAttaches; i++)
		{
			//Validating Object type and works for PartModifyRequestRevision
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);

			if (tc_strcmp(pcObjectType, TD_PART_MOD_REQ_REV) == 0)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tags(tAttaches[i], "fnd0AllWorkflows", &wrkfwcount, &wrkfw_tag), TD_LOG_ERROR_AND_THROW);
				for (int k = 0; k < wrkfwcount; k++)
				{
					TERADYNE_TRACE_CALL(iStatus = EPM_ask_sub_tasks(wrkfw_tag[k], &iSubTaskCount, &ptSubTasks), TD_LOG_ERROR_AND_THROW);
					for (int j = 0; j <= iSubTaskCount; j++)
					{
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_name(ptSubTasks[j], &subtaskname), TD_LOG_ERROR_AND_THROW);
						if (tc_strcasecmp("CSE Workset", subtaskname) == 0)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptSubTasks[j], "comments", &pccomments), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_owner(msg.task, &tOwner), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tOwner, &pcOwnerName), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = teradyne_ask_person_mailaddress(tOwner, &pcNotificationReceiverEmail), TD_LOG_ERROR_AND_THROW);
							string	szCurTimeStamp;
							date_t	curDateTime;

							TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d%H%M%S", szCurTimeStamp, curDateTime), TD_LOG_ERROR_AND_THROW); // get current system date
							strMailFilePath.append(TD_TEMP_PATH).append("COMMENT_NOTIFICATION").append(szCurTimeStamp).append(".htm");

							date_t  	LastModDate;
							char *pcLastModDateWithHMS = NULL;
							AOM_ask_value_date(tAttaches[i], "last_mod_date", &LastModDate);
							TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string(LastModDate, TD_DATE_YMD_CONSTANT, &pcLastModDateWithHMS), TD_LOG_ERROR_AND_THROW);

							MapSignOff mapSignOff;
							mapSignOff["lastModifiedDate"] = pcLastModDateWithHMS;
							mapSignOff["emailAddress"] = string(pcNotificationReceiverEmail);
							mapSignOff["CSEWorksetComment"] = string(pccomments);
							mapSignOff["Owner"] = string(pcOwnerName);
							setMapSignOff.insert(mapSignOff);

							Custom_free(pcLastModDateWithHMS);


							if (!setMapSignOff.empty())
							{
								MapSignOff lastModifiedSignOff = *setMapSignOff.begin();
								string strComment = lastModifiedSignOff.find("CSEWorksetComment")->second;
								string strOwnerName = lastModifiedSignOff.find("Owner")->second;
								if (pcNotificationReceiverEmail != NULL)
								{

									subject.assign(teradyneBuildNotificationSubject(msg, strOwnerName));
									string htmlBodyContent = teradyneBuildNotificationBodyContentComment(msg, strComment);
									TERADYNE_TRACE_CALL(iStatus = teradyne_os_mail_body(strMailFilePath, htmlBodyContent), TD_LOG_ERROR_AND_THROW); //required for teradyne_send_os_mail
									TERADYNE_TRACE_CALL(iStatus = teradyne_send_os_mail(subject, strMailFilePath, pcNotificationReceiverEmail), TD_LOG_ERROR_AND_THROW); //sends the email
								}

								DeleteFileA(strMailFilePath.c_str());//Deleting the file after sending the mail
							}
							break;
						}


					}


				}

			}
			Custom_free(pcOwnerName);
			Custom_free(pccomments);
			Custom_free(subtaskname);
			Custom_free(ptSubTasks);
			Custom_free(pcNotificationReceiverEmail);
			Custom_free(wrkfw_tag);
			Custom_free(pcObjectType);
		}
	}

	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	return iStatus;
}


/*******************************************************************************
 * Function Name			: teradyneBuildNotificationSubject
 * Description				: Will return the subject for notification email
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg            - EPM_action_message_t
 *							  strSubject     - The subject for notification
 *
 * RETURN VALUE				: string
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				:
 * NOTES					:
 ******************************************************************************/
std::string teradyneBuildNotificationSubject(EPM_action_message_t msg, string reviewerName) {
	int iStatus = ITK_ok;

	string bufferSubject = " ";
	char *jobName = NULL,
		*currentTask = NULL,
		*parentTaskName = NULL;

	const char * __function__ = "teradyneBuildNotificationSubject";

	try
	{
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "job_name", &jobName), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "object_string", &currentTask), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(msg.task, "parent_name", &parentTaskName), TD_LOG_ERROR_AND_THROW);
		bufferSubject.append("Your request is completed with comments");
		Custom_free(jobName);
		Custom_free(currentTask);
		Custom_free(parentTaskName);


	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
		}
	}

	return bufferSubject;
}
