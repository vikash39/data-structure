/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_check_commercial_parts_exists.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains functions related to Teradyne-Check-Manufacturer-Status rule handler
#      Project         :           libTD4teradyne
#      Author          :           Lalit
#  =================================================================================================
#  Date                              Name                               Description of Change
#  14-Aug-2015                      Lalit                    		Added function definitions teradyne_check_commercial_parts_exists.
#  =================================================================================================*/
#include <workflow/teradyne_handlers.h>


/*******************************************************************************
 * Function Name			: teradyne_check_commercial_parts_exists
 * Description				: Validate CPR that have a Approved or Preferred supplier
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					:
 ******************************************************************************/
int teradyne_check_commercial_parts_exists(EPM_action_message_t msg)
{
	int iStatus = ITK_ok,
		iAttaches = 0,
		iSecCount = 0,
		n_references = 0,
		iFlag = 0,
		iPrimaryObjCount = 0,
		iCount = 0;

	char *tSecObjectType = NULL,
		*pcObjectType = NULL,
		*pcItemId = NULL,
		*pcEcnCBU = NULL,
		*pcCBU = NULL,
		*pcRevID = NULL,
		*pcECNId = NULL,
		*MfrPartNumber1 = NULL,
		*MfrPartNumber2 = NULL,
		*MfrPartNumber3 = NULL,
		*psManufacturer1 = NULL,
		*psManufacturer2 = NULL,
		*psManufacturer3 = NULL,
		*sVendorName = NULL,
		*sStatusName = NULL,
		**relation_type_name = NULL;

	tag_t *tAttaches = { NULLTAG },
		*tSecObjects = { NULLTAG },
		tItemSecObject = NULLTAG,
		*tMfgPartTags = NULLTAG,
		tRelationType = NULLTAG,
		*tPrimaryObjects = NULLTAG,
		tVendorTag = NULLTAG,
		tVMRepresentsRelObject = NULLTAG,
		tRootTask = NULLTAG,
		*reference_tags = { NULLTAG };

	tag_t *tagArray = { NULLTAG };

	//tag_t *tagArray = { NULLTAG };

	vector <tag_t> tCommParts;
	vector <tag_t>::iterator it;

	int tagCount = 0;

	int     iRefAttchType = EPM_reference_attachment;

	bool isCPRStatusApprovedOrPreferred = false,
		is_latest = false;


	//std::map<string, string> strPropNameValueMap;

	const char * __function__ = "teradyne_check_commercial_parts_exists";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Getting target attachments from the roottask.
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);

		if (iAttaches != 0)
		{
			for (int i = 0; i < iAttaches; i++)
			{
				//Validating Object type and works for StandardECNRevision,ProtoBOMECNRevision,ReleaseECNRevision
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);

				if (tc_strcmp(pcObjectType, TD_COMM_PART_REQ_REV) == 0)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_MANUFACTURE_PAER_1_ATTR, &MfrPartNumber1), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_MANUFACTURE_PAER_2_ATTR, &MfrPartNumber2), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_MANUFACTURE_PAER_3_ATTR, &MfrPartNumber3), TD_LOG_ERROR_AND_THROW);
					
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_MANUFACTURE_1_ATTR, &psManufacturer1), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_MANUFACTURE_2_ATTR, &psManufacturer2), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[i], TD_MANUFACTURE_3_ATTR, &psManufacturer3), TD_LOG_ERROR_AND_THROW);

					if (MfrPartNumber1 != NULL && tc_strcmp(MfrPartNumber1, "") != 0 && psManufacturer1 != NULL && tc_strcmp(psManufacturer1, "") != 0)
					{
						std::map<string, string> strPropNameValueMap1;

						strPropNameValueMap1.insert(::make_pair((string)TD_ITEMID_INPUT, (string)MfrPartNumber1));

						TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry("TER_VENDOR_PARTS", strPropNameValueMap1, &iCount, &tMfgPartTags), TD_LOG_ERROR_AND_THROW);

						if (iCount > 0)
						{
							for (int j = 0; j < iCount; j++)
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tMfgPartTags[j], TD_VENDOR_REFERENCE_ATTR, &tVendorTag), TD_LOG_ERROR_AND_THROW);
							
								if (tVendorTag != NULLTAG)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTag, TD_OBJECT_NAME_ATTR, &sVendorName), TD_LOG_ERROR_AND_THROW);
									
									if (sVendorName != NULL && strstr(psManufacturer1, sVendorName) != NULL)
									{
										TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VMREPRESENTS, &tRelationType), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tMfgPartTags[j], tRelationType, &iPrimaryObjCount, &tPrimaryObjects), TD_LOG_ERROR_AND_THROW);

										if (iPrimaryObjCount != 0)
										{
											for (int itr = 0; itr < iPrimaryObjCount; itr++)
											{
												TERADYNE_TRACE_CALL(iStatus = ITEM_rev_sequence_is_latest(tPrimaryObjects[itr], &is_latest), TD_LOG_ERROR);
												if (iStatus != ITK_ok)
												{
													TERADYNE_TRACE_CALL(iStatus = EMH_clear_errors(), TD_LOG_ERROR);
												}
												else if (is_latest)
												{
													TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObjects[itr], &pcObjectType), TD_LOG_ERROR_AND_THROW);

													if (tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0)
													{
														TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObjects[itr], tMfgPartTags[j], tRelationType, &tVMRepresentsRelObject), TD_LOG_ERROR_AND_THROW);

														TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVMRepresentsRelObject, TD_PREFERRED_STATUS_ATTR, &sStatusName), TD_LOG_ERROR_AND_THROW);

														if (tc_strcmp(sStatusName, NULL) != 0 && tc_strcmp(sStatusName, TD_OBSOLETE) != 0)
														{
															TERADYNE_TRACE_CALL(iStatus = teradyne_add_unique_tag_to_array(&tagCount, &tagArray, tPrimaryObjects[itr]), TD_LOG_ERROR_AND_THROW);
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					if (MfrPartNumber2 != NULL && tc_strcmp(MfrPartNumber2, "") != 0)
					{
						std::map<string, string> strPropNameValueMap2;

						strPropNameValueMap2.insert(::make_pair((string)TD_ITEMID_INPUT, (string)MfrPartNumber2));

						TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry("TER_VENDOR_PARTS", strPropNameValueMap2, &iCount, &tMfgPartTags), TD_LOG_ERROR_AND_THROW);
						
						if (iCount > 0)
						{
							for (int j = 0; j < iCount; j++)
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tMfgPartTags[j], TD_VENDOR_REFERENCE_ATTR, &tVendorTag), TD_LOG_ERROR_AND_THROW);

								if (tVendorTag != NULLTAG)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTag, TD_OBJECT_NAME_ATTR, &sVendorName), TD_LOG_ERROR_AND_THROW);

									if (sVendorName != NULL && strstr(psManufacturer2, sVendorName) != NULL)
									{
										TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VMREPRESENTS, &tRelationType), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tMfgPartTags[j], tRelationType, &iPrimaryObjCount, &tPrimaryObjects), TD_LOG_ERROR_AND_THROW);

										if (iPrimaryObjCount != 0)
										{
											for (int itr = 0; itr < iPrimaryObjCount; itr++)
											{
												TERADYNE_TRACE_CALL(iStatus = ITEM_rev_sequence_is_latest(tPrimaryObjects[itr], &is_latest), TD_LOG_ERROR);
												if (iStatus != ITK_ok)
												{
													TERADYNE_TRACE_CALL(iStatus = EMH_clear_errors(), TD_LOG_ERROR);
												}
												else if (is_latest)
												{
													TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObjects[itr], &pcObjectType), TD_LOG_ERROR_AND_THROW);

													if (tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0)
													{
														TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObjects[itr], tMfgPartTags[j], tRelationType, &tVMRepresentsRelObject), TD_LOG_ERROR_AND_THROW);

														TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVMRepresentsRelObject, TD_PREFERRED_STATUS_ATTR, &sStatusName), TD_LOG_ERROR_AND_THROW);

														if (tc_strcmp(sStatusName, NULL) != 0 && tc_strcmp(sStatusName, TD_OBSOLETE) != 0)
														{
															TERADYNE_TRACE_CALL(iStatus = teradyne_add_unique_tag_to_array(&tagCount, &tagArray, tPrimaryObjects[itr]), TD_LOG_ERROR_AND_THROW);
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					if (MfrPartNumber3 != NULL && tc_strcmp(MfrPartNumber3, "") != 0)
					{
						std::map<string, string> strPropNameValueMap3;

						strPropNameValueMap3.insert(::make_pair((string)TD_ITEMID_INPUT, (string)MfrPartNumber3));

						TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry("TER_VENDOR_PARTS", strPropNameValueMap3, &iCount, &tMfgPartTags), TD_LOG_ERROR_AND_THROW);

						if (iCount > 0)
						{
							for (int j = 0; j < iCount; j++)
							{
								TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tMfgPartTags[j], TD_VENDOR_REFERENCE_ATTR, &tVendorTag), TD_LOG_ERROR_AND_THROW);

								if (tVendorTag != NULLTAG)
								{
									TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVendorTag, TD_OBJECT_NAME_ATTR, &sVendorName), TD_LOG_ERROR_AND_THROW);

									if (sVendorName != NULL && strstr(psManufacturer2, sVendorName) != NULL)
									{
										TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VMREPRESENTS, &tRelationType), TD_LOG_ERROR_AND_THROW);

										TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tMfgPartTags[j], tRelationType, &iPrimaryObjCount, &tPrimaryObjects), TD_LOG_ERROR_AND_THROW);

										if (iPrimaryObjCount != 0)
										{
											for (int itr = 0; itr < iPrimaryObjCount; itr++)
											{
												TERADYNE_TRACE_CALL(iStatus = ITEM_rev_sequence_is_latest(tPrimaryObjects[itr], &is_latest), TD_LOG_ERROR);
												if (iStatus != ITK_ok)
												{
													TERADYNE_TRACE_CALL(iStatus = EMH_clear_errors(), TD_LOG_ERROR);
												}
												else if (is_latest)
												{
													TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObjects[itr], &pcObjectType), TD_LOG_ERROR_AND_THROW);

													if (tc_strcmp(pcObjectType, TD_COMM_PART_REV) == 0)
													{
														TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObjects[itr], tMfgPartTags[j], tRelationType, &tVMRepresentsRelObject), TD_LOG_ERROR_AND_THROW);

														TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVMRepresentsRelObject, TD_PREFERRED_STATUS_ATTR, &sStatusName), TD_LOG_ERROR_AND_THROW);

														if (tc_strcmp(sStatusName, NULL) != 0 && tc_strcmp(sStatusName, TD_OBSOLETE) != 0)
														{
															TERADYNE_TRACE_CALL(iStatus = teradyne_add_unique_tag_to_array(&tagCount, &tagArray, tPrimaryObjects[itr]), TD_LOG_ERROR_AND_THROW);
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				Custom_free(pcObjectType);
			}

			if (tagCount != 0)
			{
				int cntAttachTypes = 0;
				int* attachTypes = (int*)MEM_alloc(tagCount * sizeof(int));

				for (int idx = 0; idx < tagCount; idx++)
				{
					attachTypes[idx] = EPM_reference_attachment;
				}
				const tag_t * 	attachments = tagArray;
				const int  	attachment_types = EPM_target_attachment;

				TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = EPM_add_attachments(tRootTask, tagCount, tagArray, attachTypes), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, EPM_RESULT_True), TD_LOG_ERROR_AND_THROW);
			
				Custom_free(tagArray);
				Custom_free(attachTypes);
			}
			else
			{
				TERADYNE_TRACE_CALL(iStatus = EPM_set_task_result(msg.task, EPM_RESULT_False), TD_LOG_ERROR_AND_THROW);
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
		//return ITK_ok;
	}
	//CLEANUP:
	Custom_free(tAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}

