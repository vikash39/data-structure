/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_check_vendorPartCOO.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-Check-VendorPartCOO rule handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  21-Oct-2020                      Marjorie                    	Added function definitions teradyne_check_vendorPartCOO.cpp
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_check_vendorPartCOO
 * Description				: Validate the COO field of Vendor if blank OR empty
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: Validate the COO field of Vendor if blank OR empty. If the field is empty, set the COO to "Pending|999"
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_check_vendorPartCOO(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0;
	tag_t *tAttaches			= NULL;
	char *pcObjectType			= NULL;

	string strPropNamesArr[] = { TD_COUNTRY_OF_ORIGIN_LIST };

	map<string, string> strPropNameValueMap;
	list<string> strAttrList(strPropNamesArr, strPropNamesArr + sizeof(strPropNamesArr) / sizeof(string));

	const char * __function__ = "teradyne_check_vendorPartCOO";
	TERADYNE_TRACE_ENTER();

	try 
	{
		//Getting reference attachments from the roottask.
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_reference_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
		for(int i = 0; i < iAttaches; i++) 
		{			
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
			if(tc_strcmp(pcObjectType, TD_MFG_PART) == 0 ) 
			{
				//Checking the COO property of Vendor Part
				logical isCheckOut = false;
				char *pcPending[1] = {"Pending|999"};


				TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tAttaches[i], strAttrList, strPropNameValueMap), TD_LOG_ERROR_AND_THROW);

				//check here if COO is blank then set as "Pending|999"
				if (strPropNameValueMap.size() > 0) 
				{
					if (strPropNameValueMap.find(TD_COUNTRY_OF_ORIGIN_LIST)->second.empty()  || strPropNameValueMap.find(TD_COUNTRY_OF_ORIGIN_LIST)->second == "" )
					{
						POM_AM__set_application_bypass(true);

						TERADYNE_TRACE_CALL(iStatus = teradyne_set_arrayproperty_value(tAttaches[i], TD_COUNTRY_OF_ORIGIN_LIST, 1, pcPending), TD_LOG_ERROR_AND_THROW);

						POM_AM__set_application_bypass(false);
					}
				}

				Custom_free(pcObjectType);
			}
		}
	} 
	catch(...) 
	{

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	POM_AM__set_application_bypass(false);
	TERADYNE_TRACE_LEAVE(iStatus);

	return ITK_ok;
}