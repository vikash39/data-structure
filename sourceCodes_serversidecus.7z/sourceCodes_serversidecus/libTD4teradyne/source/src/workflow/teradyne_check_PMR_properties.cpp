/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           teradyne_check_PMR_properties.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains functionsValidating PMR Properties rule handler
#      Project         :           libTD4teradyne
#      Author          :
#  =================================================================================================
#  Date                              Name                               Description of Change
#  09-Mar-2021						Gurunathan S						Added function definitions teradyne_check_PMR_properties
#  =================================================================================================*/
#include <workflow/teradyne_handlers.h>


/*******************************************************************************
 * Function Name			: teradyne_check_PMR_properties
 * Description				: Validate send to CE Review and Send to ENG Review properties in PMR Revision
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					:
 ******************************************************************************/
EPM_decision_t teradyne_check_PMR_properties(EPM_rule_message_t msg)
{
	int iStatus = ITK_ok,
		iAttaches = 0,
		iValue = 0;

	char *pcObjectType = NULL,
		**pcCEResponsible = NULL;


	logical pcSendToCE,
		pcSendToENG,
		pcRouteToNXT,
		pcRouteToSTD,
		pcRouteToSTG,
		pcRouteToUR,
		pcRouteToHDD,
		check_zero_length,
		is_CE_null_empty,
		is_ENG_null_empty;
	int errorcount = 0;
	tag_t *tAttaches = { NULLTAG };


	EPM_decision_t epmDecision = EPM_go;


	const char * __function__ = "teradyne_check_PMR_properties";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Getting target attachments from the roottask.
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
		for (int i = 0; i < iAttaches; i++)
		{
			//Validating Object type and works for PartModifyRequestRevision
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);

			if (tc_strcmp(pcObjectType, TD_PART_MOD_REQ_REV) == 0)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttaches[i], TD_CE_REVIEW, &pcSendToCE), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttaches[i], TD_ENG_REVIEW, &pcSendToENG), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tAttaches[i], TD_CE_RESPONSIBLE, &iValue, &pcCEResponsible), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttaches[i], TD_ROUTE_TO_NXT, &pcRouteToNXT), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttaches[i], TD_ROUTE_TO_STD, &pcRouteToSTD), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttaches[i], TD_ROUTE_TO_STG, &pcRouteToSTG), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttaches[i], TD_ROUTE_TO_UR, &pcRouteToUR), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_logical(tAttaches[i], TD_ROUTE_TO_HDD, &pcRouteToHDD), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_is_null_empty(tAttaches[i], TD_CE_REVIEW, check_zero_length, &is_CE_null_empty), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_is_null_empty(tAttaches[i], TD_ENG_REVIEW, check_zero_length, &is_ENG_null_empty), TD_LOG_ERROR_AND_THROW);

				if (is_CE_null_empty == 1)
				{
					iStatus = EMH_store_error_s5(EMH_severity_error, TD_SEND_TO_CE_NOT_VALID_ERROR, pcObjectType, NULL, NULL, NULL, NULL);
					epmDecision = EPM_nogo;
					errorcount++;
					
				}
				if (is_ENG_null_empty == 1)
				{
					iStatus = EMH_store_error_s5(EMH_severity_error, TD_SEND_TO_ENG_NOT_VALID_ERROR, pcObjectType, NULL, NULL, NULL, NULL);
					epmDecision = EPM_nogo;
					errorcount++;

				}
				if (pcSendToCE != 0 && iValue == 0)
				{
					errorcount++;
					iStatus = EMH_store_error_s5(EMH_severity_error, TD_CE_RESPONSIBLE_NOT_VALID_ERROR, pcObjectType, NULL, NULL, NULL, NULL);
					epmDecision = EPM_nogo;
				}
				
				if (pcSendToENG != 0)
				{
					if (pcRouteToNXT == 0 && pcRouteToSTD == 0 && pcRouteToSTG == 0 && pcRouteToUR == 0 && pcRouteToHDD == 0)
					{
						errorcount++;
						iStatus = EMH_store_error_s5(EMH_severity_error, TD_ENG_NOT_VALID_ERROR, pcObjectType, NULL, NULL, NULL, NULL);
						epmDecision = EPM_nogo;
					}
				}

			}
			if (pcCEResponsible != NULLTAG) MEM_free(pcCEResponsible);


		}
		if (errorcount > 0)
			epmDecision = EPM_nogo;


	}
	catch (...)
	{

		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(tAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);

	return epmDecision;
}
