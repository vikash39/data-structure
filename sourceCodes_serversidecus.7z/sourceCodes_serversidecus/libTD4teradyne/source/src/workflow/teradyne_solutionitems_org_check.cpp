/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_solutionitems_org_check.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-SolutionItems-ORG-Check rule handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  05-Aug-2015                      Haripriya                    	Added function definitions teradyne_solutionitems_org_check.
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_solutionitems_org_check
 * Description				: Validate Oracle Form and child ORG Value in Oracle name property
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					: 
 ******************************************************************************/
EPM_decision_t teradyne_solutionitems_org_check(EPM_rule_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iSecCount               = 0,
		iBomCount               = 0;
	tag_t *tAttaches			= NULL,
		  *tSecObjects			= NULL,
          tItemSecObject        = NULLTAG,
		  *tBomViewRevs			= NULL;
	char *pcObjectType			= NULL,
		 *pcItemId			    = NULL;

	vector<string> VOrgItem;
	EPM_decision_t epmDecision  = EPM_nogo;

	const char * __function__ = "teradyne_solutionitems_org_check";
	TERADYNE_TRACE_ENTER();

	try 
	{
		//Getting target attachments from the roottask.
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
		for(int i = 0; i < iAttaches; i++) 
		{
			//Validating Object type and works for StandardECNRevision,ProtoBOMECNRevision,ReleaseECNRevision
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
			if( (tc_strcmp(pcObjectType, TD_STD_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcObjectType, TD_REL_ECN_REV_TYPE) == 0 ) || (tc_strcmp(pcObjectType, TD_PROTOBOM_ECN_REV_TYPE) == 0 ) )
			{
				//Getting the Parts under solution item Folder
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iSecCount, &tSecObjects), TD_LOG_ERROR_AND_THROW);
				for(int j = 0; j < iSecCount; j++) 
				{
					//checking the part is assembly or component
					TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tSecObjects[j], &iBomCount, &tBomViewRevs), TD_LOG_ERROR_AND_THROW); 
					if(iBomCount > 0)
					{
						bool isPrimary = 0;
						tag_t tSecObjs = NULLTAG;
						TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tSecObjects[j],&tItemSecObject), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL ( iStatus = ITEM_ask_id2(tItemSecObject,&pcItemId),TD_LOG_ERROR_AND_THROW );
						TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tItemSecObject,TD_ORG_REL_NAME,TD_ORACLE_ORG_FORM_TYPE,isPrimary,&tSecObjs),TD_LOG_ERROR_AND_THROW);
						if(tSecObjs != NULLTAG)
						{
							char **pcOrgName = NULL;
							int iOrgNameCnt  = 0;

							epmDecision  = EPM_go;
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tSecObjs,TD_ORG_FORM_ATTR,&iOrgNameCnt,&pcOrgName),TD_LOG_ERROR_AND_THROW);
							if(iOrgNameCnt == 0)
							{
								VOrgItem.push_back(pcItemId);
							}
							Custom_free(pcOrgName);
						}
						else
						{
							epmDecision = EPM_nogo;
							TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error,TD_MISSING_ORG_FORM_ERROR,pcItemId), TD_LOG_ERROR_AND_THROW);
							throw (EPM_decision_t)TD_MISSING_ORG_FORM_ERROR;
						}

					}
					else
					{
						epmDecision  = EPM_go;
					}
					Custom_free(tBomViewRevs);
					Custom_free(pcItemId);
				}
				if(VOrgItem.size()>0)
				{
					epmDecision = EPM_nogo;
					string szitemvalues="";
					for(int k=0;k<VOrgItem.size();k++)
					{
						if(k == VOrgItem.size()-1 )
						{
							szitemvalues.append(VOrgItem.at(k));
						}
						else
						{
							szitemvalues.append(VOrgItem.at(k)).append(",");
						}
					}
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error,TD_MISSING_ORG_NAME_ERROR,szitemvalues.c_str()), TD_LOG_ERROR_AND_THROW);
					throw (EPM_decision_t)TD_MISSING_ORG_NAME_ERROR;
				}
				Custom_free(tSecObjects);
				Custom_free(pcObjectType);
			}
		}
	} 
	catch(...) 
	{

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	VOrgItem.clear();
	TERADYNE_TRACE_LEAVE(iStatus);

	return epmDecision;
}