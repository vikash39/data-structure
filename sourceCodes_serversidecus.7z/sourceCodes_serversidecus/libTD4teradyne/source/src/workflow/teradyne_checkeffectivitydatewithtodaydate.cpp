/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :          teradyne_checkeffectivitydatewithtodaydate.cpp      
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-CheckEffectivityDate action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D.          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  24-Apr-2015                       Kameshwaran D                    	Initial Creation
#  04-May-2015                       Vijayasekhar                    	Added error message on failure cases.
#  07-May-2015						 Vijayasekhar                    	Added condition to check the suitable target objects
#  18-May-2015						 Vijayasekhar                    	Modified the code for error condition
#  15-Oct-2015                       Manimaran                          Added the code to convert current effectivity date to GMT and set the same as new effectivity date if effectivity time is greater than or equal to 9 pm.
#  24-Nov-2015                       Manimaran                          Added code to check whether Impacted Items effectivity is later than the ECN effectivity set by user.
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_checkeffectivitydatewithtodaydate
 * Description				: This function will check the Effectivity date with todays date.
 *							                             
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 *
 *
 * NOTES					: 
 ******************************************************************************/
int teradyne_checkeffectivitydatewithtodaydate(EPM_action_message_t msg){
	
	int		iStatus			    = ITK_ok,
			iAttachCount		= 0,
			iEffCount			= 0,
			iDateCount			= 0;

	tag_t	*tAttachtag			= NULL,
			tECNRelStatusTag	= NULLTAG,
			*tEffTagList		= NULL;

	string  szStartDate			= "";

	char	*pcAttachType		= NULL,
		    *pcEffDateTime		= NULL,
			*pcEffDate			= NULL,
			*pcRange            = NULL;

	string	szCurTimeStamp,
	        szEffrange;

	date_t	curDateTime,
			*tEffDateTime = NULL,
			convertedDateTime;

	WSOM_open_ended_status_t  	open_ended_or_stock_out;

	const char * __function__    = "teradyne_checkeffectivitydatewithtodaydate" ;
	TERADYNE_TRACE_ENTER();

	try{
			if(msg.task != NULLTAG) 
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task,EPM_target_attachment, &iAttachCount, &tAttachtag), TD_LOG_ERROR_AND_THROW);
				for(int i = 0; i < iAttachCount; i++) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttachtag[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcAttachType, TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOBOM_ECN_REV_TYPE) || !tc_strcmp(pcAttachType, TD_PROTOPART_ECN_REV_TYPE) ) {

						TERADYNE_TRACE_CALL(iStatus = teradyne_get_release_status_tag(tAttachtag[i],&tECNRelStatusTag), TD_LOG_ERROR_AND_THROW);
						if(tECNRelStatusTag != NULLTAG) {

							TERADYNE_TRACE_CALL(iStatus = WSOM_status_ask_effectivities(tECNRelStatusTag,&iEffCount,&tEffTagList),TD_LOG_ERROR_AND_THROW);
							if(iEffCount > 0) {

								TERADYNE_TRACE_CALL( iStatus = WSOM_eff_ask_dates( tECNRelStatusTag, tEffTagList[iEffCount - 1], &iDateCount, &tEffDateTime, &open_ended_or_stock_out ), TD_LOG_ERROR_AND_THROW );
								//Gets the latest start date in the start-end date range
								int iLatestStartDate = (iDateCount % 2 == 0) ? (iDateCount - 2) : (iDateCount - 1);

								if (tEffDateTime[iLatestStartDate].hour >= 21) {
									TERADYNE_TRACE_CALL(iStatus = POM_convert_date(POM_local_to_gmt, tEffDateTime[iLatestStartDate], &convertedDateTime), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( convertedDateTime, "%Y%m%d%H%M", &pcEffDateTime), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( convertedDateTime, "%Y%m%d", &pcEffDate), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( convertedDateTime, "%d-%b-%Y %H:%M", &pcRange), TD_LOG_ERROR_AND_THROW);
									szEffrange.append(pcRange).append(" to ").append("UP");
									TERADYNE_TRACE_CALL(iStatus = teradyne_set_effectivity(tAttachtag[i], tECNRelStatusTag, szEffrange, "", false), TD_LOG_ERROR_AND_THROW);
								} else {
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( tEffDateTime[iLatestStartDate], "%Y%m%d%H%M", &pcEffDateTime), TD_LOG_ERROR_AND_THROW);
									TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string( tEffDateTime[iLatestStartDate], "%Y%m%d", &pcEffDate), TD_LOG_ERROR_AND_THROW);
								}

								string szEffDate(pcEffDateTime);
								szEffDate = szEffDate.substr(0, 8);

								TC_write_syslog("INFO : The Latest start date of effectivity is %s \n",szEffDate);
								TERADYNE_TRACE_CALL(iStatus = teradyne_current_timestamp("%Y%m%d", szCurTimeStamp, curDateTime), TD_LOG_ERROR_AND_THROW);
								TC_write_syslog("INFO : The Current time stamp is %s \n",szCurTimeStamp);
								unsigned long long lEffDate = stoull(szEffDate.c_str());
								unsigned long long lCurrDate = stoull(szCurTimeStamp.c_str());
								if(lEffDate < lCurrDate)
								{
									TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_EFF_DATE_ERROR), TD_LOG_ERROR_AND_THROW);
									iStatus = TD_EFF_DATE_ERROR;
									throw iStatus;
								} 

								Custom_free(pcRange);

								int iImpObjCount = 0;
								tag_t *tImpObjects = NULL;
								char *pcObjectType = NULL;

								TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttachtag[i], TD_IMPACTED_ITEM_REL_NAME, &iImpObjCount, &tImpObjects), TD_LOG_ERROR_AND_THROW);
								if (iImpObjCount > 0) {
									for (int iImpItemCount = 0; iImpItemCount < iImpObjCount; iImpItemCount++) {
										TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tImpObjects[iImpItemCount], &pcObjectType), TD_LOG_ERROR_AND_THROW);
										if(!tc_strcmp(pcObjectType, TD_DIV_PART_REV)) {
											int iBomViewCount = 0;
											tag_t *tBomViewRevs = NULL;

											TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tImpObjects[iImpItemCount], &iBomViewCount, &tBomViewRevs), TD_LOG_ERROR_AND_THROW);
											if (iBomViewCount > 0) {
												tag_t tPartRelStatusTag = NULLTAG;

												TERADYNE_TRACE_CALL(iStatus = teradyne_get_release_status_tag(tImpObjects[iImpItemCount], &tPartRelStatusTag), TD_LOG_ERROR_AND_THROW);
												if (tPartRelStatusTag != NULLTAG) {
													int iPartEffCount = 0;
													tag_t *tPartEffTagList = NULL;

													TERADYNE_TRACE_CALL(iStatus = WSOM_status_ask_effectivities(tPartRelStatusTag, &iPartEffCount, &tPartEffTagList),TD_LOG_ERROR_AND_THROW);
													if (iPartEffCount > 0) {
														int iDateCnt = 0;
														date_t *tPartEffDateTime;
														char *pcPartEffDateTime = NULL;
														WSOM_open_ended_status_t open_end_or_stock_out;

														TERADYNE_TRACE_CALL( iStatus = WSOM_eff_ask_dates(tPartRelStatusTag, tPartEffTagList[iPartEffCount - 1], &iDateCnt, &tPartEffDateTime, &open_end_or_stock_out), TD_LOG_ERROR_AND_THROW );
														//Gets the latest start date in the start-end date range
														int iLatestEffStartDate = (iDateCnt % 2 == 0) ? (iDateCnt - 2) : (iDateCnt - 1);

														TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string(tPartEffDateTime[iLatestEffStartDate], "%Y%m%d%H%M", &pcPartEffDateTime), TD_LOG_ERROR_AND_THROW);

														TC_write_syslog("INFO : ECN effectivity is %s \n", pcEffDateTime);
														TC_write_syslog("INFO : Impacted Items effectivity is %s \n", pcPartEffDateTime);

														unsigned long long lECNEffDate = stoull(pcEffDateTime);
														unsigned long long lPartEffDate = stoull(pcPartEffDateTime);
														if (lECNEffDate < lPartEffDate) {
															TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_EFF_DATE_TIME_ERROR), TD_LOG_ERROR_AND_THROW);
															iStatus = TD_EFF_DATE_TIME_ERROR;
															throw iStatus;
														}

														char *pcPartEffDate = NULL;
														TERADYNE_TRACE_CALL(iStatus = DATE_date_to_string(tPartEffDateTime[iLatestEffStartDate], "%Y%m%d", &pcPartEffDate), 
														TD_LOG_ERROR_AND_THROW);

														unsigned long long lECNEffDateOnly = stoull(pcEffDate);
														unsigned long long lPartEffDateOnly = stoull(pcPartEffDate);
														
														if (lECNEffDateOnly == lPartEffDateOnly) {
															TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_EFF_DATE_EQ_TIME_ERROR), TD_LOG_ERROR_AND_THROW);
															iStatus = TD_EFF_DATE_TIME_ERROR;
															throw iStatus;
														}
														Custom_free(tPartEffDateTime);
														Custom_free(pcPartEffDateTime);
														Custom_free(pcPartEffDate);
													}
													Custom_free(tPartEffTagList);
												}
											}
											Custom_free(tBomViewRevs);
										}
									}
								}
								Custom_free(pcObjectType);
								Custom_free(tImpObjects);
								Custom_free(pcEffDateTime);
								Custom_free(pcEffDate);
							} else {

								TERADYNE_TRACE_CALL(iStatus = EMH_store_error(EMH_severity_error, TD_EFF_DATE_ERROR), TD_LOG_ERROR_AND_THROW);
								iStatus = TD_EFF_DATE_ERROR;
								throw iStatus;
							}
							Custom_free(tEffTagList);
							Custom_free(tEffDateTime);
						}
					}
					Custom_free(pcAttachType);
				}
			}
	}catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tEffTagList);
	Custom_free(tEffDateTime);
	Custom_free(pcAttachType);
	Custom_free(tAttachtag);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
