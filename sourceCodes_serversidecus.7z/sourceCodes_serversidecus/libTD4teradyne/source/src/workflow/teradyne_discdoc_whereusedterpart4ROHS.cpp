/*=================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_discdoc_whereusedterpart4ROHS.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-DiscDocWhereUsedTERPart4ROHS action handler
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  23-Mar-2015						Kameshwaran D						Initial creation
#  18-May-2015						Haripriya						    Added type check condition and modified relation name
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>
/*******************************************************************************
 * Function Name			: teradyne_discdoc_whereusedterpart4ROHS
 * Description				: This function will get where used parts for the action handler 
 *							  Teradyne-DiscDocWhereUsedTERPart4ROHS                            
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Checks whether "Compliance Regrade" folder present in dba group.
 *							  2. If folder not available then creating the folder under dba group
 *							  3. Geting the where used parts of the Item revision and will get copy to the created folder.
 *
 * NOTES					:
 ******************************************************************************/
extern "C"
int teradyne_discdoc_whereusedterpart4ROHS(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttachCount			= 0;
		
	tag_t *ptAttaches			= NULL,
		  tFolder				= NULLTAG;

	std::vector<tag_t>	tVendorPartTagVec,
						tTeradynePartVec;

	char *pcAttachType          = NULL;

	const char * __function__ = "teradyne_discdoc_whereusedterpart4ROHS";
	TERADYNE_TRACE_ENTER();

	try {
		
			//Checks whether "Compliance Regrade" folder present in dba group ,if not create it under dba group
			TERADYNE_TRACE_CALL(iStatus = teradyne_check_and_create_complaince_regrade_folder(&tFolder), TD_LOG_ERROR_AND_THROW);
			if(msg.task != NULLTAG) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
				for(int i = 0; i < iAttachCount; i++) {
					
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcAttachType), TD_LOG_ERROR_AND_THROW);
					if(!tc_strcmp(pcAttachType, TD_DISCON_DOC_REV_TYPE)) { 
					//Get the Vendor part related to disconitnous document
						TERADYNE_TRACE_CALL(iStatus = teradyne_getvendorpart_related_discdoc(ptAttaches[i],&tVendorPartTagVec), TD_LOG_ERROR_AND_THROW);

						size_t iSizeVec = tVendorPartTagVec.size();
						for(int iPos=0;iPos < iSizeVec ; iPos++) {

							//Get the Teradyne Part related to Vendor part 
							TERADYNE_TRACE_CALL(iStatus = teradyne_get_teradyne_part_related_to_vendor_part(tVendorPartTagVec.at(iPos),&tTeradynePartVec), TD_LOG_ERROR_AND_THROW);

							size_t iTeraVecSize = tTeradynePartVec.size();
							for(int iTeraPos=0;iTeraPos < iTeraVecSize ; iTeraPos++) {

								//Get the where used parts of the Item revision and will get copy to "Compliance Regrade".
								TERADYNE_TRACE_CALL(iStatus = teradyne_get_and_copy_where_used_parts(tTeradynePartVec.at(iTeraPos),tFolder), TD_LOG_ERROR_AND_THROW);
							}
						}
					}
					Custom_free(pcAttachType);
				}
			}
	}catch(...)
    {
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	

	Custom_free(ptAttaches);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/***************************************************************************************************
 * Function Name			: teradyne_getvendorpart_related_discdoc
 * Description				: This function to get the Teradyne part and Vendor part tag 
 *							  which are under VMRepresent relation.
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tRevTag (Tag)		-  Revision tag of attachment
 *							  iFlagCheck(I)		-  FLag to decide which operation to trigger
 *											[0] -> Invalid
 *											[1] -> Update preferred_status
 *											[2] -> Update Teradyne part DSP SBM Form
 *							 
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. To all Vendor part revision in attachment tag
 *							  2. Get the Vendor part Tag
 *							  3. Get the All teradyne parts tag with respect to VMRepresent relation
 *							  4. Update the all relation attribute preffered_status to Obsolete
 * NOTES					: 
 ******************************************************************************************************/

int teradyne_getvendorpart_related_discdoc(tag_t tRevTag,std::vector<tag_t> *tVendorPartTagVec)
{
	int iStatus			= 0;
	std::vector<tag_t> tVendorPartRevTagVec;

	const char * __function__		   = "teradyne_getvendorpart_related_discdoc";

	TERADYNE_TRACE_ENTER();

	try{	

			int		iObjCnt			 = 0;

			tag_t	*tFindObjTag	 = NULL,
					tRelationTag	 = NULLTAG;

			//Get the IMAN_specification relation type tag
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_PART_TOBE_DISCON_REL,&tRelationTag),TD_LOG_ERROR_AND_THROW);

			//Get Secondary objects of the attach object
			TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tRevTag,tRelationTag,&iObjCnt,&tFindObjTag),TD_LOG_ERROR_AND_THROW);
			
			for(int iPos=0; iPos< iObjCnt; iPos++)
			{
				/*Need to proccess only Vendor part object. Here we seperating those by pushing it to vector*/

				char *objecttype = NULL;
				TERADYNE_TRACE_CALL(iStatus = WSOM_ask_object_type2(tFindObjTag[iPos],&objecttype),TD_LOG_ERROR_AND_THROW);
				string strObjectType(objecttype);

				if(strObjectType.compare(TD_MFG_PART_REV) == 0)
				{
					tVendorPartRevTagVec.push_back(tFindObjTag[iPos]);
				}
				Custom_free(objecttype);
			}

			size_t iVendorRevVecSiz = tVendorPartRevTagVec.size();
			for(int iVenPartPos = 0 ; iVenPartPos < iVendorRevVecSiz ; iVenPartPos++)
			{
				tag_t tVendorPart		= NULLTAG;
				//Get the Vendor part by using Vendor part revision
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tVendorPartRevTagVec.at(iVenPartPos),&tVendorPart),TD_LOG_ERROR_AND_THROW);
				//Push to vendor part into vector
				if(tVendorPart != NULLTAG) tVendorPartTagVec->push_back(tVendorPart);
			}

	}catch(...)
		{
			if(iStatus == ITK_ok)
			{
				TC_write_syslog("%s: Unhandled Exception",__function__);
				iStatus = TERADYNE_UNKNOWN_ERROR;
			}
		}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
