/*=================================================================================================                    
#                Copyright (c) 2016 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_update_materialimpact_ECN_Form.cpp        
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-UpdateMaterialImpact action handler
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya S          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  17-Aug-2016						Haripriya S							Intital creation
#  16-Sep-2019						Marjorie D							Modified teradyne_update_materialimpact_ECN_Form that will set the DeptNumber, ReworkInstructions, ReworkCost 
#																		and ScrapCost of ECNs
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>
#include <extensions/teradyne_extensions.h>
#include <base_utils/ScopedSmPtr.hxx>
/*******************************************************************************
 * Function Name			: teradyne_update_materialimpact_ECN_Form
 * Description				: This function set the MaterialImpact Property on Standard\Protobom ECN Revision from 
 *                            Material Impact Update Form in Reference attachments
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Find the Material Impact Update Form in Reference attachments.
 *							  2. Get the td4MaterialImpact Property value from Material Impact Update Form
 *							  3. Update td4MaterialImpact Property value in Standard or protobom ECn Revision 
 * NOTES					: 
 ******************************************************************************/
int teradyne_update_materialimpact_ECN_Form(EPM_action_message_t msg)
{

	int iStatus					= ITK_ok,
		iTargetCount			= 0,
		iRefCount				= 0;

	tag_t *tRefAttaches			= NULL,
		   *tTargetAttaches     = NULL;

	char *pcRefObjectType		= NULL,
		 *pcTargetObjectType	= NULL,
		 *pcattrvalue           = NULL,
		 *pcdeptNumber			= NULL,
		 *pcreworkInstructions	= NULL;

	double pcReworkCost			= 0,
		   pcScrapCost			= 0;


	const char * __function__ = "teradyne_update_materialimpact_ECN_Form";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Getting Reference attachments
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_reference_attachment, &iRefCount, &tRefAttaches), TD_LOG_ERROR_AND_THROW);
		for(int iRef = 0; iRef < iRefCount; iRef++) 
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tRefAttaches[iRef], &pcRefObjectType), TD_LOG_ERROR_AND_THROW);
			//Check object type and works for TD4MaterialImpactUpdateForm
			if(!tc_strcmp(pcRefObjectType,TD_MATL_IMP_UPDATE_FORM_TYPE)) 
			{
				//Getting Target attachments
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iTargetCount, &tTargetAttaches), TD_LOG_ERROR_AND_THROW);
				for(int iTarget = 0; iTarget < iTargetCount; iTarget++) 
				{
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tTargetAttaches[iTarget], &pcTargetObjectType), TD_LOG_ERROR_AND_THROW);
					//Get the td4MaterialImpact Property value from Material Impact Update Form
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRefAttaches[iRef],TD_ECN_MAT_IMPACT_STD,&pcattrvalue),TD_LOG_ERROR_AND_THROW);	
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRefAttaches[iRef],TD_ECN_DEPT_NO,&pcdeptNumber),TD_LOG_ERROR_AND_THROW);	
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRefAttaches[iRef],TD_ECN_REWORK_INSTR_SUMM,&pcreworkInstructions),TD_LOG_ERROR_AND_THROW);	
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tRefAttaches[iRef],TD_ECN_EST_RWK_COST,&pcReworkCost),TD_LOG_ERROR_AND_THROW);	
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tRefAttaches[iRef],TD_ECN_EST_SCRAP_COST,&pcScrapCost),TD_LOG_ERROR_AND_THROW);	
					POM_AM__set_application_bypass(true);
					if(!tc_strcmp(pcTargetObjectType,TD_STD_ECN_REV_TYPE))
					{
						//Update td4MaterialImpact Property value in  Standard ECn Revision 
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tTargetAttaches[iTarget],TD_ECN_MAT_IMPACT_STD,pcattrvalue),TD_LOG_ERROR_AND_THROW);						
					}
					if(!tc_strcmp(pcTargetObjectType,TD_PROTOBOM_ECN_REV_TYPE))
					{
						//Update td4MaterialImpact Property value in  protobom ECn Revision 
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tTargetAttaches[iTarget],TD_ECN_MAT_IMPACT_PROTOBOM,pcattrvalue),TD_LOG_ERROR_AND_THROW);						
					}
					if(!tc_strcmp(pcTargetObjectType,TD_STD_ECN_REV_TYPE) || !tc_strcmp(pcTargetObjectType,TD_PROTOBOM_ECN_REV_TYPE))
					{
						string tempReworkCost = to_string(pcReworkCost), tempScrapCost = to_string(pcScrapCost);
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tTargetAttaches[iTarget],TD_ECN_DEPT_NO,pcdeptNumber),TD_LOG_ERROR_AND_THROW);	
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tTargetAttaches[iTarget],TD_ECN_REWORK_INSTR_SUMM,pcreworkInstructions),TD_LOG_ERROR_AND_THROW);	
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tTargetAttaches[iTarget],TD_ECN_EST_RWK_COST, tempReworkCost),TD_LOG_ERROR_AND_THROW);	
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tTargetAttaches[iTarget],TD_ECN_EST_SCRAP_COST, tempScrapCost),TD_LOG_ERROR_AND_THROW);	

						//Check if rework OR scrap cost is greater than $0
						double reworkCost = 0, scrapCost = 0;
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tTargetAttaches[iTarget],TD_ECN_EST_RWK_COST,&reworkCost),TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tTargetAttaches[iTarget],TD_ECN_EST_SCRAP_COST,&scrapCost),TD_LOG_ERROR_AND_THROW);
						if( reworkCost > 0 || scrapCost > 0)
						{
							//initiate TD_SCRAP_REWORK_WF_PREF
							TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(TD_SCRAP_REWORK_WF_PREF, tTargetAttaches[iTarget]) ,TD_LOG_ERROR_AND_THROW);

							//send email
							/*tag_t temp_tag = NULLTAG;
							char *pcProcessTemplateName = NULL;

							TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_SCRAP_REWORK_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = EPM_find_process_template(pcProcessTemplateName, &temp_tag) ,TD_LOG_ERROR_AND_THROW);

							int n_subtasks = 0;
							scoped_smptr<tag_t> subtasks; */
						} 
					}
					POM_AM__set_application_bypass(false);
					Custom_free(pcattrvalue);
					Custom_free(pcTargetObjectType);
					Custom_free(pcdeptNumber);
					Custom_free(pcreworkInstructions);
				}

				Custom_free(pcRefObjectType);
			}
		}
		
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			POM_AM__set_application_bypass(false);
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(tRefAttaches);
	Custom_free(tTargetAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;
}

