/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_gendeviationreport.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-GenDeviationReport action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  16-Apr-2015                       Vijayasekhar                    	Added function definitions teradyne_gendeviationreport, teradyne_convert_xls2xlsx and teradyne_generate_report
#  21-Apr-2015                       Selvi                    	        Moved function   teradyne_convert_xls2xlsx to teradyne_common
#  22-Apr-2015                       Vijayasekhar                    	Added Error for the case the deviation part has more teradyne parts in solution items folder And changed for new report files
#  29-Apr-2015                       Vijayasekhar                    	Added condition to check the suitable target objects
#  25-Sep-2015                       Manimaran                          Commented the code to convert xls to xlsx.
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_gendeviationreport
 * Description				: Will generate the report for the deviation object
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 1. Generates the report based on the input parameters
 *							: 2. Converts the report from xls to xlsx
 *							: 3. Attaches the dataset to the part with Reference material relation 
 * NOTES					: 
 ******************************************************************************/
extern "C"
int teradyne_gendeviationreport(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAttaches				= 0,
		iSolutionItems			= 0,
		iTerPartCount			= 0;
	tag_t *tAttaches			= NULL,
		  tNewDataset			= NULLTAG,
		  *tSolutionItems		= NULL;
	char *pcDataSetPath			= NULL,
		 *pcDevNum				= NULL,
		 *pcRevId				= NULL,
		 *pcSolutionItemType	= NULL,
		 *pcObjectType			= NULL;
	string strOutXlsxPath		= "";

	AE_reference_type_t tagRefType = AE_ASSOCIATION;
	const char * __function__ = "teradyne_gendeviationreport";
	TERADYNE_TRACE_ENTER();

	try { 
		if(msg.task != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int i = 0; i < iAttaches; i++) {
				
				iTerPartCount = 0;
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[i], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_DEVIATION_NOTICE_REV_TYPE)) {
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_get_associated_objects(tAttaches[i], TD_SOLUTION_ITEMS_REL_NAME, &iSolutionItems, &tSolutionItems), TD_LOG_ERROR_AND_THROW);
					for(int j = 0; j < iSolutionItems; j++) {
				
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSolutionItems[j], &pcSolutionItemType), TD_LOG_ERROR_AND_THROW);
						if(!tc_strcmp(pcSolutionItemType, TD_COMM_PART_REV) || !tc_strcmp(pcSolutionItemType, TD_DIV_PART_REV)) {
					
							iTerPartCount++;
							if(iTerPartCount > 1) {
						
								break;
							}
						}
						Custom_free(pcSolutionItemType);
					}
					if(iTerPartCount > 1) {
						//Error if the part has more than one teradyne part(CommPart or DivPart in SolutionItems folder

						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tAttaches[i], &pcDevNum), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = ITEM_ask_rev_id2(tAttaches[i], &pcRevId), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus=EMH_store_error_s2(EMH_severity_error, TD_DEVIATION_REPORT_ERROR, pcDevNum, pcRevId), TD_LOG_ERROR_AND_THROW);
						iStatus = TD_DEVIATION_REPORT_ERROR;
						throw iStatus;
					} else {
					
						TERADYNE_TRACE_CALL(iStatus = teradyne_generate_report(TD_DEVIATION_REPORT_ID, TD_DEVIATION_REPORT_NAME, ITEM_REP_TYPE, TD_DEVIATION_STYLE_SHEET, iAttaches, tAttaches, TD_DATASETTYPE, &pcDataSetPath), TD_LOG_ERROR_AND_THROW);
						if(pcDataSetPath != NULL) {
							//converting the report to xlsx by using vb script
							//TERADYNE_TRACE_CALL(iStatus = teradyne_convert_xls2xlsx(pcDataSetPath, strOutXlsxPath), TD_LOG_ERROR_AND_THROW);
							if(tc_strlen(pcDataSetPath) > 0) {
				
								//creates the dataset and attaches to part 
								TERADYNE_TRACE_CALL(iStatus = teradyne_create_and_attach_dataset(TD_DEVIATION_REPORT, "", TD_DATASETTYPE, TD_BINARY_FORMATTYPE, pcDataSetPath, TD_NAMED_REFERENCE, TD_REF_MATERIAL_REL, tagRefType, tAttaches[0], &tNewDataset),TD_LOG_ERROR_AND_THROW);
								DeleteFileA(pcDataSetPath);
								//DeleteFileA(strOutXlsxPath.c_str());
							}
						}
					}
				}
				Custom_free(tSolutionItems);
				Custom_free(pcDataSetPath);
				Custom_free(pcObjectType);
			}
		}
		
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_generate_report
 * Description				: Will generate the report
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : pcReportId	(I) - report id const char*
 *							: pcReportName	(I) - report name const char*
 *							: pcCategory	(I) - category const char*
 *							: pcStyleSheet	(I) - StyleSheet name char*
 *							: iContextObjects(I) - contentext object count int
 *							: ptContextObjects(I) - contentext objects tag_t*
 *							: pcDataSetType  (I) - dataset type char*
 *							: pcDataSetPath  (OF) - Path of the dataset char**
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				: 
 * NOTES					: 
 ******************************************************************************/
int teradyne_generate_report(const char* pcReportId, const char* pcReportName, const char* pcCategory, char* pcStyleSheet, int iContextObjects, tag_t* ptContextObjects, char* pcDataSetType, char** pcDataSetPath) {

	int iStatus					= ITK_ok,
		iRepDef					= 0;
	tag_t *tRepDef				= NULL;
	
	const char * __function__ = "teradyne_generate_report";
	TERADYNE_TRACE_ENTER(); 

	try {
		TERADYNE_TRACE_CALL(iStatus = CRF_get_report_definitions(pcReportId, pcReportName, pcCategory, TD_TC, 0, 0, NULL, &iRepDef, &tRepDef), TD_LOG_ERROR_AND_THROW);
		if(iRepDef > 0) {
			//can pass the object and the dataset relaation to attach it to another object
			TERADYNE_TRACE_CALL(iStatus = CRF_generate_report_1(tRepDef[0], NULL, pcStyleSheet, NULLTAG, iContextObjects, ptContextObjects, 0, NULL, NULL, "", pcDataSetType, NULL, NULLTAG, pcDataSetPath), TD_LOG_ERROR_AND_THROW);
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tRepDef);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
