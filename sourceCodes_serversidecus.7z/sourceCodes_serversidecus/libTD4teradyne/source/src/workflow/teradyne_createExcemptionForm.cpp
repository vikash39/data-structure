/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_createExcemptionForm.cpp       
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-CreateExcemptionForm action handler
#      Project         :           libTD4teradyne          
#      Author          :           Selvi      
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  22-Apr-2015						 Selvi       						Intital creation
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>


/***************************************************************************************************
 * Function Name			: teradyne_createExcemptionForm
 * Description				: This function to Create the Apply Excemption Form
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tVendorTag (Tag)			 -  vendor part tag
 *							 
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. To all Vendor part attribute value
 * NOTES					: 
 ******************************************************************************************************/
int teradyne_createExcemptionForm (EPM_action_message_t msg)
{
	int iStatus				= ITK_ok;
	int	iAttachCount		= 0;
	int iFound				= 0;
	int iAttachmentType		= EPM_reference_attachment;
	
	char *pcTypeName		= NULL;
	char *pcPrefValue		= NULL;
	char *pcObjUID			= NULL;
	char *pcVendorPartName  = NULL;
	char *pcRegVersion  = NULL;

	tag_t *ptAttaches		= NULL;
	tag_t *tWSOtags			= NULL;
	tag_t tFormTag			= NULLTAG;
	tag_t tRootTask			= NULLTAG;

	string strROHsName		= "";
	string strExmptFormName = "";

	vector<string> vecROHValue;
	
	WSO_search_criteria_t criteria;

	const char * __function__		   = "teradyne_createExcemptionForm";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttachCount, &ptAttaches), TD_LOG_ERROR_AND_THROW);
		for(int i = 0; i < iAttachCount; i++) 
		{			
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptAttaches[i], &pcTypeName), TD_LOG_ERROR_AND_THROW);
			if(pcTypeName != NULL && (tc_strcmp(pcTypeName, TD_MFG_PART) == 0))
			{
				//Getting Vendor Part Name.
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptAttaches[i],TD_OBJECT_NAME_ATTR,&pcVendorPartName),TD_LOG_ERROR_AND_THROW);
				
				//Reading Preference value.
				TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_AUTO_CMPLCHECK_REGULATION,TC_preference_site,0,&pcPrefValue),TD_LOG_ERROR_AND_THROW);
				vecROHValue = teradyne_generate_tokens(pcPrefValue, ":");
			
				//Searching for Regulation object based on preference value.	
				WSOM_clear_search_criteria(&criteria);
				tc_strcpy(criteria.class_name,TD_CMPL_REGULATION_TYPE);
				tc_strcpy(criteria.name, vecROHValue[0].c_str());

				TERADYNE_TRACE_CALL(iStatus= WSOM_search(criteria, &iFound,&tWSOtags), TD_LOG_ERROR_AND_THROW);
				for (int iCounter = 0; iCounter < iFound; iCounter++)
				{					
					//Reading Version of Regulation
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tWSOtags[iCounter],TD_REGULATION_VERSION,&pcRegVersion),TD_LOG_ERROR_AND_THROW);
				    if(pcRegVersion != NULL && (tc_strcmp(vecROHValue[1].c_str(), pcRegVersion) == 0))
					{
						ITK__convert_tag_to_uid (tWSOtags[iCounter], &pcObjUID);
						strExmptFormName.assign(TD_EXEMPTION_FORM_Name); strExmptFormName.append(pcVendorPartName); 

						//Creating Exemption Form.
						TERADYNE_TRACE_CALL(iStatus=teradyne_create_object(TD_EXEMPTION_FORM_TYPE, strExmptFormName, &tFormTag),TD_LOG_ERROR_AND_THROW);
						if( tFormTag != NULLTAG)
						{
							//Setting Form attribute scp0regulation_uid
							TERADYNE_TRACE_CALL(iStatus=teradyne_setproperty_value(tFormTag,TD_EXEMPTION_FORM_UID,pcObjUID),TD_LOG_ERROR_AND_THROW);
						
							//Attach Exemption Form under Reference folder of EPM Task.
							tag_t *tForm = (tag_t*)MEM_alloc(sizeof(tag_t)*1);
							tForm[0] = tFormTag;
							TERADYNE_TRACE_CALL(iStatus = EPM_add_attachments(tRootTask, 1, tForm, &iAttachmentType), TD_LOG_ERROR_AND_THROW);
							Custom_free(tForm);
						}
					}
					Custom_free(pcObjUID);
					Custom_free(pcRegVersion);					
				}
				Custom_free(pcVendorPartName);
		        Custom_free(pcPrefValue);				
				Custom_free(tWSOtags);
			}
			Custom_free(pcTypeName);
		}
		Custom_free(ptAttaches);
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}