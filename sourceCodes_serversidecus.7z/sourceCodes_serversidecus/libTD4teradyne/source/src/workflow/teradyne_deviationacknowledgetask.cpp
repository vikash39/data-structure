/*=================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_deviationacknowledgetask.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains functions related to Teradyne-DeviationAcknowledgeTask action handler
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  20-Mar-2015                       Vijayasekhar                    	Added function definitions teradyne_deviationacknowledgetask.
#  29-Apr-2015                       Vijayasekhar                    	Added condition to check the suitable target objects
#  $HISTORY$                    
#  =================================================================================================*/ 
#include <workflow/teradyne_handlers.h>

/*******************************************************************************
 * Function Name			: teradyne_deviationacknowledgetask
 * Description				: Will assign a review task to users based on attribute �Additional Users for Acknowledgement�
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : msg - Structure contains tags related to work flow,
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					: 
 ******************************************************************************/
int teradyne_deviationacknowledgetask(EPM_action_message_t msg) {

	int iStatus					= ITK_ok,
		iAddAckUserCount		= 0,
		iUsers					= 0,
		iAttaches				= 0;
	char **pcAddAckUsers		= NULL,
		 *pcPerson				= NULL,
		 *pcEngSendTo			= NULL,
		 *pcObjectType			= NULL;
	tag_t *tUsers				= NULL,
		  *tAttaches			= NULL;

	const char * __function__ = "teradyne_deviationacknowledgetask";
	TERADYNE_TRACE_ENTER();

	try {
		if(msg.task != NULLTAG) {
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_attachments(msg.task, EPM_target_attachment, &iAttaches, &tAttaches), TD_LOG_ERROR_AND_THROW);
			for(int k = 0; k < iAttaches; k++) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tAttaches[k], &pcObjectType), TD_LOG_ERROR_AND_THROW);
				if(!tc_strcmp(pcObjectType, TD_DEVIATION_NOTICE_REV_TYPE)) {
				
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tAttaches[k], TD_ADD_ACK_USERS_ATTR, &iAddAckUserCount, &pcAddAckUsers), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tAttaches[k], TD_ENG_SENT_TO_ATTR, &pcEngSendTo), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = SA_extent_user(&iUsers, &tUsers),TD_LOG_ERROR_AND_THROW );
					for(int i = 0; i < iAddAckUserCount; i++) {
			
						for(int j = 0; j < iUsers; j++) {
				
							TERADYNE_TRACE_CALL(iStatus = SA_ask_user_person_name2(tUsers[j], &pcPerson),TD_LOG_ERROR_AND_THROW );
							
							if(!tc_strcmp(pcAddAckUsers[i], pcPerson)) { 
								//Assigns user to tast
								TERADYNE_TRACE_CALL(iStatus = teradyne_assign_task_to_users(msg.task, tUsers[j]), TD_LOG_ERROR_AND_THROW);
								Custom_free(pcPerson);
								break;
							}
							Custom_free(pcPerson);
						}
					}
					if(!tc_strcmp(pcEngSendTo, "STD") || !tc_strcmp(pcEngSendTo, "Both")) {

						TERADYNE_TRACE_CALL(iStatus = teradyne_assign_task_to_users(msg.task, NULLTAG, "STD AVL/Deviation Resource", "PRODUCT.ENG.Teradyne"), TD_LOG_ERROR_AND_THROW);
					}
					if(!tc_strcmp(pcEngSendTo, "STG") || !tc_strcmp(pcEngSendTo, "Both")) {

						TERADYNE_TRACE_CALL(iStatus = teradyne_assign_task_to_users(msg.task, NULLTAG, "STG AVL/Deviation Resource", "PRODUCT.ENG.Teradyne"), TD_LOG_ERROR_AND_THROW);
					}
				}
				Custom_free(pcAddAckUsers);
				Custom_free(pcEngSendTo);
				Custom_free(pcObjectType);
			}
		}
		
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tAttaches);
	Custom_free(tUsers);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
