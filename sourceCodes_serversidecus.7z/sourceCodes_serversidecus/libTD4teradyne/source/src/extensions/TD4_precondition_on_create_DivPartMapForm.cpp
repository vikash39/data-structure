/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_precondition_on_create_DivPartMapForm.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for postaction on createPost in DivisionalPartMap Form
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  16-Feb.-2015                      Haripriya                          Initial Creation
#  18-Feb-2015	                     Vijayasekhar                       changed the from precondition on IMAN_save to postaction on createPost
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : TD4_precondition_on_create_DivPartMapForm
 * Description      : This postaction will check whether DivisionalPartMap Form with same
 *                    PartCategory-PartSubcategory already exists and throw error if yes.
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : METHOD_message_t*  msg, va_list args
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        : 
 *
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int TD4_precondition_on_create_DivPartMapForm(METHOD_message_t*  msg, va_list args)
{
	const char* __function__ = "TD4_precondition_on_create_DivPartMapForm";
	TERADYNE_TRACE_ENTER();

	int  iStatus				      = ITK_ok;

	tag_t tObject                     = NULLTAG,
		  tDivPartTag                 = NULLTAG;

	 string szDivPartCatergoryName    = "",
		   szDivPartSubCatergoryName  = "",    
		   szDivPart_Attr[]           = {TD_PART_CATEGORY_ATTR,TD_PART_SUBCATEGORY_ATTR};

	std::map<string,string> strDivPartPropNameValueMap;

	try
	{
		//Get the input arguments
		tag_t tObject = msg->object_tag;

		if( tObject != NULLTAG)
		{
			std::list<string> strDivPartAttrList( szDivPart_Attr, szDivPart_Attr + sizeof(szDivPart_Attr) / sizeof(string) );
			//calling function to get DivPartRevision property values
			TERADYNE_TRACE_CALL(iStatus = teradyne_getproperty_values(tObject,strDivPartAttrList,strDivPartPropNameValueMap),TD_LOG_ERROR_AND_THROW);
			if( strDivPartPropNameValueMap.size() > 0 )
			{
				szDivPartCatergoryName.assign( strDivPartPropNameValueMap.find(TD_PART_CATEGORY_ATTR)->second);
				szDivPartSubCatergoryName.assign( strDivPartPropNameValueMap.find(TD_PART_SUBCATEGORY_ATTR)->second );
				TERADYNE_TRACE_CALL( iStatus =teradyne_search_divpartmap_form_using_partcategoryandpartsubcategory((char*)szDivPartCatergoryName.c_str(),(char*)szDivPartSubCatergoryName.c_str(),&tDivPartTag),TD_LOG_ERROR_AND_THROW );

			}
		}

	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
