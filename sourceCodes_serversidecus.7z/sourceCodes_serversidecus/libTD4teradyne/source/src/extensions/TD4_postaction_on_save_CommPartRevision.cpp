/*==================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_save_CommPartRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save in Commercial Part revision
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  05-Nov-2014                       Haripriya                          Initial Creation
#  04-Feb-2015						 Selvi                              Modified code to support only for change td4description on IMAN_Save and moved remaining code on ITEM_create_rev
#  19-Feb-2015						 Haripriya                          Modified code to initiate the Workflow on creation.
#  5 -Dec-2020                       Anandha Bharathi R                 Added code that will validate owning Group as UR,if then update Item Status Property Value in Change Admin Form
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>


/*******************************************************************************
* Function Name	    : TD4_postaction_on_save_CommPartRevision
* Description		: Postaction to update td4Description	  
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM	    	: Gets the revision tag and update td4Description of	 
*                     CommPartRevision and while creating CommPartRevision workflow 
*                     is initiated.
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_CommPartRevision(METHOD_message_t*  msg, va_list args)
{
	//Declartion and Initialization of Local Variables
	int iStatus					= 0;

	tag_t tRevtag               = NULLTAG,
		  tNewProcess           = NULLTAG;

	tag_t tUserTag = NULLTAG,
		tRoleTag = NULLTAG,
		tGroupTag = NULLTAG,
		tParentTag = NULLTAG,
		tItemTag = NULLTAG,
		tChgeAdminForm = NULLTAG;

	char  *description=NULL,*freeFormDispName=NULL,*specialChar=NULL,*pcCBU=NULL;

	char *sPartCategory = "",
		 *sSubPartCategory = "";

	const char* __function__ = "TD4_postaction_on_save_CommPartRevision";
	TERADYNE_TRACE_ENTER();

	char  *pcRoleName = NULL,
		*pcGroupFullName = NULL,
		*pcGroupName = NULL,
		*pcUsername = NULL,
		*pcParentGroupName = NULL;

	try
	{
		//Get the input arguments
		tRevtag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);

		
	
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);

		// Validating Owning Group as UR (Universal Robots)
		int valResult = 1;

		if ((hasEnding(string(pcGroupFullName), ".UR") == true) || (hasEnding(string(pcGroupFullName), ".MIR") == true))
		{
			valResult = 0;
		}

		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_PART_CATEGORY_ATTR, &sPartCategory), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_PART_SUBCATEGORY_ATTR, &sSubPartCategory), TD_LOG_ERROR_AND_THROW);
		if (valResult == 0 && ((strcmp(sPartCategory, "") == 0) || (strcmp(sSubPartCategory, "") == 0)))
		{
			TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_COMM_PART_PARTCATEGORY_ERROR, "", ""), TD_LOG_ERROR_AND_THROW);
			iStatus = TD_COMM_PART_PARTCATEGORY_ERROR;
			throw iStatus;
		}

		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_DESCR_ATTR, &description),TD_LOG_ERROR_AND_THROW);

		if(hasInvalidChar(description,&specialChar))
		{
			TERADYNE_TRACE_CALL(iStatus = AOM_UIF_ask_name(tRevtag,TD_DESC_ATTR,&freeFormDispName), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_INVALID_CHAR, freeFormDispName,specialChar), TD_LOG_ERROR_AND_THROW);
			iStatus = TD_INVALID_CHAR;
			throw iStatus;
		} 

		// For AWC Save as Operation added below lines 
		TCTYPE_save_operation_context_t tsaveOpContext;
		TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_save_operation_context(&tsaveOpContext), TD_LOG_ERROR_AND_THROW);
		bool isSaveAs = false;

		switch (tsaveOpContext)
		{
		case TCTYPE_save_on_saveas:
		{
			int urGrp = 1;
			urGrp = ur_validateOwningGroup();

			bool isFormCreated = false;

			tag_t  tDisSpecRelTag = NULLTAG,
				*tSecObjs = NULLTAG;

			int  iFormCount = 0;

			//Getting DisciplineSpecific and OracleOrg relation tags
			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_DIS_SPEC_REL_NAME, &tDisSpecRelTag), TD_LOG_ERROR_AND_THROW);

			if (tDisSpecRelTag != NULLTAG)
				TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tRevtag, tDisSpecRelTag, &iFormCount, &tSecObjs), TD_LOG_ERROR_AND_THROW);

			TC_write_syslog("\n iFormCount : %d", iFormCount);

			// Discipline specific Forms Available
			isFormCreated = (iFormCount == 6);

			//urGrp == 0 && 
			if (!isFormCreated)
			{
				isSaveAs = true;
			}
			break;
		}
		case TCTYPE_save_on_create:
			break;
		case TCTYPE_save_on_revise:
			break;
		case TCTYPE_save_on_update:
			break;
		default:
			break;
		}

		
		tag_t tOwningGrp = NULLTAG;
		char *cpOwningGrp = NULL;

		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tag(tRevtag, "owning_group", &tOwningGrp), TD_LOG_ERROR_AND_THROW);
		TC_write_syslog("\n OwningGrp Tag: %d", tOwningGrp);
		SA_ask_group_full_name(tOwningGrp, &cpOwningGrp);

		TC_write_syslog("\n cpOwningGrp : %s", cpOwningGrp);

		if (cpOwningGrp != NULL)
		{
			if ((hasEnding(cpOwningGrp, ".UR") == true) || (hasEnding(cpOwningGrp, ".MIR") == true))
			{
				TC_write_syslog("\n Its Belongs to UR or MIR Part");
			}
			else
			{
				//to change the td4description from lower case to upper case
				TERADYNE_TRACE_CALL(iStatus = teradyne_update_commpart_desc(tRevtag), TD_LOG_ERROR_AND_THROW);
			}
		}
				
		if(bisNew || isSaveAs)
		{
			

			AM__set_application_bypass(true);
			TERADYNE_TRACE_CALL(iStatus = teradyne_create_discipleSpecificForms(tRevtag), TD_LOG_ERROR_AND_THROW);
			AM__set_application_bypass(false);

			// TER Parts update Item Status property value as Production
			if (hasEnding(string(pcGroupFullName), ".Teradyne") == true)
			{
				AM__set_application_bypass(true);// Bypass is set true to update TD4OracleOrg form
				// To get Change Admin Form Object
				TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tRevtag, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, &tChgeAdminForm), TD_LOG_ERROR_AND_THROW);

				if (tChgeAdminForm != NULLTAG)
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tChgeAdminForm, TD_ITEM_STATUS_ATTR, TD_PRODUCTION_TYPE_ATTR), TD_LOG_ERROR_AND_THROW);

				AM__set_application_bypass(false);
			}

			TERADYNE_TRACE_CALL(iStatus = teradyne_get_cbu_from_project(tRevtag, TD_PROJECT_NAME_ATTR,&pcCBU), TD_LOG_ERROR_AND_THROW);

			/* Added by Anandha Bharathi for MIR Requirement */
			if (hasEnding(string(pcGroupFullName), ".MIR") == true) // MIR Validation
			{
				mir_getDivCommPartPostAction(tRevtag, sPartCategory, sSubPartCategory, bisNew);
			}

			
			/** Added by Anandha Bharathi for UR Requirement **/
		
				ur_CommPart_postAction(tRevtag);
			

			TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRevtag, TD_CONTRL_BUSS_UNIT, pcCBU), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ERP(TD_PART_CREATED_EVENT,tRevtag,false),TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(iStatus = teradyne_update_object_name(tRevtag),TD_LOG_ERROR_AND_THROW);

	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(freeFormDispName);
	Custom_free(description);
	Custom_free(pcCBU);
	Custom_free(pcUsername);
	Custom_free(pcRoleName);
	Custom_free(pcGroupName);
	Custom_free(pcGroupFullName);
	Custom_free(pcParentGroupName);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: ur_CommPart_postAction
 * Description				: Commercial Part Post Action activities For UR Requirements
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      :
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 * ALGORITHM				:
 * NOTES					:
 ******************************************************************************/

int ur_CommPart_postAction(tag_t tRevtag)
{
	const char* __function__ = "ur_CommPart_postAction";
	
	int iStatus = 1;

	char *pGrpname = "",
		*szItemId = "",
	    *pcRoleName = NULL,
		*pcGroupFullName = NULL,
		*pcGroupName = NULL,
		*pcUsername = NULL,
		*pcParentGroupName = NULL,
		*sPartCategory = "",
		*sSubPartCategory = "";

	tag_t tUserTag = NULLTAG,
		tRoleTag = NULLTAG,
		tGroupTag = NULLTAG,
		tSecObjs = NULLTAG;


	TERADYNE_TRACE_ENTER();

	try
	{
		// Validating Owning Group as UR (Universal Robots)
		int valResult = 0;
		valResult = ur_validateOwningGroup();

		if (valResult == 1) // validate Owning Group not UR then Check it is dba
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);
			
			//pGrpname = strstr(pcGroupFullName, "dba");
			if (strcmp(pcGroupFullName, TD_DBA_ROLE_CONSTANT) == 0)
				valResult = 0;
			else
				valResult = 1;
		}
		if(valResult == 0)
		{
			tag_t tItemTag = NULL_TAG;
			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tRevtag, &tItemTag), TD_LOG_ERROR_AND_THROW);

			valResult = ur_CommPartCMAdminRole_postAction(tRevtag);
			if (valResult == 2)
			{
				TC_write_syslog("CM Admin Group Parts ");
					
			}
			else
			{
				char *pcsevDigItemID = "";

				TERADYNE_TRACE_CALL(iStatus = NR_pattern_next_value(TD_COMM_PART, TD_ITEM_ID_ATTR, NULLTAG, "", "", "", NULLTAG, "", "", "NNNNNNN", &pcsevDigItemID), TD_LOG_ERROR_AND_THROW);

				AM__set_application_bypass(true);

				TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tItemTag, "item_id", pcsevDigItemID), TD_LOG_ERROR_AND_THROW);

				AM__set_application_bypass(false);

			}
		

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_ITEM_ID_ATTR, &szItemId), TD_LOG_ERROR_AND_THROW);
				if (tc_strlen(szItemId) == 7)
				{
					// To set Part Type Property Value in Item Revision
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRevtag, TD_PART_TYPE_ATTR, "Component"), TD_LOG_ERROR_AND_THROW);
				}
				Custom_free(szItemId);

				// To get Change Admin Form Object
				TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tRevtag, TD_DIS_SPEC_REL_NAME, TD_CHANGEADMIN_FORM_TYPE, 0, &tSecObjs), TD_LOG_ERROR_AND_THROW);

				if (tSecObjs != NULLTAG)
				{
					AM__set_application_bypass(true);// Bypass is set true to update change admin form and Item Revision

					//Calling function to set the property value (Item Status Property) in Change admin form and Item Revision
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tSecObjs, TD_ITEM_STATUS_ATTR, "Concept"), TD_LOG_ERROR_AND_THROW);
					//TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRevtag, TD_ITEM_STATUS_ATTR, "Concept"), TD_LOG_ERROR_AND_THROW);

					AM__set_application_bypass(false);
				}

		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
* Function Name	    : teradyne_update_commpart_desc
*
* Description		: Update td4Description attribute in Upper case 
* REQUIRED HEADERS	: 
* INPUT PARAMS		:  
*                    
*
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM			: 1.Updates td4Description Value of TD4CommpartRevision in uppercase
*
* NOTES				:
*------------------------------------------------------------------------------*/
int teradyne_update_commpart_desc(tag_t tRevtag) 
{
	//Declartion and Initialization of Local Variables
	int   iStatus				= ITK_ok;

	char *pcDescription			= NULL,
		 *pcDescriptionUpr	    = NULL;
	bool toUpper				= false;

	char* __function__ = "teradyne_update_commpart_desc";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_DESCR_ATTR, &pcDescription), TD_LOG_ERROR_AND_THROW);
		if(pcDescription != NULL) {
			
			for(int i = 0; i < tc_strlen(pcDescription); i++) {
			
				if(islower(pcDescription[i])) {
				
					toUpper = true;
					break;
				}
			}
			if(toUpper) {
			
				tc_strupr(pcDescription, &pcDescriptionUpr);
				if(pcDescriptionUpr != NULL) {
				
					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRevtag, TD_DESCR_ATTR, pcDescriptionUpr), TD_LOG_ERROR_AND_THROW);
				}
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcDescription);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
int ur_CommPartCMAdminRole_postAction(tag_t tRevtag)
{


	/***************************************************************************************************/
	char	*pcRoleName = NULL,
		*pcGroupFullName = NULL,
		*pcGroupName = NULL,
		*pcUsername = NULL,
		*pcParentGroupName = NULL;

	char *cpItemId = NULL, *pcsevDigItemID = NULL;

	tag_t	tUserTag = NULLTAG,
		tRoleTag = NULLTAG,
		tGroupTag = NULLTAG,
		tItemTag = NULLTAG;

	int iStatus = 0;

	// Add logic for checking CM Admin.UR/Admin role in UR group could be possible to enter id manually

	char* __function__ = "teradyne_update_commpart_desc";
	TERADYNE_TRACE_ENTER();

	try
	{
	TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_ITEM_ID_ATTR, &cpItemId), TD_LOG_ERROR_AND_THROW);

	TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);

	if (pcGroupFullName != NULL)
	{
		if (strcmp(pcGroupFullName, TD_UR_ADMIN_GRP_CONSTANT) == 0)
		{
			if (cpItemId != NULL)
			{
				pcsevDigItemID = cpItemId;

				AM__set_application_bypass(true);
				TERADYNE_TRACE_CALL(iStatus = ITEM_ask_item_of_rev(tRevtag, &tItemTag), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_set_value_string(tItemTag, "item_id", pcsevDigItemID), TD_LOG_ERROR_AND_THROW);
				AM__set_application_bypass(false);
				iStatus = 2;
			}
			else
			{
				TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s2(EMH_severity_error, TD_COMM_PART_ITEM_ID_NTFOUND_ERROR, "", ""), TD_LOG_ERROR_AND_THROW);
				iStatus = TD_COMM_PART_ITEM_ID_NTFOUND_ERROR;
				throw iStatus;
			}
		}
	}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcGroupFullName);
	Custom_free(pcRoleName);
	Custom_free(pcUsername);
	Custom_free(pcParentGroupName);

	TERADYNE_TRACE_LEAVE(iStatus);

	return iStatus;

	/**************************************************************************************************************************/
}