/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_copy_DivPartRevision.cpp
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on ITEM_copy_rev on Divisional Part revision
#      Project         :           libTD4teradyne          
#      Author          :           Manimaran
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  16-Nov-2015						 Manimaran                          Initial Creation
#  20-Nov-2015                       Manimaran                          Added code to skip revisions (I,O,P,Q,S,X,Z) for CM Admin group during revise operation.
#  24-Dec-2015                       Manimaran                          Modified code to skip revisions only if previous revision id is not present in TD4TeradyneRevisionScheme preference values.
#  23-Mar-2016                       Manimaran                          Modified the code to skip revisions (I,O,P,Q,S,X,Z) for dba group.
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_copy_DivPartRevision
* Description		: Post action to skip revisions (I,O,P,Q,S,X,Z) for CM Admin and dba group
*                           
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*                           
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_copy_DivPartRevision(METHOD_message_t *msg , va_list args)
{
	int iStatus					 = ITK_ok;

	char  *pcCurRevId			 = NULL,
		   *pcControllingBusUnit  =NULL,
		    *pcRevId               =NULL;

	tag_t tRevTag                = NULLTAG,
		  tBOMViewRevTag		 = NULLTAG;

	
	tag_t	tLatestRev		= NULLTAG;

	char *newRevID = NULL,
		*pcObjectType = NULL;
	
	 bool bisverdict         = true;
	string szUsergroup           = "";



	char	*pcRoleName = NULL,
		*pcGroupFullName = NULL,
		*pcGroupName = NULL,
		*pcUsername = NULL,
		*pcParentGroupName = NULL;

	tag_t 	tUserTag = NULLTAG,
			tRoleTag = NULLTAG,
			tGroupTag = NULLTAG;



	const char* __function__ = "TD4_postaction_on_copy_DivPartRevision";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments from item_copy_rev msg
		tRevTag = va_arg(args, tag_t);
		pcCurRevId = va_arg(args, char*);

		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tRevTag,&pcObjectType),TD_LOG_ERROR_AND_THROW);
		
		//Check if the div part controlling business unit is Nextest and has numeric revision , the sequence of revision will be numeric
	    
		TERADYNE_TRACE_CALL(iStatus=AOM_ask_value_string(tRevTag,TD_CONTRL_BUSS_UNIT, &pcControllingBusUnit),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus=ITEM_ask_rev_id2(tRevTag, &pcRevId),TD_LOG_ERROR_AND_THROW);
		string controllingBusUnit(pcControllingBusUnit);
           
		if(controllingBusUnit.compare(TD_NXT)==0) 
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_latest_rev_from_rev(tRevTag, &tLatestRev), TD_LOG_ERROR_AND_THROW);
		
			POM_AM__set_application_bypass(true);
			
			TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tLatestRev,true),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_assign_string(tLatestRev,TD_CONTRL_BUSS_UNIT_CRE,pcControllingBusUnit), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tLatestRev), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tLatestRev,false),TD_LOG_ERROR_AND_THROW);
	        				
			POM_AM__set_application_bypass(false);
		}
			
		if(isDigitWSAllowed(pcRevId) && controllingBusUnit.compare(TD_NXT)==0){

			TERADYNE_TRACE_CALL(iStatus = teradyne_latest_rev_from_rev(tRevTag, &tLatestRev), TD_LOG_ERROR_AND_THROW);

			POM_AM__set_application_bypass(true);
			
			TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tLatestRev,true),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyneGenerateNextTestRevisionID(pcRevId, &newRevID), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_assign_string(tLatestRev,TD_ITEM_REVISION_ID,newRevID), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tLatestRev), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tLatestRev,false),TD_LOG_ERROR_AND_THROW);
			
			/*
			tag_t attr_id_tag=NULLTAG;
			TERADYNE_TRACE_CALL(iStatus=POM_attr_id_of_attr(TD_ITEM_REVISION_ID,"TD4DivPartRevision",&attr_id_tag),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_refresh_instances_any_class(1,&tLatestRev,POM_modify_lock), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyneGenerateNextTestRevisionID(pcRevId, &newRevID), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_set_attr_string(1,&tLatestRev,attr_id_tag,newRevID), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_save_instances(1,&tLatestRev,false), TD_LOG_ERROR_AND_THROW);
			*/

			//Align BOM View revision IDs with div part rev IDs
			int iBomCountCheck     = 0;
			tag_t *tBomViewRevions = NULL;
			TERADYNE_TRACE_CALL(iStatus = ITEM_rev_list_bom_view_revs(tLatestRev, &iBomCountCheck, &tBomViewRevions), TD_LOG_ERROR_AND_THROW);
			if(iBomCountCheck > 0)
			{
				for(int z = 0; z < iBomCountCheck; z++)
				{
					char *pcBomViewRev = NULL;
					char *pcItemId = NULL;

					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_item_id_from_rev_tag(tLatestRev, &pcItemId), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tBomViewRevions[z], TD_OBJECT_NAME_ATTR, &pcBomViewRev), TD_LOG_ERROR_AND_THROW);

					string szBomViewRev = string(pcBomViewRev);
					int ifnd = (int)szBomViewRev.find_last_of("-");
					string szBomViewRevName = string(pcItemId) + "/" + newRevID + string(szBomViewRev.substr(ifnd, szBomViewRev.length()));

					TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tBomViewRevions[z], TD_OBJECT_NAME_ATTR, szBomViewRevName), TD_LOG_ERROR_AND_THROW);

					Custom_free(pcBomViewRev);
					Custom_free(pcItemId);
				}
			}
			Custom_free(tBomViewRevions);

			POM_AM__set_application_bypass(false);

			return ITK_ok;
		}
		
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_usergroup_as_string(&szUsergroup),TD_LOG_ERROR_AND_THROW);

		/********************************************************************************************************************/

		int iPrefValCount = 0;
		char **pcPrefValues = NULL;

		TERADYNE_TRACE_CALL(iStatus = teradyne_get_current_user_and_group(&pcUsername, &pcRoleName, &pcGroupName, &pcGroupFullName, &tUserTag, &tRoleTag, &tGroupTag), TD_LOG_ERROR_AND_THROW);

		if (pcGroupFullName != NULL)
		{
			
			if (strcmp(pcGroupFullName, TD_UR_ADMIN_GRP_CONSTANT) == 0 || strcmp(pcGroupFullName, TD_UR_RD_GRP_CONSTANT) == 0 || strcmp(pcGroupFullName, TD_DBA_GROUP) == 0)
			{
				// UR revision Scheme
				TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_values_at_location(TD_UR_REV_PREF, TC_preference_site, &iPrefValCount, &pcPrefValues), TD_LOG_ERROR_AND_THROW);
			}
		}
		else
		{
			TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_values_at_location(TD_TERADYNE_REV_PREF, TC_preference_site, &iPrefValCount, &pcPrefValues), TD_LOG_ERROR_AND_THROW);
		}

		/**********************************************************************************************************************************/

		if((szUsergroup.compare(TD_ADMIN_ROLE_CONSTANT) == 0 ) || (szUsergroup.compare(TD_DBA_ROLE_CONSTANT) == 0 ))
		{
			std::map<string, string> strRevIDValueMap;
			/*int iPrefValCount = 0;
			char **pcPrefValues = NULL;*/
			//TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_values_at_location(TD_TERADYNE_REV_PREF, TC_preference_site, &iPrefValCount, &pcPrefValues), TD_LOG_ERROR_AND_THROW);
			for(int iCount = 0; iCount < iPrefValCount; iCount++)
			{
				string szPrefValue = pcPrefValues[iCount];
				size_t iFound = szPrefValue.find(":");
				strRevIDValueMap.insert(::make_pair(szPrefValue.substr(0, iFound), szPrefValue.substr(iFound + 1)));
			}
			Custom_free(pcPrefValues);

			char *pcPrevRevID = NULL;
			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_rev_id2(tRevTag, &pcPrevRevID), TD_LOG_ERROR_AND_THROW);

			if(strRevIDValueMap.find(pcPrevRevID) != strRevIDValueMap.end()) {
				//Previous revision id is present in TD4TeradyneRevisionScheme preference values.
			} else {
				int     iLovs    = 0,
						iLovVals = 0;

				tag_t *tLovs = NULL;

				char *pcLovVals = NULL;

				string szCurRevId(pcCurRevId);
				bool bRevCheck = false;

				TERADYNE_TRACE_CALL(iStatus = LOV_find("TcRevisionSkipLetters", &iLovs, &tLovs), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = LOV_ask_values_char(tLovs[0], &iLovVals, &pcLovVals), TD_LOG_ERROR_AND_THROW);

				for (int valCount = 0; valCount < iLovVals; valCount++) {
					size_t pos = szCurRevId.find(pcLovVals[valCount]);
					if (pos == -1) {
						continue;
					} else {
						bRevCheck = true;
						break;
					}
				}

				if (bRevCheck) {
					TERADYNE_TRACE_CALL(iStatus = teradyne_check_and_apply_revision_rule(tRevTag, pcCurRevId, iLovVals, pcLovVals), TD_LOG_ERROR_AND_THROW);
				}

				Custom_free(tLovs);
				Custom_free(pcLovVals);

			}
			Custom_free(pcPrevRevID);
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);	
	return iStatus;
}
