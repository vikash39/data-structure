/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_create_Scp0PartToSubsCmplResultRel.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save for creating Scp0PartToSubsCmplResult relation
#      Project         :           libTD4teradyne          
#      Author          :           Vijayasekhar          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  04-Jun-2015                       Vijayasekhar                       Initial Creation
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : TD4_postaction_on_create_Scp0PartToSubsCmplResultRel
 * Description      : This post action will be executed when a compliance result object is attached to vendor part or TER part revision
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : msg (I) - Message structure
 *                    args (I) - variable number of arguments
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        : 1.Gets the Primary and Secondary object type.
 *					  2.If the Primary Object type is Vendor part
 *                    and Secondary Object type is Scp0SubstanceCmplResult then get the scp0status_display_name attribut from 
 *					  secondary object and set to td4ROHSCompliantStatus attribute on primary object
 * NOTES            :
 ******************************************************************************/
extern "C" 
int TD4_postaction_on_create_Scp0PartToSubsCmplResultRel(METHOD_message_t*  msg, va_list args) {

	int iStatus					= ITK_ok;

	char  *pcPrimaryTypeName    = NULL,
		  *pcSecondaryTypeName  = NULL,
		  *pcDisplyVal			= NULL;

	tag_t tObject               = NULLTAG,
	      tPrimaryObject        = NULLTAG,
		  tSecondaryObject      = NULLTAG;

	const char* __function__ = "TD4_postaction_on_create_Scp0PartToSubsCmplResultRel";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		tObject = va_arg(args, tag_t);
		
		//Getting Primary and Secondary Object for the Relation
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_primary(tObject,&tPrimaryObject),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = GRM_ask_secondary(tObject,&tSecondaryObject),TD_LOG_ERROR_AND_THROW);
		if ( (tPrimaryObject != NULLTAG) && ( tSecondaryObject != NULLTAG ) )
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tPrimaryObject,&pcPrimaryTypeName),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tSecondaryObject,&pcSecondaryTypeName),TD_LOG_ERROR_AND_THROW);
			if((tc_strcmp(pcPrimaryTypeName, TD_MFG_PART) == 0 || tc_strcmp(pcPrimaryTypeName, TD_DIV_PART_REV) == 0 || tc_strcmp(pcPrimaryTypeName, TD_COMM_PART_REV) == 0) && (tc_strcmp(pcSecondaryTypeName, TD_SUBCMPL_RESULT_TYPE) == 0)) { 
			
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tSecondaryObject, TD_SCP_STATUS_DISPLY_ATTR, &pcDisplyVal), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tPrimaryObject, TD_ROHS_COMMPLT_STATUS_ATTR, pcDisplyVal),TD_LOG_ERROR_AND_THROW);
			}
		}
	} 
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcPrimaryTypeName);
	Custom_free(pcSecondaryTypeName);
	Custom_free(pcDisplyVal);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}