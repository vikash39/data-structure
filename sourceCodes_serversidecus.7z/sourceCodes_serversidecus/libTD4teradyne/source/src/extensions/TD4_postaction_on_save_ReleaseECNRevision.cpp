/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_save_ReleaseECNRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_SAVE in Release ECN revision
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  =================================================================================================  
#  =================================================================================================                    
#  Date                              Name                           Description of Change
#  5-Mar-2015                       Kameshwaran D                     Initial Creation 
#  $HISTORY$                    
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_save_ReleaseECNRevision
* Description		:       
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    : 				 
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
int TD4_postaction_on_save_ReleaseECNRevision(METHOD_message_t *msg , va_list args)
{
	int iStatus					= ITK_ok,
		iSaveFlag				= 1;

	tag_t tRevtag               = NULLTAG,
		  tNewProcess           = NULLTAG;

	string szPrimaryProjectName		= "",
		   szImpactedProjectName	= "";

	map<string,string>	strECNRevisionPropNameValueMap;

	vector<string>	strProjectformVec;

	char *pcWrkFlowName			= TD_RELEASE_ECN_REL_WF_PREF;

	char *urWrkFlowName = NULL;

	const char* __function__ = "TD4_postaction_on_save_ReleaseECNRevision";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		tRevtag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);
		if( !bisNew )
		{
			TC_write_syslog("bisNew If COndition");
			TERADYNE_TRACE_CALL(iStatus = teradyne_attachorremove_project_form_with_ProjectRel(tRevtag,iSaveFlag),TD_LOG_ERROR_AND_THROW);

			TC_write_syslog("teradyne_attachorremove_project_form_with_ProjectRel after if condition :");
		}
		else
		{
			string  szFormName[] = { "Additional Reviewers Form" },
				szFormType[] = { TD_ADDITIONAL_REVIEWER_FORM_TYPE };

			map<string, string> strFormTypeNameMap;

			int iTypesize = sizeof(szFormName) / sizeof(string);
			for (int iCount = 0; iCount < iTypesize; iCount++)
			{
				strFormTypeNameMap.insert(::make_pair(szFormType[iCount], szFormName[iCount]));
			}

			char *pcAdditonalReviewerURL = NULL;

			//Attach or remove the project form with relation TD4ProjectRel
			TERADYNE_TRACE_CALL(iStatus = teradyne_attachorremove_project_form_with_ProjectRel(tRevtag, 0), TD_LOG_ERROR_AND_THROW);

			//Create Additional Reviewer form and attach it with TD4AdditionalReviewersRel relation
			TERADYNE_TRACE_CALL(iStatus = teradyne_create_additional_reviewer_form(tRevtag, strFormTypeNameMap), TD_LOG_ERROR_AND_THROW);

			//Getting Preference Value to get Reviewr URL name
			TERADYNE_TRACE_CALL(iStatus = PREF_ask_char_value_at_location(TD_REVIEWERS_INSTRUCTION_URL_PREF, TC_preference_site, 0, &pcAdditonalReviewerURL), TD_LOG_ERROR_AND_THROW);

			//Set td4ReviewersInstructionUrl value with preference value.
			TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tRevtag, TD_REVIEWER_INSTRC_URL, pcAdditonalReviewerURL), TD_LOG_ERROR_AND_THROW);

			// Added by Anandha Bharathi 
			int ur_result = ur_validateOwningGroup();

			char * cpLifeCyclestatus = "";
			if (ur_result == 0)
			{
				//Get the td4LifeCyclestatus Value
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tRevtag, TD_LIFE_CYCLE_STATUS, &cpLifeCyclestatus), TD_LOG_ERROR_AND_THROW);
				
				int ilifecycleStatus = 1;
				ilifecycleStatus = atoi(cpLifeCyclestatus);
				Custom_free(cpLifeCyclestatus);

				if (ilifecycleStatus > 20)
				{
					urWrkFlowName = UR_RELEASE_LIFECYCLE_ECN_WF_PREF;

					// Initiate UR_ReleaseLifecycleWF workflow
					TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(urWrkFlowName, tRevtag), TD_LOG_ERROR_AND_THROW);
				}
				else
				{
					urWrkFlowName = UR_RELEASE_ECN_WF_PREF;
	
					// Initiate UR_ReleaseECN workflow
					TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(urWrkFlowName, tRevtag), TD_LOG_ERROR_AND_THROW);
				}
			}
			else
			{
				//To initiate the workflow
				TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(pcWrkFlowName, tRevtag), TD_LOG_ERROR_AND_THROW);
			}

			
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}