//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*
 * @file
 *
 *   This file contains the implementation for the Extension getTd4COO_CodeBase
 *
 */

#include <extensions/getTd4COO_CodeBase.hxx>


int getTd4COO_CodeBase(METHOD_message_t * msg, va_list args)
{

	int       		ifail 				= ITK_ok;
	int       		iStatus 			= ITK_ok;
	int 			iVendorPartsCountCOO 		= 0;
	tag_t 			tSelectedObjectCOO 		= msg->object_tag;
	tag_t  			tPropTag 			= va_arg(args, tag_t);
	char**			propValueCOO 			= NULL;
	const char* 		cpAttname 			= msg->prop_name;
	tag_t 			tRelationTypeCOO 		= NULLTAG;
	tag_t * 		tVendorPartsCOO 		= NULLTAG;
	char ** 		td4CountryOfOriginVPCOO 	= NULL;
	int 			iFlag 				= 0;
	char *			tTempValue 			= NULL;
	char* 			value 				= NULL;
	char *			sFinalValue 			= NULL;
	char*			sStatusName 			= "";
	char *			finalPropValue 			= NULL;
	int			valueCount 			= 0;
	tag_t 			tVMRepresentsRelObj 		= NULLTAG;
	propValueCOO = va_arg(args, char**);

	list<string> cooCodeList;
	list <string>::iterator it;
	vector <string> cooValueVector;

	const char * __function__ = "getTd4COO_CodeBase";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_VMREPRESENTS, &tRelationTypeCOO), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tSelectedObjectCOO, tRelationTypeCOO, &iVendorPartsCountCOO, &tVendorPartsCOO), TD_LOG_ERROR_AND_THROW);

		if (iVendorPartsCountCOO != 0)
		{
			for (int inx = 0; inx < iVendorPartsCountCOO; inx++)
			{
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tSelectedObjectCOO, tVendorPartsCOO[inx], tRelationTypeCOO, &tVMRepresentsRelObj), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tVMRepresentsRelObj, TD_PREFERRED_STATUS_ATTR, &sStatusName), TD_LOG_ERROR_AND_THROW);

				if (tc_strcmp(sStatusName, TD_REMOVED) != 0)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_strings(tVendorPartsCOO[inx], TD_COUNTRY_OF_ORIGIN_LIST, &valueCount, &td4CountryOfOriginVPCOO), TD_LOG_ERROR_AND_THROW);

					if (valueCount != 0 && valueCount != NULL)
					{
						for (int iny = 0; iny < valueCount; iny++)
						{
							if (strstr(td4CountryOfOriginVPCOO[iny], "Pending") == NULL)
							{
								char *token = tc_strtok(td4CountryOfOriginVPCOO[iny], "|");

								while (token != NULL)
								{
									tTempValue = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(token)) + 1));

									tc_strcpy(tTempValue, token);

									token = tc_strtok(NULL, "|");
								}
								std::string s(tTempValue);

								cooCodeList.push_back(s);
							}
						}
					}
				}
			}

			if (cooCodeList.size() > 0)
			{
				cooCodeList.sort();

				cooCodeList.unique();

				sFinalValue = (char*)MEM_alloc(sizeof(char) * (4 * (int)(cooCodeList.size()) + 1));

				for (it = cooCodeList.begin(); it != cooCodeList.end(); ++it)
				{

					if (tc_strcmp(sFinalValue, "") == 0)
					{
						tc_strcat(sFinalValue, it->c_str());
					}
					else
					{
						tc_strcat(sFinalValue, ",");

						tc_strcat(sFinalValue, it->c_str());
					}

				}
				*propValueCOO = (char*)MEM_alloc(sizeof(char) * ((int)(tc_strlen(sFinalValue)) + 1));

				tc_strcpy(*propValueCOO, sFinalValue);

				MEM_free(sFinalValue);

				MEM_free(tTempValue);
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
