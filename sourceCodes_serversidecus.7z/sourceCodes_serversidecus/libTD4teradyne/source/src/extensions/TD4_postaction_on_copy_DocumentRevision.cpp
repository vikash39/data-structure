/*==================================================================================================                    
#                Copyright (c) 2016 Teradyne
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_copy_DocumentRevision.cpp
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on ITEM_copy_rev on DesingDoc Revision and GeneralDoc Revision
#      Project         :           libTD4teradyne          
#      Author          :           Manimaran
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  16-Mar-2016						 Manimaran                          Initial Creation
#  23-Mar-2016                       Manimaran                          Modified the code to skip revisions (I,O,P,Q,S,X,Z) for dba group.
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_copy_DocumentRevision
* Description		: Post action to skip revisions (I,O,P,Q,S,X,Z) for CM Admin and dba group
*                           
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :
*                           
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_copy_DocumentRevision(METHOD_message_t *msg , va_list args)
{
	int iStatus					 = ITK_ok;

	char  *pcCurRevId			 = NULL;
	char  *pcRevId               =NULL;
	tag_t tRevTag                = NULLTAG;
	tag_t	tLatestRev		= NULLTAG;
	string szUsergroup           = "";
	char *newRevID = NULL;
	const char* __function__ = "TD4_postaction_on_copy_DocumentRevision";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments from item_copy_rev msg
		tRevTag = va_arg(args, tag_t);
		pcCurRevId = va_arg(args, char*);

		TERADYNE_TRACE_CALL(iStatus = teradyne_get_usergroup_as_string(&szUsergroup),TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus=ITEM_ask_rev_id2(tRevTag, &pcRevId),TD_LOG_ERROR_AND_THROW);
		
		if((szUsergroup.compare(TD_ADMIN_ROLE_CONSTANT) == 0 ) || (szUsergroup.compare(TD_DBA_ROLE_CONSTANT) == 0 ))
		{
			int     iLovs    = 0,
					iLovVals = 0;

			tag_t *tLovs = NULL;

			char *pcLovVals = NULL;

			string szCurRevId(pcCurRevId);
			bool bRevCheck = false;

			TERADYNE_TRACE_CALL(iStatus = LOV_find("TcRevisionSkipLetters", &iLovs, &tLovs), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = LOV_ask_values_char(tLovs[0], &iLovVals, &pcLovVals), TD_LOG_ERROR_AND_THROW);

			for (int valCount = 0; valCount < iLovVals; valCount++) {
				size_t pos = szCurRevId.find(pcLovVals[valCount]);
				if (pos == -1) {
					continue;
				} else {
					bRevCheck = true;
					break;
				}
			}

			if (bRevCheck) {
				TERADYNE_TRACE_CALL(iStatus = teradyne_check_and_apply_revision_rule(tRevTag, pcCurRevId, iLovVals, pcLovVals), TD_LOG_ERROR_AND_THROW);
			}

			Custom_free(tLovs);
			Custom_free(pcLovVals);
		}else if(isDigitWSAllowed(pcRevId)){
           

			//Check if the document has numeric revision , the sequence of revision will be numeric

			TERADYNE_TRACE_CALL(iStatus = teradyne_latest_rev_from_rev(tRevTag, &tLatestRev), TD_LOG_ERROR_AND_THROW);
		
			
	       POM_AM__set_application_bypass(true);
			
			TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tLatestRev,true),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_refresh_instances(1,&tLatestRev,NULLTAG,POM_modify_lock), TD_LOG_ERROR_AND_THROW);
            TERADYNE_TRACE_CALL(iStatus = teradyneGenerateNextTestRevisionID(pcRevId, &newRevID), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_assign_string(tLatestRev,TD_ITEM_REVISION_ID,newRevID), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tLatestRev), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus=AOM_refresh(tLatestRev,false),TD_LOG_ERROR_AND_THROW);
		    POM_AM__set_application_bypass(false);
			
			/*
			tag_t attr_id_tag=NULLTAG;
			TERADYNE_TRACE_CALL(iStatus=POM_attr_id_of_attr(TD_ITEM_REVISION_ID,"TD4DivPartRevision",&attr_id_tag),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_refresh_instances_any_class(1,&tLatestRev,POM_modify_lock), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyneGenerateNextTestRevisionID(pcRevId, &newRevID), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_set_attr_string(1,&tLatestRev,attr_id_tag,newRevID), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_save_instances(1,&tLatestRev,false), TD_LOG_ERROR_AND_THROW);
			
			POM_AM__set_application_bypass(false);
			*/
			
		   			
			
		  
			return ITK_ok;
		}
		

	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);	
	return iStatus;
}
