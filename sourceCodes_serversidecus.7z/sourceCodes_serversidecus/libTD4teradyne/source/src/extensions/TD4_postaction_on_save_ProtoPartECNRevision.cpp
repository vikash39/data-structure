/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_save_ProtoBOMECNRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save in ProtoBOM ECN revision
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  ================================================================================================= 
#  =================================================================================================                    
#  Date                            Name                           Description of Change
#  5-Mar-2015                      Kameshwaran D                     Initial Creation 
#  16-Sept-2019                    Marjorie D			             Modified TD4_postaction_on_save_ProtoPartECNRevision that will initiate TER_ScrapReworkWF if Scrap or Rework Cost > 0
#  $HISTORY$                    
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_save_ProtoBOMECNRevision
* Description		:       
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :1.  				 
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_ProtoPartECNRevision(METHOD_message_t *msg , va_list args)
{
	int iStatus					= ITK_ok;

	tag_t   tItemtag				= NULLTAG,
			tRevtag					= NULLTAG;

	const char*	pcRevid				= NULL;

	const char* __function__		= "TD4_postaction_on_save_ProtoPartECNRevision";

	char *pcWrkFlowName = TD_PROTOPART_ECN_REV_WF_PREF;

	try
	{
		tRevtag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);
		if( bisNew )
		{
			//To initiate the workflow
			TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(pcWrkFlowName,tRevtag) ,TD_LOG_ERROR_AND_THROW);
						
			//Check if rework OR scrap cost is greater than $0
			double reworkCost = 0, scrapCost = 0;
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tRevtag,TD_ECN_EST_RWK_COST,&reworkCost),TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_double(tRevtag,TD_ECN_EST_SCRAP_COST,&scrapCost),TD_LOG_ERROR_AND_THROW);
			if( reworkCost > 0 || scrapCost > 0)
			{
				//initiate TD_SCRAP_REWORK_WF_PREF
				TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(TD_SCRAP_REWORK_WF_PREF,tRevtag) ,TD_LOG_ERROR_AND_THROW);
		}
	}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}