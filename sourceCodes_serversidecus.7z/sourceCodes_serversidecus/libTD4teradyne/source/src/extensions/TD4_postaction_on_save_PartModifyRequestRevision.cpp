/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_create_InitiateWorkflow.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save in Custom Request Objects
#      Project         :           libTD4teradyne          
#      Author          :           Haripriya          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  19-Feb-2015                       Haripriya                          Initial Creation
#  06-Mar-2015						 Kameshwaran D						Added function "teradyne_update_forms_of_createormodify_request" to update Model Forms value
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_save_PartModifyRequestRevision
* Description		: Create a relationship to part(s) for this request
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM	    	:
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_PartModifyRequestRevision(METHOD_message_t*  msg, va_list args)
{
	//Declartion and Initialization of Local Variables
	int  iStatus				= ITK_ok,
		 iCreateReqFlag			= 0,
		 iTerParts		= 0;

	tag_t 
		  tRevTag				= NULL;

	tag_t	
			*tTerParts		= NULL;

	char
		*pcObjectType = NULL,
		*pcTypeName = NULL;
	
	const char* __function__ = "TD4_postaction_on_save_PartModifyRequestRevision";

	TERADYNE_TRACE_ENTER();

	try
	{
		tRevTag      = va_arg(args, tag_t);
		
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tRevTag,&pcObjectType),TD_LOG_ERROR_AND_THROW);
			if (!tc_strcmp(pcObjectType,TD_PART_MODIFY_REQ_REV))
			{
				  tag_t  tPartModifiedByRelTag = NULLTAG; 
				  tag_t  tItemRevTag = NULL;
				  
				  tag_t	tRelationTypeTag = NULL;
				  TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_PART_TO_BE_MODIFIED_REL, &tRelationTypeTag), TD_LOG_ERROR_AND_THROW); 
				  TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tRevTag, tRelationTypeTag, &iTerParts, &tTerParts), TD_LOG_ERROR_AND_THROW);
				  
				  for(int jj=0;jj<iTerParts;jj++){

					  TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tTerParts[jj], &pcTypeName), TD_LOG_ERROR_AND_THROW);
					  if(pcTypeName != NULL && (tc_strcmp(pcTypeName, TD_DIV_PART_REV) == 0 || tc_strcmp(pcTypeName, TD_COMM_PART_REV) == 0)){
						    AM__set_application_bypass(true);

							//Create a relationship between this request and the parts
					          tag_t tRelation = NULLTAG;
					          TERADYNE_TRACE_CALL(iStatus=GRM_find_relation_type(TD_PART_MODIFIED_BY_REL,&tPartModifiedByRelTag),TD_LOG_ERROR_AND_THROW);
							  TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tTerParts[jj], tRevTag, tPartModifiedByRelTag, &tRelation), TD_LOG_ERROR_AND_THROW);

					              if(tRelation ==NULLTAG){
						                 tag_t tNewRelation	= NULLTAG;
                                         TERADYNE_TRACE_CALL(iStatus=GRM_create_relation(tTerParts[jj],tRevTag,tPartModifiedByRelTag,NULLTAG,&tNewRelation),TD_LOG_ERROR_AND_THROW);
										
										if(tNewRelation != NULLTAG){
							                TERADYNE_TRACE_CALL(iStatus=GRM_save_relation(tNewRelation),TD_LOG_ERROR_AND_THROW);
						                }
					              }

					        AM__set_application_bypass(false);
					  
					  }
				  }
				  
		}

	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcObjectType);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
