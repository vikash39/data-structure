/*==================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           teradyne_postaction_on_checkin_msg.cpp         
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for checkin post action
#      Project         :           libTD4teradyne          
#      Author          :           Vivek          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  07-Oct-2014                       Vivek                              Initial Creation
#  31-Oct-2014                       Haripriya                          Added Checkin postaction for DivPartRevision and oracleForm
#  11-Nov-2014			             Vijayasekhar		                Initial creation of function teradyne_update_change_history_on_dse_form_edit
#  21-Jan-2015						 Kameshwaran D.						Added condition to not initiate workflow for the object types DFM form , Reliability Form and Safety Form on Post action.
#  22-Jan-2015						 Kameshwaran D.						Renamed workflow's preference macro name to TD_T4O_ITEM_PUSH_WF_PREF,TD_COMMERCIALPARTREQUEST_WF_PREF, TD_T4O_ORGEXTEND_WF_PREF.
#  03-Feb-2015						 Kameshwaran D.						Fix: Not to initiate workflow more than one time over same object.
#  09-Feb-2015						 Kameshwaran D.						Added code to initiate Workflow when commercial part revision checkin happens.
#  09-Feb-2015						 Selvi     						    Modified code to initiate process on latest released DivPart Revision when Oracle Form checkin happens. 
#  17-Feb-2015						 Kameshwaran D.						Added AM__set_application_bypass to bypass the access rule while updating the History form
#  18-Feb-2015						 Vijayasekhar						Added changes for SBM Form checkin to attach Commodity level 1 form to the respective part revision
#  24-Feb-2015						 Haripriya						    Modified code to initiate workflow on commercialpart when oracle form is checked in.
#  30-Mar-2015						 Vijayasekhar						Modified the function call teradyne_current_time_utc
#  07-May-2015                       Selvi                              Added Function teradyne_find_execute_qry and removed teradyne_find_latest_released_revision.
#  29-May-2015						 Kameshwaran D.						Added Vendor part checkin to call a function teradyne_UpdateTerPartRevComplAtr.
#  15-Jun-2015						 Vijayasekhar						Getting the workflow name TER_UpdateComplianceAttributes from the preference
#  19-Nov-2015                       Manimaran                          Added code to update the solution item revision synopsis value whenever ECN Revision check-in happens.
#  14-Dec-2015						 Kameshwaran D.						Added code to restrict create process if div/comm part has more than one revision
#  15-Jan-2018						 Marjorie D.						Added code to teradyne_postaction_on_checkin_msg function to enable checkin of closed ECNs	
#  17-Sep-2018						 Marjorie D.						Added code to teradyne_attach_commlvl1form_on_sbmform_edit function to update the Commodity Level 1 Commodity Engineer and Manager
 # 07-July-2021						Gurunathan S						Modified to initiate item push for CMAdmin and DBA 
 #  $HISTORY$ 
                  
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : teradyne_postaction_on_checkin_msg
 * Description      :
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : METHOD_message_t*  msg, va_list args
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int teradyne_postaction_on_checkin_msg(METHOD_message_t*  msg, va_list args)
{
	//Declartion and Initialization of Local Variables
	int iStatus					= ITK_ok,
		iCount					= 0,
		iRevCount				= 0;

    char *pcTypeName            = NULL,
		 *pcObjTypeName         = NULL,
		 *pcProcessTemplateName = NULL,
		 *pcItemID		        = NULL;

	tag_t tObject				= NULLTAG,
		  tOrgRelTag            = NULLTAG,
		  tLatRevTag            = NULLTAG,
		  tObjFoundTag          = NULLTAG,
		  *tRevTags				= NULLTAG,
		  tNewProcess               = NULLTAG;

	std::map<string,string> strPropNameValueMap;

	const char* __function__ = "teradyne_postaction_on_checkin_msg";
	TERADYNE_TRACE_ENTER();

	try
	{
		//Get the input arguments
		tObject = va_arg(args, tag_t);
		if(tObject != NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_performActionAfterCheckIn(tObject),TD_LOG_ERROR_AND_THROW);
				
				}
			}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcProcessTemplateName);
	Custom_free(pcObjTypeName);
	Custom_free(pcTypeName);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}



/*******************************************************************************
 * Function Name			: teradyne_update_change_history_on_part_edit
 * Description				: This function will perfrom checkin operation
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : targetObjTag  		  (I) - Target object tag
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Checking whether History Form present in the related objects of change admin form
 *							  2. It will update change history attribute with appended values user name, change reason of change admin form 
 *								 and current time stamp.
 *							  3. It will update change reason attrbute of change admin form with empty values.
 *						      4. If all the above operations are succeed it will initiate the T4O_Item_Push workflow
 * NOTES					:
 ******************************************************************************/
int teradyne_update_change_history_on_part_edit(tag_t tObject,char* pcTypeName) {
	
	int iStatus					= ITK_ok,
		iPriCount				= 0,
		iSecCount				= 0;
	tag_t tUser					= NULLTAG,
		  tRelationType			= NULLTAG,
		  *ptPriObjs			= NULL,
		  *ptSecObjs			= NULL;

	char *pcChgReason			= NULL,
		  *pcUserName			= NULL,
		  *pcObjTypeName		= NULL,
		  *pcChgHstry			= NULL;

	string strCurTimeStamp		= "",
		   concatenatedString	= "",
		   appendedValue		= "",
		   pcTypePartNameArr[]	= {TD_DIV_PART_REV,TD_COMM_PART_REV}; // Add the Part name in array if need to get the primary object Tag.
	bool bIsBreak				= false,
		 isPrimary				= 1;
	date_t curDate;

	const char * __function__     = "teradyne_update_change_history_on_part_edit" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if(tObject != NULLTAG) {
			//Getting the Changes reason value and username
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_CHNG_RESN_ATTR, &pcChgReason), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcUserName, &tUser), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_current_time_utc(TD_DATE_YMD_CONSTANT, strCurTimeStamp, curDate), TD_LOG_ERROR_AND_THROW);
			if(pcUserName != NULL) {
	
				concatenatedString = pcUserName;
				concatenatedString.append(TD_RIGHT_SHIFT_ARROW_CONSTANT);
			}
			if(strCurTimeStamp != "" && strCurTimeStamp.length() > 0) {
		
				concatenatedString.append(strCurTimeStamp);
				concatenatedString.append(TD_RIGHT_SHIFT_ARROW_CONSTANT);
			}
			if(pcChgReason != NULL) {
		
				concatenatedString.append(pcChgReason);
			}

			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_DIS_SPEC_REL_NAME, &tRelationType), TD_LOG_ERROR_AND_THROW);
			if(tRelationType != NULLTAG) {
	
			       TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tObject, tRelationType, &iSecCount, &ptSecObjs), TD_LOG_ERROR_AND_THROW);
					for(int i = 0; i < iSecCount; i++) {
			
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptSecObjs[i], &pcObjTypeName), TD_LOG_ERROR_AND_THROW); //getting the object type name
						if(pcObjTypeName != NULL && tc_strcmp(pcObjTypeName, TD_CHANGEHISTORY_FORM_TYPE) == 0) {
						
							pcChgHstry = NULL;
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptSecObjs[i], TD_CHG_HSTRY_ATTR, &pcChgHstry), TD_LOG_ERROR_AND_THROW);
							if(pcChgHstry != NULL) {

								appendedValue = pcChgHstry;
							}
							appendedValue.append("\n------\n");
							if(concatenatedString != "" && concatenatedString.length() > 0) {
		
								appendedValue.append(concatenatedString);
							}
							//updating the change history attribute with appendedvalue
							AM__set_application_bypass(true);// Bypass is set true to update change history form
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(ptSecObjs[i], TD_CHG_HSTRY_ATTR, appendedValue), TD_LOG_ERROR_AND_THROW);
							AM__set_application_bypass(false);
							appendedValue = "";
							bIsBreak = true;
							break; //if the part revision having only one change history form.
						}
					}
					
				//updating the change reason attribute with empty value
				TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tObject, TD_CHNG_RESN_ATTR, ""), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = teradyne_update_object_name(tObject), TD_LOG_ERROR_AND_THROW);
			
				

			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcChgReason);
	Custom_free(pcUserName);
	Custom_free(pcChgHstry);
	Custom_free(ptPriObjs);
	Custom_free(pcObjTypeName);
	Custom_free(ptSecObjs);
	Custom_free(pcObjTypeName);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name			: teradyne_update_change_history_on_mfgpart_edit
 * Description				: This function will perfrom checkin operation
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : targetObjTag  		  (I) - Target object tag
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Checking whether History Form present in the related objects of change admin form
 *							  2. It will update change history attribute with appended values user name, change reason of change admin form
 *								 and current time stamp.
 *							  3. It will update change reason attrbute of change admin form with empty values.
 *						      4. If all the above operations are succeed it will initiate the T4O_Item_Push workflow
 * NOTES					:
 ******************************************************************************/

int teradyne_update_change_history_on_mfgpart_edit(tag_t tObject, char* pcTypeName) {

	int iStatus = ITK_ok,
		iPriCount = 0,
		iSecCount = 0,
		iFlag = 0;
	tag_t tUser = NULLTAG,
		tRelationType = NULLTAG,
		*ptPriObjs = NULL,
		*ptSecObjs = NULL;

	char *pcChgReason = NULL,
		*pcUserName = NULL,
		*pcObjTypeName = NULL,
		*pcChgHstry = NULL;

	string strCurTimeStamp = "",
		concatenatedString = "",
		appendedValue = "",
		pcTypePartNameArr[] = { TD_DIV_PART_REV,TD_COMM_PART_REV }; // Add the Part name in array if need to get the primary object Tag.
	bool bIsBreak = false,
		isPrimary = 1;
	date_t curDate;

	const char * __function__ = "teradyne_update_change_history_on_mfgpart_edit";
	TERADYNE_TRACE_ENTER();

	try
	{
		if (tObject != NULLTAG) {
			//Getting the Changes reason value and username
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_CHNG_RESN_ATTR, &pcChgReason), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcUserName, &tUser), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_current_time_utc(TD_DATE_MDY_CONSTANT, strCurTimeStamp, curDate), TD_LOG_ERROR_AND_THROW);
			if (pcUserName != NULL) {

				concatenatedString = pcUserName;
				concatenatedString.append(TD_RIGHT_SHIFT_ARROW_CONSTANT);
			}
			if (strCurTimeStamp != "" && strCurTimeStamp.length() > 0) {

				concatenatedString.append(strCurTimeStamp);
				concatenatedString.append(TD_RIGHT_SHIFT_ARROW_CONSTANT);
			}
			if (pcChgReason != NULL) {

				concatenatedString.append(pcChgReason);
			}

			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_DIS_SPEC_REL_NAME, &tRelationType), TD_LOG_ERROR_AND_THROW);
			if (tRelationType != NULLTAG) {

				TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tObject, tRelationType, &iSecCount, &ptSecObjs), TD_LOG_ERROR_AND_THROW);
				for (int i = 0; i < iSecCount; i++) {

					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptSecObjs[i], &pcObjTypeName), TD_LOG_ERROR_AND_THROW); //getting the object type name
					if (pcObjTypeName != NULL && tc_strcmp(pcObjTypeName, TD_CHANGEHISTORY_FORM_TYPE) == 0) {
						iFlag = 1;
						pcChgHstry = NULL;
						TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptSecObjs[i], TD_CHG_HSTRY_ATTR, &pcChgHstry), TD_LOG_ERROR_AND_THROW);
						if (pcChgHstry != NULL) {

							appendedValue = pcChgHstry;
						}
						
						if (concatenatedString != "" && concatenatedString.length() > 0) {
							concatenatedString.append("\n------\n");
							concatenatedString.append(appendedValue);
						}
						//updating the change history attribute with appendedvalue
						AM__set_application_bypass(true);// Bypass is set true to update change history form
						TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(ptSecObjs[i], TD_CHG_HSTRY_ATTR, concatenatedString), TD_LOG_ERROR_AND_THROW);
						AM__set_application_bypass(false);
						appendedValue = "";
						bIsBreak = true;
						break; //if the part revision having only one change history form.
					}
				}
				if (iFlag == 0) {
					TERADYNE_TRACE_CALL(iStatus = teradyne_create_ChangeHistoryForms(tObject), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_update_change_history_on_mfgpart_edit(tObject, pcTypeName), TD_LOG_ERROR_AND_THROW);
				}

				//updating the change reason attribute with empty value
				TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tObject, TD_CHNG_RESN_ATTR, ""), TD_LOG_ERROR_AND_THROW);




			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcChgReason);
	Custom_free(pcUserName);
	Custom_free(pcChgHstry);
	Custom_free(ptPriObjs);
	Custom_free(pcObjTypeName);
	Custom_free(ptSecObjs);
	Custom_free(pcObjTypeName);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


/*******************************************************************************
 * Function Name			: teradyne_update_change_history_on_dse_form_edit
 * Description				: This function will perfrom checkin operation
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : targetObjTag  		  (I) - Target object tag
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Checking whether History Form present in the related objects of change admin form
 *							  2. It will update change history attribute with appended values user name, change reason of change admin form 
 *								 and current time stamp.
 *							  3. It will update change reason attrbute of change admin form with empty values.
 *						      4. If all the above operations are succeed it will initiate the T4O_Item_Push workflow
 * NOTES					:
 ******************************************************************************/
int teradyne_update_change_history_on_dse_form_edit(tag_t tObject,char* pcTypeName) {
	
	int iStatus					= ITK_ok,
		iPriCount				= 0,
		iSecCount				= 0;
	tag_t tUser					= NULLTAG,
		  tRelationType			= NULLTAG,
		  *ptPriObjs			= NULL,
		  *ptSecObjs			= NULL;

	char *pcChgReason			= NULL,
		  *pcUserName			= NULL,
		  *pcObjTypeName		= NULL,
		  *pcChgHstry			= NULL;

	string strCurTimeStamp		= "",
		   concatenatedString	= "",
		   appendedValue		= "",
		   pcTypePartNameArr[]	= {TD_DIV_PART_REV,TD_COMM_PART_REV}; // Add the Part name in array if need to get the primary object Tag.
	bool bIsBreak				= false,
		 isPrimary				= 1;
	date_t curDate;

	const char * __function__     = "teradyne_update_change_history_on_dse_form_edit" ;
	TERADYNE_TRACE_ENTER();

	try
	{
		if(tObject != NULLTAG) {
			//Getting the Changes reason value and username
			TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_CHNG_RESN_ATTR, &pcChgReason), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcUserName, &tUser), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = teradyne_current_time_utc(TD_DATE_YMD_CONSTANT, strCurTimeStamp, curDate), TD_LOG_ERROR_AND_THROW);
			if(pcUserName != NULL) {
	
				concatenatedString = pcUserName;
				concatenatedString.append(TD_RIGHT_SHIFT_ARROW_CONSTANT);
			}
			if(strCurTimeStamp != "" && strCurTimeStamp.length() > 0) {
		
				concatenatedString.append(strCurTimeStamp);
				concatenatedString.append(TD_RIGHT_SHIFT_ARROW_CONSTANT);
			}
			if(pcChgReason != NULL) {
		
				concatenatedString.append(pcChgReason);
			}

			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_DIS_SPEC_REL_NAME, &tRelationType), TD_LOG_ERROR_AND_THROW);
			if(tRelationType != NULLTAG) {
	
				TERADYNE_TRACE_CALL(iStatus = GRM_list_primary_objects_only(tObject, tRelationType, &iPriCount, &ptPriObjs), TD_LOG_ERROR_AND_THROW);
				for(int i = 0; i < iPriCount; i++) {
			
					TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(ptPriObjs[i], tRelationType, &iSecCount, &ptSecObjs), TD_LOG_ERROR_AND_THROW);
					for(int i = 0; i < iSecCount; i++) {
			
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(ptSecObjs[i], &pcObjTypeName), TD_LOG_ERROR_AND_THROW); //getting the object type name
						if(pcObjTypeName != NULL && tc_strcmp(pcObjTypeName, TD_CHANGEHISTORY_FORM_TYPE) == 0) {
						
							pcChgHstry = NULL;
							TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(ptSecObjs[i], TD_CHG_HSTRY_ATTR, &pcChgHstry), TD_LOG_ERROR_AND_THROW);
							if(pcChgHstry != NULL) {

								appendedValue = pcChgHstry;
							}
							appendedValue.append("\n------\n");
							if(concatenatedString != "" && concatenatedString.length() > 0) {
		
								appendedValue.append(concatenatedString);
							}
							//updating the change history attribute with appendedvalue
							AM__set_application_bypass(true);// Bypass is set true to update change history form
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(ptSecObjs[i], TD_CHG_HSTRY_ATTR, appendedValue), TD_LOG_ERROR_AND_THROW);
							AM__set_application_bypass(false);
							appendedValue = "";
							bIsBreak = true;
							break; //if the part revision having only one change history form.
						}
					}
					if(bIsBreak) break; //breaking the loop if the change history form found
				}
				//updating the change reason attribute with empty value
				TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tObject, TD_CHNG_RESN_ATTR, ""), TD_LOG_ERROR_AND_THROW);
			
				int pcTypePartNameArrSize = sizeof(pcTypePartNameArr)/sizeof(string);

				for(int pos=0 ; pos<pcTypePartNameArrSize ; pos++)
				{
					tag_t tObjFoundTag = NULLTAG;

					TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tObject,TD_DIS_SPEC_REL_NAME,pcTypePartNameArr[pos],isPrimary,&tObjFoundTag),TD_LOG_ERROR_AND_THROW);
					
					if( tObjFoundTag == NULLTAG ) continue;

					//initiating the workflow only to those types which are other than DFM form , Reliablity form and Safety form.
					if(tc_strcmp(pcTypeName, TD_DFM_FORM_TYPE) != 0) 
					{
						if(tc_strcmp(pcTypeName, TD_RELIABILITY_FORM_TYPE) != 0)
						{
							if(tc_strcmp(pcTypeName, TD_SAFETY_FORM_TYPE) != 0)
							{
								char *pcObjTypeName = NULL;
								TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObjFoundTag,&pcObjTypeName),TD_LOG_ERROR_AND_THROW);
								if(tc_strcmp(pcObjTypeName, TD_COMM_PART_REV) == 0 || tc_strcmp(pcObjTypeName, TD_DIV_PART_REV) == 0)
								{
									TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ERP(TD_PART_UPDATED_EVENT,tObjFoundTag,false),TD_LOG_ERROR_AND_THROW);
							}
						}
					}	
				}
			}
		}
	}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcChgReason);
	Custom_free(pcUserName);
	Custom_free(pcChgHstry);
	Custom_free(ptPriObjs);
	Custom_free(pcObjTypeName);
	Custom_free(ptSecObjs);
	Custom_free(pcObjTypeName);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_attach_commlvl1form_on_sbmform_edit
 * Description				: This function will perfromed on checkin operation of SBM form
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tObject  		  (I) - Target object tag
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 1. Will find the selected commodity level 1 forms in teamcenter 
 *							  2. Attaches the commodity level 1 form with the corresponding part revision with Commodity level 1 relation
 *							  3. It will delete the form if the form already exits in the part with the relation
 * NOTES					:
 ******************************************************************************/
int teradyne_attach_commlvl1form_on_sbmform_edit(tag_t tObject) {

	int iStatus					= ITK_ok,
		iCount					= 0;

	char *pcFormName			= NULL,
		  *pcObjType			= NULL;

	tag_t *tCommodityFormList	= NULL,
		  tPrimaryObj			= NULLTAG,
		  tCommRel				= NULLTAG,
		  tComodityRelType		= NULLTAG;

	const char * __function__ = "teradyne_attach_commlvl1form_on_sbmform_edit";
	TERADYNE_TRACE_ENTER();

	try {
	
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_COMMODITY_LEVEL_1, &pcFormName), TD_LOG_ERROR_AND_THROW);
		if(pcFormName != NULL) {
		
			TERADYNE_TRACE_CALL(iStatus = WSOM_find2(pcFormName, &iCount, &tCommodityFormList), TD_LOG_ERROR_AND_THROW); 
			for(int i = 0; i < iCount; i++) {
			
				TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tCommodityFormList[i], &pcObjType), TD_LOG_ERROR_AND_THROW);
				if(pcObjType != NULL && tc_strcmp(pcObjType, TD_COMMODITY_FORM_TYPE) == 0) {
	
					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_COMMODITY_LVL1_REL_NAME, &tComodityRelType), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tObject, TD_DIS_SPEC_REL_NAME, "", 1, &tPrimaryObj), TD_LOG_ERROR_AND_THROW); //getting primary object for SBM form 
						
					if(tPrimaryObj != NULLTAG && tComodityRelType != NULLTAG) {
							
						AM__set_application_bypass(true); //bypassing to create or delete relation
						//deleting commodity level 1 forms if already exists in the relation
						TERADYNE_TRACE_CALL(iStatus = teradyne_find_and_delete_relation(tComodityRelType, tPrimaryObj),TD_LOG_ERROR_AND_THROW);
						//attaching the commodity level 1 form to the part revision with commodity level 1 relation
						TERADYNE_TRACE_CALL(iStatus = GRM_create_relation(tPrimaryObj, tCommodityFormList[i], tComodityRelType, NULLTAG, &tCommRel), TD_LOG_ERROR_AND_THROW);
						if(tCommRel != NULLTAG) {
							
							TERADYNE_TRACE_CALL(iStatus = GRM_save_relation(tCommRel), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL ( iStatus = AOM_refresh(tPrimaryObj, true), TD_LOG_ERROR_AND_THROW);	
							TERADYNE_TRACE_CALL(iStatus=ITEM_save_rev(tPrimaryObj),TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL ( iStatus = AOM_refresh(tPrimaryObj, false), TD_LOG_ERROR_AND_THROW);	
							
							break; //skip the multiple form names with the same name
						}
						AM__set_application_bypass(false);
					}
				}
			}
		}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(pcFormName);
	Custom_free(tCommodityFormList);
	Custom_free(pcObjType);
	
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name			: teradyne_find_and_delete_relation
 * Description				: This function will delete the relation if the it is available
 *
 * REQUIRED HEADERS :
 * INPUT/OUTPUT PARAMS      : tComodityRelType(I) - Relation type tag
 *							  tPrimaryObj	  (I) - Primary Object tag
 *
 * RETURN VALUE				: int : 0/error code
 * GLOBALS USED				:
 * FUNCTIONS CALLED			:
 *
 * ALGORITHM				: 
 * NOTES					:
 ******************************************************************************/
int teradyne_find_and_delete_relation(tag_t tComodityRelType, tag_t tPrimaryObj ) {

	int iStatus					= ITK_ok,
		iSecCount				= 0;

	tag_t *tSecObjs				= NULL,
		  tCommRel				= NULLTAG;

	const char * __function__ = "teradyne_find_and_delete_relation";
	TERADYNE_TRACE_ENTER();

	try {
		
		if(tPrimaryObj != NULLTAG && tComodityRelType != NULLTAG) {
						
				TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tPrimaryObj, tComodityRelType, &iSecCount, &tSecObjs),TD_LOG_ERROR_AND_THROW);
				for(int i = 0; i < iSecCount; i++) {
						
					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimaryObj, tSecObjs[i], tComodityRelType, &tCommRel), TD_LOG_ERROR_AND_THROW);
					if(tCommRel != NULLTAG)
						GRM_delete_relation(tCommRel);
				}
			}
	} catch(...) {

		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
    }
	Custom_free(tSecObjs);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}


int teradyne_performActionAfterCheckIn(tag_t tObject)
{
	//Declartion and Initialization of Local Variables
	int iStatus					= ITK_ok,
		iCount					= 0,
		iRevCount				= 0;
	
    char *pcTypeName            = NULL,
		 *pcObjTypeName         = NULL,
		 *pcProcessTemplateName	= NULL,
		 *pcItemID		        = NULL,
		 *pcChgReason			= NULL,
		 *pcUserName			= NULL,
		 *pcChgHstry			= NULL;

	tag_t tOrgRelTag            = NULLTAG,
		  tLatRevTag            = NULLTAG,
		  tObjFoundTag          = NULLTAG,
		  *tRevTags				= NULLTAG,
		  tNewProcess           = NULLTAG,
		  tUser					= NULLTAG;

	string strCurTimeStamp		= "",
		concatenatedString		= "",
		szUsergroup             ="",
		appendedValue			= "";

	date_t curDate;

	std::map<string,string> strPropNameValueMap;

	const char* __function__ = "teradyne_performActionAfterCheckIn";
	TERADYNE_TRACE_ENTER();

	try
	{
		
		if(tObject != NULLTAG)
		{
			TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObject,&pcTypeName),TD_LOG_ERROR_AND_THROW);
			// if type is TD4DivPartRevision or TD4CommPartReqRevision
			if( tc_strcmp(pcTypeName, TD_DIV_PART_REV) == 0)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_update_change_history_on_part_edit(tObject,pcTypeName), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_list_all_revisions_from_revtag(tObject, &iRevCount, &tRevTags), TD_LOG_ERROR_AND_THROW);

				//modified to initiate item push for CMAdmin and DBA
				TERADYNE_TRACE_CALL(iStatus = teradyne_get_usergroup_as_string(&szUsergroup), TD_LOG_ERROR_AND_THROW);
				if(iRevCount == 1 || szUsergroup.compare(TD_ADMIN_ROLE_CONSTANT) == 0 || szUsergroup.compare(TD_DBA_ROLE_CONSTANT) == 0) {
					TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ERP(TD_PART_UPDATED_EVENT,tObject,false),TD_LOG_ERROR_AND_THROW);
				} 

				Custom_free(tRevTags);
			} 
			else if(tc_strcmp(pcTypeName, TD_COMM_PART_REV) == 0)
			{
			    TERADYNE_TRACE_CALL(iStatus = teradyne_update_change_history_on_part_edit(tObject,pcTypeName), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_send_to_ERP(TD_PART_UPDATED_EVENT,tObject,false),TD_LOG_ERROR_AND_THROW);
				
			}
			
			// for the forms of type Discipline Specific edit
			if(tc_strcmp(pcTypeName, TD_CHANGEADMIN_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_DFM_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_RELIABILITY_FORM_TYPE) == 0 
				|| tc_strcmp(pcTypeName, TD_SBM_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_SAFETY_FORM_TYPE) == 0 || tc_strcmp(pcTypeName, TD_TRADE_COMPL_FORM_TYPE) == 0)
			{
				if(tc_strcmp(pcTypeName, TD_SBM_FORM_TYPE) == 0) {
			
					TERADYNE_TRACE_CALL(iStatus = teradyne_attach_commlvl1form_on_sbmform_edit(tObject), TD_LOG_ERROR_AND_THROW); // will be called on SBM form checkin only
				}
				TERADYNE_TRACE_CALL(iStatus = teradyne_update_change_history_on_dse_form_edit(tObject,pcTypeName), TD_LOG_ERROR_AND_THROW);
			}

			if (tc_strcmp(pcTypeName, TD_VENDOR) == 0)
			{
				TERADYNE_TRACE_CALL(iStatus = teradyne_update_change_history_on_part_edit(tObject, pcTypeName), TD_LOG_ERROR_AND_THROW);

				//Getting the Changes reason value and username
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_VD_CHNG_RESN_ATTR, &pcChgReason), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = POM_get_user(&pcUserName, &tUser), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_current_time_utc(TD_DATE_YMD_CONSTANT, strCurTimeStamp, curDate), TD_LOG_ERROR_AND_THROW);
				if (pcUserName != NULL) {

					concatenatedString = pcUserName;
					concatenatedString.append(TD_RIGHT_SHIFT_ARROW_CONSTANT);
				}
				if (strCurTimeStamp != "" && strCurTimeStamp.length() > 0) {

					concatenatedString.append(strCurTimeStamp);
					concatenatedString.append(TD_RIGHT_SHIFT_ARROW_CONSTANT);
				}
				if (pcChgReason != NULL) {

					concatenatedString.append(pcChgReason);
				}

				pcChgHstry = NULL;
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_CHG_HSTRY_ATTR, &pcChgHstry), TD_LOG_ERROR_AND_THROW);
				if (pcChgHstry != NULL) {

					appendedValue = pcChgHstry;
				}
				appendedValue.append("\n------\n");
				if (concatenatedString != "" && concatenatedString.length() > 0) {

					appendedValue.append(concatenatedString);
				}
				//updating the change history attribute with appendedvalue
				AM__set_application_bypass(true);// Bypass is set true to update change history form
				TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tObject, TD_CHG_HSTRY_ATTR, appendedValue), TD_LOG_ERROR_AND_THROW);
				AM__set_application_bypass(false);
				appendedValue = "";


				//updating the change reason attribute with empty value
				TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tObject, TD_VD_CHNG_RESN_ATTR, ""), TD_LOG_ERROR_AND_THROW);
			}
			// if type is TD4OracleORGForm
			if(tc_strcmp(pcTypeName, TD_ORACLE_ORG_FORM_TYPE) == 0)
			{
				bool isPrimary = 1;
				TERADYNE_TRACE_CALL(iStatus = teradyne_getprimaryorsecondary_relation_objecttag(tObject,TD_ORG_REL_NAME,"",isPrimary,&tObjFoundTag),TD_LOG_ERROR_AND_THROW);
				
				if( tObjFoundTag != NULLTAG )
				{													
					TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObjFoundTag,&pcObjTypeName),TD_LOG_ERROR_AND_THROW);
				    // if type is TD4DivPart or TD_COMM_PART
					if((tc_strcmp(pcObjTypeName, TD_DIV_PART) == 0 ) || (tc_strcmp(pcObjTypeName, TD_COMM_PART) == 0 ))
					{
						//Getting Item ID of Object
						TERADYNE_TRACE_CALL(iStatus = ITEM_ask_id2(tObjFoundTag,&pcItemID),TD_LOG_ERROR_AND_THROW);
				
						//Process to get latest released DivPart Revision
						strPropNameValueMap.insert(::make_pair((string)TD_TYPE_INPUT,(string)TD_DIV_PART_REV));
						strPropNameValueMap.insert(::make_pair((string)TD_ITEMID_INPUT,(string)pcItemID));
						strPropNameValueMap.insert(::make_pair((string)TD_STATUS_INPUT,(string)TD_REL_STATUS_NAME));
						TERADYNE_TRACE_CALL(iStatus = teradyne_find_execute_qry(TD_ITEM_QUERY, strPropNameValueMap, &iCount, &tRevTags),TD_LOG_ERROR_AND_THROW);
						if ( iCount > 0 ) { 
							tLatRevTag = tRevTags[0]; 
						} 
					
						if ( tLatRevTag == NULLTAG )
						{  
								TERADYNE_TRACE_CALL(iStatus =ITEM_ask_latest_rev(tObjFoundTag,&tLatRevTag),TD_LOG_ERROR_AND_THROW);
						}			

						if ( tLatRevTag != NULLTAG)
						{   
							//Getting Preference Value to get Workflow template name
							TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_T4O_ORGEXTEND_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
							//Initiate the T4O workflow
							TERADYNE_TRACE_CALL(iStatus = teradyne_create_process(pcProcessTemplateName,"",EPM_target_attachment,tLatRevTag,&tNewProcess),TD_LOG_ERROR_AND_THROW);
							Custom_free(pcProcessTemplateName);
						}
						
					}
				}
			}
			if(tc_strcmp(pcTypeName, TD_MFG_PART) == 0)
			{
				//Getting Preference Value to get Workflow template name
				TERADYNE_TRACE_CALL(iStatus=PREF_ask_char_value_at_location(TD_VENDOR_PART_CMPL_ATTR_WF_PREF,TC_preference_site,0,&pcProcessTemplateName),TD_LOG_ERROR_AND_THROW);
				//Function will initiate TER_UpdateComplianceAttributes workflow
				TERADYNE_TRACE_CALL(iStatus = teradyne_create_process(pcProcessTemplateName,"",EPM_target_attachment,tObject,&tNewProcess),TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = teradyne_update_change_history_on_mfgpart_edit(tObject, pcTypeName), TD_LOG_ERROR_AND_THROW);
			}
			if((tc_strcmp(pcTypeName, TD_STD_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_PROTOBOM_ECN_REV_TYPE) == 0) || (tc_strcmp(pcTypeName, TD_REL_ECN_REV_TYPE) == 0)) {
				tag_t tRelationTag = NULLTAG;
				tag_t *tObjectFoundTag = NULL;
				int iObjCount = 0;

				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD_ECR_SOLREL_NAME, &tRelationTag), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = GRM_list_secondary_objects_only(tObject, tRelationTag, &iObjCount, &tObjectFoundTag),TD_LOG_ERROR_AND_THROW);

				if (iObjCount > 0) {
					char *pcSynopsis = NULL;

					TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_ECN_SYNOP, &pcSynopsis),TD_LOG_ERROR_AND_THROW);
					for (int i = 0; i < iObjCount; i++) {
						TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObjectFoundTag[i], &pcObjTypeName),TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(pcObjTypeName, TD_DIV_PART_REV) == 0) {
							AM__set_application_bypass(true);
							TERADYNE_TRACE_CALL(iStatus = teradyne_setproperty_value(tObjectFoundTag[i], TD_SYNOPSIS_ATTR, pcSynopsis), TD_LOG_ERROR_AND_THROW);
							AM__set_application_bypass(false);
						}
					}
					Custom_free(pcSynopsis);
				}
				Custom_free(tObjectFoundTag);
			}
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}
	Custom_free(pcProcessTemplateName);
	Custom_free(pcObjTypeName);
	Custom_free(pcTypeName);
	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
