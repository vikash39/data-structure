/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_save_ComEnggTranRqRevision.cpp
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on IMAN_save in Commodity Engineer Transfer Request
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  ================================================================================================= 
#  =================================================================================================                    
#  Date                            Name                           Description of Change
#  16-Apr-2015                     Kameshwaran D                     Initial Creation 
#  $HISTORY$                    
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_save_ComEnggTranRqRevision.cpp
* Description		:       
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :1.  				 
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_save_ComEnggTranRqRevision(METHOD_message_t *msg , va_list args)
{
	int iStatus						= ITK_ok;

	tag_t   tItemtag				= NULLTAG,
			tRevtag					= NULLTAG;

	const char*	pcRevid				= NULL;

	const char* __function__		= "TD4_postaction_on_save_ComEnggTranRqRevision";

	char *pcWrkFlowName				= TD_COMMDTY_ENGG_TRANSFER_REQ_WF_PREF;

	try
	{
		tRevtag      = va_arg(args, tag_t);
		bool bisNew  = va_arg(args, logical);
		if( bisNew )
		{
			//To initiate the workflow
			TERADYNE_TRACE_CALL(iStatus = teradyne_initiate_workflow_based_on_argument(pcWrkFlowName,tRevtag) ,TD_LOG_ERROR_AND_THROW);
		}
	}
	catch(...)
	{
		if(iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception",__function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}