/*==================================================================================================                    
#                Copyright (c) 2014 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_create_CommPartRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on ITEM_create_rev in Commercial Part revision
#      Project         :           libTD4teradyne          
#      Author          :           Selvi          
#  =================================================================================================                    
#  Date                              Name                               Description of Change
#  05-Nov-2014                       Haripriya                          Initial Creation
#  14-Nov-2014                       Haripriya                          Added form creation in ImanSpecification Relation
#  13-Jan-2015						 kameshwaran D.						Removed Change Admin form from form name and form type array.
#  22-Jan-2015						 Kameshwaran						Renamed workflow's preference macro name to TD_T4O_ITEM_PUSH_WF_PREF.
#  28-Jan-2015						 Viajyasekhar						Added code changes for td4description to convert it to uppper case.
#  30-Jan-2015						 Haripriya                          Added condition to call postaction while creating CommercialPartRevision.
#  04-Feb-2015						 Selvi                              Modified the postaction operation to ITEM_create_rev
#  19-Feb-2015						 Haripriya                          Moved the Workflow creation to Iman_Save Postaction
#  18-Jun-2015						 Haripriya                          Removed the Commented Codes.
#  $HISTORY$                    
#  =================================================================================================*/  

#include <extensions/teradyne_extensions.h>


/*******************************************************************************
* Function Name	    : TD4_postaction_on_create_CommPartRevision
* Description		: Postaction to create forms  
*
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM	    	: Gets the revision tag and create forms DisciplineSpecific 
*                      Relation while creating 
*                     CommPartRevision
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_create_CommPartRevision(METHOD_message_t*  msg, va_list args)
{
	//Declartion and Initialization of Local Variables
	int iStatus					= ITK_ok;

	const char* __function__ = "TD4_postaction_on_create_CommPartRevision";
	TERADYNE_TRACE_ENTER();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
