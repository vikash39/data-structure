/*==================================================================================================                    
#                Copyright (c) 2015 Teradyne                    
#                Unpublished - All Rights Reserved                    
#  =================================================================================================                    
#      Filename        :           TD4_postaction_on_create_ReleaseECNRevision.cpp          
#      Module          :           libTD4teradyne.dll          
#      Description     :           This file contains function for post action on Create in Release ECN revision
#      Project         :           libTD4teradyne          
#      Author          :           Kameshwaran D          
#  ================================================================================================= 
#  =================================================================================================                    
#  Date                            Name                           Description of Change
#  5-Mar-2015                      Kameshwaran D                     Initial Creation 
#  $HISTORY$                    
#  =================================================================================================*/


#include <extensions/teradyne_extensions.h>

/*******************************************************************************
* Function Name	    : TD4_postaction_on_create_ReleaseECNRevision
* Description		:       
* REQUIRED HEADERS	: 
* INPUT PARAMS		: msg (I) - Message structure
*                     args (I) - variable number of arguments
*                    
* RETURN VALUE		: int iStatus - Error Code or Success Code
* GLOBALS USED		:
* FUNCTIONS CALLED	:
*
* ALGORITHM		    :1.  				 
*
*
* NOTES			    :
*------------------------------------------------------------------------------*/
extern "C"
int TD4_postaction_on_create_ReleaseECNRevision(METHOD_message_t *msg , va_list args)
{
	int   iStatus = ITK_ok;
	const char* __function__		= "TD4_postaction_on_create_ReleaseECNRevision";

	TERADYNE_TRACE_ENTER();

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
