/*==================================================================================================
#                Copyright (c) 2014 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           TD4_precondition_on_create_Form.cpp
#      Module          :           libTD4teradyne.dll
#      Description     :           This file contains function for postaction on createPost in a Form
#      Project         :           libTD4teradyne
#      Author          :           Vivek
#  =================================================================================================
#  Date                              Name                               Description of Change
#  07-Nov.-2014                      Vivek                              Initial Creation
#  10-Nov.-2014                      Vivek                              Added condition to check only on creation of ProjectForm
#  28-Jan.-2015                      Haripriya                          Removed TCTYPE_save_operation_context_t condition check and checking using logical value
#  18-Feb-2015                       Vijayasekhar                       Added condition to check creation of Commodity level 1 Form
#																		changed the from precondition on IMAN_save to postaction on createPost
#  03-Aug-2016						Kameshwaran							Modified POM query to get Form tag not the Form_storage_class tag.
#  $HISTORY$
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

/*******************************************************************************
 * Function Name    : TD4_postaction_on_save_Form
 * Description      : This precondition will check whether Form with same
 *                    object_name already exists and throw error if yes.
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : METHOD_message_t*  msg, va_list args
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
extern "C"
int TD4_preaction_on_save_Form(METHOD_message_t*  msg, va_list args)
{
	const char* __function__ = "TD4_preaction_on_save_Form";
	TERADYNE_TRACE_ENTER();

	int iStatus = ITK_ok;
	tag_t tObject = NULLTAG;
	char *pcObjectName = NULL;
	bool bisExists = false;
	tag_t tActSeqObjTag = NULLTAG;

	try
	{
		//Get the input arguments
		tag_t tObject =va_arg(args, tag_t);
		bool bisNew = va_arg(args, logical);
		//tag_t tObject = va_arg(args, tag_t);

		TCTYPE_save_operation_context_t saveOperationContext;
		TERADYNE_TRACE_CALL(iStatus = TCTYPE_ask_save_operation_context(&saveOperationContext), TD_LOG_ERROR_AND_THROW);

		if (TCTYPE_save_on_create == saveOperationContext) {
			if (tObject != NULLTAG)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tObject, TD_OBJECT_NAME_ATTR, &pcObjectName), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = teradyne_check_form_with_name_already_exists(tObject, pcObjectName, bisExists, &tActSeqObjTag), TD_LOG_ERROR_AND_THROW);
				
				if (bisExists)
				{
					TERADYNE_TRACE_CALL(iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_PROJECT_FORM_WITH_NAME_EXISTS_ERROR, pcObjectName), TD_LOG_ERROR_AND_THROW);
					iStatus = TERADYNE_PROJECT_FORM_WITH_NAME_EXISTS_ERROR;
				}
			}
		}



	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	Custom_free(pcObjectName);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

/*******************************************************************************
 * Function Name    : teradyne_check_form_with_name_already_exists
 * Description      : This function will search for the form based on object_name
 *                    and returs true or false using POM_API
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : tObject    (I) - Target Object tag
 *					  pcFormName (I) - Form name
 *                    bisExists  (O) - true or false
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
int teradyne_check_form_with_name_already_exists(tag_t tObject, char *pcFormName, bool &bisExists, tag_t *tActSeqObjTag)
{
	int iStatus = ITK_ok;
	char* pcEnquiryID = "validate_form_with_name_exists";
	const char* cpSelectAttrs[] = { "puid" };
	char *pcFormType = NULL,
		*pcClassName = NULL;
	const int iActiveSeq = 0;
	int iTotalRows = 0;
	int iTotalCols = 0;
	void*** pvQueryResults = NULL;

	const char* __function__ = "teradyne_check_form_with_name_already_exists";
	TERADYNE_TRACE_ENTER();

	try
	{
		TERADYNE_TRACE_CALL(iStatus = teradyne_ask_object_type(tObject, &pcFormType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = teradyne_get_class_name(tObject, &pcClassName), TD_LOG_ERROR_AND_THROW); //will get the storage class name of the form

		if (pcFormName != NULL && pcFormType != NULL )
		{

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_create(pcEnquiryID), TD_LOG_ERROR_AND_THROW);

			//TERADYNE_TRACE_CALL( iStatus = POM_enquiry_add_select_attrs ( pcEnquiryID, pcClassName, 1, cpSelectAttrs ),TD_LOG_ERROR_AND_THROW );

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_add_select_attrs(pcEnquiryID, "Form", 1, cpSelectAttrs), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_string_value(pcEnquiryID, "formName", 1, (const char**)&pcFormName, POM_enquiry_bind_value), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_string_value(pcEnquiryID, "formType", 1, (const char**)&pcFormType, POM_enquiry_bind_value), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_int_value(pcEnquiryID, "active_seq_val", 1, &iActiveSeq, POM_enquiry_const_value), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_join_expr(pcEnquiryID, "join_expr", TD_WORKSPACEOBJECT_TYPE, TD_PUID_CONSTANT,
				POM_enquiry_equal, TD_FORM_CLASS, TD_PUID_CONSTANT), TD_LOG_ERROR_AND_THROW);

			//TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_join_expr(pcEnquiryID,"join_expr1",TD_FORM_CLASS,TD_DATAFILE_PROP,
				//POM_enquiry_equal,pcClassName,TD_PUID_CONSTANT),TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_attr_expr(pcEnquiryID, "expr1", TD_WORKSPACEOBJECT_TYPE, TD_OBJECT_NAME_ATTR,
				POM_enquiry_equal, "formName"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_attr_expr(pcEnquiryID, "expr2", TD_WORKSPACEOBJECT_TYPE, TD_OBJECT_TYPE_ATTR,
				POM_enquiry_equal, "formType"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_attr_expr(pcEnquiryID, "expr3", TD_WORKSPACEOBJECT_TYPE, TD_ACTIVE_SEQUENCE_ATTR,
				POM_enquiry_not_equal, "active_seq_val"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_expr(pcEnquiryID, "expr4", "expr1", POM_enquiry_and, "expr2"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_expr(pcEnquiryID, "expr5", "expr4", POM_enquiry_and, "expr3"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_expr(pcEnquiryID, "expr6", "expr5", POM_enquiry_and, "join_expr"), TD_LOG_ERROR_AND_THROW);

			//TERADYNE_TRACE_CALL ( iStatus = POM_enquiry_set_expr( pcEnquiryID,"expr7", "expr6",POM_enquiry_and,"join_expr1"),TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_set_where_expr(pcEnquiryID, "expr6"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_execute(pcEnquiryID, &iTotalRows, &iTotalCols, &pvQueryResults), TD_LOG_ERROR_AND_THROW);

			if (iTotalRows != 0)
			{
				bisExists = true;
			}

			if (bisExists)
			{
				tag_t *tResultList = NULL;

				tResultList = (tag_t *)MEM_alloc(iTotalRows * sizeof(tag_t));
				for (int iresult = 0; iresult < iTotalRows; iresult++)
				{
					tResultList[iresult] = *((tag_t *)pvQueryResults[iresult][0]);
					*tActSeqObjTag = tResultList[iresult];
				}

			}

			TERADYNE_TRACE_CALL(iStatus = POM_enquiry_delete(pcEnquiryID), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
		TERADYNE_TRACE_CALL(POM_enquiry_delete(pcEnquiryID), TD_LOG_ERROR);
	}
	Custom_free(pcFormType);
	Custom_free(pcClassName);
	Custom_free(pvQueryResults);

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
/*******************************************************************************
 * Function Name    : teradyne_get_class_name
 * Description      : This function will get the storage class of the given forms
 *
 * REQUIRED HEADERS :
 * INPUT PARAMS     : tObject    (I)  - Target Object tag
 *					  pcClassName(OF) - Storage class name char*
 *
 * RETURN VALUE     : int : 0/error code
 * GLOBALS USED     :
 * FUNCTIONS CALLED :
 *
 * ALGORITHM        :
 *
 *
 * NOTES            :
 ******************************************************************************/
int teradyne_get_class_name(tag_t tObject, char** pcClassName) {

	int iStatus = ITK_ok;
	tag_t tClassId = NULLTAG,
		tInstance = NULLTAG;

	const char * __function__ = "teradyne_get_class_name";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = FORM_ask_pom_instance(tObject, &tInstance), TD_LOG_ERROR_AND_THROW);
		if (tInstance != NULLTAG) {

			TERADYNE_TRACE_CALL(iStatus = POM_class_of_instance(tInstance, &tClassId), TD_LOG_ERROR_AND_THROW);
			if (tClassId != NULLTAG) {

				TERADYNE_TRACE_CALL(iStatus = POM_name_of_class(tClassId, pcClassName), TD_LOG_ERROR_AND_THROW);
			}
		}
	}
	catch (...) {

		if (iStatus == ITK_ok)
		{
			TC_write_syslog("%s: Unhandled Exception", __function__);
			iStatus = TERADYNE_UNKNOWN_ERROR;
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}
