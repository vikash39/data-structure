/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_complete_debug_and_repair.cpp
#      Module          :           libTD7_teradyne_services.dll
#      Project         :           libTD7_teradyne_services
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  17-Jun-2019                       Sundarraj                    	        Initial Code
#  18-Mar-2020						 Sundarraj								Implement Incoing Object validation when move to 'Repair' Checklist.
#  =================================================================================================*/

#include <services/td_bw_complete_debug_and_repair.h>

int validate_checkListName(string uid, string checkListName) {

	int iStatus = ITK_ok;
	tag_t tRepairOrderRev = NULLTAG;
	tag_t tRelation = NULLTAG;

	int iCount = 0;
	int iPreInspectionCount = 0;
	int iPreTestCount = 0;
	int iRepairCount = 0;
	int iRepairVerificationCount = 0;
	int iPostTestCount = 0;

	logical bIsPropertyFilled = false;
	tag_t* tSecondaryObjects = NULLTAG;
	tag_t tCheckListObject = NULLTAG;
	vector<string> vCheckLitInput;
	// check object type
	logical bIsNull = false;
	char* cpCurrentTaskName = NULL;

	const char * __function__ = "validate_checkListName";
	TERADYNE_TRACE_ENTER();

	ITK__convert_uid_to_tag(uid.c_str(), &tRepairOrderRev);
	TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, TD7_CURRENT_TASK_NAME, &cpCurrentTaskName), TD_LOG_ERROR_AND_THROW);

	// To get Repair Order ID.
	BusinessObjectRef<Teamcenter::BusinessObject> boRepairOrderRev(tRepairOrderRev);
	std::string sRepairOrderId("");
	//std::string sCurrentTaskName("");
	TERADYNE_TRACE_CALL(boRepairOrderRev->getString(ITEM_ID, sRepairOrderId, bIsNull), TD_LOG_ERROR_AND_THROW);
	//TERADYNE_TRACE_CALL(boRepairOrderRev->getString(TD7_CURRENT_TASK_NAME, sCurrentTaskName, bIsNull));

	TERADYNE_TRACE_CALL(GRM_find_relation_type("IMAN_specification", &tRelation), TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelation, &iCount, &tSecondaryObjects), TD_LOG_ERROR_AND_THROW);
	try {
		if (iCount > 0) {
			for (int i = 0; i < iCount; i++) {

				TERADYNE_TRACE_ENTER();
				BusinessObjectRef<Teamcenter::BusinessObject> checkListObj(tSecondaryObjects[i]);

				std::string sCheckListObjType("");
				bool islatestRevChecklist = false;
				TERADYNE_TRACE_CALL(checkListObj->getString(OBJECT_TYPE, sCheckListObjType, bIsNull), TD_LOG_ERROR_AND_THROW);

				if (sCheckListObjType.compare(TD7_PRE_INSPECTION_FORM) == 0 || sCheckListObjType.compare(TD7_PRE_TEST_FORM) == 0 || sCheckListObjType.compare(TD7_REPAIR_FORM) == 0 || sCheckListObjType.compare(TD7_REPAIR_VERIFICATION_FORM) == 0 || sCheckListObjType.compare(TD7_POST_TEST_FORM) == 0) {
					TERADYNE_TRACE_CALL(checkListObj->getLogical(TD7_IS_LATEST_VERSION, islatestRevChecklist, bIsNull), TD_LOG_ERROR_AND_THROW);
				}

				// to get each checklist count, to generate checklist revisions, if checklist stage processeing from backward also.
				if (sCheckListObjType.compare(TD7_PRE_INSPECTION_FORM) == 0) {
					iPreInspectionCount++;
				}
				if (sCheckListObjType.compare(TD7_PRE_TEST_FORM) == 0) {
					iPreTestCount++;
				}
				if (sCheckListObjType.compare(TD7_REPAIR_FORM) == 0) {
					iRepairCount++;
				}
				if (sCheckListObjType.compare(TD7_REPAIR_VERIFICATION_FORM) == 0) {
					iRepairVerificationCount++;
				}
				if (sCheckListObjType.compare(TD7_POST_TEST_FORM) == 0) {
					iPostTestCount++;
				}

				// validate all the checklist mandatory proerpties based on the checklist type.
				if (checkListName.compare("Pre Test") == 0 && (sCheckListObjType.compare(TD7_PRE_INSPECTION_FORM) == 0 || sCheckListObjType.compare(TD7_REPAIR_FORM) == 0)) {
					if (tc_strcmp(cpCurrentTaskName, "Debug and Repair FVR") == 0)
					{
						// Validate Incoming Object is exists or not for tis Repair Order.
						tag_t tIncomingConfigRel = NULLTAG;
						int iIncomingObjectsCount = 0;
						tag_t* tIncomingConfigObjects = NULLTAG;
						TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_INCOMING_CONFIG_REL, &tIncomingConfigRel), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tIncomingConfigRel, &iIncomingObjectsCount, &tIncomingConfigObjects), TD_LOG_ERROR_AND_THROW);
						if (iIncomingObjectsCount == 0) {
							//Display the error message if incoming config object is not upload.
							iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_INCOMING_CONFIG_OBJECTS_NOT_UPLOAD, sRepairOrderId.c_str());
							iStatus = TERADYNE_INCOMING_CONFIG_OBJECTS_NOT_UPLOAD;
							throw iStatus;
						}
					}
					
					if (islatestRevChecklist) {
						if (sCheckListObjType.compare(TD7_PRE_INSPECTION_FORM) == 0) {
							std::string cPreInsTestResult("");
							TERADYNE_TRACE_CALL(checkListObj->getString(TD7_PRE_INSPECTION_TEST_RESULT, cPreInsTestResult, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(cPreInsTestResult.c_str(), "") != 0) {
								std::string preInsFailureComments("");
								TERADYNE_TRACE_CALL(checkListObj->getString(TD7_PRE_INSPECTION_FAILURE_COMMENTS, preInsFailureComments, bIsNull), TD_LOG_ERROR_AND_THROW);
								if (tc_strcmp(preInsFailureComments.c_str(), "") != 0) {
									std::string cTampered("");
									TERADYNE_TRACE_CALL(checkListObj->getString(TD7_TAMPERED, cTampered, bIsNull), TD_LOG_ERROR_AND_THROW);
									if (tc_strcmp(cTampered.c_str(), "") != 0) {
										bIsPropertyFilled = true;
									}
								}
							}

						}
					}

					vCheckLitInput.push_back(checkListName);
					vCheckLitInput.push_back(TD7_PRE_INSPECTION_FORM);
				}
				if (checkListName.compare("Repair") == 0 && (sCheckListObjType.compare(TD7_PRE_TEST_FORM) == 0 || sCheckListObjType.compare(TD7_REPAIR_VERIFICATION_FORM) == 0)) {

					// Validate Incoming Object is exists or not for tis Repair Order.
					tag_t tIncomingConfigRel = NULLTAG;
					int iIncomingObjectsCount = 0;
					tag_t* tIncomingConfigObjects = NULLTAG;
					TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_INCOMING_CONFIG_REL, &tIncomingConfigRel), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tIncomingConfigRel, &iIncomingObjectsCount, &tIncomingConfigObjects), TD_LOG_ERROR_AND_THROW);
					if (iIncomingObjectsCount == 0) {
						//Display the error message if incoming config object is not upload.
						iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_INCOMING_CONFIG_OBJECTS_NOT_UPLOAD, sRepairOrderId.c_str());
						iStatus = TERADYNE_INCOMING_CONFIG_OBJECTS_NOT_UPLOAD;
						throw iStatus;
					}

					if (sCheckListObjType.compare(TD7_PRE_TEST_FORM) == 0) {
						if (islatestRevChecklist) {
							std::string cPreTestResult("");
							TERADYNE_TRACE_CALL(checkListObj->getString(TD7_PRE_TEST_TEST_RESULT, cPreTestResult, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(cPreTestResult.c_str(), "") != 0) {
								std::string cPreTestFinding("");
								TERADYNE_TRACE_CALL(checkListObj->getString(TD7_PRE_TEST_FINDING, cPreTestFinding, bIsNull), TD_LOG_ERROR_AND_THROW);
								if (tc_strcmp(cPreTestFinding.c_str(), "") != 0) {
									bIsPropertyFilled = true;
								}
							}
						}
					}

					vCheckLitInput.push_back(checkListName);
					//vCheckLitInput.push_back(cPreTestResult);
					vCheckLitInput.push_back(TD7_PRE_TEST_FORM);
				}
				if (checkListName.compare("Repair Verification") == 0 && (sCheckListObjType.compare(TD7_REPAIR_FORM) == 0 || sCheckListObjType.compare(TD7_POST_TEST_FORM) == 0)) {
					if (sCheckListObjType.compare(TD7_REPAIR_FORM) == 0) {
						if (islatestRevChecklist) {
							std::string cRepairResult("");
							TERADYNE_TRACE_CALL(checkListObj->getString(TD7_REPAIR_RESULT, cRepairResult, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(cRepairResult.c_str(), "") != 0) {
								std::string cRepairDetails("");
								TERADYNE_TRACE_CALL(checkListObj->getString(TD7_REPAIR_DETAILS, cRepairDetails, bIsNull), TD_LOG_ERROR_AND_THROW);
								if (tc_strcmp(cRepairDetails.c_str(), "") != 0) {
									bIsPropertyFilled = true;
								}
							}
						}
					}

					vCheckLitInput.push_back(checkListName);
					//vCheckLitInput.push_back(cRepairResult);
					vCheckLitInput.push_back(TD7_REPAIR_FORM);
				}
			
				
				if (checkListName.compare("Post Test") == 0) {
					if (tc_strcmp(cpCurrentTaskName, "Debug and Repair FVR") == 0)
					{
						if (checkListName.compare("Post Test") == 0 && ((sCheckListObjType.compare(TD7_PRE_TEST_FORM) == 0))) {
							if (islatestRevChecklist) {
								std::string cPreTestResult("");
								TERADYNE_TRACE_CALL(checkListObj->getString(TD7_PRE_TEST_TEST_RESULT, cPreTestResult, bIsNull), TD_LOG_ERROR_AND_THROW);
								if (tc_strcmp(cPreTestResult.c_str(), "") != 0) {
									std::string cPreTestFinding("");
									TERADYNE_TRACE_CALL(checkListObj->getString(TD7_PRE_TEST_FINDING, cPreTestFinding, bIsNull), TD_LOG_ERROR_AND_THROW);
									if (tc_strcmp(cPreTestFinding.c_str(), "") != 0) {
										bIsPropertyFilled = true;
									}
								}
							}
							vCheckLitInput.push_back(checkListName);
							//vCheckLitInput.push_back(cRepairVerificationResult);
							vCheckLitInput.push_back(TD7_PRE_TEST_FORM);
						}
					}
					else {
						if (checkListName.compare("Post Test") == 0 && ((sCheckListObjType.compare(TD7_REPAIR_VERIFICATION_FORM) == 0))) {
							if (islatestRevChecklist) {
								std::string cRepairVerificationStatus("");
								TERADYNE_TRACE_CALL(checkListObj->getString(TD7_REPAIR_VERIFICATION_STATUS, cRepairVerificationStatus, bIsNull), TD_LOG_ERROR_AND_THROW);
								if (tc_strcmp(cRepairVerificationStatus.c_str(), "") != 0) {
									std::string cRepairVerificationResult("");
									TERADYNE_TRACE_CALL(checkListObj->getString(TD7_REPAIR_VERIFICATION_RESULTS, cRepairVerificationResult, bIsNull), TD_LOG_ERROR_AND_THROW);
									if (tc_strcmp(cRepairVerificationResult.c_str(), "") != 0) {

										bIsPropertyFilled = true;
									}
								}
							}
							vCheckLitInput.push_back(checkListName);
							//vCheckLitInput.push_back(cRepairVerificationResult);
							vCheckLitInput.push_back(TD7_REPAIR_VERIFICATION_FORM);
						}
					}

				}
			}
		}
		// call the function
		TERADYNE_TRACE_CALL(validate_checklist_properties(tRepairOrderRev, vCheckLitInput, bIsPropertyFilled), TD_LOG_ERROR_AND_THROW);

		// generete checklists forms
		TERADYNE_TRACE_CALL(generate_checklists_revisions_complete_debug_and_repair(tRepairOrderRev, iPreInspectionCount, iPreTestCount,
			iRepairCount, iRepairVerificationCount, iPostTestCount), TD_LOG_ERROR_AND_THROW);
	}
	catch (exception) {
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_checklist_properties(tag_t tRepairOrderRev, vector<string> vCheckListInput, logical bIsPropertyFilled) {

	int iStatus = ITK_ok;
	logical bIsNull = false;

	const char * __function__ = "validate_checklist_properties";
	TERADYNE_TRACE_ENTER();

	if (bIsPropertyFilled) {

		BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);

		AcquireLock lockOnLLApartNum(tRepairOrderRev);
		TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_BAT_CHECKLIST, vCheckListInput[0], false)), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
	}
	else {
		//Display the error message if Test Result is not update.
		iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_CHECKLIST_ERROR, vCheckListInput[1].c_str());
		iStatus = TERADYNE_CHECKLIST_ERROR;
		throw iStatus;
	}
	return iStatus;
}

int generate_checklists_revisions_complete_debug_and_repair(tag_t tRepairOrderRev, int iPreInspectionCount, int iPreTestCount,
	int iRepairCount, int iRepairVerificationCount, int iPostTestCount) {

	int iStatus = 0;
	logical bIsNull = false;
	tag_t tFormTypeTag = NULLTAG;
	tag_t tCreateInputTag = NULLTAG;
	tag_t tForm = NULLTAG;

	string formName = "";
	bool isNeedToGenerate = false;

	const char * __function__ = "generate_checklists_revisions_complete_debug_and_repair";
	TERADYNE_TRACE_ENTER();
	try {
		string checkListStatus;
		BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderRevBORef(tRepairOrderRev);
		TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_BAT_CHECKLIST, checkListStatus, bIsNull), TD_LOG_ERROR_AND_THROW);
		if (tc_strcmp(checkListStatus.c_str(), "Pre Inspection") == 0) {
			TERADYNE_TRACE_CALL(is_need_to_generate_checklist_version(tRepairOrderRev, IMAN_SPECIFICATION, TD7_PRE_INSPECTION_FORM, TD7_PRE_INSPECTION_TEST_RESULT, isNeedToGenerate), TD_LOG_ERROR_AND_THROW);
			if (isNeedToGenerate) {
				iPreInspectionCount++;
				formName = formName.append("Pre Inspection");
				formName = formName.append("_");
				formName = formName.append("v");
				formName = formName.append(to_string(iPreInspectionCount));
				TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_PRE_INSPECTION_FORM, "Pre Inspection", formName), TD_LOG_ERROR_AND_THROW);
			}
		}
		if (tc_strcmp(checkListStatus.c_str(), "Pre Test") == 0) {
			TERADYNE_TRACE_CALL(is_need_to_generate_checklist_version(tRepairOrderRev, IMAN_SPECIFICATION, TD7_PRE_TEST_FORM, TD7_PRE_TEST_TEST_RESULT, isNeedToGenerate), TD_LOG_ERROR_AND_THROW);
			if (isNeedToGenerate) {
				iPreTestCount++;
				formName = formName.append("Pre Test");
				formName = formName.append("_");
				formName = formName.append("v");
				formName = formName.append(to_string(iPreTestCount));
				TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_PRE_TEST_FORM, "Pre Test", formName), TD_LOG_ERROR_AND_THROW);
			}
		}
		if (tc_strcmp(checkListStatus.c_str(), "Repair") == 0) {
			TERADYNE_TRACE_CALL(is_need_to_generate_checklist_version(tRepairOrderRev, IMAN_SPECIFICATION, TD7_REPAIR_FORM, TD7_REPAIR_RESULT, isNeedToGenerate), TD_LOG_ERROR_AND_THROW);
			if (isNeedToGenerate) {
				iRepairCount++;
				formName = formName.append("Repair");
				formName = formName.append("_");
				formName = formName.append("v");
				formName = formName.append(to_string(iRepairCount));
				TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_REPAIR_FORM, "Repair", formName), TD_LOG_ERROR_AND_THROW);
			}
		}
		if (tc_strcmp(checkListStatus.c_str(), "Repair Verification") == 0) {
			TERADYNE_TRACE_CALL(is_need_to_generate_checklist_version(tRepairOrderRev, IMAN_SPECIFICATION, TD7_REPAIR_VERIFICATION_FORM, TD7_REPAIR_VERIFICATION_STATUS, isNeedToGenerate), TD_LOG_ERROR_AND_THROW);
			if (isNeedToGenerate) {
				iRepairVerificationCount++;
				formName = formName.append("Repair Verification");
				formName = formName.append("_");
				formName = formName.append("v");
				formName = formName.append(to_string(iRepairVerificationCount));
				TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_REPAIR_VERIFICATION_FORM, "Repair Verification", formName), TD_LOG_ERROR_AND_THROW);
			}
		}
		if (tc_strcmp(checkListStatus.c_str(), "Post Test") == 0) {
			TERADYNE_TRACE_CALL(is_need_to_generate_checklist_version(tRepairOrderRev, IMAN_SPECIFICATION, TD7_POST_TEST_FORM, TD7_POST_TEST_RESULT, isNeedToGenerate), TD_LOG_ERROR_AND_THROW);
			if (isNeedToGenerate) {
				iPostTestCount++;
				formName = formName.append("Post Test");
				formName = formName.append("_");
				formName = formName.append("v");
				formName = formName.append(to_string(iPostTestCount));
				TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_POST_TEST_FORM, "Post Test", formName), TD_LOG_ERROR_AND_THROW);
			}
		}
	}
	catch (exception exp) {}
	TERADYNE_TRACE_LEAVE();
	return iStatus;

}

int is_need_to_generate_checklist_version(tag_t tPrimaryObj, string sRelation, string sFormType, string sRequiredValue, bool &isNeedToGenerate) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "is_need_to_generate_checklist_version";
	TERADYNE_TRACE_ENTER();
	try {
		if (sRelation.empty() || tPrimaryObj == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(sRelation.c_str(), &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tPrimaryObj, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(sObjectType.c_str(), sFormType.c_str()) == 0) {
				bool isLatest = false;
				TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
				if (isLatest) {
					std::string cResultProperty("");
					TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(sRequiredValue, cResultProperty, bIsNull), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(cResultProperty.c_str(), "") != 0) {
						isNeedToGenerate = true;
					}
				}
			}
		}
	}
	catch (...)
	{

	}
	TERADYNE_MEM_FREE(tpSecondaryObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}


int teradyne_attach_checklist_with_repair_order(tag_t tPrimObj, tag_t tSecObj, string sAttachRel) {
	int iStatus = 0;
	tag_t tNewRel = NULLTAG;
	tag_t tRelation = NULLTAG;

	const char * __function__ = "teradyne_attach_checklist_with_repair_order";
	TERADYNE_TRACE_ENTER();
	try {
		TERADYNE_TRACE_CALL(GRM_find_relation_type(sAttachRel.c_str(), &tRelation), TD_LOG_ERROR_AND_THROW);
		if (tRelation != NULLTAG) {
			TERADYNE_TRACE_CALL(GRM_create_relation(tPrimObj, tSecObj, tRelation, NULLTAG, &tNewRel), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(GRM_save_relation(tNewRel), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}


int complete_review_task(string uid, string decision, string comments, string task) {

	int iStatus = ITK_ok;
	tag_t * tRunningWorkflows = NULLTAG;
	int iNumOfWorkflows = 0;
	tag_t tRepairOrderRev = NULLTAG;
	bool isValidTask = false;
	bool bIsNull = false;

	ITK__convert_uid_to_tag(uid.c_str(), &tRepairOrderRev);

	TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_tags(tRepairOrderRev, "fnd0AllWorkflows", &iNumOfWorkflows, &tRunningWorkflows), TD_LOG_ERROR_AND_THROW);

	// get current task
	tag_t tSubTask = NULLTAG;

	TERADYNE_TRACE_CALL(EPM_ask_sub_task(tRunningWorkflows[0], task.c_str(), &tSubTask), TD_LOG_ERROR_AND_THROW);
	// get process_name
	BusinessObjectRef< Teamcenter::BusinessObject > boWorkflowProcessRev(tSubTask);
	AcquireLock lockOnWorkflow(tSubTask);
	std::string sProcessName("");
	boWorkflowProcessRev->getString("job_name", sProcessName, bIsNull);

	BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);
	AcquireLock lockOnLLApartNum(tRepairOrderRev);
	std::string sItemId("");
	boRepairOrderRev->getString(ITEM_ID, sItemId, bIsNull);

	// Set custom decision based on the current task.
	if (tc_strcmp(decision.c_str(), "") != 0 && tc_strcmp(decision.c_str(), NULL) != 0) {

		if (tc_strcmp(task.c_str(), "Repair Routing") == 0) {
			isValidTask = true;
			TERADYNE_TRACE_CALL(update_sender_value_from_routing_task(tRepairOrderRev, comments), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(complete_repair_routing(tRepairOrderRev, isValidTask, iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
		}
		if ((tc_strcmp(task.c_str(), "Vendor Repair Order") == 0)) {

			// to validate repair components exists, before completeing full vendor repair
			/** requirement changes, TERADYNE dont wat validate the repair components.
			//bool bValidReparOrder = false;
			//TERADYNE_TRACE_CALL(validate_repair_components_exist(tRepairOrderRev, bValidReparOrder));
			//isValidTask = bValidReparOrder;
			*/

			isValidTask = true;

			char* cpOrderCat = NULL;
			char* cpRepairLocation = NULL;
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, TD7_BAT_ORDER_CATEGORY, &cpOrderCat), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, TD7_BAT_REPAIR_LOCATION, &cpRepairLocation), TD_LOG_ERROR_AND_THROW);

			//Create all checklists.

			if ((tc_strcmp(cpOrderCat, "Full Vendor Repair") == 0) && (tc_strcmp(cpRepairLocation, "Costa Rica") == 0)) {
				task = "Debug and Repair FVR";
				bool bValidReparOrder = false;
				bool bMainRootCauseUpdate = false;
				bool bValidErrorMessage = false;
				bool bIsRepairChecklistUpdated = false;
				if (tc_strcmp(decision.c_str(), "Complete") == 0) {
					TERADYNE_TRACE_CALL(validate_debug_and_repair_checklists(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
					isValidTask = bValidReparOrder;
					if (bValidReparOrder) {
						TERADYNE_TRACE_CALL(validate_main_root_ause_value(tRepairOrderRev, bMainRootCauseUpdate), TD_LOG_ERROR_AND_THROW);
						bValidErrorMessage = true;
						isValidTask = bMainRootCauseUpdate;
					}
				}
				TERADYNE_TRACE_CALL(complete_debug_and_repair(tRepairOrderRev, isValidTask, bValidErrorMessage, bIsRepairChecklistUpdated, iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
			}
			else {
				TERADYNE_TRACE_CALL(complete_vendor_repair_order(tRepairOrderRev, isValidTask, iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
			}

			

			// Update HLA SerialNumber Status property for Part Serial Number.
			tag_t trealtionType = NULLTAG;
			int iSnCount = 0;
			tag_t* tHLASerialNumbers = NULLTAG;

			TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_REPAIR_SERIAL_NO_REL, &trealtionType), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, trealtionType, &iSnCount, &tHLASerialNumbers), TD_LOG_ERROR_AND_THROW);

			for (int i = 0; i < iSnCount; i++) {

				bool bisverdict = false;
				//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_FINAL_INS_STAUTS, decision, false)));
				TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tHLASerialNumbers[i], &bisverdict), TD_LOG_ERROR_AND_THROW);
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tHLASerialNumbers[i], true), TD_LOG_ERROR_AND_THROW);
				}
				TERADYNE_TRACE_CALL(AOM_set_value_string(tHLASerialNumbers[i], TD7_SERIAL_NUMBER_STATUS, "Repaired"), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_save_without_extensions(tHLASerialNumbers[i]), TD_LOG_ERROR_AND_THROW);
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tHLASerialNumbers[i], false), TD_LOG_ERROR_AND_THROW);
				}


				/**BusinessObjectRef< Teamcenter::BusinessObject > boSerialNumRev(tHLASerialNumbers[i]);
				AcquireLock lockOnLLApartNum(boSerialNumRev);

				TERADYNE_TRACE_CALL((boSerialNumRev->setString(TD7_SERIAL_NUMBER_STATUS, "Retired", false)));
				TERADYNE_TRACE_CALL(AOM_save(tHLASerialNumbers[i]));*/

			}

		}
		if (tc_strcmp(task.c_str(), "Normal Repair Routing") == 0) {
			isValidTask = true;
			//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_NORMAL_REPAIR_ORDER_STATUS, decision, false)));
			TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_NORMAL_REPAIR_ORDER_STATUS, decision.c_str()), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);

			if (tc_strcmp(decision.c_str(), "Move to Engg Evaluation") == 0) {
				TERADYNE_TRACE_CALL(update_sender_value_from_routing_task(tRepairOrderRev, comments), TD_LOG_ERROR_AND_THROW);
			}
			TERADYNE_TRACE_CALL(complete_normal_repair_routing(tRepairOrderRev, isValidTask, iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
		}
		if (tc_strcmp(task.c_str(), "Engg Evaluation") == 0) {
			isValidTask = true;

			// validate scrap reason, if user try to move RO into Scrap
			if (tc_strcmp(decision.c_str(), "Scrapped") == 0) {
				bool bValidReparOrder = false;
				TERADYNE_TRACE_CALL(validate_engg_evaluation_checklists(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
				/**BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderRevBORef(tRepairOrderRev);
				std::string sScrapReason("");
				TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_SCRSP_REASON, sScrapReason, bIsNull));
				if (tc_strcmp(sScrapReason.c_str(), "") == 0) {
					isValidTask = false;
				}*/
				if (bValidReparOrder) {
					bool isHLAOutRevStamp = false;
					TERADYNE_TRACE_CALL(release_all_serial_number_objects(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(is_same_hla_sn_and_hla_pn_complete_wf(tRepairOrderRev, isHLAOutRevStamp), TD_LOG_ERROR_AND_THROW);
				}
			}

			// genereate email task send to 'Request to On Hold' from Engg Evaluation
			if (tc_strcmp(decision.c_str(), "Request to On Hold") == 0) {
				std::string mailSubject = "";
				mailSubject = mailSubject.append("Request To Place Repair Order On Hold:");
				mailSubject = mailSubject.append(sProcessName);
				mailSubject = mailSubject.append(":");
				mailSubject = mailSubject.append(task);

				vector<tag_t> vValidReceipants;
				tag_t tRole = NULLTAG;
				char* cpRoleName = NULL;
				int iDebugAndRepairAssignee = 0;
				tag_t* tpDebugAndRepairAssignee = NULLTAG;
				TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_DEBUG_AND_REPAIR_ASSIGNEES, &iDebugAndRepairAssignee, &tpDebugAndRepairAssignee), TD_LOG_ERROR_AND_THROW);
				for (int i = 0; i < iDebugAndRepairAssignee; i++) {
					TERADYNE_TRACE_CALL(SA_ask_groupmember_role(tpDebugAndRepairAssignee[i], &tRole), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(SA_ask_role_name2(tRole, &cpRoleName), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(cpRoleName, "Repair Supervisor") == 0) {
						vValidReceipants.push_back(tpDebugAndRepairAssignee[i]);
					}
				}

				TERADYNE_TRACE_CALL(generate_email_to_specified_users(tRepairOrderRev, mailSubject, tSubTask, vValidReceipants), TD_LOG_ERROR_AND_THROW);
			}

			// genereate email task send to 'Debug and Repair' from Engg Evaluation
			if (tc_strcmp(decision.c_str(), "Complete") == 0) {

				bool bValidReparOrder = false;
				TERADYNE_TRACE_CALL(validate_engg_evaluation_checklists_complete_stage(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;

				if (isValidTask) {
					std::string mailSubject = "";
					mailSubject = mailSubject.append("Engg Evaluation Completed:");
					mailSubject = mailSubject.append(sProcessName);
					mailSubject = mailSubject.append(":");
					mailSubject = mailSubject.append(task);

					vector<tag_t> vValidReceipants;

					// get the previous task, which is comes from 
					std::string sTaskStatus("");
					boRepairOrderRev->getString(TD7_ENGG_EVALUATION_TASK_STATUS, sTaskStatus, bIsNull);

					// if return back to 'Debug and Repair
					if (tc_strcmp(sTaskStatus.c_str(), "Debug and Repair") == 0) {
						int iDebugAndRepairAssignee = 0;
						tag_t* tpDebugAndRepairAssignee = NULLTAG;
						TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_DEBUG_AND_REPAIR_ASSIGNEES, &iDebugAndRepairAssignee, &tpDebugAndRepairAssignee), TD_LOG_ERROR_AND_THROW);
						for (int i = 0; i < iDebugAndRepairAssignee; i++) {
							vValidReceipants.push_back(tpDebugAndRepairAssignee[i]);
						}
					}

					// if return back to Reowrk
					if (tc_strcmp(sTaskStatus.c_str(), "Rework") == 0) {
						int iReworkAssignee = 0;
						tag_t* tpReworkAssignee = NULLTAG;
						TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_REWORK_ASSIGNEES, &iReworkAssignee, &tpReworkAssignee), TD_LOG_ERROR_AND_THROW);
						for (int i = 0; i < iReworkAssignee; i++) {
							vValidReceipants.push_back(tpReworkAssignee[i]);
						}
					}

					// if return back to Final Inspection
					if (tc_strcmp(sTaskStatus.c_str(), "Final Inspection") == 0) {
						int iFinalInsAssignee = 0;
						tag_t* tpFinalInsAssignee = NULLTAG;
						TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_FINAL_INSPECTION_ASSIGNEES, &iFinalInsAssignee, &tpFinalInsAssignee), TD_LOG_ERROR_AND_THROW);
						if (iFinalInsAssignee > 0) {
							for (int i = 0; i < iFinalInsAssignee; i++) {
								vValidReceipants.push_back(tpFinalInsAssignee[i]);
							}
						}
						else {
							int iDebugAndRepairAssignee = 0;
							tag_t* tpDebugAndRepairAssignee = NULLTAG;
							TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_DEBUG_AND_REPAIR_ASSIGNEES, &iDebugAndRepairAssignee, &tpDebugAndRepairAssignee), TD_LOG_ERROR_AND_THROW);
							for (int i = 0; i < iDebugAndRepairAssignee; i++) {
								vValidReceipants.push_back(tpDebugAndRepairAssignee[i]);
							}
						}
					}

					// if Engg Evaluation comes from Repair Routing
					if (vValidReceipants.size() == 0) {
						int iDebugAndRepairAssignee = 0;
						tag_t* tpDebugAndRepairAssignee = NULLTAG;
						TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_DEBUG_AND_REPAIR_ASSIGNEES, &iDebugAndRepairAssignee, &tpDebugAndRepairAssignee), TD_LOG_ERROR_AND_THROW);
						for (int i = 0; i < iDebugAndRepairAssignee; i++) {
							vValidReceipants.push_back(tpDebugAndRepairAssignee[i]);
						}
					}

					TERADYNE_TRACE_CALL(generate_email_to_specified_users(tRepairOrderRev, mailSubject, tSubTask, vValidReceipants), TD_LOG_ERROR_AND_THROW);
				}
			}

			//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_ENGG_EVALUATION_STATUS, decision, false)));
			TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_ENGG_EVALUATION_STATUS, decision.c_str()), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(complete_engg_evaluation(tRepairOrderRev, isValidTask, iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
		}
		if (tc_strcmp(task.c_str(), "Debug and Repair") == 0) {
			isValidTask = true;
			//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_DEBUG_AND_REAPIR_TASK_STATUS, decision, false)));
			TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_DEBUG_AND_REAPIR_TASK_STATUS, decision.c_str()), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
			bool bValidReparOrder = false;
			bool bMainRootCauseUpdate = false;
			bool bValidErrorMessage = false;
			bool bIsRepairChecklistUpdated = false;
			if (tc_strcmp(decision.c_str(), "Complete") == 0) {
				TERADYNE_TRACE_CALL(validate_debug_and_repair_checklists(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
				if (bValidReparOrder) {
					TERADYNE_TRACE_CALL(validate_main_root_ause_value(tRepairOrderRev, bMainRootCauseUpdate), TD_LOG_ERROR_AND_THROW);
					bValidErrorMessage = true;
					isValidTask = bMainRootCauseUpdate;
				}
			}
			// genereate email task send to 'Request to On Hold' from Debug and Repair
			if (tc_strcmp(decision.c_str(), "Request to On Hold") == 0) {
				std::string mailSubject = "";
				mailSubject = mailSubject.append("Request To Place Repair Order On Hold:");
				mailSubject = mailSubject.append(sProcessName);
				mailSubject = mailSubject.append(":");
				mailSubject = mailSubject.append(task);

				vector<tag_t> vValidReceipants;
				tag_t tRole = NULLTAG;
				char* cpRoleName = NULL;
				int iDebugAndRepairAssignee = 0;
				tag_t* tpDebugAndRepairAssignee = NULLTAG;
				TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_DEBUG_AND_REPAIR_ASSIGNEES, &iDebugAndRepairAssignee, &tpDebugAndRepairAssignee), TD_LOG_ERROR_AND_THROW);
				for (int i = 0; i < iDebugAndRepairAssignee; i++) {
					TERADYNE_TRACE_CALL(SA_ask_groupmember_role(tpDebugAndRepairAssignee[i], &tRole), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(SA_ask_role_name2(tRole, &cpRoleName), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(cpRoleName, "Repair Supervisor") == 0) {
						vValidReceipants.push_back(tpDebugAndRepairAssignee[i]);
					}
				}

				TERADYNE_TRACE_CALL(generate_email_to_specified_users(tRepairOrderRev, mailSubject, tSubTask, vValidReceipants), TD_LOG_ERROR_AND_THROW);
			}

			// if moves to engg evaluation, will send an email to 'Test Engineer'
			if (tc_strcmp(decision.c_str(), "Move to Rework") == 0) {
				TERADYNE_TRACE_CALL(validate_repair_checklists(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
				if (!bValidReparOrder) {
					bIsRepairChecklistUpdated = true;
				}
			}

			// if moves to engg evaluation, will send an email to 'Test Engineer'
			if (tc_strcmp(decision.c_str(), "Move to Engg Evaluation") == 0) {
				TERADYNE_TRACE_CALL(validate_debug_and_repair_checklists_for_engg_evaluation(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
				if (bValidReparOrder) {
					std::string mailSubject = "";
					mailSubject = mailSubject.append("Engg Evaluation Requested:");
					mailSubject = mailSubject.append(sProcessName);
					mailSubject = mailSubject.append(":");
					mailSubject = mailSubject.append(task);

					vector<tag_t> vValidReceipants;
					int iFinalInsAssignee = 0;
					tag_t* tpFinalInsAssignee = NULLTAG;

					TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_ENGG_EVALUATION_ASSIGNEES, &iFinalInsAssignee, &tpFinalInsAssignee), TD_LOG_ERROR_AND_THROW);
					for (int i = 0; i < iFinalInsAssignee; i++) {
						vValidReceipants.push_back(tpFinalInsAssignee[i]);
					}
					TERADYNE_TRACE_CALL(update_sender_value_to_engg_evaluation_form(tRepairOrderRev, comments), TD_LOG_ERROR_AND_THROW);
					
					TERADYNE_TRACE_CALL(generate_email_to_specified_users(tRepairOrderRev, mailSubject, tSubTask, vValidReceipants), TD_LOG_ERROR_AND_THROW);
				}
			}
			TERADYNE_TRACE_CALL(complete_debug_and_repair(tRepairOrderRev, isValidTask, bValidErrorMessage, bIsRepairChecklistUpdated, iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
		}
		if (tc_strcmp(task.c_str(), "Vendor") == 0) {
			isValidTask = true;
			TERADYNE_TRACE_CALL(complete_vendor(tRepairOrderRev, isValidTask, iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
		}
		if (tc_strcmp(task.c_str(), "Rework") == 0) {

			isValidTask = true;

			if (tc_strcmp(decision.c_str(), "Complete") == 0) {
				bool bValidReparOrder = false;
				TERADYNE_TRACE_CALL(validate_rework_checklists(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
			}
			// genereate email task send to 'Request to On Hold' from Engg Evaluation
			if (tc_strcmp(decision.c_str(), "Request to On Hold") == 0) {
				bool bValidReparOrder = false;
				TERADYNE_TRACE_CALL(validate_rework_checklists(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
				if (isValidTask) {
					std::string mailSubject = "";
					mailSubject = mailSubject.append("Request To Place Repair Order On Hold:");
					mailSubject = mailSubject.append(sProcessName);
					mailSubject = mailSubject.append(":");
					mailSubject = mailSubject.append(task);

					vector<tag_t> vValidReceipants;
					tag_t tRole = NULLTAG;
					char* cpRoleName = NULL;
					int iDebugAndRepairAssignee = 0;
					tag_t* tpDebugAndRepairAssignee = NULLTAG;
					TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_DEBUG_AND_REPAIR_ASSIGNEES, &iDebugAndRepairAssignee, &tpDebugAndRepairAssignee), TD_LOG_ERROR_AND_THROW);
					for (int i = 0; i < iDebugAndRepairAssignee; i++) {
						TERADYNE_TRACE_CALL(SA_ask_groupmember_role(tpDebugAndRepairAssignee[i], &tRole), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(SA_ask_role_name2(tRole, &cpRoleName), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cpRoleName, "Repair Supervisor") == 0) {
							vValidReceipants.push_back(tpDebugAndRepairAssignee[i]);
						}
					}

					TERADYNE_TRACE_CALL(generate_email_to_specified_users(tRepairOrderRev, mailSubject, tSubTask, vValidReceipants), TD_LOG_ERROR_AND_THROW);
				}
			}

			// if moves to engg evaluation, will send an email to 'Test Engineer'
			if (tc_strcmp(decision.c_str(), "Move to Engg Evaluation") == 0) {
				bool bValidReparOrder = false;
				TERADYNE_TRACE_CALL(validate_rework_checklists(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
				if (isValidTask) {
					std::string mailSubject = "";
					mailSubject = mailSubject.append("Engg Evaluation Requested:");
					mailSubject = mailSubject.append(sProcessName);
					mailSubject = mailSubject.append(":");
					mailSubject = mailSubject.append(task);

					vector<tag_t> vValidReceipants;
					int iFinalInsAssignee = 0;
					tag_t* tpFinalInsAssignee = NULLTAG;

					TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_ENGG_EVALUATION_ASSIGNEES, &iFinalInsAssignee, &tpFinalInsAssignee), TD_LOG_ERROR_AND_THROW);
					for (int i = 0; i < iFinalInsAssignee; i++) {
						vValidReceipants.push_back(tpFinalInsAssignee[i]);
					}

					TERADYNE_TRACE_CALL(update_sender_value_to_engg_evaluation_form(tRepairOrderRev, comments), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(generate_email_to_specified_users(tRepairOrderRev, mailSubject, tSubTask, vValidReceipants), TD_LOG_ERROR_AND_THROW);
				}
			}

			

		//	TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_REWORK_STATUS, decision, false)));
			TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_REWORK_STATUS, decision.c_str()), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(complete_rework(tRepairOrderRev, isValidTask, iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
		}
		if ((tc_strcmp(task.c_str(), "Final Inspection") == 0)) {
 			isValidTask = true;
			// genereate email task send to 'Request to On Hold' from Engg Evaluation
			if (tc_strcmp(decision.c_str(), "Request to On Hold") == 0) {
				bool bValidReparOrder = false;

				TERADYNE_TRACE_CALL(validate_final_inspection_checklists(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
				if (isValidTask) {
					std::string mailSubject = "";
					mailSubject = mailSubject.append("Request To Place Repair Order On Hold:");
					mailSubject = mailSubject.append(sProcessName);
					mailSubject = mailSubject.append(":");
					mailSubject = mailSubject.append(task);

					vector<tag_t> vValidReceipants;
					tag_t tRole = NULLTAG;
					char* cpRoleName = NULL;
					int iDebugAndRepairAssignee = 0;
					tag_t* tpDebugAndRepairAssignee = NULLTAG;
					TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_DEBUG_AND_REPAIR_ASSIGNEES, &iDebugAndRepairAssignee, &tpDebugAndRepairAssignee), TD_LOG_ERROR_AND_THROW);
					for (int i = 0; i < iDebugAndRepairAssignee; i++) {
						TERADYNE_TRACE_CALL(SA_ask_groupmember_role(tpDebugAndRepairAssignee[i], &tRole), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(SA_ask_role_name2(tRole, &cpRoleName), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cpRoleName, "Repair Supervisor") == 0) {
							vValidReceipants.push_back(tpDebugAndRepairAssignee[i]);
						}
					}

					TERADYNE_TRACE_CALL(generate_email_to_specified_users(tRepairOrderRev, mailSubject, tSubTask, vValidReceipants), TD_LOG_ERROR_AND_THROW);
				}
			}

			// if moves to Debug and Repair, will send an email to 'Test Technicain and Reair Supervisor'
			if (tc_strcmp(decision.c_str(), "Reject") == 0) {
				bool bValidReparOrder = false;

				TERADYNE_TRACE_CALL(validate_final_inspection_checklists(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
				if (isValidTask) {
					std::string mailSubject = "";
					mailSubject = mailSubject.append("Post Inspection Rejected:");
					mailSubject = mailSubject.append(sProcessName);
					mailSubject = mailSubject.append(":");
					mailSubject = mailSubject.append(task);

					vector<tag_t> vValidReceipants;
					int iDebugAndRepairAssignee = 0;
					tag_t* tpDebugAndRepairAssignee = NULLTAG;

					TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_DEBUG_AND_REPAIR_ASSIGNEES, &iDebugAndRepairAssignee, &tpDebugAndRepairAssignee), TD_LOG_ERROR_AND_THROW);
					for (int i = 0; i < iDebugAndRepairAssignee; i++) {
						vValidReceipants.push_back(tpDebugAndRepairAssignee[i]);
					}

					TERADYNE_TRACE_CALL(generate_email_to_specified_users(tRepairOrderRev, mailSubject, tSubTask, vValidReceipants), TD_LOG_ERROR_AND_THROW);
				}
			}

			// if moves to engg evaluation, will send an email to 'Test Engineer'
			if (tc_strcmp(decision.c_str(), "Move to Engg Evaluation") == 0) {
				
				bool bValidReparOrder = false;

				TERADYNE_TRACE_CALL(validate_final_inspection_checklists(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
				if (isValidTask) {
					std::string mailSubject = "";
					mailSubject = mailSubject.append("Engg Evaluation Requested:");
					mailSubject = mailSubject.append(sProcessName);
					mailSubject = mailSubject.append(":");
					mailSubject = mailSubject.append(task);

					vector<tag_t> vValidReceipants;
					int iFinalInsAssignee = 0;
					tag_t* tpFinalInsAssignee = NULLTAG;

					TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_ENGG_EVALUATION_ASSIGNEES, &iFinalInsAssignee, &tpFinalInsAssignee), TD_LOG_ERROR_AND_THROW);
					for (int i = 0; i < iFinalInsAssignee; i++) {
						vValidReceipants.push_back(tpFinalInsAssignee[i]);
					}

					TERADYNE_TRACE_CALL(update_sender_value_to_engg_evaluation_form(tRepairOrderRev, comments), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(generate_email_to_specified_users(tRepairOrderRev, mailSubject, tSubTask, vValidReceipants), TD_LOG_ERROR_AND_THROW);
				}
			}

			bool bValidReparOrder = false;
			bool isSameHLASNAndPN = false;
			if (tc_strcmp(decision.c_str(), "Approve") == 0) {
				TERADYNE_TRACE_CALL(validate_final_inspection_checklists_when_complete(tRepairOrderRev, bValidReparOrder), TD_LOG_ERROR_AND_THROW);
				isValidTask = bValidReparOrder;
				if (isValidTask) {
					TERADYNE_TRACE_CALL(is_same_hla_sn_and_hla_pn_complete_wf(tRepairOrderRev, isSameHLASNAndPN), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(release_all_serial_number_objects(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
				}
			}
			bool bisverdict = false;
			//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_FINAL_INS_STAUTS, decision, false)));
			TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tRepairOrderRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
			if (!bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, true), TD_LOG_ERROR_AND_THROW);
			}
			TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, TD7_FINAL_INS_STAUTS, decision.c_str()), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_save_without_extensions(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
			if (!bisverdict)
			{
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, false), TD_LOG_ERROR_AND_THROW);
			}

			/** Requirement Change:
			char* cpLocation = NULL;
			AOM_ask_value_string(tRepairOrderRev, TD7_BAT_REPAIR_LOCATION, &cpLocation);
			if (tc_strcmp(cpLocation, "Cebu") == 0) {
				task = "Final Inspection_Cebu";
			}*/
			TERADYNE_TRACE_CALL(complete_final_inspection(tRepairOrderRev, isValidTask, iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
		}
	}
	return iStatus;
}

int complete_repair_routing(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows) {
	int iStatus = ITK_ok;

	if (isValidTask) {
		TERADYNE_TRACE_CALL(perform_task(iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
	}
	else {
		//Display the error message if there s not repair components add.
		//iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_REPAIR_COMPONENTS_NOT_ADD, sItemId.c_str());
		//iStatus = TERADYNE_REPAIR_COMPONENTS_NOT_ADD;
		//throw iStatus;
	}
	return iStatus;
}

int complete_vendor_repair_order(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows) {
	int iStatus = ITK_ok;
	bool bIsNull = false;

	if (isValidTask) {
		TERADYNE_TRACE_CALL(perform_task(iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
	}
	else {
		// get item id to display te error message.
		BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);
		AcquireLock lockOnLLApartNum(tRepairOrderRev);
		std::string sItemId("");
		boRepairOrderRev->getString(ITEM_ID, sItemId, bIsNull);

		//Display the error message if there s not repair components add.
		iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_REPAIR_COMPONENTS_NOT_ADD, sItemId.c_str());
		iStatus = TERADYNE_REPAIR_COMPONENTS_NOT_ADD;
		throw iStatus;
	}
	return iStatus;
}

int complete_normal_repair_routing(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows) {
	int iStatus = ITK_ok;

	if (isValidTask) {
		TERADYNE_TRACE_CALL(perform_task(iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
	}
	else {
		//Display the error message if there s not repair components add.
		//iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_REPAIR_COMPONENTS_NOT_ADD, sItemId.c_str());
		//iStatus = TERADYNE_REPAIR_COMPONENTS_NOT_ADD;
		//throw iStatus;
	}
	return iStatus;
}

int complete_engg_evaluation(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows) {
	int iStatus = ITK_ok;

	if (isValidTask) {
		TERADYNE_TRACE_CALL(perform_task(iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
	}
	else {
		char* sItemId = NULL;
		TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, ITEM_ID, &sItemId), TD_LOG_ERROR_AND_THROW);
		//Display the error message if there s not repair components add.
		iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_INVALID_SCRAP_REASON, sItemId);
		iStatus = TERADYNE_INVALID_SCRAP_REASON;
		throw iStatus;
	}
	return iStatus;
}

int complete_debug_and_repair(tag_t tRepairOrderRev, bool isValidTask, bool bValidErrorMessage, bool bIsRepairChecklistUpdated, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows) {
	int iStatus = ITK_ok;
	bool bIsNull = false;
	bool isMainRootCauseUpdated = false;
	if (isValidTask) {

		TERADYNE_TRACE_CALL(perform_task(iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
	}


	else {
		// get item id to display te error message.
		BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);
		AcquireLock lockOnLLApartNum(tRepairOrderRev);
		std::string sItemId("");
		boRepairOrderRev->getString(ITEM_ID, sItemId, bIsNull);
		if (bIsRepairChecklistUpdated) {
			//Display the error message if Repair checklist is not updated.
			iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_REPAIR_CHECKLIST_IS_NOT_UPDATED, sItemId.c_str());
			iStatus = TERADYNE_REPAIR_CHECKLIST_IS_NOT_UPDATED;
			throw iStatus;
		}
		if (!bValidErrorMessage) {
			//Display the error message if checklist stage is not as post test.
			iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_VALIDATE_CHECKLIST_STAGE, sItemId.c_str());
			iStatus = TERADYNE_VALIDATE_CHECKLIST_STAGE;
			throw iStatus;
		}
		else {
			//Display the error message if checklist stage is not as post test.
			iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_MAIN_ROOT_CAUSE_VALIDATION, sItemId.c_str());
			iStatus = TERADYNE_MAIN_ROOT_CAUSE_VALIDATION;
			throw iStatus;
		}
	}

	return iStatus;
}

int validate_main_root_ause_value(tag_t tRepairOrderRev, bool &bMainRootCauseUpdate) {

	int iStatus = ITK_ok;

	tag_t tSolutionConfigRel = NULLTAG;
	tag_t tRpairCompRel = NULLTAG;
	tag_t* tpSolutionConfigs = NULLTAG;
	tag_t* tpReairComponents = NULLTAG;
	int ISolutionConfigs = 0;
	int iRepairComps = 0;

	bool isValidComp = FALSE;

	const char * __function__ = "validate_main_root_ause_value";
	TERADYNE_TRACE_ENTER();
	try {

		TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tSolutionConfigRel), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tSolutionConfigRel, &ISolutionConfigs, &tpSolutionConfigs), TD_LOG_ERROR_AND_THROW);
		for (int i = 0; i < ISolutionConfigs; i++) {
			TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_REPAIRS_REL, &tRpairCompRel), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpSolutionConfigs[i], tRpairCompRel, &iRepairComps, &tpReairComponents), TD_LOG_ERROR_AND_THROW);
			for (int j = 0; j < iRepairComps; j++) {
				char* sMainRootCauseValue;
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tpReairComponents[j], TD7_MAIN_ROOT_CAUSE, &sMainRootCauseValue), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(sMainRootCauseValue, "Yes") == 0) {
					char* sCustomerFailureData;
					TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, TD7_CUSTOMER_FAILURE_DATA, &sCustomerFailureData), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(sCustomerFailureData, "") != 0) {
					char* sCustoemrDatalogRating;
					TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, TD7_CUSTOMER_DATALOG_RATING, &sCustoemrDatalogRating), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(sCustoemrDatalogRating, "") != 0) {
						isValidComp = TRUE;
					}
					}
				}
			}
		}
		// TO CHECK VALID OR NOT
		bMainRootCauseUpdate = isValidComp;
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return  iStatus;
}

int complete_rework(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows) {
	int iStatus = ITK_ok;

	if (isValidTask) {
		TERADYNE_TRACE_CALL(perform_task(iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
	}
	else {
		//Display the error message if there s not repair components add.
		iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_CHECKLIST_ERROR, task.c_str());
		iStatus = TERADYNE_CHECKLIST_ERROR;
		throw iStatus;
	}
	return iStatus;
}

int complete_vendor(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows) {
	int iStatus = ITK_ok;

	if (isValidTask) {
		TERADYNE_TRACE_CALL(perform_task(iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
	}
	else {
		//Display the error message if there s not repair components add.
		//iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_REPAIR_COMPONENTS_NOT_ADD, sItemId.c_str());
		//iStatus = TERADYNE_REPAIR_COMPONENTS_NOT_ADD;
		//throw iStatus;
	}
	return  iStatus;
}

int complete_final_inspection(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows) {
	int iStatus = ITK_ok;

	if (isValidTask) {
		TERADYNE_TRACE_CALL(perform_task(iNumOfWorkflows, task, comments, tRunningWorkflows), TD_LOG_ERROR_AND_THROW);
	}
	else {
		//Display the error message if there s not repair components add.
		iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_FINAL_INSPECTION_VALIDATION, task.c_str());
		iStatus = TERADYNE_FINAL_INSPECTION_VALIDATION;
		throw iStatus;
	}

	return iStatus;
}

int perform_task(int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows) {

	int iStatus = ITK_ok;
	// complete the perform-signoff task.
	logical bIsApproved = false;
	for (int i = 0; i < iNumOfWorkflows; i++) {

		int iTaskCount = 0;
		tag_t * tStartedTasks = NULLTAG;
		tag_t tSubTask = NULLTAG;

		TERADYNE_TRACE_CALL(EPM_ask_sub_task(tRunningWorkflows[i], task.c_str(), &tSubTask), TD_LOG_ERROR_AND_THROW);
		int iSubTaskCount = 0;
		tag_t* ptSubTasks = NULLTAG;
		TERADYNE_TRACE_CALL(iStatus = EPM_ask_sub_tasks(tSubTask, &iSubTaskCount, &ptSubTasks), TD_LOG_ERROR_AND_THROW);
		if (ITK_ok == iStatus && iSubTaskCount == 2) {

			char* cTaskName = NULL;
			for (int j = 0; j < iSubTaskCount; j++) {

				TERADYNE_TRACE_CALL(AOM_ask_value_string(ptSubTasks[j], OBJECT_NAME, &cTaskName), TD_LOG_ERROR_AND_THROW);

				if (tc_strcmp(cTaskName, "perform-signoffs") == 0) {

					int n_signoffs = 0;
					tag_t *signoffs = NULL;
					char* tName = NULL;
					TERADYNE_TRACE_CALL(EPM_ask_attachments(ptSubTasks[j],
						EPM_signoff_attachment, &n_signoffs, &signoffs), TD_LOG_ERROR_AND_THROW);

					for (int signoff = 0; signoff < n_signoffs; signoff++) {
						TERADYNE_TRACE_CALL(AOM_ask_value_string(signoffs[signoff], "object_name", &tName), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(tName, "perform-signoffs") == 0) {
							tag_t signoff_tag = signoffs[signoff];


							if (!bIsApproved) {
								TERADYNE_TRACE_CALL(EPM_set_task_decision3(ptSubTasks[j], signoff_tag,
									EPM_approve_decision, comments.c_str()
								), TD_LOG_ERROR_AND_THROW);
								bIsApproved = true;
							}
						}
					}
					TERADYNE_MEM_FREE(signoffs);
					TERADYNE_MEM_FREE(tName);
				}
			}
			TERADYNE_MEM_FREE(cTaskName);
		}
		TERADYNE_MEM_FREE(tRunningWorkflows);	
	}
	return iStatus;
}

int claim_unclaim_debug_and_repair(string isClaim, string uid) {

	int iStatus = ITK_ok;
	tag_t * tRunningWorkflows = NULLTAG;
	int iNumOfWorkflows = 0;
	tag_t tRepairOrderRev = NULLTAG;
	logical bIsNull = false;

	tag_t tSubTask = NULLTAG;
	tag_t tUserTag = NULLTAG;
	tag_t tCurrentGroupMember = NULLTAG;
	char* cpUsername = NULL;
	tag_t tParticipant = NULLTAG;
	int iParticipantCount = 0;
	int iParticipant = 0;
	int iAssignee = 0;
	int iReworkAssignee = 0;
	int iFinalInsAssignee = 0;
	tag_t tParticipantList = NULLTAG;
	tag_t* tParticipantTypeList = NULLTAG;
	tag_t* vsAssignee = NULLTAG;
	tag_t* tpReworkAssignee = NULLTAG;
	tag_t* tpFinalInsAssignee = NULLTAG;
	bool bisverdict = false;

	const char * __function__ = "claim_unclaim_debug_and_repair";
	TERADYNE_TRACE_ENTER();
	try {
		if (tc_strcmp(isClaim.c_str(), "true") == 0) {

			ITK__convert_uid_to_tag(uid.c_str(), &tRepairOrderRev);

			BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);

			std::string sCurrentTaskName("");
			TERADYNE_TRACE_CALL((boRepairOrderRev->getString(TD7_CURRENT_TASK_NAME, sCurrentTaskName, bIsNull)), TD_LOG_ERROR_AND_THROW);

			iStatus = AOM_ask_value_tags(tRepairOrderRev, "fnd0AllWorkflows", &iNumOfWorkflows, &tRunningWorkflows);

			if (iNumOfWorkflows > 0) {
				for (int i = 0; i < iNumOfWorkflows; i++) {

					TERADYNE_TRACE_CALL(EPM_ask_sub_task(tRunningWorkflows[i], sCurrentTaskName.c_str(), &tSubTask), TD_LOG_ERROR_AND_THROW);
					// Get logged in user.
					TERADYNE_TRACE_CALL(POM_get_user(&cpUsername, &tUserTag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(SA_ask_current_groupmember(&tCurrentGroupMember), TD_LOG_ERROR_AND_THROW);

					if (tc_strcmp(sCurrentTaskName.c_str(), "Engg Evaluation") == 0) {
						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7EnggEvaluationSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tRepairOrderRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
						if (!bisverdict)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, true), TD_LOG_ERROR_AND_THROW);
						}
					
						TERADYNE_TRACE_CALL(AOM_set_value_logical(tRepairOrderRev, IS_ENGG_EVALUATION_CLAIMED, FALSE), TD_LOG_ERROR_AND_THROW);
						//To set claimed user.
						TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, IS_CLAIMED_USER, cpUsername), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_set_value_tag(tRepairOrderRev, TD7_CLAIMED_MEMBER, tCurrentGroupMember), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
						if (!bisverdict)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, false), TD_LOG_ERROR_AND_THROW);
						}
					}

					if (tc_strcmp(sCurrentTaskName.c_str(), "Debug and Repair") == 0) {
						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7DebugAndRepairSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tRepairOrderRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
						if (!bisverdict)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, true), TD_LOG_ERROR_AND_THROW);
						}
						TERADYNE_TRACE_CALL(AOM_set_value_logical(tRepairOrderRev, IS_DEB_AND_REPAIR_CLAIMED, FALSE), TD_LOG_ERROR_AND_THROW);
						//To set claimed user.
						TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, IS_CLAIMED_USER, cpUsername), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_set_value_tag(tRepairOrderRev, TD7_CLAIMED_MEMBER, tCurrentGroupMember), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
						if (!bisverdict)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, false), TD_LOG_ERROR_AND_THROW);
						}
					}

					if (tc_strcmp(sCurrentTaskName.c_str(), "Rework") == 0) {
						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7ReworkSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tRepairOrderRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
						if (!bisverdict)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, true), TD_LOG_ERROR_AND_THROW);
						}
						TERADYNE_TRACE_CALL(AOM_set_value_logical(tRepairOrderRev, IS_REWORK_CLAIMED, FALSE), TD_LOG_ERROR_AND_THROW);
						//To set claimed user.
						TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, IS_CLAIMED_USER, cpUsername), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_set_value_tag(tRepairOrderRev, TD7_CLAIMED_MEMBER, tCurrentGroupMember), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
						if (!bisverdict)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, false), TD_LOG_ERROR_AND_THROW);
						}
					}

					if (tc_strcmp(sCurrentTaskName.c_str(), "Final Inspection") == 0) {
						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7FinalInspectSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tRepairOrderRev, &bisverdict), TD_LOG_ERROR_AND_THROW);
						if (!bisverdict)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, true), TD_LOG_ERROR_AND_THROW);
						}
						TERADYNE_TRACE_CALL(AOM_set_value_logical(tRepairOrderRev, IS_FINAL_INS_CLAIMED, FALSE), TD_LOG_ERROR_AND_THROW);
						//To set claimed user.
						TERADYNE_TRACE_CALL(AOM_set_value_string(tRepairOrderRev, IS_CLAIMED_USER, cpUsername), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_set_value_tag(tRepairOrderRev, TD7_CLAIMED_MEMBER, tCurrentGroupMember), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
						if (!bisverdict)
						{
							TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, false), TD_LOG_ERROR_AND_THROW);
						}
					}
					if (tParticipant != NULLTAG) {

						// Remove all the assignees from the participant, except logged in user -- Claim Action.
						TERADYNE_TRACE_CALL(PARTICIPANT_ask_participants(tRepairOrderRev, tParticipant, &iParticipant, &tParticipantTypeList), TD_LOG_ERROR_AND_THROW);
						for (int i = 0; i < iParticipant; i++) {
							TERADYNE_TRACE_CALL(PARTICIPANT_remove_participant(tRepairOrderRev, tParticipantTypeList[i]), TD_LOG_ERROR_AND_THROW);
						}
						//TERADYNE_TRACE_CALL(AOM_save_with_extensions(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tCurrentGroupMember, tParticipant, &tParticipantList), TD_LOG_ERROR_AND_THROW);
						POM_AM__set_application_bypass(true);
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, true), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = AOM_save_without_extensions(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tRepairOrderRev, false), TD_LOG_ERROR_AND_THROW);
						POM_AM__set_application_bypass(false);				
		
					}

					// Demote tha task.
					AM__set_application_bypass(true);
					POM_AM__set_application_bypass(true);

					TERADYNE_TRACE_CALL(EPM_trigger_action(tSubTask, EPM_undo_action, "Claimed"), TD_LOG_ERROR_AND_THROW);

					TERADYNE_MEM_FREE(tRunningWorkflows);
					TERADYNE_MEM_FREE(vsAssignee);
					TERADYNE_MEM_FREE(tParticipantTypeList);
				}
			}
		}
		else if (tc_strcmp(isClaim.c_str(), "false") == 0) {

			ITK__convert_uid_to_tag(uid.c_str(), &tRepairOrderRev);

			BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);

			std::string sCurrentTask("");
			TERADYNE_TRACE_CALL((boRepairOrderRev->getString(TD7_CURRENT_TASK_NAME, sCurrentTask, bIsNull)), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, "fnd0AllWorkflows", &iNumOfWorkflows, &tRunningWorkflows), TD_LOG_ERROR_AND_THROW);

			if (iNumOfWorkflows > 0) {

				for (int i = 0; i < iNumOfWorkflows; i++) {

					TERADYNE_TRACE_CALL(EPM_ask_sub_task(tRunningWorkflows[i], sCurrentTask.c_str(), &tSubTask), TD_LOG_ERROR_AND_THROW);


					if (tc_strcmp(sCurrentTask.c_str(), "Engg Evaluation") == 0) {

						TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_ENGG_EVALUATION_ASSIGNEES, &iAssignee, &vsAssignee), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7EnggEvaluationSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);

						// To visble Claim button.
						BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
						AcquireLock lockForReworkSpecialist(tRepairOrderBORef);

						TERADYNE_TRACE_CALL((tRepairOrderBORef->setLogical(IS_ENGG_EVALUATION_CLAIMED, TRUE, false)), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);

						for (int j = 0; j < iAssignee; j++) {

							if (tParticipant != NULLTAG) {

								TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(vsAssignee[j], tParticipant, &tParticipantList), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(AOM_save_with_extensions(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
							}
						}
					}
					if (tc_strcmp(sCurrentTask.c_str(), "Debug and Repair") == 0) {

						TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_DEBUG_AND_REPAIR_ASSIGNEES, &iAssignee, &vsAssignee), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7DebugAndRepairSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);

						// To visble Claim button.
						BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
						AcquireLock lockForReworkSpecialist(tRepairOrderBORef);

						TERADYNE_TRACE_CALL((tRepairOrderBORef->setLogical(IS_DEB_AND_REPAIR_CLAIMED, TRUE, false)), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);

						for (int j = 0; j < iAssignee; j++) {

							if (tParticipant != NULLTAG) {

								TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(vsAssignee[j], tParticipant, &tParticipantList), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(AOM_save_with_extensions(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
							}
						}
					}

					if (tc_strcmp(sCurrentTask.c_str(), "Rework") == 0) {

						TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_REWORK_ASSIGNEES, &iReworkAssignee, &tpReworkAssignee), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7ReworkSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);

						// To visble Claim button.
						BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
						AcquireLock lockForReworkSpecialist(tRepairOrderBORef);

						TERADYNE_TRACE_CALL((tRepairOrderBORef->setLogical(IS_REWORK_CLAIMED, TRUE, false)), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);


						for (int j = 0; j < iReworkAssignee; j++) {

							if (tParticipant != NULLTAG) {

								TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tpReworkAssignee[j], tParticipant, &tParticipantList), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(AOM_save_with_extensions(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
							}
						}
					}

					if (tc_strcmp(sCurrentTask.c_str(), "Final Inspection") == 0) {

						TERADYNE_TRACE_CALL(AOM_ask_value_tags(tRepairOrderRev, TD7_FINAL_INSPECTION_ASSIGNEES, &iFinalInsAssignee, &tpFinalInsAssignee), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7FinalInspectSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);

						// To visble Claim button.
						BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
						AcquireLock lockForReworkSpecialist(tRepairOrderBORef);

						TERADYNE_TRACE_CALL((tRepairOrderBORef->setLogical(IS_FINAL_INS_CLAIMED, TRUE, false)), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);

						for (int j = 0; j < iFinalInsAssignee; j++) {

							if (tParticipant != NULLTAG) {

								TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tpFinalInsAssignee[j], tParticipant, &tParticipantList), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList), TD_LOG_ERROR_AND_THROW);
								TERADYNE_TRACE_CALL(AOM_save_with_extensions(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
							}
						}
					}

					// Demote the task.
					AM__set_application_bypass(true);
					POM_AM__set_application_bypass(true);
					TERADYNE_TRACE_CALL(EPM_trigger_action(tSubTask, EPM_undo_action, "Claimed"), TD_LOG_ERROR_AND_THROW);

				}
			}
		}
	}
	catch (exception) {
	}
	TERADYNE_MEM_FREE(tRunningWorkflows);
	TERADYNE_MEM_FREE(vsAssignee);
	TERADYNE_MEM_FREE(tpReworkAssignee);
	TERADYNE_MEM_FREE(tpFinalInsAssignee);
	TERADYNE_MEM_FREE(tParticipantTypeList);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_repair_components_exist(tag_t tPrimaryObject, bool &bValidReparOrder) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	const char * __function__ = "validate_repair_components_exist";
	TERADYNE_TRACE_ENTER();
	try {
		if (tPrimaryObject == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);
		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tPrimaryObject, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		// If may solution config is not added into repair order.
		if (iSecondaryCnt > 0) {
			for (int i = 0; i < iSecondaryCnt; i++)
			{

				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIRS_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);
				int iRepairCompCount = 0;
				TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpSecondaryObjects[i], tRelationType, &iRepairCompCount, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);
				if (iRepairCompCount > 0)
				{
					bValidReparOrder = TRUE;
				}
			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_debug_and_repair_checklists(tag_t tRepairOrderRev, bool &bValidReparOrder) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "validate_debug_and_repair_checklists";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(IMAN_SPECIFICATION, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(sObjectType.c_str(), TD7_POST_TEST_FORM) == 0) {
				bool isLatest = false;
				TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
				if (isLatest) {
					std::string cResultProperty("");
					TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_POST_TEST_RESULT, cResultProperty, bIsNull), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(cResultProperty.c_str(), "") != 0) {
						std::string cPostTestFailureDetails("");
						TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_POST_TEST_FAILURE_DETAILS, cPostTestFailureDetails, bIsNull), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cPostTestFailureDetails.c_str(), "") != 0) {
							bValidReparOrder = TRUE;
						}
					}
				}
			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_debug_and_repair_checklists_for_engg_evaluation(tag_t tRepairOrderRev, bool &bValidReparOrder) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "validate_debug_and_repair_checklists_for_engg_evaluation";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;
		char* cCheckListStage = NULL;
		TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, TD7_BAT_CHECKLIST, &cCheckListStage), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(IMAN_SPECIFICATION, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(cCheckListStage, "Pre Inspection") == 0) {
				if (tc_strcmp(sObjectType.c_str(), TD7_PRE_INSPECTION_FORM) == 0) {
					bool isLatest = false;
					TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
					if (isLatest) {
						std::string cPreInsTestResult("");
						TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_PRE_INSPECTION_TEST_RESULT, cPreInsTestResult, bIsNull), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cPreInsTestResult.c_str(), "") != 0) {
							std::string preInsFailureComments("");
							TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_PRE_INSPECTION_FAILURE_COMMENTS, preInsFailureComments, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(preInsFailureComments.c_str(), "") != 0) {
								std::string cTampered("");
								TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_TAMPERED, cTampered, bIsNull), TD_LOG_ERROR_AND_THROW);
								if (tc_strcmp(cTampered.c_str(), "") != 0) {
									bValidReparOrder = true;
								}
							}
						}
					}
				}
			}
			if (tc_strcmp(cCheckListStage, "Pre Test") == 0) {
				if (tc_strcmp(sObjectType.c_str(), TD7_PRE_TEST_FORM) == 0) {
					bool isLatest = false;
					TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
					if (isLatest) {
						std::string cPreTestResult("");
						TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_PRE_TEST_TEST_RESULT, cPreTestResult, bIsNull), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cPreTestResult.c_str(), "") != 0) {
							std::string cPreTestFinding("");
							TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_PRE_TEST_FINDING, cPreTestFinding, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(cPreTestFinding.c_str(), "") != 0) {
								bValidReparOrder = true;
							}
						}
					}
				}
			}
			if (tc_strcmp(cCheckListStage, "Repair") == 0) {
				if (tc_strcmp(sObjectType.c_str(), TD7_REPAIR_FORM) == 0) {
					bool isLatest = false;
					TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
					if (isLatest) {
						std::string cRepairResult("");
						TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_REPAIR_RESULT, cRepairResult, bIsNull), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cRepairResult.c_str(), "") != 0) {
							std::string cRepairDetails("");
							TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_REPAIR_DETAILS, cRepairDetails, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(cRepairDetails.c_str(), "") != 0) {
								bValidReparOrder = true;
							}
						}
					}
				}
			}
			if (tc_strcmp(cCheckListStage, "Repair Verification") == 0) {
				if (tc_strcmp(sObjectType.c_str(), TD7_REPAIR_VERIFICATION_FORM) == 0) {
					bool isLatest = false;
					TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
					if (isLatest) {
						std::string cRepairVerificationStatus("");
						TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_REPAIR_VERIFICATION_STATUS, cRepairVerificationStatus, bIsNull), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cRepairVerificationStatus.c_str(), "") != 0) {
							std::string cRepairVerificationResult("");
							TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_REPAIR_VERIFICATION_RESULTS, cRepairVerificationResult, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(cRepairVerificationResult.c_str(), "") != 0) {
								bValidReparOrder = true;
							}
						}
					}
				}
			}
			if (tc_strcmp(cCheckListStage, "Post Test") == 0) {
				if (tc_strcmp(sObjectType.c_str(), TD7_POST_TEST_FORM) == 0) {
					bool isLatest = false;
					TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
					if (isLatest) {
						std::string cResultProperty("");
						TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_POST_TEST_RESULT, cResultProperty, bIsNull), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cResultProperty.c_str(), "") != 0) {
							std::string cPostTestFailureDetails("");
							TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_POST_TEST_FAILURE_DETAILS, cPostTestFailureDetails, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(cPostTestFailureDetails.c_str(), "") != 0) {
								bValidReparOrder = TRUE;
							}
						}
					}
				}
			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int update_sender_value_to_engg_evaluation_form(tag_t tRepairOrderRev, string comments) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "update_sender_value_to_engg_evaluation_form";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}

		BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);
		AcquireLock lockOnRepairOrderRev(boRepairOrderRev);

		if (tc_strcmp(comments.c_str(), "") != 0 && tc_strcmp(comments.c_str(), NULL) != 0) {
			TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_INFO_FROM_SENDER, comments, false)), TD_LOG_ERROR_AND_THROW);
		}
		TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int update_sender_value_from_routing_task(tag_t tRepairOrderRev, string comments) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "update_sender_value_from_routing_task";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(IMAN_SPECIFICATION, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);

			if (tc_strcmp(sObjectType.c_str(), TD7_ENGG_EVALUATION_FORM) == 0) {
				bool isLatest = false;
				TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
				if (isLatest) {
					BusinessObjectRef< Teamcenter::BusinessObject > boEnggEvaluationForm(tpSecondaryObjects[i]);
					AcquireLock lockOnEnngEvaluationForm(boEnggEvaluationForm);

					if (tc_strcmp(comments.c_str(), "") != 0 && tc_strcmp(comments.c_str(), NULL) != 0) {
						TERADYNE_TRACE_CALL((boEnggEvaluationForm->setString(TD7_INFO_FROM_SENDER, comments, false)), TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(AOM_save(tpSecondaryObjects[i]), TD_LOG_ERROR_AND_THROW);

				}
			}

		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_engg_evaluation_checklists(tag_t tRepairOrderRev, bool &bValidReparOrder) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "validate_engg_evaluation_checklists";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(IMAN_SPECIFICATION, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);
			//if (tc_strcmp(sObjectType.c_str(), "Repair") == 0) {
			if (tc_strcmp(sObjectType.c_str(), TD7_ENGG_EVALUATION_FORM) == 0) {
				bool isLatest = false;
				TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
				if (isLatest) {
					std::string cDispostion("");
					TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_ENGG_EVALUATION_DISPOSITION, cDispostion, bIsNull), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(cDispostion.c_str(), "") != 0) {
						if (tc_strcmp(cDispostion.c_str(), "Scrap") == 0) {
							std::string cScrapCriteria("");
							std::string cScrapCode("");
							TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_SCRAP_CRITERIA, cScrapCriteria, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(cScrapCriteria.c_str(), "") != 0) {
								TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_SCRAP_CODE, cScrapCode, bIsNull), TD_LOG_ERROR_AND_THROW);
								if (tc_strcmp(cScrapCode.c_str(), "") != 0) {
									bValidReparOrder = true;
								}
							}
						}
						//else {
							//bValidReparOrder = true;
					//	}
					}
				}
			}
			//}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_engg_evaluation_checklists_complete_stage(tag_t tRepairOrderRev, bool &bValidReparOrder) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "validate_engg_evaluation_checklists_complete_stage";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(IMAN_SPECIFICATION, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);
			//if (tc_strcmp(sObjectType.c_str(), "Repair") == 0) {
			if (tc_strcmp(sObjectType.c_str(), TD7_ENGG_EVALUATION_FORM) == 0) {
				bool isLatest = false;
				TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
				if (isLatest) {
					std::string cDispostion("");
					TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_ENGG_EVALUATION_DISPOSITION, cDispostion, bIsNull), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(cDispostion.c_str(), "") != 0) {
						if (tc_strcmp(cDispostion.c_str(), "Scrap") == 0) {
							std::string cScrapCriteria("");
							std::string cScrapCode("");
							TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_SCRAP_CRITERIA, cScrapCriteria, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(cScrapCriteria.c_str(), "") != 0) {
								TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_SCRAP_CODE, cScrapCode, bIsNull), TD_LOG_ERROR_AND_THROW);
								if (tc_strcmp(cScrapCode.c_str(), "") != 0) {
									bValidReparOrder = true;
								}
							}
						}
						else {
							bValidReparOrder = true;
						}
					}
				}
			}
			//}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_repair_checklists(tag_t tRepairOrderRev, bool &bValidReparOrder) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "validate_repair_checklists";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(IMAN_SPECIFICATION, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);
			//if (tc_strcmp(sObjectType.c_str(), "Repair") == 0) {
				if (tc_strcmp(sObjectType.c_str(), TD7_REPAIR_FORM) == 0) {
					bool isLatest = false;
					TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
					if (isLatest) {
						std::string cRepairResult("");
						TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_REPAIR_RESULT, cRepairResult, bIsNull), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cRepairResult.c_str(), "") != 0) {
							std::string cRepairDetails("");
							TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_REPAIR_DETAILS, cRepairDetails, bIsNull), TD_LOG_ERROR_AND_THROW);
							if (tc_strcmp(cRepairDetails.c_str(), "") != 0) {
								bValidReparOrder = true;
							}
						}
					}
				}
			//}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_rework_checklists(tag_t tRepairOrderRev, bool &bValidReparOrder) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "validate_rework_checklists";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(IMAN_SPECIFICATION, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(sObjectType.c_str(), TD7_REPAIR_REWORK_FORM) == 0) {
				bool isLatest = false;
				TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
				if (isLatest) {
					std::string sResultProperty("");
					TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_REWORK_RESULTS, sResultProperty, bIsNull), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(sResultProperty.c_str(), "") != 0) {
						std::string sReworkStatus("");
						TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_REWORK_STATUS, sReworkStatus, bIsNull), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(sReworkStatus.c_str(), "") != 0) {
							bValidReparOrder = TRUE;
						}
					}
				}
			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_final_inspection_checklists(tag_t tRepairOrderRev, bool &bValidReparOrder) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "validate_final_inspection_checklists";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(IMAN_SPECIFICATION, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(sObjectType.c_str(), TD7_QUALITY_INSPECTION_FORM) == 0) {
				bool isLatest = false;
				TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
				if (isLatest) {
					std::string cResultProperty("");
					TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_QUALITY_INSPECTION_TEST_RESULT, cResultProperty, bIsNull), TD_LOG_ERROR_AND_THROW);
					if (tc_strcmp(cResultProperty.c_str(), "") != 0) {
						std::string cQualityInsFailureDetails("");
						TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_QUALITY_INSPECTION_FAILURE_DETAILS, cQualityInsFailureDetails, bIsNull), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cQualityInsFailureDetails.c_str(), "") != 0) {
							bValidReparOrder = TRUE;
						}
					}
				}
			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_final_inspection_checklists_when_complete(tag_t tRepairOrderRev, bool &bValidReparOrder) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "validate_final_inspection_checklists_when_complete";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(IMAN_SPECIFICATION, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(sObjectType.c_str(), TD7_QUALITY_INSPECTION_FORM) == 0) {
				bool isLatest = false;
				TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
				if (isLatest) {
					std::string cResultProperty("");
					TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_QUALITY_INSPECTION_TEST_RESULT, cResultProperty, bIsNull), TD_LOG_ERROR_AND_THROW);
					if ((tc_strcmp(cResultProperty.c_str(), "") != 0) && (tc_strcmp(cResultProperty.c_str(), "Fail") != 0)) {
						std::string cQualityInsFailureDetails("");
						TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(TD7_QUALITY_INSPECTION_FAILURE_DETAILS, cQualityInsFailureDetails, bIsNull), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(cQualityInsFailureDetails.c_str(), "") != 0) {
							bValidReparOrder = TRUE;
						}
					}
				}
			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int generate_email_to_specified_users(tag_t tRepairOrderRev, std::string mailSubject, tag_t tcurrentTask, vector<tag_t> vValidReceipants) {

	int iStatus = ITK_ok;
	bool bIsNull = false;

	int server_name_count = 0;
	int server_port_count = 0;

	char *mail_body_FilePath = NULL;
	char *mail_list_FilePath = NULL;
	char** server_name_pref_value = NULL;
	char** server_port_pref_value = NULL;

	ofstream outfile;
	ofstream out_mail_file;

	string uti_exec_path = "";
	string mailBody = "";
	int 	users_count = 0;
	tag_t* 	list_users = NULLTAG;

	const char * __function__ = "generate_email_to_specified_users";
	TERADYNE_TRACE_ENTER();
	try {

		// get all the receipants
		mail_list_FilePath = USER_new_file_name("Mail_list", "TEXT", "txt", 1);
		out_mail_file.open(mail_list_FilePath);


		for (int i = 0; i < vValidReceipants.size(); i++)
		{
			char* 	userEmailValue = NULL;
			tag_t tPerson = NULLTAG;
			tag_t tUser = NULLTAG;
			SA_ask_groupmember_user(vValidReceipants[i], &tUser);
			SA_ask_user_person(tUser, &tPerson);
			if (tPerson != NULLTAG)
			{
				SA_ask_person_email_address(tPerson, &userEmailValue);
			}

			TC_write_syslog(" charEmailID : %s\n", userEmailValue);
			if (userEmailValue != NULL)
			{
				// write inputted data into the file.
				out_mail_file << userEmailValue << endl;
				TERADYNE_MEM_FREE(userEmailValue);
			}

		}

		// close the opened file.
		out_mail_file.close();

		// generate the mail body
		mailBody = generate_mail_body(tRepairOrderRev, tcurrentTask);

		mail_body_FilePath = USER_new_file_name("Mail_Body", "TEXT", "html", 1);
		outfile.open(mail_body_FilePath);

		// write inputted data into the file.
		outfile << mailBody << endl;

		// close the opened file.
		outfile.close();

		// email notification
		PREF_ask_char_values("Mail_server_name", &server_name_count, &server_name_pref_value);
		PREF_ask_char_values("Mail_server_port", &server_port_count, &server_port_pref_value);

		uti_exec_path.append("tc_mail_smtp.exe -to_list_file=").append(mail_list_FilePath).append(" -subject=\"").append(mailSubject).append("\" -server=\"").append(*server_name_pref_value).append("\" -port=\"").append(*server_port_pref_value).append("\" -body=\"").append(mail_body_FilePath);

		system(uti_exec_path.c_str());
		TC_write_syslog(" \n email notification sent!!\n");

		DeleteFileA(mail_body_FilePath);//Deleting the file after sending the mail
		DeleteFileA(mail_list_FilePath);//Deleting the file after sending the mail

	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

std::string generate_mail_body(tag_t tRepairOrderRev, tag_t tcurrentTask) {
	int iStatus = ITK_ok;
	bool bIsNull = false;

	char *jobName = NULL,
		*currentTask = NULL,
		*description = NULL,
		*pcDueDate = NULL;

	date_t due_date;

	string bufferHTMLContent = "<html><head></head><body>";

	const char * __function__ = "generate_mail_body";
	TERADYNE_TRACE_ENTER();
	try {
		// prepare mail body
		BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);
		AcquireLock lockOnLLApartNum(tRepairOrderRev);
		std::string sRepairOrderID("");
		std::string sHLAPartNumber("");
		std::string sHLASerialNumber("");
		std::string sServiceType("");
		std::string sRepaiGroup("");
		boRepairOrderRev->getString(ITEM_ID, sRepairOrderID, bIsNull);
		boRepairOrderRev->getString(TD7_BAT_SERVICE_TYPE, sServiceType, bIsNull);
		// HLA Part Number
		boRepairOrderRev->getString(TD7_PART_NUMBER, sHLAPartNumber, bIsNull);
		if (tc_strcmp(sHLAPartNumber.c_str(), "") == 0) {
			boRepairOrderRev->getString(TD7_COMM_PART_NUMBER, sHLAPartNumber, bIsNull);
		}
		if (tc_strcmp(sHLAPartNumber.c_str(), "") == 0) {
			boRepairOrderRev->getString(TD7_REP_MANAGE_PART, sHLAPartNumber, bIsNull);
		}

		boRepairOrderRev->getString(TD7_DIV_PART_REPAIR_GROUP, sRepaiGroup, bIsNull);
		if (tc_strcmp(sRepaiGroup.c_str(), "") == 0) {
			boRepairOrderRev->getString(TD7_COMM_PART_REPAIR_GROUP, sRepaiGroup, bIsNull);
		}
		if (tc_strcmp(sRepaiGroup.c_str(), "") == 0) {
			boRepairOrderRev->getString(TD7_RMP_REPAIR_GROUP, sRepaiGroup, bIsNull);
		}
		boRepairOrderRev->getString(TD7_SERIAL_NUMBER, sHLASerialNumber, bIsNull);

		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tcurrentTask, "job_name", &jobName), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tcurrentTask, "object_string", &currentTask), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_date(tcurrentTask, "due_date", &due_date), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tcurrentTask, "object_desc", &description), TD_LOG_ERROR_AND_THROW);

		if (due_date.year == 0 && due_date.month == 0 && due_date.day == 0)
		{
			pcDueDate = (char *)MEM_alloc(sizeof(char) * 2);
			strcpy(pcDueDate, "None");
		}
		else
		{
			DATE_date_to_string(due_date, "%d-%b-%Y %H:%M", &pcDueDate); // convert the date to string 
		}

		bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\" ><b>Overview:</b></font>\r\n");
		bufferHTMLContent.append("<table  style=\"border-collapse:collapse;\"><tbody>\r\n"); //start table

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">\r\n");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Current Task: </font>");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(currentTask).append(" in ").append(jobName).append("</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Process Name: </font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(sRepairOrderID).append("-").append(sServiceType).append("-").append(sRepaiGroup).append("</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">HLA Part Number: </font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(sHLAPartNumber).append("</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">HLA Serial Number: </font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(sHLASerialNumber).append("</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Due Date: </font>");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(pcDueDate).append("</font>");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Comments:</font>");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append("(none)").append("</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Instructions:</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append("Go to your Worklist, expand Task to Perform, Select ").append(jobName).append("</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		
		bufferHTMLContent.append("</tbody></table>\r\n"); //end table
		bufferHTMLContent.append("<br><br>");

		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>This email was sent from Teamcenter.</b></font>");

		bufferHTMLContent.append("</body></html>\r\n");
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return bufferHTMLContent;
}

int is_same_hla_sn_and_hla_pn_complete_wf(tag_t tRepairOrderRev, bool &isSameHLASNAndPN) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	int iSolSecondaryCnt = 0;
	tag_t tSolRelationType = NULLTAG;
	tag_t* tpSolSecondaryObjects = NULLTAG;
	tag_t* tpSecondaryPartObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	tag_t tLLASerialRev = NULLTAG;
	tag_t tLLAPartNumberRev = NULLTAG;

	int iHLASerialCnt = 0;
	tag_t* tpHLASerialRevs = NULLTAG;
	tag_t tHLASerialNumRelationType = NULLTAG;
	int iHLAPartCnt = 0;
	tag_t* tpHLAPartRevs = NULLTAG;
	tag_t tHLAPartNumRelationType = NULLTAG;

	const char * __function__ = "is_same_hla_sn_and_hla_pn_complete_wf";
	TERADYNE_TRACE_ENTER();
	try {

		// get HLA Serial Number
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIRS_SERIAL_NO_REL, &tHLASerialNumRelationType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tHLASerialNumRelationType, &iHLASerialCnt, &tpHLASerialRevs), TD_LOG_ERROR_AND_THROW);
		if (iHLASerialCnt > 0) {
			for (int i = 0; i < iHLASerialCnt; i++) {
				tLLASerialRev = tpHLASerialRevs[i];
				// get HLA Part Number
				TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tHLAPartNumRelationType), TD_LOG_ERROR_AND_THROW);
				if (tHLAPartNumRelationType != NULLTAG) {
					TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpHLASerialRevs[i], tHLAPartNumRelationType, &iHLAPartCnt, &tpHLAPartRevs), TD_LOG_ERROR_AND_THROW);
				}
				if (iHLAPartCnt > 0) {
					for (int j = 0; j < iHLAPartCnt; j++) {
						tLLAPartNumberRev = tpHLAPartRevs[j];
					}
				}
			}
		}


		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tSolRelationType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tSolRelationType, &iSolSecondaryCnt, &tpSolSecondaryObjects), TD_LOG_ERROR_AND_THROW);
		if (iSolSecondaryCnt > 0) {
			for (int k = 0; k < iSolSecondaryCnt; k++)
			{
				char* cpSolutionitemId = NULL;
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSolSecondaryObjects[k], ITEM_ID, &cpSolutionitemId), TD_LOG_ERROR_AND_THROW);
				char* cpRevStamp = NULL;
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSolSecondaryObjects[k], TD7_REV_STAMP, &cpRevStamp), TD_LOG_ERROR_AND_THROW);
				char* cpHLASNitemId = NULL;
				char* cpHLAPNitemId = NULL;
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerialRev, ITEM_ID, &cpHLASNitemId), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLAPartNumberRev, ITEM_ID, &cpHLAPNitemId), TD_LOG_ERROR_AND_THROW);

				//if (tLLASerialRev == tpSolSecondaryObjects[k])
				if (tc_strcmp(cpSolutionitemId, cpHLASNitemId) == 0)
				{
					tag_t tPartRelationType = NULLTAG;
					TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_PART_SERIAL_REL, &tPartRelationType), TD_LOG_ERROR_AND_THROW);
					int iSecondaryPartCnt = 0;
					//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
					TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tpSolSecondaryObjects[k], tPartRelationType, &iSecondaryPartCnt, &tpSecondaryPartObjects), TD_LOG_ERROR_AND_THROW);

					if (iSecondaryPartCnt > 0) {

						for (int i = 0; i < iSecondaryPartCnt; i++)
						{
							char* cpSolutionPNitemId = NULL;
							TERADYNE_TRACE_CALL(AOM_ask_value_string(tpSecondaryPartObjects[i], ITEM_ID, &cpSolutionPNitemId), TD_LOG_ERROR_AND_THROW);
							//if (tLLAPartNumberRev == tpSecondaryPartObjects[i])
							if (tc_strcmp(cpSolutionPNitemId, cpHLAPNitemId) == 0)
							{
								
								isSameHLASNAndPN = TRUE;
							}
						}
					}
				}
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int release_all_serial_number_objects(tag_t tRepairOrderRev) {
	int iStatus = ITK_ok;
	bool bIsNull = false;
	int iSolSecondaryCnt = 0;
	int iIncomSecondaryCnt = 0;
	tag_t tSolRelationType = NULLTAG;
	tag_t tIncomRelationType = NULLTAG;
	tag_t* tpSolSecondaryObjects = NULLTAG;
	tag_t* tpIncomSecondaryObjects = NULLTAG;
	tag_t* tpSecondaryPartObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;
	tag_t tLLASerialRev = NULLTAG;
	tag_t tLLAPartNumberRev = NULLTAG;

	int iHLASerialCnt = 0;
	tag_t* tpHLASerialRevs = NULLTAG;
	tag_t tHLASerialNumRelationType = NULLTAG;
	int iHLAPartCnt = 0;
	tag_t* tpHLAPartRevs = NULLTAG;
	tag_t tHLAPartNumRelationType = NULLTAG;
	int iReleaseStatusCount = 0;
	tag_t* tReleaseStatusList = NULLTAG;
	tag_t tReleaseStatus = NULLTAG;
	vector<tag_t> vtSerialNumbers;

	const char * __function__ = "release_all_serial_number_objects";
	TERADYNE_TRACE_ENTER();
	try {

		//TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_INCOMING_CONFIG_REL, &tIncomRelationType));
		//TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tIncomRelationType, &iIncomSecondaryCnt, &tpIncomSecondaryObjects));
		//if (iIncomSecondaryCnt > 0) {
		//	for (int i = 0; i < iIncomSecondaryCnt; i++)
		//	{
		//		vtSerialNumbers.push_back(tpIncomSecondaryObjects[i]);
		//	}
		//}

		tag_t tPartRelationType = NULLTAG;
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_REPAIRS_SERIAL_NO_REL, &tPartRelationType), TD_LOG_ERROR_AND_THROW);
		int iSecondaryPartCnt = 0;
		//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tPartRelationType, &iSecondaryPartCnt, &tpSecondaryPartObjects), TD_LOG_ERROR_AND_THROW);

		if (iSecondaryPartCnt > 0) {

			for (int j = 0; j < iSecondaryPartCnt; j++)
			{
				//vtSerialNumbers.push_back(tpSecondaryPartObjects[i]);
				TERADYNE_TRACE_CALL(AOM_ask_value_tags(tpSecondaryPartObjects[j], RELEASE_STATUS_LIST, &iReleaseStatusCount, &tReleaseStatusList), TD_LOG_ERROR_AND_THROW);

				// Add Released status (Locked) for Incoming Objects
				if (iReleaseStatusCount == 0) {
					TERADYNE_TRACE_CALL(RELSTAT_create_release_status(TD_REL_STATUS_NAME, &tReleaseStatus), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(RELSTAT_add_release_status(tReleaseStatus, 1, &tpSecondaryPartObjects[j], true), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(AOM_save(tpSecondaryPartObjects[j]), TD_LOG_ERROR_AND_THROW);
				}
			}
		}


		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tSolRelationType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tSolRelationType, &iSolSecondaryCnt, &tpSolSecondaryObjects), TD_LOG_ERROR_AND_THROW);
		if (iSolSecondaryCnt > 0) {
			for (int i = 0; i < iSolSecondaryCnt; i++)
			{
				//vtSerialNumbers.push_back(tpSolSecondaryObjects[i]);
				TERADYNE_TRACE_CALL(AOM_ask_value_tags(tpSolSecondaryObjects[i], RELEASE_STATUS_LIST, &iReleaseStatusCount, &tReleaseStatusList), TD_LOG_ERROR_AND_THROW);

				// Add Released status (Locked) for Incoming Objects
				if (iReleaseStatusCount == 0) {
					TERADYNE_TRACE_CALL(RELSTAT_create_release_status(TD_REL_STATUS_NAME, &tReleaseStatus), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(RELSTAT_add_release_status(tReleaseStatus, 1, &tpSolSecondaryObjects[i], true), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(AOM_save(tpSolSecondaryObjects[i]), TD_LOG_ERROR_AND_THROW);
				}
			}
		}
	}
	catch (...)
	{

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;

}