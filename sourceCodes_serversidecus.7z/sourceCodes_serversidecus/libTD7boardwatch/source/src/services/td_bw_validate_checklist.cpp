#include <services/td_bw_validate_checklist.h>

int td_bw_validate_checklist_execute(string uid, string checkListName) {
	// TO DO
	int iStatus = ITK_ok;
	tag_t * tRunningWorkflows = NULLTAG;
	int iNumOfWorkflows = 0;
	tag_t tRepairOrderRev = NULLTAG;

	ITK__convert_uid_to_tag(uid.c_str(), &tRepairOrderRev);
	return iStatus;
}