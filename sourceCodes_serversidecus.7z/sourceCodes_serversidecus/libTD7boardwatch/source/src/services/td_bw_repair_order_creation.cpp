/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_repair_order_creation.cpp
#      Module          :           libTD7_teradyne_services.dll
#      Project         :           libTD7_teradyne_services
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  05-July-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <services/td_bw_repair_order_creation.h>

//Initiate Repair order creation
int td_bw_repair_order_creation_execute(vector<string> vvRoInput)
{
	int iStatus = ITK_ok;
	int strErroCode = 0;

	const char * __function__ = "td_bw_repair_order_creation_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(validate_and_start_process(vvRoInput, strErroCode), TD_LOG_ERROR_AND_THROW);
		if (strErroCode != 0) {
			EMH_clear_errors();
			iStatus = EMH_store_error_s1(EMH_severity_error, strErroCode, "");
			iStatus = strErroCode;
			throw iStatus;
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

//Read vector of values
int validate_and_start_process(vector<string> vRoInput, int &strErroCode)
{
	int iStatus = ITK_ok;
	int iLLACount = 0;
	int iRCount = 0;
	tag_t tCustomerRev = NULLTAG;
	tag_t tRepairOrderRev = NULLTAG;
	tag_t tCustomerOrderRev = NULLTAG;
	tag_t tSerialNum = NULLTAG;
	tag_t tSerialNumRev = NULLTAG;
	tag_t tQueriedDivPartRev = NULLTAG;
	tag_t tQueriedRepManagePart = NULLTAG;
	tag_t tQueriedRepManagePartRev = NULLTAG;
	tag_t tRepairMenagePartRev = NULLTAG;
	tag_t tRevisedObject = NULLTAG;
	tag_t tRepairOrder = NULLTAG;

	logical bValidClosureValue = false;

	const char * __function__ = "validate_and_start_process";
	TERADYNE_TRACE_ENTER();
	try
	{
		// Validate Repair Order Exist or Not.
		TERADYNE_TRACE_CALL(query_item(vRoInput[13], REPAIR_ORDER, iRCount, tRepairOrder), TD_LOG_ERROR_AND_THROW);

		if (tRepairOrder == NULLTAG) {
			//	TERADYNE_TRACE_AND_THROW( );
			string sCustID = "";
			sCustID = vRoInput[0].c_str();
			sCustID = sCustID.append("_");
			sCustID = sCustID.append(vRoInput[4]);

			TERADYNE_TRACE_CALL(get_customer_rev(sCustID, tCustomerRev), TD_LOG_ERROR_AND_THROW);


			if (tCustomerRev != NULLTAG) {

				// ## Requirement Change -> Customer Program property moved into Repair Order
				// store customer program attribute
				//BusinessObjectRef< Teamcenter::BusinessObject > boCustomerRev(tCustomerRev);
				//AcquireLock lockOnCustomerRev(boCustomerRev);

				//if (tc_strcmp(vRoInput[3].c_str(), "") != 0 && tc_strcmp(vRoInput[3].c_str(), NULL) != 0) {
				//	TERADYNE_TRACE_AND_THROW((boCustomerRev->setString(TD7_CUSTOMER_PROGRAM, vRoInput[3], false)));
				//}
				//TERADYNE_TRACE_AND_THROW(AOM_save(tCustomerRev));

				std::vector<string> vtRoRevProps;
				vtRoRevProps.push_back(vRoInput[7]);
				vtRoRevProps.push_back(vRoInput[15]);
				vtRoRevProps.push_back(vRoInput[14]);
				vtRoRevProps.push_back(vRoInput[5]);
				vtRoRevProps.push_back(vRoInput[6]);
				vtRoRevProps.push_back(vRoInput[12]);
				vtRoRevProps.push_back(vRoInput[16]);
				vtRoRevProps.push_back(vRoInput[3]);
				vtRoRevProps.push_back(vRoInput[10]);

				//TERADYNE_TRACE_AND_THROW(query_item(vRoInput[11], SERIALNUMBER, iLLACount, tSerialNum));
				TERADYNE_TRACE_CALL(query_lla_serial_number_ro_creation(vRoInput[11], SERIALNUMBER, iLLACount, tSerialNum), TD_LOG_ERROR_AND_THROW);

				if (tSerialNum != NULLTAG) {

					//TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tSerialNum, &tSerialNumRev));
					TERADYNE_TRACE_CALL(get_serial_number_revision_based_on_revstamp_with_ro_creation(tSerialNum, vRoInput[10], tSerialNumRev), TD_LOG_ERROR_AND_THROW);

					
					// Requirement Changed -> If Part Serial Number exists, no need closure validation
					TERADYNE_TRACE_CALL(validate_closure_value_of_existing_repair_orders(tSerialNum, bValidClosureValue), TD_LOG_ERROR_AND_THROW);

					if (!bValidClosureValue) {
						// get hla part number
						TERADYNE_TRACE_CALL(get_hla_part_number(vRoInput, tQueriedDivPartRev), TD_LOG_ERROR_AND_THROW);
						// validate sn is attached with same part number if not attach it and proceed else create sn with sn_partnum and proceed
						bool bObjectFound = false;
						TC_write_syslog("Checking if its attch with Div part");
						TERADYNE_TRACE_CALL(is_psn_attched_with_lla_ro_creation(tSerialNumRev, TD7_PART_SERIAL_REL, tQueriedDivPartRev, bObjectFound), TD_LOG_ERROR_AND_THROW);

						if (bObjectFound) {
							TC_write_syslog("Attaching to div part");
							//TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tSerialNumRev, tQueriedDivPartRev, TD7_PART_SERIAL_REL));
						}
						else {
							// create serial number and attach to newly created repmange part
							std::string sSerialNumber = "";
							std::string sPartNumber = "";
							int iLastChars = 5;
							sSerialNumber = sSerialNumber.append(vRoInput[11]);
							
							//requirement changes
							sPartNumber = removeSpecialCharactors(vRoInput[9]);
							//sPartNumber = sPartNumber.substr(0, 5);
							if (iLastChars < sPartNumber.length()) {
								sPartNumber = sPartNumber.substr(sPartNumber.length() - iLastChars);
							}
							sSerialNumber = sSerialNumber.append(sPartNumber);

							//sSerialNumber = sSerialNumber.append("_");
							//sSerialNumber = sSerialNumber.append(vRoInput[9]);
							TERADYNE_TRACE_CALL(create_attach_serial_number_ro_creation(vRoInput[11], sSerialNumber, vRoInput[10], tQueriedDivPartRev, tSerialNumRev), TD_LOG_ERROR_AND_THROW);
						}
					}
					else {
						//Display the error message if Customer not found.
						/**iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_VALIDATE_CLOSURE_VALUE_ERROR, vRoInput[11].c_str());
						iStatus = TERADYNE_VALIDATE_CLOSURE_VALUE_ERROR;
						throw iStatus;*/
						strErroCode = TERADYNE_VALIDATE_CLOSURE_VALUE_ERROR;
						return 0;
					}
				}
				else {

					// create a new sn and proceed the same logic what we have
					TERADYNE_TRACE_CALL(get_hla_part_number(vRoInput, tQueriedDivPartRev), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_attach_serial_number_ro_creation(vRoInput[11], vRoInput[11], vRoInput[10], tQueriedDivPartRev, tSerialNumRev), TD_LOG_ERROR_AND_THROW);

				}
				//create Repair order and attach serial number 
				TERADYNE_TRACE_CALL(create_repair_order(vRoInput[13], tSerialNumRev, vtRoRevProps, tRepairOrderRev), TD_LOG_ERROR_AND_THROW);

				char* cpOrderCat = NULL;
				char* cpRepairLocation = NULL;
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, TD7_BAT_ORDER_CATEGORY, &cpOrderCat), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, TD7_BAT_REPAIR_LOCATION, &cpRepairLocation), TD_LOG_ERROR_AND_THROW);

				//Create all checklists.

			if ((tc_strcmp(cpOrderCat, "Full Vendor Repair") == 0) && (tc_strcmp(cpRepairLocation, "Costa Rica") == 0)) {
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_PRE_INSPECTION_FORM, "Pre Inspection", "Pre Inspection_v1"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_PRE_TEST_FORM, "Pre Test", "Pre Test_v1"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_POST_TEST_FORM, "Post Test", "Post Test_v1"), TD_LOG_ERROR_AND_THROW);

				}
				else {
					
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_ENGG_EVALUATION_FORM, "Engg Evaluation", "Engg Evaluation_v1"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_PRE_INSPECTION_FORM, "Pre Inspection", "Pre Inspection_v1"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_PRE_TEST_FORM, "Pre Test", "Pre Test_v1"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_REPAIR_FORM, "Repair", "Repair_v1"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_REPAIR_VERIFICATION_FORM, "Repair Verification", "Repair Verification_v1"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_POST_TEST_FORM, "Post Test", "Post Test_v1"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_REPAIR_REWORK_FORM, "Rework", "Rework_v1"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_QUALITY_INSPECTION_FORM, "Final Inspection", "Final Inspection_v1"), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(create_checklist_form_ro_creation(tRepairOrderRev, TD7_VENDOR_REPAIR_FORM, "Vendor Repair", "Vendor Repair_v1"), TD_LOG_ERROR_AND_THROW);
				}
				//create customer order and attach to repair order & customer revision
				TERADYNE_TRACE_CALL(create_attach_customer_order(vRoInput[1], tRepairOrderRev, tCustomerRev, tCustomerOrderRev), TD_LOG_ERROR_AND_THROW);

				
				TERADYNE_TRACE_CALL(assign_repair_order_participants(tRepairOrderRev, "TD7RepairAdminSpecialist", "REPAIR ADMIN.Business ADMIN.Teradyne", "Admin"), TD_LOG_ERROR_AND_THROW);
				
				//requirement changes - Enable auto complete for Repair Routing Stage.
				TERADYNE_TRACE_CALL(assign_repair_order_participants(tRepairOrderRev, "TD7RoutingSpecialist", "GSO.Teradyne", "Logistics Handler"), TD_LOG_ERROR_AND_THROW);
				
				TERADYNE_TRACE_CALL(assign_repair_order_participants(tRepairOrderRev, "TD7VendorRepairSpecialist", "GSO.Teradyne", "Vendor Repair Recorder"), TD_LOG_ERROR_AND_THROW);
				//TERADYNE_TRACE_CALL(assign_repair_order_participants(tRepairOrderRev, "TD7EnggEvaluationSpecialist", "GSO.Teradyne", "Test Engineer"));
				//TERADYNE_TRACE_CALL(assign_repair_order_participants(tRepairOrderRev, "TD7FinalInspectSpecialist", "GSO.Teradyne", "Quality Inspector"));
				TERADYNE_TRACE_CALL(assign_repair_order_participants(tRepairOrderRev, "TD7ReworkSpecialist", "GSO.Teradyne", "Rework Technician"), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(assign_project_team(tRepairOrderRev, tQueriedDivPartRev), TD_LOG_ERROR_AND_THROW);

				//initiate WF on repair order
				TERADYNE_TRACE_CALL(initiate_workflow_on_repair_order(WF_TERADYNE_REPAIR_ORDER, tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
			}
			else {
				//Display the error message if Customer not found.
				/**iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_CUSTOMER_NOT_FOUND, sCustID.c_str());
				iStatus = TERADYNE_CUSTOMER_NOT_FOUND;
				throw iStatus;*/
				strErroCode = TERADYNE_CUSTOMER_NOT_FOUND;
				return 0;
			}
		}
		else {
			//Display the error message if Repair Order exists.
			/**iStatus = EMH_store_error_s1(EMH_severity_error, TERADYNE_REPAIR_ORDER_ALREADY_EXISTS, vRoInput[13].c_str());
			iStatus = TERADYNE_REPAIR_ORDER_ALREADY_EXISTS;
			throw iStatus;*/
			strErroCode = TERADYNE_REPAIR_ORDER_ALREADY_EXISTS;
			return 0;
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int query_lla_serial_number_ro_creation(string sLLASerialNumberID, string sType, int iCount, tag_t& tSerialNum)
{
	int iStatus = ITK_ok;

	const char * __function__ = "query_lla_serial_number_ro_creation";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tSavedQuery = NULLTAG;

		if (!sLLASerialNumberID.empty()) {
			iStatus = QRY_find2(QUERY_ITEM, &tSavedQuery);
			if (tSavedQuery != NULLTAG)
			{

				char * cpEntries[] = { QUERY_INPUT_NAME, QUERY_INPUT_TYPE };
				const char * cpValues[] = { sLLASerialNumberID.c_str(), sType.c_str() };

				int iFound = 0;
				tag_t* tpResults = NULL;
				TERADYNE_TRACE_CALL(QRY_execute(tSavedQuery, 2, cpEntries, (char**)cpValues, &iFound, &tpResults), TD_LOG_ERROR_AND_THROW);

				if (iFound > 0)
				{
					tSerialNum = tpResults[0];
				}
				TERADYNE_MEM_FREE(tpResults);
				//MEM_FREE(cpEntries);
				//MEM_FREE(cpValues);
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;

}

int get_serial_number_revision_based_on_revstamp_with_ro_creation(tag_t tLLASerial, string sLLARevStamp, tag_t& tLLASerialRev) {
	int iStatus = ITK_ok;
	char* cpSerialNumberType = NULL;
	char* cpRevStamp = NULL;
	int iSerialNumRevisionsCount = 0;
	tag_t* tSerialNumberRevisions = NULLTAG;
	tag_t tSerialNumRev = NULLTAG;
	tag_t tLatestRevTag = NULLTAG;
	int iReleaseStatusCount = 0;
	tag_t* tReleaseStatusList = NULLTAG;

	const char * __function__ = "get_serial_number_revision_based_on_revstamp_with_ro_creation";
	TERADYNE_TRACE_ENTER();
	try {
		char* itemid = NULL;
		char* itemRevid = NULL;
		TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerial, ITEM_ID, &itemid), TD_LOG_ERROR_AND_THROW);
		
		//TERADYNE_TRACE_CALL(ITEM_find_item(sPartNumber.c_str(), &tDivisionalPart));
		if (tLLASerial != NULLTAG) {
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tLLASerial, OBJECT_TYPE, &cpSerialNumberType), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(cpSerialNumberType, TD7_PART_SERIAL_NUM) == 0) {
				TERADYNE_TRACE_CALL(ITEM_list_all_revs(tLLASerial, &iSerialNumRevisionsCount, &tSerialNumberRevisions), TD_LOG_ERROR_AND_THROW);
				if (iSerialNumRevisionsCount > 0) {
					for (int i = 0; i < iSerialNumRevisionsCount; i++) {
						TERADYNE_TRACE_CALL(AOM_ask_value_string(tSerialNumberRevisions[i], ITEM_REVISION_ID, &itemRevid), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(AOM_ask_value_string(tSerialNumberRevisions[i], TD7_REV_STAMP, &cpRevStamp), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(sLLARevStamp.c_str(), cpRevStamp) == 0) {
							tSerialNumRev = tSerialNumberRevisions[i];
							break;
						}
					}
					// if there is no Rev Stamp matches, get the latest revision
					if (tSerialNumRev == NULLTAG) {
						tag_t tRevisedObject = NULLTAG;
						//TERADYNE_TRACE_CALL(revise_object(tLLASerial, tRevisedObject));
						//TERADYNE_TRACE_CALL(remove_secondary_objects(tRevisedObject, TD7_REPAIRS_REL));
						TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tLLASerial, &tRevisedObject), TD_LOG_ERROR_AND_THROW);
						tSerialNumRev = tRevisedObject;
					}
					tLLASerialRev = tSerialNumRev;
				}
			}
		}

	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int get_hla_part_number(vector<string> vRoInput, tag_t &tQueriedDivPartRev) {

	int iStatus = ITK_ok;
	int iDivCount = 0;
	int iCommercialPartRevCount = 0;
	int iRepairManagedPartRevCount = 0;

	tag_t tCustomerRev = NULLTAG;
	tag_t tRepairOrderRev = NULLTAG;
	tag_t tCustomerOrderRev = NULLTAG;
	tag_t tSerialNum = NULLTAG;
	tag_t tSerialNumRev = NULLTAG;
	tag_t tDivPartRev = NULLTAG;
	tag_t tQueriedRepManagePart = NULLTAG;
	tag_t tQueriedRepManagePartRev = NULLTAG;
	tag_t tRepairMenagePartRev = NULLTAG;
	tag_t tRevisedObject = NULLTAG;
	tag_t tRepairOrder = NULLTAG;

	tag_t tCommercialPart = NULLTAG;
	tag_t tCommercilaPartRev = NULLTAG;
	tag_t tRepairManagedPartRev = NULLTAG;
	tag_t tLatestRevTag = NULLTAG;
	tag_t* tCommercilaPartRevs = NULLTAG;
	tag_t* tRepairManagedPartRevs = NULLTAG;
	char* cpCommercialType = NULL;
	char* cpCommercialRevType = NULL;

	// get the div part repair group
	int iProjectCount = 0;
	tag_t* tProjectList = NULLTAG;

	const char * __function__ = "get_hla_part_number";
	TERADYNE_TRACE_ENTER();
	try {
		//TERADYNE_TRACE_CALL(query_div_and_rep_mang_part_revs(vRoInput[9], vRoInput[10], TERADYNE_DIVISIONAL_PART_REV, iDivCount, tDivPartRev));

		TERADYNE_TRACE_CALL(get_divisionla_part_with_revstamp_create_repairorder(vRoInput[9], vRoInput[10], tDivPartRev), TD_LOG_ERROR_AND_THROW);
		// Validate Commercial Part.
		if (tDivPartRev == NULLTAG) {

			TERADYNE_TRACE_CALL(ITEM_find_item(vRoInput[9].c_str(), &tCommercialPart), TD_LOG_ERROR_AND_THROW);

			if (tCommercialPart != NULLTAG) {
				TERADYNE_TRACE_CALL(AOM_ask_value_string(tCommercialPart, OBJECT_TYPE, &cpCommercialType), TD_LOG_ERROR_AND_THROW);
				if (tc_strcmp(cpCommercialType, TD4_COMMERCIAL_PART) == 0) {

					TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tCommercialPart, &tLatestRevTag), TD_LOG_ERROR_AND_THROW);
					tDivPartRev = tLatestRevTag;
				}
				
			}
		}

		if (tDivPartRev == NULLTAG) {
			int iRepCount = 0;

			TERADYNE_TRACE_CALL(query_item(vRoInput[9], REP_MANAGED_PART, iRepCount, tQueriedRepManagePart), TD_LOG_ERROR_AND_THROW);
			if (tQueriedRepManagePart != NULLTAG) {
				TERADYNE_TRACE_CALL(ITEM_list_all_revs(tQueriedRepManagePart, &iRepairManagedPartRevCount, &tRepairManagedPartRevs), TD_LOG_ERROR_AND_THROW);
				if (iRepairManagedPartRevCount > 0) {
					char* cpRevStamp = NULL;
					for (int i = 0; i < iRepairManagedPartRevCount; i++) {
						TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairManagedPartRevs[i], TD7_REV_STAMP, &cpRevStamp), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(vRoInput[10].c_str(), cpRevStamp) == 0) {
							tRepairManagedPartRev = tRepairManagedPartRevs[i];
						}
						/**else {
							revise_object(tQueriedRepManagePart, tRevisedObject);
							tRepairManagedPartRev = tRevisedObject;
						}*/
					}
					if (tRepairManagedPartRev == NULLTAG) {
						TERADYNE_TRACE_CALL(revise_object(tQueriedRepManagePart, tRevisedObject), TD_LOG_ERROR_AND_THROW);
						// Update repair revision property for Repair Managed Part
						BusinessObjectRef< Teamcenter::BusinessObject > boRepairManagedPartRev(tRevisedObject);
						AcquireLock lockOnLLApartNum(boRepairManagedPartRev);

						if (tc_strcmp(vRoInput[10].c_str(), "") != 0 && tc_strcmp(vRoInput[10].c_str(), NULL) != 0) {
							TERADYNE_TRACE_CALL((boRepairManagedPartRev->setString(TD7_REV_STAMP, vRoInput[10], false)), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(AOM_save(tRevisedObject), TD_LOG_ERROR_AND_THROW);
						}
						tRepairManagedPartRev = tRevisedObject;
					}
					tDivPartRev = tRepairManagedPartRev;
				}

				// Update repair revision property for Repair Managed Part
				/**BusinessObjectRef< Teamcenter::BusinessObject > boRepairManagedPartRev(tDivPartRev);
				AcquireLock lockOnRepairManagedPart(boRepairManagedPartRev);

				if (tc_strcmp(vRoInput[10].c_str(), "") != 0 && tc_strcmp(vRoInput[10].c_str(), NULL) != 0) {
					TERADYNE_TRACE_CALL((boRepairManagedPartRev->setString(TD7_REV_STAMP, vRoInput[10], false)));
				}
				TERADYNE_TRACE_AND_THROW(AOM_save(tDivPartRev));*/
			}
		}
		if (tDivPartRev == NULLTAG) {
			tag_t tRepManagePartRev = NULLTAG;
			TERADYNE_TRACE_CALL(create_repair_managed_part(vRoInput[9], vRoInput[10], vRoInput[8], tRepManagePartRev), TD_LOG_ERROR_AND_THROW);

			if (tRepManagePartRev != NULLTAG) {
				// Update repair revision property for Repair Managed Part
				BusinessObjectRef< Teamcenter::BusinessObject > boRepairManagedPartRev(tRepManagePartRev);
				AcquireLock lockOnLLApartNum(boRepairManagedPartRev);

				if (tc_strcmp(vRoInput[10].c_str(), "") != 0 && tc_strcmp(vRoInput[10].c_str(), NULL) != 0) {
					TERADYNE_TRACE_CALL((boRepairManagedPartRev->setString(TD7_REV_STAMP, vRoInput[10], false)), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(AOM_save(tRepManagePartRev), TD_LOG_ERROR_AND_THROW);
				}
				tDivPartRev = tRepManagePartRev;
			}
		}

		// assign UNKNOWN repair group into created repair managed part
		tag_t tDivPart = NULLTAG;
		TERADYNE_TRACE_CALL(ITEM_ask_item_of_rev(tDivPartRev, &tDivPart), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(AOM_ask_value_tags(tDivPart, TD7_PROJECT_LIST, &iProjectCount, &tProjectList), TD_LOG_ERROR_AND_THROW);
		if (iProjectCount == 0) {
			tag_t tUnknownProjectTag = NULLTAG;
			TERADYNE_TRACE_CALL(PROJ_find("UNKNOWN_01", &tUnknownProjectTag), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = PROJ_assign_objects(1, &tUnknownProjectTag, 1, &tDivPart), TD_LOG_ERROR_AND_THROW);
		}


		tQueriedDivPartRev = tDivPartRev;
	}
	catch (...)
	{
	}
	TERADYNE_MEM_FREE(cpCommercialType);
	TERADYNE_MEM_FREE(cpCommercialRevType);
	TERADYNE_MEM_FREE(tProjectList);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int get_divisionla_part_with_revstamp_create_repairorder(string sPartNumber, string sPartRevStamp, tag_t& tQueriedPartRev) {
	int iStatus = ITK_ok;
	int iDivisionalPartRevCount = 0;
	char* cpDivisionalPartType = NULL;
	char* cpRevStamp = NULL;
	tag_t tDivisionalPart = NULLTAG;
	tag_t* tDivisionalPartRevs = NULLTAG;
	tag_t tLatestRevTag = NULLTAG;
	tag_t tDivPartRevTag = NULLTAG;

	const char * __function__ = "get_divisionla_part_with_revstamp_create_repairorder";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(ITEM_find_item(sPartNumber.c_str(), &tDivisionalPart), TD_LOG_ERROR_AND_THROW);
		if (tDivisionalPart != NULLTAG) {
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tDivisionalPart, OBJECT_TYPE, &cpDivisionalPartType), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(cpDivisionalPartType, TD4_DIVISIONAL_PART) == 0) {
				TERADYNE_TRACE_CALL(ITEM_list_all_revs(tDivisionalPart, &iDivisionalPartRevCount, &tDivisionalPartRevs), TD_LOG_ERROR_AND_THROW);
				if (iDivisionalPartRevCount > 0) {
					for (int i = 0; i < iDivisionalPartRevCount; i++) {
						TERADYNE_TRACE_CALL(AOM_ask_value_string(tDivisionalPartRevs[i], TD4_TERADYNE_REV_STAMP, &cpRevStamp), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(sPartRevStamp.c_str(), cpRevStamp) == 0) {
							tDivPartRevTag = tDivisionalPartRevs[i];
						}
					}
					// if there is no Rev Stamp matches, get the latest revision
					if (tDivPartRevTag == NULLTAG) {
						TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tDivisionalPart, &tLatestRevTag), TD_LOG_ERROR_AND_THROW);
						tDivPartRevTag = tLatestRevTag;
					}
					tQueriedPartRev = tDivPartRevTag;
				}
			}
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int is_psn_attched_with_lla_ro_creation(tag_t tPrimaryObj, string sRelation, tag_t tSecondaryObj, bool &bObjectFound) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "is_psn_attched_with_lla_ro_creation";
	TERADYNE_TRACE_ENTER();
	try {
		if (tSecondaryObj == NULLTAG || sRelation.empty() || tPrimaryObj == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;
		char * itemId = NULL;
		char * itemrEVId = NULL;
		AOM_ask_value_string(tSecondaryObj, ITEM_ID, &itemId);
		AOM_ask_value_string(tSecondaryObj, ITEM_REVISION_ID, &itemrEVId);
		TERADYNE_TRACE_AND_THROW(iStatus = GRM_find_relation_type(sRelation.c_str(), &tRelationType));
		int iSecondaryCnt = 0;
		//GRM_find_relation(tPrimaryObj, tSecondaryObj, tRelationType, &tRelation);
		TERADYNE_TRACE_AND_THROW(GRM_list_secondary_objects_only(tPrimaryObj, tRelationType, &iSecondaryCnt, &tpSecondaryObjects));

		if (iSecondaryCnt > 0) {
			//bObjectFound = TRUE;
		//}
			for (int i = 0; i < iSecondaryCnt; i++)
			{
				if (tSecondaryObj == tpSecondaryObjects[i])
				{
					bObjectFound = TRUE;
				}
			}
		}
	}
	catch (...)
	{
	}
	TERADYNE_MEM_FREE(tpSecondaryObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int attach_commercial_part(tag_t tCommercialPart, tag_t tDivPartRev, tag_t tRepManagedPartRev) {

	int iStatus = ITK_ok;
	char* cpPartNumber = NULL;
	const char * __function__ = "attach_commercial_part";
	TERADYNE_TRACE_ENTER();
	try {

		TERADYNE_TRACE_CALL(AOM_ask_value_string(tCommercialPart, TD7_PART_NUMBER, &cpPartNumber), TD_LOG_ERROR_AND_THROW);
		if (tc_strcmp(cpPartNumber, "") == 0) {
			//TERADYNE_TRACE_AND_THROW(query_item(vRoInput[11], COMMERCIAL_PART, iLLACount, tSerialNum));
			if (tDivPartRev != NULLTAG) {
				teradyne_attach_with_relation(tCommercialPart, tDivPartRev, TD7_PART_SERIAL_REL);
			}
			else if (tRepManagedPartRev != NULLTAG) {
				teradyne_attach_with_relation(tCommercialPart, tRepManagedPartRev, TD7_PART_SERIAL_REL);
			}

		}
	}
	catch (exception ex) {

	}
	TERADYNE_MEM_FREE(cpPartNumber);
	TERADYNE_TRACE_LEAVE();
	return iStatus;

}
//check customer availibility
int get_customer_rev(string sCustomerId, tag_t& tCustomerRev)
{
	int iStatus = ITK_ok;

	const char * __function__ = "get_customer_rev";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tCustomer = NULLTAG;

		if (!sCustomerId.empty())
		{
			TERADYNE_TRACE_AND_THROW(ITEM_find_item(sCustomerId.c_str(), &tCustomer));

			if (tCustomer != NULLTAG)
			{
				tag_t tTemplateRevTag = NULLTAG;
				TERADYNE_TRACE_AND_THROW(ITEM_ask_latest_rev(tCustomer, &tCustomerRev));
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

//create repair managed part
int create_repair_managed_part(string sPartNumber, string sPartNumberRev, string sPartDesc, tag_t& tRepManagePartRev)
{
	int iStatus = ITK_ok;
	tag_t   tItemTypeTag = NULLTAG;
	tag_t   tItemRevTypeTag = NULLTAG;
	tag_t   tNewItem = NULLTAG;
	bool	isNull = false;

	const char * __function__ = "create_repair_managed_part";
	TERADYNE_TRACE_ENTER();
	try
	{
		if (!sPartNumber.empty()) {

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_REPAIR_MANAGED_PART, TD7_REPAIR_MANAGED_PART, &tItemTypeTag), TD_LOG_ERROR_AND_THROW);

			tag_t   tItemCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemTypeTag, &tItemCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sPartNumber.c_str()), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, sPartDesc.c_str()), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_REPAIR_MANAGED_PART_REVISION, TD7_REPAIR_MANAGED_PART_REVISION, &tItemRevTypeTag), TD_LOG_ERROR_AND_THROW);

			tag_t   tItemRevCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemRevTypeTag, &tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, "A"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewItem), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tNewItem), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tNewItem, false), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tNewItem, &tRepManagePartRev), TD_LOG_ERROR_AND_THROW);

			// Update repair revision property for Repair Managed Part
			BusinessObjectRef< Teamcenter::BusinessObject > boRepairManagedPartRev(tRepManagePartRev);
			AcquireLock lockOnRepairManagedPartpartNum(boRepairManagedPartRev);

			if (tc_strcmp(sPartNumberRev.c_str(), "") != 0 && tc_strcmp(sPartNumberRev.c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boRepairManagedPartRev->setString(TD7_REPAIR_REVISION, sPartNumberRev, false)), TD_LOG_ERROR_AND_THROW);
			}
			TERADYNE_TRACE_CALL(AOM_save(tRepManagePartRev), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_save(tNewItem), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

//create hla serial number
int create_attach_serial_number_ro_creation(string sSerialNumberId, string sObjectName, string sLLARevStamp, tag_t tPartRev, tag_t& tSerialNumRev)
{
	int iStatus = ITK_ok;

	tag_t   tItemTypeTag = NULLTAG;
	tag_t   tItemRevTypeTag = NULLTAG;
	tag_t   tNewItem = NULLTAG;

	const char * __function__ = "create_attach_serial_number_ro_creation";
	TERADYNE_TRACE_ENTER();
	try
	{
		if (!sSerialNumberId.empty()) {

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_PART_SERIAL_NUM, TD7_PART_SERIAL_NUM, &tItemTypeTag), TD_LOG_ERROR_AND_THROW);

			tag_t   tItemCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemTypeTag, &tItemCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sSerialNumberId.c_str()), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, sObjectName.c_str()), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_PART_SERIAL_NUM_REVISION, TD7_PART_SERIAL_NUM_REVISION, &tItemRevTypeTag), TD_LOG_ERROR_AND_THROW);
			tag_t   tItemRevCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemRevTypeTag, &tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemRevCreateInput, ITEM_REVISION_ID, "A"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_tag(tItemCreateInput, REVISION, tItemRevCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewItem), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tNewItem), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tNewItem, false), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tNewItem, &tSerialNumRev), TD_LOG_ERROR_AND_THROW);

			// Update Rev Stamp for HLA Serial Number
			BusinessObjectRef< Teamcenter::BusinessObject > boSerialNumRev(tSerialNumRev);
			AcquireLock lockOnSerialNum(boSerialNumRev);

			if (tc_strcmp(sLLARevStamp.c_str(), "") != 0 && tc_strcmp(sLLARevStamp.c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boSerialNumRev->setString(TD7_REV_STAMP, sLLARevStamp, false)), TD_LOG_ERROR_AND_THROW);
			}
			TERADYNE_TRACE_CALL(AOM_save(tSerialNumRev), TD_LOG_ERROR_AND_THROW);

			if (tSerialNumRev != NULLTAG && tPartRev != NULLTAG) {
				tag_t tRelationType = NULLTAG;
				TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_PART_SERIAL_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);

				tag_t tRelation = NULLTAG;
				TERADYNE_TRACE_CALL(GRM_create_relation(tSerialNumRev, tPartRev, tRelationType, NULLTAG, &tRelation), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(GRM_save_relation(tRelation), TD_LOG_ERROR_AND_THROW);

			}

		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

//create repair order
int create_repair_order(string sRepairOrderNumber, tag_t tSerialNumberRev, vector<string> vtRoRevProps, tag_t& tRepairOrderRev)
{
	int iStatus = ITK_ok;
	tag_t   tItemTypeTag = NULLTAG;
	tag_t   tNewItem = NULLTAG;

	const char * __function__ = "create_repair_order";
	TERADYNE_TRACE_ENTER();
	try
	{
		if (!sRepairOrderNumber.empty()) {

			TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_REPAIR_ORDER, TD7_REPAIR_ORDER, &tItemTypeTag), TD_LOG_ERROR_AND_THROW);

			tag_t   tItemCreateInput = NULLTAG;
			TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemTypeTag, &tItemCreateInput), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sRepairOrderNumber.c_str()), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, "Repair Order"), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewItem), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tNewItem), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tNewItem, false), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tNewItem, &tRepairOrderRev), TD_LOG_ERROR_AND_THROW);

			BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);
			AcquireLock lockOnRepairOrderRev(tRepairOrderRev);

			if (tc_strcmp(vtRoRevProps[3].c_str(), "") != 0 && tc_strcmp(vtRoRevProps[3].c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_BAT_ORDER_CATEGORY, vtRoRevProps[3], false)), TD_LOG_ERROR_AND_THROW);
			}
			if (tc_strcmp(vtRoRevProps[0].c_str(), "") != 0 && tc_strcmp(vtRoRevProps[0].c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_BAT_ORDER_TYPE, vtRoRevProps[0], false)), TD_LOG_ERROR_AND_THROW);
			}

			if (tc_strcmp(vtRoRevProps[1].c_str(), "") != 0 && tc_strcmp(vtRoRevProps[1].c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_BAT_SERVICE_TYPE, vtRoRevProps[1], false)), TD_LOG_ERROR_AND_THROW);
			}

			if (tc_strcmp(vtRoRevProps[2].c_str(), "") != 0 && tc_strcmp(vtRoRevProps[2].c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_SPR_FLAG, vtRoRevProps[2], false)), TD_LOG_ERROR_AND_THROW);
			}

			//if (tc_strcmp(vtRoRevProps[3].c_str(), "") != 0 && tc_strcmp(vtRoRevProps[3].c_str(), NULL) != 0) {
			//	TERADYNE_TRACE_AND_THROW((boRepairOrderRev->setString(TD7_E_SUSPENSE_FLAG, vtRoRevProps[3], false)));
			//}

			if (tc_strcmp(vtRoRevProps[5].c_str(), "") != 0 && tc_strcmp(vtRoRevProps[5].c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_BAT_REPAIR_LOCATION, vtRoRevProps[5], false)), TD_LOG_ERROR_AND_THROW);
			}

			if (tc_strcmp(vtRoRevProps[4].c_str(), "") != 0 && tc_strcmp(vtRoRevProps[4].c_str(), NULL) != 0) {
				date_t dDateProp;
				TERADYNE_TRACE_CALL(DATE_convert_formatted_string_to_date(vtRoRevProps[4].c_str(), "%d-%b-%Y %H:%M", false, false, &dDateProp), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL((boRepairOrderRev->setDate(TD7_MERLIN_ORDER_CREATION, dDateProp, false)), TD_LOG_ERROR_AND_THROW);
			}

			if (tc_strcmp(vtRoRevProps[6].c_str(), "") != 0 && tc_strcmp(vtRoRevProps[6].c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_SYS_SERIAL_NUMBER, vtRoRevProps[6], false)), TD_LOG_ERROR_AND_THROW);
			}

			if (tc_strcmp(vtRoRevProps[7].c_str(), "") != 0 && tc_strcmp(vtRoRevProps[7].c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_CUSTOMER_PGM, vtRoRevProps[7], false)), TD_LOG_ERROR_AND_THROW);
			}

			if (tc_strcmp(vtRoRevProps[8].c_str(), "") != 0 && tc_strcmp(vtRoRevProps[8].c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_REPAIR_ORDER_REV_STAMP, vtRoRevProps[8], false)), TD_LOG_ERROR_AND_THROW);
			}

			// Initial Value for Checklist property
			TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_BAT_CHECKLIST, "Pre Inspection", false)), TD_LOG_ERROR_AND_THROW);

			
			// Create an d attach template dataset for Debug and Repair 
			//tag_t tQueriedDataset;

			//query_to_attach_template_excel(TEMPLATE_DATASET, tQueriedDataset);

			//if (tQueriedDataset != NULLTAG) {

			//	string sDatasetName = "";
			//	sDatasetName = sRepairOrderNumber.c_str();
			//	sDatasetName = sDatasetName.append("_");
			//	sDatasetName = sDatasetName.append("Checklist");

			//	tag_t tCopiedDataset;
			//	WSOM_copy(tQueriedDataset, sDatasetName.c_str(), &tCopiedDataset);

			//	teradyne_attach_with_relation(tRepairOrderRev, tCopiedDataset, IMAN_SPECIFICATION_RELATION);
			//}

			TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);

			char* cpSerialNumberStatus = NULL;
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tSerialNumberRev, TD7_SERIAL_NUMBER_STATUS, &cpSerialNumberStatus), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(cpSerialNumberStatus, "Swapped") != 0) {
				// Update HLA SerialNumber Status property for Part Serial Number.
				BusinessObjectRef< Teamcenter::BusinessObject > boSerialNumRev(tSerialNumberRev);
				AcquireLock lockOnLLApartNum(boSerialNumRev);

				TERADYNE_TRACE_CALL((boSerialNumRev->setString(TD7_SERIAL_NUMBER_STATUS, "Defective", false)), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_save(tSerialNumberRev), TD_LOG_ERROR_AND_THROW);
			}

			if (tRepairOrderRev != NULLTAG && tSerialNumberRev != NULLTAG) {
				TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tRepairOrderRev, tSerialNumberRev, TD7_REPAIR_SERIAL_NO_REL), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tRepairOrderRev, tSerialNumberRev, TD7_OUTGOING_SERIAL_REL), TD_LOG_ERROR_AND_THROW);
			}

		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

//create customer order
int create_attach_customer_order(string sCustomerOrderNumber, tag_t tRepairOrderRev, tag_t tCustomerRev, tag_t& tCustomerOrderRev)
{
	int iStatus = ITK_ok;
	tag_t   tItemTypeTag = NULLTAG;
	tag_t   tNewItem = NULLTAG;
	//tag_t tCustomerItem = NULLTAG;

	const char * __function__ = "create_attach_customer_order";
	TERADYNE_TRACE_ENTER();
	try
	{
		if (!sCustomerOrderNumber.empty()) {

			//TERADYNE_TRACE_AND_THROW(ITEM_find_item(sCustomerOrderNumber.c_str(), &tCustomerItem));
			int iCustomerOrderCount = 0;
			tag_t tCoustomerOrder = NULLTAG;
			TERADYNE_TRACE_CALL(query_item(sCustomerOrderNumber, CUSTOMER_ORDER, iCustomerOrderCount, tCoustomerOrder), TD_LOG_ERROR_AND_THROW);

			if (tCoustomerOrder == NULLTAG) {

				TERADYNE_TRACE_CALL(TCTYPE_find_type(TD7_CUSTOMER_ORDER, NULL, &tItemTypeTag), TD_LOG_ERROR_AND_THROW);

				tag_t   tItemCreateInput = NULLTAG;
				TERADYNE_TRACE_CALL(TCTYPE_construct_create_input(tItemTypeTag, &tItemCreateInput), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, ITEM_ID, sCustomerOrderNumber.c_str()), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(AOM_set_value_string(tItemCreateInput, OBJECT_NAME, CUSTOMER_ORDER), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(TCTYPE_create_object(tItemCreateInput, &tNewItem), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tNewItem), TD_LOG_ERROR_AND_THROW);

				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tNewItem, false), TD_LOG_ERROR_AND_THROW);
			}
			else {
				tNewItem = tCoustomerOrder;
			}

			TERADYNE_TRACE_CALL(iStatus = ITEM_ask_latest_rev(tNewItem, &tCustomerOrderRev), TD_LOG_ERROR_AND_THROW);

			if (tCustomerOrderRev != NULLTAG && tRepairOrderRev != NULLTAG) {
				TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tRepairOrderRev, tCustomerOrderRev, TD7_CREATED_BY_CUSTOMER_ORDER), TD_LOG_ERROR_AND_THROW);
			}

			if (tCustomerOrderRev != NULLTAG && tCustomerRev != NULLTAG) {

				TERADYNE_TRACE_CALL(teradyne_attach_with_relation(tCustomerOrderRev, tCustomerRev, TD7_CUSTOMER_ORDER_REL), TD_LOG_ERROR_AND_THROW);
			}
		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

//initiate workflow on repair order
int initiate_workflow_on_repair_order(string sWorkflowName, tag_t tRepairOrderRev)
{
	int iStatus = ITK_ok;
	tag_t tRepairOrdWF = NULLTAG;
	int	attach_types[1] = { 1 };
	tag_t tROprocess = NULLTAG;

	const char * __function__ = "initiate_workflow_on_repair_order";
	TERADYNE_TRACE_ENTER();
	try
	{

		TERADYNE_TRACE_CALL(EPM_find_process_template(WF_TERADYNE_REPAIR_ORDER, &tRepairOrdWF), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(EPM_create_process(WF_TERADYNE_REPAIR_ORDER, WF_TERADYNE_REPAIR_ORDER, tRepairOrdWF, 1, &tRepairOrderRev, attach_types, &tROprocess), TD_LOG_ERROR_AND_THROW);

	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int query_to_attach_template_excel(string datasetName, tag_t& tQueriedDataSet)
{
	int iStatus = ITK_ok;

	const char * __function__ = "query_to_attach_template_excel";
	TERADYNE_TRACE_ENTER();
	try
	{
		tag_t tSavedQuery = NULLTAG;

		iStatus = QRY_find2(QUERY_DATASET, &tSavedQuery);
		if (tSavedQuery != NULLTAG)
		{

			char * cpEntries[] = { QUERY_DATASET_NAME };
			const char * cpValues[] = { datasetName.c_str() };

			int iFound = 0;
			tag_t* tpResults = NULL;
			TERADYNE_TRACE_CALL(QRY_execute(tSavedQuery, 1, cpEntries, (char**)cpValues, &iFound, &tpResults), TD_LOG_ERROR_AND_THROW);

			if (iFound > 0)
			{
				tQueriedDataSet = tpResults[0];
			}
			TERADYNE_MEM_FREE(tpResults);
			//MEM_FREE(cpEntries);
			//MEM_FREE(cpValues);

		}
	}
	catch (...)
	{

	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;

}

int assign_repair_order_participants(tag_t tRepairOrderRev, char* sParticipantName, char* sGroupName, char* sRoleName) {

	int iStatus = ITK_ok;
	int iParticipant = 0;
	int iMemberCount = 0;
	tag_t tParticipant = NULLTAG;
	tag_t tGroup = NULLTAG;
	tag_t tRole = NULLTAG;
	tag_t tResourcePool = NULLTAG;
	tag_t* tParticipantTypeList = NULLTAG;
	tag_t* tGroupMemberList = NULLTAG;
	tag_t tParticipantList = NULLTAG;
	tag_t* tAssigneeList = NULLTAG;

	tag_t tUserTag = NULLTAG;
	tag_t tPersonTag = NULLTAG;
	char * cpRoleName = NULL;
	char * cCountry = NULL;
	char * cpUserId = NULL;
	bool bIsNull = false;
	vector<tag_t> vsEEAssignee;
	vector<tag_t> vsReworkAssignee;
	//vector<tag_t> vsFinalInsAssignee;

	const char * __function__ = "assign_repair_order_participants";
	TERADYNE_TRACE_ENTER();
	try {
		// Get Repair Location from Repair Order Object
		BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderBORef(tRepairOrderRev);
		std::string sRepairLocation("");
		TERADYNE_TRACE_CALL(tRepairOrderBORef->getString(TD7_BAT_REPAIR_LOCATION, sRepairLocation, bIsNull), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype(sParticipantName, &tParticipant), TD_LOG_ERROR_AND_THROW);
		if (tParticipant != NULLTAG) {
			TERADYNE_TRACE_CALL(iStatus = SA_find_group(sGroupName, &tGroup), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = SA_find_role2(sRoleName, &tRole), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(SA_find_groupmember_by_role(tRole, tGroup, &iMemberCount, &tGroupMemberList), TD_LOG_ERROR_AND_THROW);

			if (iMemberCount > 0) {
				for (int i = 0; i < iMemberCount; i++) {
					// create resource pool
					//TERADYNE_TRACE_CALL(iStatus = EPM_get_resource_pool(tGroup, tRole, true, &tResourcePool));

					// Validate the user location and Repair Order's location
					TERADYNE_TRACE_CALL(SA_ask_groupmember_user(tGroupMemberList[i], &tUserTag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(SA_ask_user_person(tUserTag, &tPersonTag), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(SA_ask_person_attr2(tPersonTag, "PA5", &cCountry), TD_LOG_ERROR_AND_THROW); // PA5 --> is the real name for country property in Person object.

					if (tc_strcmp(cCountry, sRepairLocation.c_str()) == 0) {

						if (tc_strcmp(sParticipantName, "TD7EnggEvaluationSpecialist") == 0) {
							vsEEAssignee.push_back(tGroupMemberList[i]);
						}
						if (tc_strcmp(sParticipantName, "TD7ReworkSpecialist") == 0) {
							vsReworkAssignee.push_back(tGroupMemberList[i]);
						}
						

						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_ask_participants(tRepairOrderRev, tParticipant, &iParticipant, &tParticipantTypeList), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tGroupMemberList[i], tParticipant, &tParticipantList), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList), TD_LOG_ERROR_AND_THROW);
					}
				}
			}

			// To get the list of assigneed for 'Claim/ Un Claim action.
			/**if (tc_strcmp(sParticipantName, "TD7EnggEvaluationSpecialist") == 0) {
				BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
				AcquireLock lockForEESpecialist(tRepairOrderBORef);

				TERADYNE_TRACE_CALL((tRepairOrderBORef->setTagArray(TD7_ENGG_EVALUATION_ASSIGNEES, vsEEAssignee, false)));
				TERADYNE_TRACE_AND_THROW(AOM_save(tRepairOrderRev));
			}*/
			if (tc_strcmp(sParticipantName, "TD7ReworkSpecialist") == 0) {
				BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
				AcquireLock lockForReworkSpecialist(tRepairOrderBORef);

				TERADYNE_TRACE_CALL((tRepairOrderBORef->setTagArray(TD7_REWORK_ASSIGNEES, vsReworkAssignee, false)), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_AND_THROW(AOM_save(tRepairOrderRev));
			}
			/**if (tc_strcmp(sParticipantName, "TD7FinalInspectSpecialist") == 0) {
				BusinessObjectRef< Teamcenter::BusinessObject > tRepairOrderBORef(tRepairOrderRev);
				AcquireLock lockForReworkSpecialist(tRepairOrderBORef);

				TERADYNE_TRACE_CALL((tRepairOrderBORef->setTagArray(TD7_FINAL_INSPECTION_ASSIGNEES, vsFinalInsAssignee, false)));
				TERADYNE_TRACE_AND_THROW(AOM_save(tRepairOrderRev));
			}*/
		}
	}
	catch (...)
	{
	}

	TERADYNE_MEM_FREE(tParticipantTypeList);
	TERADYNE_MEM_FREE(tGroupMemberList);
	TERADYNE_MEM_FREE(tAssigneeList);
	TERADYNE_MEM_FREE(cpRoleName);
	TERADYNE_MEM_FREE(cCountry);

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_closure_value_of_existing_repair_orders(tag_t tSecondaryObj, bool &bValidClosureValue) {

	int iStatus = ITK_ok;
	char* cpSerialNumberType = NULL;
	char* cpSnStauts = NULL;
	int iSerialNumRevisionsCount = 0;
	tag_t* tSerialNumberRevisions = NULLTAG;
	tag_t tSerialNumRev = NULLTAG;
	tag_t tLatestRevTag = NULLTAG;

	const char * __function__ = "validate_closure_value_of_existing_repair_orders";
	TERADYNE_TRACE_ENTER();
	try {

		//TERADYNE_TRACE_CALL(ITEM_find_item(sPartNumber.c_str(), &tDivisionalPart));
		if (tSecondaryObj != NULLTAG) {
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tSecondaryObj, OBJECT_TYPE, &cpSerialNumberType), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(cpSerialNumberType, TD7_PART_SERIAL_NUM) == 0) {
				TERADYNE_TRACE_CALL(ITEM_list_all_revs(tSecondaryObj, &iSerialNumRevisionsCount, &tSerialNumberRevisions), TD_LOG_ERROR_AND_THROW);
				if (iSerialNumRevisionsCount > 0) {
					for (int i = 0; i < iSerialNumRevisionsCount; i++) {
						TERADYNE_TRACE_CALL(AOM_ask_value_string(tSerialNumberRevisions[i], TD7_SERIAL_NUMBER_STATUS, &cpSnStauts), TD_LOG_ERROR_AND_THROW);
						if ((tc_strcmp(cpSnStauts, "In Progress") == 0) || (tc_strcmp(cpSnStauts, "Defective") == 0)) {
							bValidClosureValue = true;
							return 0;

						}
/**
						if ((tc_strcmp(cpSnStauts, "New") == 0) || (tc_strcmp(cpSnStauts, "Repaired") == 0) || (tc_strcmp(cpSnStauts, "Swapped") == 0) || (tc_strcmp(cpSnStauts, "Defective") == 0))
						{
							bValidClosureValue = TRUE;
						}*/
					}
				}
			}
		}

		
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int assign_project_team(tag_t tRepairOrderRev, tag_t tHLAPartRev) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	
	const char * __function__ = "assign_project_team";
	TERADYNE_TRACE_ENTER();
	try {

	int iProjectCount = 0;
	tag_t* tProjectList = NULLTAG;

	tag_t tDivPart = NULLTAG;
	TERADYNE_TRACE_CALL(ITEM_ask_item_of_rev(tHLAPartRev, &tDivPart), TD_LOG_ERROR_AND_THROW);
	TERADYNE_TRACE_CALL(AOM_ask_value_tags(tDivPart, TD7_PROJECT_LIST, &iProjectCount, &tProjectList), TD_LOG_ERROR_AND_THROW);

	if (iProjectCount > 0) {
		for (int i = 0; i < iProjectCount; i++) {
			
			BusinessObjectRef<Teamcenter::BusinessObject> tTcProjectBORef(tProjectList[i]);
			std::string sProjectId("");
			TERADYNE_TRACE_CALL(tTcProjectBORef->getString(TD7_PROJECT_ID, sProjectId, bIsNull), TD_LOG_ERROR_AND_THROW);

			if (tc_strcmp(sProjectId.c_str(), "UNKNOWN_01") != 0) {




				TERADYNE_TRACE_CALL(assign_project_team_members_into_signoff_ro_creation(tRepairOrderRev, tProjectList[i]), TD_LOG_ERROR_AND_THROW);
			}
		}
	}
	// requirement changed, if there is not repair group, workflow will be assigned to Repair Admin.
	/**else {
		tag_t tUnknownProjectTag = NULLTAG;
		TERADYNE_TRACE_CALL(PROJ_find("UNKNOWN_01", &tUnknownProjectTag));
		TERADYNE_TRACE_CALL(assign_project_team_members_into_signoff_ro_creation(tRepairOrderRev, tUnknownProjectTag));
	}*/
}
catch (...)
{
}
TERADYNE_TRACE_LEAVE();
return iStatus;
}

int assign_project_team_members_into_signoff_ro_creation(tag_t tRepairOrderRev, tag_t tProjectTag) {

	int iStatus = ITK_ok;
	int iMembersCount = 0;
	tag_t* tMembersTag = NULLTAG;
	int iAdminCount = 0;
	tag_t* tAdminMembersTag = NULLTAG;
	int iPrvillagedCount = 0;
	tag_t* tPrivillagedTag = NULLTAG;
	const char cSubTaskName = NULL;
	tag_t tSubTask = NULLTAG;
	int iSignOffCount = 0;
	tag_t* tSignOffTag = NULLTAG;

	int iSubTaskCount = 0;
	tag_t* ptSubTasks = NULLTAG;
	bool bIsNull = false;
	std::set<tag_t> tagRespPartySet;

	// To be use for Claim / Un claim
	vector<tag_t> vsAssignee;
	vector<tag_t> vsEEAssignee;
	vector<tag_t> vsFIAssignee;
	try {
	TERADYNE_TRACE_CALL(iStatus = PROJ_ask_team(tProjectTag, &iMembersCount, &tMembersTag, &iAdminCount, &tAdminMembersTag, &iPrvillagedCount, &tPrivillagedTag), TD_LOG_ERROR_AND_THROW);

	// Get Repair Location from Repair Order Object
	BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderBORef(tRepairOrderRev);

	std::string sRepairLocation("");

	TERADYNE_TRACE_CALL(tRepairOrderBORef->getString(TD7_BAT_REPAIR_LOCATION, sRepairLocation, bIsNull), TD_LOG_ERROR_AND_THROW);

	if (iMembersCount > 0) {
		for (int i = 0; i < iMembersCount; i++) {
			tag_t tRoleTag = NULLTAG;
			tag_t tUserTag = NULLTAG;
			tag_t tPersonTag = NULLTAG;
			char * cpRoleName = NULL;
			char * cCountry = NULL;
			char * cpUserId = NULL;
			char * personName = NULL;

			// Validate the user location and Repair Order's location
			TERADYNE_TRACE_CALL(SA_ask_groupmember_user(tMembersTag[i], &tUserTag), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(SA_ask_user_person(tUserTag, &tPersonTag), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(SA_ask_person_attr2(tPersonTag, "PA5", &cCountry), TD_LOG_ERROR_AND_THROW); // PA5 --> is the real name for country property in Person object.

			//TERADYNE_TRACE_CALL(SA_ask_user_person_name2(tUserTag, &personName), TD_LOG_ERROR_AND_THROW);

			//TERADYNE_TRACE_CALL(SA_ask_user_identifier2(tMembersTag[i], &cpUserId), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(cCountry, sRepairLocation.c_str()) == 0) {

				TERADYNE_TRACE_CALL(SA_ask_groupmember_role(tMembersTag[i], &tRoleTag), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(SA_ask_role_name2(tRoleTag, &cpRoleName), TD_LOG_ERROR_AND_THROW);

				if (tc_strcmp(cpRoleName, "Test Technician") == 0) {

					tag_t tParticipant = NULLTAG;
					int iParticipantCount = 0;
					int iParticipant = 0;
					tag_t tParticipantList = NULLTAG;
					tag_t* tParticipantTypeList = NULLTAG;

					// To be use for Claim / Un claim
					vsAssignee.push_back(tMembersTag[i]);

					TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7DebugAndRepairSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);
					if (tParticipant != NULLTAG) {

						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_ask_participants(tRepairOrderRev, tParticipant, &iParticipant, &tParticipantTypeList), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tMembersTag[i], tParticipant, &tParticipantList), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList), TD_LOG_ERROR_AND_THROW);
					}
				}

				if (tc_strcmp(cpRoleName, "Repair Supervisor") == 0) {

					tag_t tParticipant = NULLTAG;
					int iParticipantCount = 0;
					int iParticipant = 0;
					tag_t tParticipantList = NULLTAG;
					tag_t* tParticipantTypeList = NULLTAG;

					TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7DebAndRepResSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);
					if (tParticipant != NULLTAG) {

						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_ask_participants(tRepairOrderRev, tParticipant, &iParticipant, &tParticipantTypeList), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tMembersTag[i], tParticipant, &tParticipantList), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList), TD_LOG_ERROR_AND_THROW);
					}
				}
				if ((tc_strcmp(cpRoleName, "Test Engineer") == 0)) {

					tag_t tParticipant = NULLTAG;
					int iParticipantCount = 0;
					int iParticipant = 0;
					tag_t tParticipantList = NULLTAG;
					tag_t* tParticipantTypeList = NULLTAG;

					// To be use for Claim / Un claim
					vsEEAssignee.push_back(tMembersTag[i]);

					TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7EnggEvaluationSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);
					if (tParticipant != NULLTAG) {

						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_ask_participants(tRepairOrderRev, tParticipant, &iParticipant, &tParticipantTypeList), TD_LOG_ERROR_AND_THROW);

						TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tMembersTag[i], tParticipant, &tParticipantList), TD_LOG_ERROR_AND_THROW);
						TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList), TD_LOG_ERROR_AND_THROW);
					}
				}

				//Requirement Changes - If Repair Location is Cebu, No Need to add Quality Inspectors
				//if (tc_strcmp(sRepairLocation.c_str(), "Cebu") != 0) {
					if ((tc_strcmp(cpRoleName, "Quality Inspector") == 0)) {

						tag_t tParticipant = NULLTAG;
						int iParticipantCount = 0;
						int iParticipant = 0;
						tag_t tParticipantList = NULLTAG;
						tag_t* tParticipantTypeList = NULLTAG;

						// To be use for Claim / Un claim
						vsFIAssignee.push_back(tMembersTag[i]);

						TERADYNE_TRACE_CALL(iStatus = EPM_get_participanttype("TD7FinalInspectSpecialist", &tParticipant), TD_LOG_ERROR_AND_THROW);
						if (tParticipant != NULLTAG) {

							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_ask_participants(tRepairOrderRev, tParticipant, &iParticipant, &tParticipantTypeList), TD_LOG_ERROR_AND_THROW);

							TERADYNE_TRACE_CALL(iStatus = EPM_create_participant(tMembersTag[i], tParticipant, &tParticipantList), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(iStatus = PARTICIPANT_add_participant(tRepairOrderRev, true, tParticipantList), TD_LOG_ERROR_AND_THROW);
						}
					}
				//}

			}

		}

		BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);
		AcquireLock lockOnLLApartNum(boRepairOrderRev);

		TERADYNE_TRACE_CALL((boRepairOrderRev->setTagArray(TD7_DEBUG_AND_REPAIR_ASSIGNEES, vsAssignee, false)), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL((boRepairOrderRev->setTagArray(TD7_ENGG_EVALUATION_ASSIGNEES, vsEEAssignee, false)), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL((boRepairOrderRev->setTagArray(TD7_FINAL_INSPECTION_ASSIGNEES, vsFIAssignee, false)), TD_LOG_ERROR_AND_THROW);
	

		TERADYNE_TRACE_CALL(AOM_save(tRepairOrderRev), TD_LOG_ERROR_AND_THROW);
	}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
	TERADYNE_MEM_FREE(tMembersTag);
	TERADYNE_MEM_FREE(tAdminMembersTag);
	TERADYNE_MEM_FREE(tPrivillagedTag);
	TERADYNE_MEM_FREE(tSignOffTag);
}

int create_checklist_form_ro_creation(tag_t tRepairOrderRev, string tFormType, string sObjName, string sFormName) {

	int iStatus = 0;
	tag_t tFormTypeTag = NULLTAG;
	tag_t tCreateInputTag = NULLTAG;
	tag_t tForm = NULLTAG;

	const char * __function__ = "create_checklist_form_ro_creation";
	TERADYNE_TRACE_ENTER();
	try {
		TCTYPE_find_type(tFormType.c_str(), tFormType.c_str(), &tFormTypeTag);
		TCTYPE_construct_create_input(tFormTypeTag, &tCreateInputTag);
		TERADYNE_TRACE_CALL(AOM_set_value_string(tCreateInputTag, OBJECT_NAME, sObjName.c_str()), TD_LOG_ERROR_AND_THROW);
		TCTYPE_create_object(tCreateInputTag, &tForm);
		if (tForm != NULLTAG) {
			TERADYNE_TRACE_CALL(iStatus = AOM_save_with_extensions(tForm), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tForm, false), TD_LOG_ERROR_AND_THROW);
			BusinessObjectRef< Teamcenter::BusinessObject > boForm(tForm);
			AcquireLock lockOnLLApartNum(boForm);

			if (tc_strcmp(sFormName.c_str(), "") != 0 && tc_strcmp(sFormName.c_str(), NULL) != 0) {
				TERADYNE_TRACE_CALL((boForm->setString(TD7_FORM_NAME, sFormName, false)), TD_LOG_ERROR_AND_THROW);
			}

			// set as latest version
			AOM_set_value_logical(tForm, TD7_IS_LATEST_VERSION, TRUE);

			TERADYNE_TRACE_CALL(AOM_save(tForm), TD_LOG_ERROR_AND_THROW);
			teradyne_attach_with_relation(tRepairOrderRev, tForm, IMAN_SPECIFICATION);
		}
	}
	catch (exception exp) {}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}