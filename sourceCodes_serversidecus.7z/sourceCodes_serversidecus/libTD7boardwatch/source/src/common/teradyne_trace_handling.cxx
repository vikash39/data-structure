
#include <common/teradyne_trace_handling.h>

#pragma warning (disable : 4267)

static enum	eTERADYNETraceMethods		geTERADYNETraceMethod   = UNKNOWN_TRACE_METHOD;
static enum	eTERADYNETraceFileLines	geTERADYNETraceFileLine = UNKNOWN_TRACE_FILELINE;

static logical						gbTERADYNETraceInitialized = FALSE;

static int							gbTERADYNETraceIsOn        = 0;

static int							giTERADYNETraceIndentIncr = 0;
static int							giTERADYNETraceIndention = 0;

static char	*						gpcTERADYNETracePrefix = NULL;

// Global Constants for Trace Initialization
static int		globalTD4TraceIndention = 0;
static bool	    globalTD4TraceInitialized = false;
static bool	    globalTD4TraceIsOn = false;
/*!
*\file teradyne_trace_handling.cxx
*\par Description:
*Initializes runtime tracing.
*A set of environment variables is asked for in order to initialize
*runtime tracing and to control the amount of output and its target.

Referenced environment variables (those in [] are optional):

TERADYNE_TRACE
[TERADYNE_TRACE_METHOD]    default: SYSLOG
[TERADYNE_TRACE_PREFIX]    default: no prefix
[TERADYNE_TRACE_INDENT]    default: 2
[P4_TRACE_FILELINE]		default: NO



*\return	logical	TRUE or FALSE signaling whether tracing has been turn on or not


*\par Owner:
*Chetan Kekade

*/

/*******************************************************************************
 * Function Name	: teradyne_get_error_text
 * Description		: Gets the severity error message from the error stack
 *                    based on the inpurt error code
 *
 * REQUIRED HEADERS	:
 * INPUT PARAMS		: int iErrorCode, char** msg
 *
 * RETURN VALUE		: int iStatus - Error Code or Success Code
 * GLOBALS USED		:
 * FUNCTIONS CALLED	:
 *
 * ALGORITHM		:
 *
 *
 * NOTES			:
 *------------------------------------------------------------------------------
 * Date         	Name                 Description of Change
 * 30-Oct.-2014   	Vivek		         Initial Code
 *------------------------------------------------------------------------------
 */
int teradyne_get_error_text(int iErrorCode, char** msg)
{
	int iStatus = ITK_ok;
	int iErrorCount;
	int* iSeverities;
	int* iFails;
	char** cTexts = NULL;

	try
	{
		//Get the errors on stack
		iStatus = EMH_ask_errors(&iErrorCount, (const int**)&iSeverities, (const int**)&iFails, (const char***)&cTexts);
		if (iErrorCount > 0)
		{
			for (int i = (iErrorCount - 1); i >= 0; i--)
			{
				//check whether the error code matches the thrown error code
				if (iErrorCode == iFails[i] && cTexts[i] != NULL)
				{
					*msg = (char*)MEM_alloc((int)(tc_strlen(cTexts[i]) + 1) * sizeof(char));
					tc_strcpy((*msg), cTexts[i]);
					break;
				}
			}
		}
	}
	catch (...)
	{
		if (iStatus == ITK_ok)
		{
			TC_write_syslog("teradyne_get_error_text: Unhandled Exception.\n");
		}
	}
	return iStatus;
}

bool td4_is_trace_handler_on(void)
{
	char	*pcTrace = NULL;

	if (!globalTD4TraceInitialized)
	{
		int		iStatus = ITK_ok;

		// Set the current search scope to user
		iStatus = PREF_ask_char_value_at_location("TERADYNE_LIB_TRACE", TC_preference_user, 0, &pcTrace);

		// Not found, look for site preference
		if ((iStatus != ITK_ok) || (pcTrace == NULL) || (tc_strlen(pcTrace) <= 0))
		{
			// Set the current search scope to site
			TERADYNE_ITKCALL_F(iStatus = PREF_ask_char_value_at_location("TERADYNE_LIB_TRACE", TC_preference_site, 0, &pcTrace));
		}

		if ((pcTrace != NULL) && (tc_strlen(pcTrace) > 0))
		{
			if (tc_strcmp(pcTrace, "ON") == 0 || tc_strcmp(pcTrace, "YES") == 0 || tc_strcmp(pcTrace, "TRUE") == 0)
			{
				globalTD4TraceIsOn = true;
			}
		}

		globalTD4TraceInitialized = true;
	}

	if (pcTrace != NULL) {
		MEM_free(pcTrace);
		pcTrace = NULL;
	}
	return globalTD4TraceIsOn;
}

void teradyne_change_indent(const char cChange)
{
	if (cChange == '+') globalTD4TraceIndention = globalTD4TraceIndention + 3;
	else if (cChange == '-') globalTD4TraceIndention = globalTD4TraceIndention - 3;
	return;
}

void teradyne_printIndent()
{
	char	cIndentFmt[128 + 1] = "";
	sprintf(cIndentFmt, "%%%ds", globalTD4TraceIndention);
	TC_write_syslog(cIndentFmt, "");
}

int teradyne_trace_handling_is_on( void )
{
	if ( !gbTERADYNETraceInitialized )
	{
		int		iStatus = ITK_ok	;

		const char	cEnvSrc[] = "environment variable"	;
		const char	cPrefSrc[] = "TC preference"		;
		const char	cNoneSrc[] = ""						;

		char	* pcSrc = (char*)cNoneSrc				;
		char	* pcMethodSrc = (char*)cNoneSrc			;
		char	* pcPrefixSrc = (char*)cNoneSrc			;
		char	* pcIndentSrc = (char*)cNoneSrc			;
		char	* pcFileLineSrc = (char*)cNoneSrc		;

		char	* pcTERADYNETrace = NULL				;
		char	* pcTERADYNETraceMethod = NULL		;
		char	* pcTERADYNETraceIndent = NULL		;
		char	* pcTERADYNETraceFileLine = NULL		;
		char	* pcTERADYNETracePrefix = NULL		;

		TC_preference_search_scope_t	currPrefSearchScope = TC_preference_site;

		if ( iStatus == ITK_ok )
		{
			// Save current preference search scope
			//TERADYNE_ITK_CALL ( PREF_ask_search_scope ( &currPrefSearchScope ) ) ;
			
		}

		if ( iStatus == ITK_ok )
		{
			//Set the current search scrope to user
			//TERADYNE_ITK_CALL ( PREF_set_search_scope ( TC_preference_user ) ) ;	// do not forget to reset

			TERADYNE_ITK_CALL ( PREF_ask_char_value ( "TERADYNE_TRACE" , 0 , &pcTERADYNETrace ) ) ;
		}


		// Second look for site preference
		if ( ( iStatus != ITK_ok ) || ( pcTERADYNETrace == NULL ) || ( strlen ( pcTERADYNETrace ) <= 0 ) )
		{
			// Set the current search scrope to user
			//TERADYNE_ITK_CALL ( PREF_set_search_scope ( TC_preference_site ) ) ;	// do not forget to reset
			TERADYNE_ITK_CALL ( PREF_ask_char_value ( "TERADYNE_TRACE" , 0 , &pcTERADYNETrace ) ) ;
		}

		// Then look for environment variable TERADYNE_TRACE
		if ( ( iStatus != ITK_ok ) || ( pcTERADYNETrace == NULL ) || ( strlen ( pcTERADYNETrace ) <= 0 ) )
		{
			// need to check

			size_t sz = 0;
			//pcTERADYNETrace = getenv ( "TERADYNE_TRACE" ) ;
			_dupenv_s(&pcTERADYNETrace, &sz,"TERADYNE_TRACE");

			pcSrc = (char*)cEnvSrc ;
		} else pcSrc = (char*)cPrefSrc ;

		if ( ( pcTERADYNETrace != NULL ) && ( strlen ( pcTERADYNETrace ) > 0 ) )
		{
			/*if ( strcmp ( pcTERADYNETrace, "OFF" ) != 0 ) 
			{
			gbTERADYNETraceIsOn = true ;
			}*/
			TC_write_syslog("Trace Option is : %s",pcTERADYNETrace);
			if ( strcmp ( pcTERADYNETrace, "0" ) == 0 ) 
				gbTERADYNETraceIsOn = 0;
			else if( strcmp ( pcTERADYNETrace, "1" ) == 0 ) 
				gbTERADYNETraceIsOn = 1;
			else if( strcmp ( pcTERADYNETrace, "2" ) == 0 ) 
				gbTERADYNETraceIsOn = 2;
			else if( strcmp ( pcTERADYNETrace, "3" ) == 0 ) 
				gbTERADYNETraceIsOn = 3;
			else if( strcmp ( pcTERADYNETrace, "ON" ) == 0 ) 
				gbTERADYNETraceIsOn = 3;

		}

		if ( gbTERADYNETraceIsOn )
		{
			// Save current preference search scope and set to user scope
			//TERADYNE_ITK_CALL ( PREF_ask_search_scope ( &currPrefSearchScope ) ) ;

			if ( iStatus == ITK_ok )
			{
				// Set the current search scrope to user
				//TERADYNE_ITK_CALL ( PREF_set_search_scope ( TC_preference_user ) ) ;	// do not forget to reset
			}

			// First look for char preference      TERADYNE_TRACE_METHOD: if not found,
			//       look for environment variable TERADYNE_TRACE_METHOD
			TERADYNE_ITK_CALL ( PREF_ask_char_value ( "TERADYNE_TRACE_METHOD" , 0 , &pcTERADYNETraceMethod ) ) ;
			if ( ( iStatus != ITK_ok ) || ( pcTERADYNETraceMethod == NULL ) || ( strlen ( pcTERADYNETraceMethod ) <= 0 ) )
			{
				//pcTERADYNETraceMethod = TC_getenv ( "TERADYNE_TRACE_METHOD" ) ;
				size_t sz = 0;
				_dupenv_s(&pcTERADYNETraceMethod, &sz,"TERADYNE_TRACE_METHOD");

				pcMethodSrc = (char*)cEnvSrc ;
			} else pcMethodSrc = (char*)cPrefSrc ;
			if ( ( pcTERADYNETraceMethod != NULL ) && ( strlen ( pcTERADYNETraceMethod ) > 0 ) )
			{
				if ( strcmp ( pcTERADYNETraceMethod , "OUTSTREAM" ) == 0 ) geTERADYNETraceMethod = OUTSTREAM_TRACE_METHOD ;
				else if ( strcmp ( pcTERADYNETraceMethod , "SYSLOG"    ) == 0 ) geTERADYNETraceMethod = SYSLOG_TRACE_METHOD    ;
				else if ( strcmp ( pcTERADYNETraceMethod , "JOURNAL"   ) == 0 ) geTERADYNETraceMethod = JOURNAL_TRACE_METHOD   ;
			}
			else {
				geTERADYNETraceMethod = SYSLOG_TRACE_METHOD ; // default
				pcMethodSrc = (char*)cNoneSrc ;
			}
			if ( geTERADYNETraceMethod == UNKNOWN_TRACE_METHOD ) gbTERADYNETraceIsOn = false ; // cancel tracing


			// First look for char preference      TERADYNE_TRACE_INDENT: if not found,
			//       look for environment variable TERADYNE_TRACE_INDENT
			TERADYNE_ITK_CALL ( PREF_ask_char_value ( "TERADYNE_TRACE_INDENT" , 0 , &pcTERADYNETraceIndent ) ) ;
			if ( ( iStatus != ITK_ok ) || ( pcTERADYNETraceIndent == NULL ) || ( strlen ( pcTERADYNETraceIndent ) <= 0 ) )
			{
				//pcTERADYNETraceIndent = getenv ( "TERADYNE_TRACE_INDENT" ) ;
				size_t sz = 0;
				_dupenv_s(&pcTERADYNETraceIndent, &sz,"TERADYNE_TRACE_INDENT");
				pcIndentSrc = (char*)cEnvSrc ;
			} else pcIndentSrc = (char*)cPrefSrc ;
			if ( ( pcTERADYNETraceIndent != NULL ) && ( strlen ( pcTERADYNETraceIndent ) > 0 ) )
			{
				char	* pcAux = NULL	;

				giTERADYNETraceIndentIncr = strtol ( pcTERADYNETraceIndent , &pcAux , 10 ) ;
				if ( *pcAux != '\0' ) gbTERADYNETraceIsOn = false ;// cancel tracing
				else if ( giTERADYNETraceIndentIncr < 0 ) gbTERADYNETraceIsOn = false ;// cancel tracing
			}
			else {
				giTERADYNETraceIndentIncr = 2 ; // default
				pcIndentSrc = (char*)cNoneSrc ;
			}


			// First look for site char preference TERADYNE_TRACE_PREFIX: if not found,
			//       look for environment variable TERADYNE_TRACE_PREFIX
			TERADYNE_ITK_CALL ( PREF_ask_char_value ( "TERADYNE_TRACE_PREFIX" , 0 , &pcTERADYNETracePrefix ) ) ;
			if ( ( iStatus != ITK_ok ) || ( pcTERADYNETracePrefix == NULL ) || ( strlen ( pcTERADYNETracePrefix ) <= 0 ) )
			{
				//pcTERADYNETracePrefix = getenv ( "TERADYNE_TRACE_PREFIX" ) ;
				size_t sz = 0;
				_dupenv_s(&pcTERADYNETracePrefix, &sz,"TERADYNE_TRACE_PREFIX");
				pcPrefixSrc = (char*)cEnvSrc ;
			} else pcPrefixSrc = (char*)cPrefSrc ;
			if ( ( pcTERADYNETracePrefix != NULL ) && ( strlen ( pcTERADYNETracePrefix ) > 0 ) )
			{
				gpcTERADYNETracePrefix = (char*) MEM_alloc ( (strlen(pcTERADYNETracePrefix)+1) * sizeof(char) ) ;
				tc_strcpy ( gpcTERADYNETracePrefix , pcTERADYNETracePrefix ) ;

			}
			else {
				gpcTERADYNETracePrefix = NULL ; // default
				pcPrefixSrc = (char*)cNoneSrc ;
			}


			// First look for char preference      TERADYNE_TRACE_FILELINE: if not found,
			//       look for environment variable TERADYNE_TRACE_FILELINE
			TERADYNE_ITK_CALL ( PREF_ask_char_value ( "TERADYNE_TRACE_FILELINE" , 0 , &pcTERADYNETraceFileLine ) ) ;
			if ( ( iStatus != ITK_ok ) || ( pcTERADYNETraceFileLine == NULL )  || ( strlen ( pcTERADYNETraceFileLine ) <= 0 ) )
			{
				//pcTERADYNETraceFileLine = getenv ( "TERADYNE_TRACE_FILELINE" ) ;
				size_t sz = 0;
				_dupenv_s(&pcTERADYNETraceFileLine, &sz,"TERADYNE_TRACE_FILELINE");
				pcFileLineSrc = (char*)cEnvSrc ;
			} else pcFileLineSrc = (char*)cPrefSrc ;
			if ( ( pcTERADYNETraceFileLine != NULL ) && ( strlen ( pcTERADYNETraceFileLine ) > 0 ) )
			{
				if ( strcmp ( pcTERADYNETraceFileLine , "NO"    ) == 0 ) geTERADYNETraceFileLine = NO_TRACE_FILELINE    ;
				else if ( strcmp ( pcTERADYNETraceFileLine , "SHORT" ) == 0 ) geTERADYNETraceFileLine = SHORT_TRACE_FILELINE ;
				else if ( strcmp ( pcTERADYNETraceFileLine , "LONG"  ) == 0 ) geTERADYNETraceFileLine = LONG_TRACE_FILELINE  ;
			}
			else {
				geTERADYNETraceFileLine = NO_TRACE_FILELINE ; // default
				pcFileLineSrc = (char*)cNoneSrc ;
			}
			if ( geTERADYNETraceFileLine == UNKNOWN_TRACE_FILELINE ) gbTERADYNETraceIsOn = false ; // cancel tracing
		}
		gbTERADYNETraceInitialized = TRUE ;


		// Log result
		if ( gbTERADYNETraceIsOn ) 
			TC_write_syslog ( "\nDue to the following options tracing is turned ON:\n" ) ;
		else 
			TC_write_syslog ( "\nDue to the following options tracing is turned OFF:\n" ) ;

		TC_write_syslog ( "    TERADYNE_TRACE          = " ) ;
		if ( pcTERADYNETrace  != NULL )          
			TC_write_syslog ( "\"%s\"" , pcTERADYNETrace ) ;
		if ( strlen ( pcSrc ) > 0 )             
			TC_write_syslog ( " (source: %s)\n" , pcSrc ) ;
		else
			TC_write_syslog ( " \"\" (default: no tracing)\n" ) ;
		TC_write_syslog ( "    TERADYNE_TRACE_METHOD   = " ) ;
		if ( pcTERADYNETraceMethod != NULL )     
			TC_write_syslog ( "\"%s\"" , pcTERADYNETraceMethod ) ;
		if ( strlen ( pcMethodSrc ) > 0 )       
			TC_write_syslog ( " (source: %s)\n" , pcMethodSrc ) ;
		else                                    
			TC_write_syslog ( " \"\" (default: SYSLOG)\n" ) ;


		TC_write_syslog ( "    TERADYNE_TRACE_INDENT   = " ) ;
		if ( pcTERADYNETraceIndent != NULL )     
			TC_write_syslog ( "\"%s\"" , pcTERADYNETraceIndent ) ;
		if ( strlen ( pcIndentSrc ) > 0 )       
			TC_write_syslog ( " (source: %s)\n" , pcIndentSrc ) ;
		else                                    
			TC_write_syslog ( " \"\" (default: 2)\n" ) ;


		TC_write_syslog ( "    TERADYNE_TRACE_PREFIX   = " ) ;
		if ( pcTERADYNETracePrefix != NULL )     
			TC_write_syslog ( "\"%s\"" , pcTERADYNETracePrefix ) ;
		if ( strlen ( pcPrefixSrc ) > 0 )      
			TC_write_syslog ( " (source: %s)\n" , pcPrefixSrc ) ;
		else                                    
			TC_write_syslog ( " \"\" (default: no prefix)\n" ) ;


		TC_write_syslog ( "    TERADYNE_TRACE_FILELINE = " ) ;
		if ( pcTERADYNETraceFileLine != NULL )   
			TC_write_syslog ( "\"%s\"" , pcTERADYNETraceFileLine ) ;
		if ( strlen ( pcFileLineSrc ) > 0 )    
			TC_write_syslog ( " (source: %s)\n" , pcFileLineSrc ) ;
		else                                   
			TC_write_syslog ( " \"\" (default: NO)\n" ) ;

		TC_write_syslog ( "(Fixed values:\n" ) ;
		TC_write_syslog ( "    TERADYNE_TRACE=0,1,2,3,ON\n" ) ;
		TC_write_syslog ( "    TERADYNE_TRACE_METHOD=SYSLOG,OUTSTREAM,JOURNAL\n" ) ;
		TC_write_syslog ( "   TERADYNE_TRACE_FILELINE=NO,SHORT,LONG\n" ) ;
		TC_write_syslog ( " Source preference has precedence over environment variable)\n\n\n" ) ;

		// Save current preference search scope and set to default again
		//TERADYNE_ITK_CALL ( PREF_set_search_scope (currPrefSearchScope ) ) ;
	}
	return gbTERADYNETraceIsOn ;	
}

/*! 
*\file teradyne_trace_handling.cxx
*\par Description:
*Writes to stdout, syslog or journal file including potential prefix
*and indention

*Based on the global variable geTERADYNETraceMethod a variable amount of arguments
*are written to stdout, to syslog or to journal file.

*Output to stdout is written straight with vfprintf, which takes a va_list type
*argument.

*Output to the syslogfile has to be written argument by argument, because
*TC_write_syslog takes a ... type argument and not a va_list type one and it is
*possible to pass a ... type argument from this function's input to TC_write_syslog.
*formatstring
*varibale number of arguments to be written

*\param[in]	pcFmtStr	formatstring
*\param[in]	...			varibale number of arguments to be written

*/
void teradyne_trace_args( const char	* pcFmtStr	,	... )
{
	char	cIndentFmt[32+1] = {0};
	char	cBuffer[4096+1] = {0};
	va_list pArgs	;


	if ( pcFmtStr != NULL )
	{
		sprintf_s ( cIndentFmt , "%%%ds" , giTERADYNETraceIndention ) ;

		va_start ( pArgs , pcFmtStr ) ;

		if( geTERADYNETraceMethod == UNKNOWN_TRACE_METHOD )
			geTERADYNETraceMethod = SYSLOG_TRACE_METHOD;

		switch ( geTERADYNETraceMethod )
		{
		case OUTSTREAM_TRACE_METHOD :
			if ( gpcTERADYNETracePrefix != NULL )
				fprintf ( stdout , "%s"       , gpcTERADYNETracePrefix ) ;
			fprintf ( stdout , cIndentFmt , ""                    ) ;
			vfprintf ( stdout , pcFmtStr   , pArgs                 ) ;
			break ;

		case SYSLOG_TRACE_METHOD :
			if ( gpcTERADYNETracePrefix != NULL )
				TC_write_syslog ( "%s"       , gpcTERADYNETracePrefix ) ;
			TC_write_syslog ( cIndentFmt , ""                    ) ;
			teradyne_write_syslog ( pcFmtStr   ,        pArgs          ) ;
			break ;

		case JOURNAL_TRACE_METHOD :
			if ( gpcTERADYNETracePrefix != NULL )
			{
				sprintf_s ( cBuffer , "%s" , gpcTERADYNETracePrefix ) ;
				vsprintf ( cBuffer + strlen ( gpcTERADYNETracePrefix ) , pcFmtStr , pArgs ) ;

			}
			else
			{
				vsprintf ( cBuffer , pcFmtStr , pArgs ) ;
			}
			if ( ( strlen(cBuffer) > 0 ) && ( *(cBuffer+strlen(cBuffer)-1) == '\n' ) )
				*(cBuffer+strlen(cBuffer)-1) = '\0' ;
			JOURNAL_comment ( cBuffer ) ;
			break ;

		default : ;
		}
		va_end ( pArgs ) ;
	}
	return ;
}


/*!
*\file teradyne_trace_handling.cxx
*\par Description:
*Get The Local Time and Date.
*write Date and Time in syslog file.
*/
void teradyne_log_local_time( void )
{
	struct timeb timebuffer ;
	ftime( &timebuffer ) ;

	time_t tt = timebuffer.time ;
	struct tm *ptm = localtime( &tt ) ;
	date_t curDate ;
	curDate.year = ptm -> tm_year + 1900 ;
	curDate.month = ptm -> tm_mon ;
	curDate.day = ptm -> tm_mday ;
	curDate.hour = ptm -> tm_hour ;
	curDate.minute = ptm -> tm_min ;
	curDate.second = ptm -> tm_sec ;

	int msec = timebuffer.millitm ;

	char *strDate = NULL ;
	DATE_date_to_string( curDate, "%Y-%m-%d %H:%M:%S", &strDate ) ;

	TC_write_syslog( "\n %s.%03d", strDate, msec );

	return;
}

/*!
*\file teradyne_trace_handling.cxx
*\par Description:
*Writes variable number of arguments to the syslog file.
*The format string is evaluated conversion specification (%..) by conversion
*specification. For each such conversion specification an argument is fetched
*from argument list and written accordingly to syslog file.
*formatstring varibale number of arguments to be written

*\param[in]	pcFmtStr	formatstring
*\param[in]	pArgs		varibale number of arguments to be written

*/
void teradyne_write_syslog ( const char	* pcFmtStr	,	va_list		pArgs )
{
	const char	cConvChars[] = "cdeEfgGinopsuxX"	; // All C onversion characters that terminate
	// conversion specifications started with %
	char	* pcFmtChr = NULL			;
	char	* pcConvChar = NULL			;
	char	cFmtStrBuff[128+1] = ""		;

	const void	* pArg = NULL	;

	if ( pcFmtStr != NULL )
	{
		for ( pcFmtChr = (char*)pcFmtStr; *pcFmtChr != '\0' ; pcFmtChr ++ )
		{
			if ( *pcFmtChr == '%' )
			{
				pcConvChar = strpbrk ( pcFmtChr + 1 , cConvChars ) ;
				if ( pcConvChar != NULL )
				{
					memset ( cFmtStrBuff , 0, sizeof(cFmtStrBuff) ) ;
					strncpy ( cFmtStrBuff , pcFmtChr , pcConvChar - pcFmtChr + 1 ) ;
					pArg = va_arg ( pArgs , const void* ) ;
					TC_write_syslog ( cFmtStrBuff , pArg ) ;

					pcFmtChr = 	pcConvChar ;
				}
			}
			else TC_write_syslog ( "%c" , *pcFmtChr ) ;
		}
	}

	return ;
}

/*!
*\file teradyne_trace_handling.cxx
*\par Description:
*Increments or decrements the golbal variable holding the current indention depth.
*\param[in]	cChange		'+' : increment, '-' : decrement

*/
void teradyne_alter_indent ( const char	cChange )
{
	if ( cChange == '+' ) giTERADYNETraceIndention = giTERADYNETraceIndention + giTERADYNETraceIndentIncr ;
	else if ( cChange == '-' ) giTERADYNETraceIndention = giTERADYNETraceIndention - giTERADYNETraceIndentIncr ;

	return ;
}

/** 
*\file teradyne_trace_handling.cxx
*\par Description:  
Depending on the global variable geTERADYNETraceFileLine, formats
the filename and the linenumber into a string and returns it
If global variable geTERADYNETraceFileLine is LONG, the entire filename and
linenumber are formatted to output parameter, if it is SHORt only the file
name and the line number are formatted to output parameter, otherwise output
parameter is set to "".   

*\param[in]	pcFile		filename
*\param[in]	iLine		linenumber
*\param[out]	cFileLine	formatted filename and linenumber
*/
void teradyne_make_fileline (	const char	* pcFile , const int	iLine ,	char	cFileLine[FILELINELENGTH+1] )
{
	char	* pcAux = NULL	;

	strcpy ( cFileLine , "" ) ;

	if ( pcFile != NULL )
	{
		switch ( geTERADYNETraceFileLine )
		{
		case LONG_TRACE_FILELINE :
			sprintf ( cFileLine , "(%s/%d)" , pcFile , iLine ) ;
			break ;

		case SHORT_TRACE_FILELINE :
#ifdef _WIN32
			pcAux = (char*)strrchr ( pcFile , '\\' ) ;
#else
			pcAux = (char*)strrchr ( pcFile , '/' ) ;
#endif
			if ( pcAux != NULL ) pcAux = pcAux + 1 ;
			else				 pcAux = (char*)pcFile ;
			sprintf ( cFileLine , "(%s/%d)" , pcAux , iLine ) ;
			break ;

		default : ;
		}
	}

	return ;
}

/*!
*\file teradyne_trace_handling.cxx
*\par Description:
*Returns the current trace method.
*\param[out]	eTERADYNETraceMethods
*/
enum eTERADYNETraceMethods teradyne_trace_method ( void )
{
	return geTERADYNETraceMethod ;
}

/*!
*\file teradyne_trace_handling.cxx
*\par Description:
*Gets the values that control the tracing.
*\par Owner:
*Chetan Kekade
*\param[out]	ptP4TraceOptions  structure holding the various trace options.
*/
void teradyne_trace_get_options (	teradyne_trace_options_t		* ptTERADYNETraceOptions )
{
	ptTERADYNETraceOptions->bTERADYNETraceIsOn       = gbTERADYNETraceIsOn       ;
	ptTERADYNETraceOptions->eTERADYNETraceMethod     = geTERADYNETraceMethod     ;
	ptTERADYNETraceOptions->pcTERADYNETracePrefix    = gpcTERADYNETracePrefix    ;
	ptTERADYNETraceOptions->iTERADYNETraceIndentIncr = giTERADYNETraceIndentIncr ;
	ptTERADYNETraceOptions->iTERADYNETraceIndention  = giTERADYNETraceIndention  ;
	ptTERADYNETraceOptions->eTERADYNETraceFileLine   = geTERADYNETraceFileLine   ;

	return ;
}

/*!
*\file teradyne_trace_handling.cxx
*\par Description:
*Sets the values that control the tracing. 
*structure holding the various trace options

*\param[in]	tP4TraceOptions  structure holding the various trace options

*/
void teradyne_trace_set_options (	const teradyne_trace_options_t	tTERADYNETraceOptions )
{
	gbTERADYNETraceIsOn        = tTERADYNETraceOptions.bTERADYNETraceIsOn       ;
	geTERADYNETraceMethod      = tTERADYNETraceOptions.eTERADYNETraceMethod     ;
	gpcTERADYNETracePrefix     = tTERADYNETraceOptions.pcTERADYNETracePrefix    ;
	giTERADYNETraceIndentIncr  = tTERADYNETraceOptions.iTERADYNETraceIndentIncr ;
	giTERADYNETraceIndention   = tTERADYNETraceOptions.iTERADYNETraceIndention  ;
	geTERADYNETraceFileLine    = tTERADYNETraceOptions.eTERADYNETraceFileLine   ;

	gbTERADYNETraceInitialized = true ;

	return ;
}

/*!
*\file teradyne_trace_handling.cxx
*\par Description:
*Get CurrentTime.

*/
void teradyne_log_current_time(void)
{
	struct timeb timebuffer ;
	ftime( &timebuffer ) ;

	time_t tt = timebuffer.time ;
	struct tm *ptm = localtime( &tt ) ;
	date_t curDate ;
	curDate.year = ptm -> tm_year + 1900 ;
	curDate.month = ptm -> tm_mon ;
	curDate.day = ptm -> tm_mday ;
	curDate.hour = ptm -> tm_hour ;
	curDate.minute = ptm -> tm_min ;
	curDate.second = ptm -> tm_sec ;

	int msec = timebuffer.millitm ;

	char *strDate = NULL ;
	DATE_date_to_string( curDate, "%Y-%m-%d %H:%M:%S", &strDate ) ;

	TC_write_syslog( "The date/time is %s.%03d -", strDate, msec );

	return;
}

char * teradyne_TRACE_object (
	const tag_t		objectTag ) 
{
	int		iObjectTraceLength = 0	;

	tag_t			classIdTag = NULLTAG					;
	tag_t			itemTag = NULLTAG						;
	tag_t			groupTag = NULLTAG						;
	tag_t			roleTag = NULLTAG						;
	tag_t			userTag = NULLTAG						;
	tag_t			relationTypeTag = NULLTAG				;
	static tag_t	sWorkspaceObjectClassIdTag = NULLTAG	;
	static tag_t	sItemClassIdTag = NULLTAG				;
	static tag_t	sItemRevisionClassIdTag = NULLTAG		;
	static tag_t	sPersonClassIdTag = NULLTAG				;
	static tag_t	sUserClassIdTag = NULLTAG				;
	static tag_t	sGroupClassIdTag = NULLTAG				;
	static tag_t	sRoleClassIdTag = NULLTAG				;
	static tag_t	sGroupMemberClassIdTag = NULLTAG		;
	static tag_t	sImanTypeClassIdTag = NULLTAG			;
	static tag_t	sImanRelationClassIdTag = NULLTAG		;

	char	* pcClassName = NULL					;
	char	*cType[WSO_name_size_c + 1] = {};
	char	*cName[WSO_name_size_c + 1] = {};
	char	*cItemId[ITEM_id_size_c + 1] = {};
	char	*cItemRevisionId[ITEM_id_size_c + 1] = {};
	char	*cPersonName[SA_name_size_c + 1] = {};
	char	*cUserId[SA_user_size_c + 1] = {};
	char	*cGroupName[SA_name_size_c + 1] = {};
	char	*cRoleName[SA_name_size_c + 1] = {};
	char  	*cTypeName[TCTYPE_name_size_c + 1] = {}	;

	static char		* spcObjectTrace = NULL		;

	logical		bValidTag = false		;
	logical		bIsDescendant = false	; 



	// Initialize output
	iObjectTraceLength = 3 + WSO_name_size_c                                                   + 1 +	// [c:class]
		4 + WSO_name_size_c                                                   + 1 +	// [t:type]
		4 + WSO_name_size_c                                                   + 1 +	// [n:name]	[g:group]	
		4 + WSO_name_size_c                                                   + 1 +	// [r:role]
		4 + ((ITEM_id_size_c>SA_user_size_c)?ITEM_id_size_c:SA_user_size_c)   + 1 +	// [i:userid/itemid]
		4 + ITEM_id_size_c                                                    + 1 +	// [r:itemrevisionid]
		1 ;						                                                    // \0
	if ( spcObjectTrace == NULL ) spcObjectTrace = (char*)MEM_alloc ( iObjectTraceLength * sizeof(char) ) ;
	memset ( spcObjectTrace , 0 , iObjectTraceLength ) ; 


	// Check input integrity
	if ( objectTag == NULLTAG ) goto LEAVE_RETURN ;
	POM_is_tag_valid  ( objectTag , &bValidTag ) ;
	if ( ! bValidTag ) goto LEAVE_RETURN ;


	// Get class of given object
	POM_class_of_instance ( objectTag , &classIdTag ) ;


	// POM_object => class
	if ( classIdTag != NULLTAG )
		POM_name_of_class ( classIdTag , &pcClassName ) ;
	if ( pcClassName != NULL ) 
	{
		strncat ( spcObjectTrace , "[c:" , 3 ) ;
		strncat ( spcObjectTrace , pcClassName , WSO_name_size_c ) ;
		strncat ( spcObjectTrace , "]" , 1 ) ;
		MEM_free ( pcClassName ) ; pcClassName = NULL ;
	}


	// WorkspaceObject => type, name
	if ( sWorkspaceObjectClassIdTag == NULLTAG )
		POM_class_id_of_class ( "WorkspaceObject" , &sWorkspaceObjectClassIdTag ) ;
	POM_is_descendant ( sWorkspaceObjectClassIdTag , classIdTag , &bIsDescendant ) ;
	if ( bIsDescendant )
	{
		WSOM_ask_object_type2 ( objectTag , cType ) ;
		strncat ( spcObjectTrace , " [t:" , 4 ) ;
		strncat ( spcObjectTrace , cType[0] , WSO_name_size_c ) ;
		strncat ( spcObjectTrace , "]" , 1 ) ;

		WSOM_ask_name2 ( objectTag , cName ) ;
		strncat ( spcObjectTrace , " [n:" , 4 ) ;
		strncat ( spcObjectTrace , cName[0] , WSO_name_size_c ) ;
		strncat ( spcObjectTrace , "]" , 1 ) ;


		// Item => item id
		if ( sItemClassIdTag == NULLTAG )
			POM_class_id_of_class ( "Item" , &sItemClassIdTag ) ;
		POM_is_descendant ( sItemClassIdTag , classIdTag , &bIsDescendant ) ;
		if ( bIsDescendant )
		{
			strncat ( spcObjectTrace , " [i:" , 4 ) ;
			ITEM_ask_id2 ( objectTag , cItemId ) ;
			strncat ( spcObjectTrace , cItemId[0] , ITEM_id_size_c ) ;
			strncat ( spcObjectTrace , "]" , 1 ) ;

		} // Item

		else {

			// ItemRevision => item id, item revision id
			if ( sItemRevisionClassIdTag == NULLTAG )
				POM_class_id_of_class ( "ItemRevision" , &sItemRevisionClassIdTag ) ;
			POM_is_descendant ( sItemRevisionClassIdTag , classIdTag , &bIsDescendant ) ;
			if ( bIsDescendant )
			{
				ITEM_ask_item_of_rev ( objectTag , &itemTag ) ;
				ITEM_ask_id2 ( itemTag , cItemId ) ;
				strncat ( spcObjectTrace , " [i:" , 4 ) ;
				strncat ( spcObjectTrace , cItemId[0] , ITEM_id_size_c ) ;
				strncat ( spcObjectTrace , "]" , 1 ) ;

				ITEM_ask_rev_id2 ( objectTag , cItemRevisionId ) ;
				strncat ( spcObjectTrace , " [r:" , 4 ) ;
				strncat ( spcObjectTrace , cItemRevisionId[0] , ITEM_id_size_c ) ;
				strncat ( spcObjectTrace , "]" , 1 ) ;

			} // ItemRevision
		} 
	} // WorkspaceObject

	else { 

		// Person => name
		if ( sPersonClassIdTag == NULLTAG )
			POM_class_id_of_class ( "Person" , &sPersonClassIdTag ) ;
		POM_is_descendant ( sPersonClassIdTag , classIdTag , &bIsDescendant ) ;
		if ( bIsDescendant )
		{
			SA_ask_person_name2 ( objectTag , cPersonName ) ;
			strncat ( spcObjectTrace , " [n:" , 4 ) ;
			strncat ( spcObjectTrace , cPersonName[0] , SA_name_size_c ) ;
			strncat ( spcObjectTrace , "]" , 1 ) ;

		} // Person

		else {

			// User => user id
			if ( sUserClassIdTag == NULLTAG )
				POM_class_id_of_class ( "User" , &sUserClassIdTag ) ;
			POM_is_descendant ( sUserClassIdTag , classIdTag , &bIsDescendant ) ;
			if ( bIsDescendant )
			{
				SA_ask_user_identifier2 ( objectTag , cUserId ) ;
				strncat ( spcObjectTrace , " [i:" , 4 ) ;
				strncat ( spcObjectTrace , cUserId[0] , SA_user_size_c ) ;
				strncat ( spcObjectTrace , "]" , 1 ) ;

			} // User

			else {

				// Group => name
				if ( sGroupClassIdTag == NULLTAG )
					POM_class_id_of_class ( "Group" , &sGroupClassIdTag ) ;
				POM_is_descendant ( sGroupClassIdTag , classIdTag , &bIsDescendant ) ;
				if ( bIsDescendant )
				{
					SA_ask_group_name2 ( objectTag , cGroupName ) ;
					strncat ( spcObjectTrace , " [n:" , 4 ) ;
					strncat ( spcObjectTrace , cGroupName[0] , SA_name_size_c ) ;
					strncat ( spcObjectTrace , "]" , 1 ) ;

				} // Group

				else {

					// Role => name
					if ( sRoleClassIdTag == NULLTAG )
						POM_class_id_of_class ( "Role" , &sRoleClassIdTag ) ;
					POM_is_descendant ( sRoleClassIdTag , classIdTag , &bIsDescendant ) ;
					if ( bIsDescendant )
					{
						SA_ask_role_name2 ( objectTag , cRoleName ) ;
						strncat ( spcObjectTrace , " [n:" , 4 ) ;
						strncat ( spcObjectTrace , cRoleName[0] , SA_name_size_c ) ;
						strncat ( spcObjectTrace , "]" , 1 ) ;

					} // Role

					else {

						// GroupMember => ...
						if ( sGroupMemberClassIdTag == NULLTAG )
							POM_class_id_of_class ( "GroupMember" , &sGroupMemberClassIdTag ) ;
						POM_is_descendant ( sGroupMemberClassIdTag , classIdTag , &bIsDescendant ) ;
						if ( bIsDescendant )
						{
							SA_ask_groupmember_group ( objectTag , &groupTag ) ;
							SA_ask_group_name2 ( groupTag , cGroupName ) ;
							strncat ( spcObjectTrace , " [g:" , 4 ) ;
							strncat ( spcObjectTrace , cGroupName[0] , SA_name_size_c ) ;
							strncat ( spcObjectTrace , "]" , 1 ) ;

							SA_ask_groupmember_role ( objectTag , &roleTag ) ;
							SA_ask_role_name2 ( roleTag , cRoleName ) ;
							strncat ( spcObjectTrace , " [r:" , 4 ) ;
							strncat ( spcObjectTrace , cRoleName[0] , SA_name_size_c ) ;
							strncat ( spcObjectTrace , "]" , 1 ) ;

							SA_ask_groupmember_user ( objectTag , &userTag ) ;
							SA_ask_user_identifier2 ( userTag , cUserId ) ;
							strncat ( spcObjectTrace , " [u:" , 4 ) ;
							strncat ( spcObjectTrace , cUserId[0] , SA_user_size_c ) ;
							strncat ( spcObjectTrace , "]" , 1 ) ;

						} // GroupMember

						else {

							// ImanType => ...
							if ( sImanTypeClassIdTag == NULLTAG )
								POM_class_id_of_class ( "ImanType" , &sImanTypeClassIdTag ) ;
							POM_is_descendant ( sImanTypeClassIdTag , classIdTag , &bIsDescendant ) ;
							if ( bIsDescendant )
							{
								TCTYPE_ask_name2 ( objectTag , cTypeName ) ;
								strncat ( spcObjectTrace , " [n:" , 4 ) ;
								strncat ( spcObjectTrace , cTypeName[0] , TCTYPE_name_size_c ) ;
								strncat ( spcObjectTrace , "]" , 1 ) ;

							} // ImanType

							else {

								// ImanRelation => ...
								if ( sImanRelationClassIdTag == NULLTAG )
									POM_class_id_of_class ( "ImanRelation" , &sImanRelationClassIdTag ) ;
								POM_is_descendant ( sImanRelationClassIdTag , classIdTag , &bIsDescendant ) ;
								if ( bIsDescendant )
								{
									GRM_ask_relation_type ( objectTag , &relationTypeTag ) ;
									TCTYPE_ask_name2 ( relationTypeTag , cTypeName ) ;
									strncat ( spcObjectTrace , " [t:" , 4 ) ;
									strncat ( spcObjectTrace , cTypeName[0] , TCTYPE_name_size_c ) ;
									strncat ( spcObjectTrace , "]" , 1 ) ;

								} // ImanRelation
							}
						}
					}
				}
			} 
		}
	}


LEAVE_RETURN : ;
	return spcObjectTrace ;
}
