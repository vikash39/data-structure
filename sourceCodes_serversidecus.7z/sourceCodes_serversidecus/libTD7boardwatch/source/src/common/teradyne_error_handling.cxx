
#include <common/teradyne_error_handling.h>

#pragma warning (disable : 4267)

/**
* \file teradyne_error_handling.cxx
* \verbatim
* \par Description:
Logs the error with following information:
ITK_ok  or custom status
EMH_severity_error  or EMH_severity_warning
File name from where error is thrown
Line  number
custom message if provided

\endverbatim
* \par Owner:
* Nikhilesh Khatra
*
*
* \param[in]  iFail             ITK_ok  or custom status
* \param[in]  iSeverity         EMH_severity_error  or EMH_severity_warning
* \param[in]  pcFileName        File name from where error is thrown
* \param[in]  iLineNumber       Line  number
* \param[in]  pcCustomMessage   custom message if provided
* 
*/
void teradyne_log_error_syslog (
	int	iFail ,					        /* <I>*/
	int	iSeverity , 			        /* <I>*/
	const char	* pcFileName , 			/* <I>*/
	int	iLineNumber , 			        /* <I>*/
	const char	* pcCustomMessage )	    /* <I>*/
{
	char * pcMessage = NULL				;
	int iLastError = 0;

	const char * __function__ = "teradyne_log_error_syslog";
	TERADYNE_TRACE_ENTER();

	// if a custom message is given, take it
	if ( pcCustomMessage != NULL )
	{
		pcMessage = (char*)MEM_alloc ( (strlen(pcCustomMessage)+1) * sizeof(char) ) ;
		strcpy ( pcMessage , pcCustomMessage ) ;
	}

	// if no custom message is given, look for topmost message on error stack whose failure code matches the given one, if any
	else
	{
		int		iIdx = 0				;
		int		iErrorCount = 0			;
		int		* piSeverities = NULL	;
		int		* piFails = NULL		;
		char	** ppcTexts = NULL		;

		EMH_ask_errors ( &iErrorCount , (const int**)&piSeverities , (const int**)&piFails , (const char***)&ppcTexts ) ;

		for ( iIdx = iErrorCount - 1 ; iIdx >= 0 ; iIdx -- )
		{
			if ( ( piFails[iIdx] == iFail ) && ( ppcTexts[iIdx] != NULL ) )
			{
				pcMessage = (char*)MEM_alloc ( (strlen(ppcTexts[iIdx])+1) * sizeof(char) ) ;
				strcpy ( pcMessage , ppcTexts[iIdx] ) ;
				break ;
			}
		}
	}

	EMH_ask_last_error(&iLastError);
	if( iFail != iLastError)
	{
		EMH_store_error(iSeverity,iFail);
	}

	// if neither custom message is given nor a message on the error stack, try generic message for given failure 
	if ( pcMessage == NULL)
	{
		EMH_ask_error_text ( iFail , &pcMessage ) ;

		if ( pcMessage == NULL )
		{
			pcMessage = (char*)MEM_alloc ( (strlen("No message available for failure code 1234567890.")+1) * sizeof(char) ) ;
			sprintf ( pcMessage , "No message available for failure code %d." , iFail ) ;
		}
	}

	// syslog output
	{
		char * pcTeradyneSeverity = NULL		;
		time_t  startTime = 0	;

		time ( &startTime ) ;
		switch ( iSeverity )
		{
		case EMH_severity_error :
			pcTeradyneSeverity = TERADYNE_ERROR_MSG ;
			break ; 
		case EMH_severity_warning :
			pcTeradyneSeverity = TERADYNE_WARNING_MSG ;
			break ;
		case EMH_severity_information :				
			pcTeradyneSeverity =TERADYNE_INFORMATION_MSG ;
			break ;
		default:
			pcTeradyneSeverity = "TERADYNE_UNKNOWN_SEVERITY_MSG" ;
			break ;
		}
		TERADYNE_TRACE_ERRORS (( "%s: %s\n", pcTeradyneSeverity , pcMessage )) ;
		if ( pcFileName != NULL ) 
			TERADYNE_TRACE_ERRORS (( "    file: %s line: %d time: %s", pcFileName  , iLineNumber , ctime(&startTime) )) ;
		else
			TERADYNE_TRACE_ERRORS (( "    file: %s line: %s time: %s", "undefined" , "undefined" , ctime(&startTime) )) ;
	}

	if( pcMessage != NULL )
		MEM_free(pcMessage);

	TERADYNE_TRACE_LEAVE();
	return ;
}
