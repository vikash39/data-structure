/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_actionhandler_to_export_lla_part_number.cpp
#      Module          :           libTD7_teradyne_workflows.dll
#      Project         :           libTD7_teradyne_workflows
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  20-Aug-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <workflows/teradyne_workflows.h>

int td7_export_lla_part_number(EPM_action_message_t msg)
{
	int    iStatus = ITK_ok;
	bool bIsNull = false;
	int iAttachmentCount = 0;
	tag_t tRootTask = NULLTAG;
	tag_t *tpAttachments = NULL;
	tag_t *tpReferencedObject = NULL;

	char *cpDatasetName = NULL;
	int namedreferencedCount = 0;
	char *cpNrPathname = NULL;
	fstream Readingfile;

	const char * __function__ = "td7_export_lla_part_number";
	TERADYNE_TRACE_ENTER();
	try
	{
		// Get root task from the current task.
		TERADYNE_TRACE_CALL(EMH_clear_errors(), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);

		//Get all the target attachments from the workflow task.
		TERADYNE_TRACE_CALL(EPM_ask_attachments(tRootTask, EPM_target_attachment, &iAttachmentCount, &tpAttachments), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(export_property_values_into_csv(tpAttachments[0]), TD_LOG_ERROR_AND_THROW);
	}
	catch (exception exp) {}
	return iStatus;
}


int export_property_values_into_csv(tag_t tLLAPartRev) {
	int iStatus = ITK_ok;

	bool bIsNull = false;
	char *revId = NULL,
		*objectName = NULL,
		*objDesc = NULL,
		*objStr = NULL,
		*objType = NULL;

	BusinessObjectRef<Teamcenter::BusinessObject> tLLApartNumberBORev(tLLAPartRev);

	std::string sLLAPartNumber("");
	std::string sHLAPartNumber("");
	std::string sHLAPartNumberRev("");
	std::string sRepManagedPart("");
	std::string sRepManagedPartRev("");
	std::string sCommercialPart("");
	std::string sCommercialPartRev("");
	std::string sHLAPartRev("");
	std::string sROId("");
	std::string sRepairLocation("");
	std::string sOrderType("");
	std::string sServiceType("");
	std::string sSystemSerialNumber("");
	std::string sCustomerId("");

	int iDivCount = 0;
	bool bIsValidProject = false;
	tag_t tQueriedDivPartRev = NULLTAG;

	int iPrimaryCount = 0;
	tag_t* tprimaryObj = NULLTAG;

	int iSubTaskCount = 0;
	tag_t* ptSubTasks = NULLTAG;
	tag_t tSolutionConfigRel = NULLTAG;
	vector<string> vSplittedValues;
	string	szCurTimeStamp;
	date_t	curDateTime;

	tag_t tLLAPart = NULLTAG;
	tag_t tIncomingConfigRel = NULLTAG;
	int iLLAPartRevCount = 0;
	char* pathName = NULL;
	tag_t* tLLAPartRevs = NULLTAG;

	const char * __function__ = "export_property_values_into_csv";
	TERADYNE_TRACE_ENTER();
	try
	{


		size_t requiredSize = 100;
		// To read the environment variable
		pathName = (char*)malloc(requiredSize * sizeof(char));

		if (!pathName)
		{
			printf("Failed to allocate memory!\n");
			exit(1);
		}
		ITK_set_bypass(TRUE);
		
		// Get the value of the TC_UTILITY_MERLIN environment variable.
		getenv_s(&requiredSize, pathName, requiredSize, TERADYNE_LLA_PART_EXPORT_LOCATION);


		// Get LLA Part Number/ HLA Part Number / Repair Managed Part.
		TERADYNE_TRACE_CALL(tLLApartNumberBORev->getString(ITEM_ID, sLLAPartNumber, bIsNull), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(tLLApartNumberBORev->getString(TD7_REV_STAMP, sHLAPartNumberRev, bIsNull), TD_LOG_ERROR_AND_THROW);

		// check for Divisional Part
		TERADYNE_TRACE_CALL(tLLApartNumberBORev->getString(TD7_PART_NUMBER, sHLAPartNumber, bIsNull), TD_LOG_ERROR_AND_THROW);


		// check for Repair Managed Part
		if ((tc_strcmp(sHLAPartNumber.c_str(), "") == 0) && (tc_strcmp(sHLAPartNumberRev.c_str(), "") == 0)) {
			TERADYNE_TRACE_CALL(tLLApartNumberBORev->getString(TD7_REP_MANAGE_PART, sHLAPartNumber, bIsNull), TD_LOG_ERROR_AND_THROW);

		}


		// check for Commercial Part
		if ((tc_strcmp(sHLAPartNumber.c_str(), "") == 0) && (tc_strcmp(sHLAPartNumberRev.c_str(), "") == 0)) {
			TERADYNE_TRACE_CALL(tLLApartNumberBORev->getString(TD7_COMM_PART_NUMBER, sHLAPartNumber, bIsNull), TD_LOG_ERROR_AND_THROW);

		}


		// Create the csv file with name of LLA Part Number (Serial Number).
		FILE *pFile;
		//string filepath(file_name);
		std::string filepath = pathName;
		filepath = filepath.append(":/");

		filepath = filepath.append("TC_UTILITY_MERLIN_EXPORT_LLA");
		filepath = filepath.append("/");
		filepath = filepath.append("export");

		filepath = filepath.append("/");

		filepath = filepath.append(sLLAPartNumber);
		TERADYNE_TRACE_CALL(teradyne_current_timestamp("%Y%m%d%H%M%S", szCurTimeStamp, curDateTime), TD_LOG_ERROR_AND_THROW);
		filepath = filepath.append("_");
		filepath = filepath.append(szCurTimeStamp);
		filepath = filepath.append(".csv");

		if (tLLAPartRev != NULLTAG) {
			fopen_s(&pFile, filepath.c_str(), "w+");

			if (pFile == NULL) {
				perror(filepath.c_str());
				perror("Error opening file");
			}


			TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tSolutionConfigRel), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(GRM_list_primary_objects_only(tLLAPartRev, tSolutionConfigRel, &iPrimaryCount, &tprimaryObj), TD_LOG_ERROR_AND_THROW);

			if (iPrimaryCount > 0) {
				// TO Do ==> Discussion needed to get repair order.
				for (int i = 0; i < iPrimaryCount; i++) {
					BusinessObjectRef<Teamcenter::BusinessObject> tRepairorderBORev(tprimaryObj[i]);
					TERADYNE_TRACE_CALL(tRepairorderBORev->getString(ITEM_ID, sROId, bIsNull), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(tRepairorderBORev->getString(TD7_BAT_REPAIR_LOCATION, sRepairLocation, bIsNull), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(tRepairorderBORev->getString(TD7_BAT_ORDER_TYPE, sOrderType, bIsNull), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(tRepairorderBORev->getString(TD7_BAT_SERVICE_TYPE, sServiceType, bIsNull), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(tRepairorderBORev->getString(TD7_SYS_SERIAL_NUMBER, sSystemSerialNumber, bIsNull), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(tRepairorderBORev->getString(TD7_CUSTOMER_ID, sCustomerId, bIsNull), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(teradyne_split(sCustomerId, '_', vSplittedValues), TD_LOG_ERROR_AND_THROW);

					fprintf(pFile, "%s|", sLLAPartNumber);

					if (tc_strcmp(sHLAPartNumber.c_str(), "") != 0) {
						fprintf(pFile, "%s|", sHLAPartNumber);
					}
					else {
						fprintf(pFile, "%s|", "NA");
					}

					if (tc_strcmp(sHLAPartNumberRev.c_str(), "") != 0) {
						fprintf(pFile, "%s|", sHLAPartNumberRev);
					}
					else {
						fprintf(pFile, "%s|", "NA");
					}
					/**if (tc_strcmp(sRepManagedPart.c_str(), "") != 0) {
						fprintf(pFile, "%s|", sRepManagedPart);
						fprintf(pFile, "%s|", sRepManagedPartRev);
					}
					if (tc_strcmp(sCommercialPart.c_str(), "") != 0) {
						fprintf(pFile, "%s|", sCommercialPart);
						fprintf(pFile, "%s|", sCommercialPartRev);
					}*/
					if (tc_strcmp(sROId.c_str(), "") != 0) {
						fprintf(pFile, "%s|", sROId);
					}
					else {
						fprintf(pFile, "%s|", "NA");
					}

					if (tc_strcmp(sRepairLocation.c_str(), "") != 0) {
						fprintf(pFile, "%s|", sRepairLocation);
					}
					else {
						fprintf(pFile, "%s|", "NA");
					}

					if (tc_strcmp(sOrderType.c_str(), "") != 0) {
						fprintf(pFile, "%s|", sOrderType);
					}
					else {
						fprintf(pFile, "%s|", "NA");
					}

					if (tc_strcmp(sServiceType.c_str(), "") != 0) {
						fprintf(pFile, "%s|", sServiceType);
					}
					else {
						fprintf(pFile, "%s|", "NA");
					}

					if (tc_strcmp(sSystemSerialNumber.c_str(), "") != 0) {
						fprintf(pFile, "%s|", sSystemSerialNumber);
					}
					else {
						fprintf(pFile, "%s|", "NA");
					}

					if (vSplittedValues.size() > 0) {
						if (tc_strcmp(vSplittedValues[0].c_str(), "") != 0) {
							fprintf(pFile, "%s|", vSplittedValues[0]);
						}
						else {
							fprintf(pFile, "%s|", "NA");
						}
						if (tc_strcmp(vSplittedValues[1].c_str(), "") != 0) {
							fprintf(pFile, "%s|", vSplittedValues[1]);
						}
						else {
							fprintf(pFile, "%s|", "NA");
						}
					}
				}

				// Update LLA SerialNumber Status property for Part Serial Number.
				POM_AM__set_application_bypass(true);
				TERADYNE_TRACE_CALL(AOM_refresh(tLLAPartRev, true), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_set_value_string(tLLAPartRev, TD7_SERIAL_NUMBER_STATUS, "Swapped"), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_save(tLLAPartRev), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_refresh(tLLAPartRev, false), TD_LOG_ERROR_AND_THROW);
				POM_AM__set_application_bypass(false);
				

				//set Incoming Config also as Swapped
				TERADYNE_TRACE_CALL(ITEM_ask_item_of_rev(tLLAPartRev, &tLLAPart), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(ITEM_list_all_revs(tLLAPart, &iLLAPartRevCount, &tLLAPartRevs), TD_LOG_ERROR_AND_THROW);
				if (iLLAPartRevCount > 0) {
					TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_INCOMING_CONFIG_REL, &tIncomingConfigRel), TD_LOG_ERROR_AND_THROW);
					for (int i = 0; i < iLLAPartRevCount; i++) {
						tag_t troRelationTag = NULLTAG;
						TERADYNE_TRACE_CALL(GRM_find_relation(tprimaryObj[0], tLLAPartRevs[i], tIncomingConfigRel, &troRelationTag), TD_LOG_ERROR_AND_THROW);
						if (troRelationTag != NULLTAG) {
							// Update LLA SerialNumber Status property for Part Serial Number.
							POM_AM__set_application_bypass(true);
							TERADYNE_TRACE_CALL(AOM_refresh(tLLAPartRevs[i], true), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(AOM_set_value_string(tLLAPartRevs[i], TD7_SERIAL_NUMBER_STATUS, "Swapped"), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(AOM_save(tLLAPartRevs[i]), TD_LOG_ERROR_AND_THROW);
							TERADYNE_TRACE_CALL(AOM_refresh(tLLAPartRevs[i], false), TD_LOG_ERROR_AND_THROW);
							POM_AM__set_application_bypass(false);
							
						}
					}
				}


				// Remove this Relation Object from Repair Order.
				TERADYNE_TRACE_CALL(teradyne_delete_relation(tprimaryObj[0], tLLAPartRev, TD7_SOLUTION_CONFIG_REL), TD_LOG_ERROR_AND_THROW);
			}
			fclose(pFile);	
		}

	}
	catch (exception ep) {

	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}


int teradyne_delete_relation(tag_t tPrimary, tag_t tSecondary, const char* strRelTypeName) {

	int iStatus = ITK_ok;
	tag_t tRelType = NULLTAG;
	tag_t tRelation = NULLTAG;

	const char * __function__ = "teradyne_delete_relation";
	TERADYNE_TRACE_ENTER();

	try {
		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(strRelTypeName, &tRelType), TD_LOG_ERROR_AND_THROW);
		if (tRelType != NULLTAG) {

			TERADYNE_TRACE_CALL(iStatus = GRM_find_relation(tPrimary, tSecondary, tRelType, &tRelation), TD_LOG_ERROR_AND_THROW);
			if (tRelation != NULLTAG) {
				bool bisverdict = false;
				//TERADYNE_TRACE_CALL((boRepairOrderRev->setString(TD7_FINAL_INS_STAUTS, decision, false)));
				TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tPrimary, &bisverdict), TD_LOG_ERROR_AND_THROW);
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tPrimary, true), TD_LOG_ERROR_AND_THROW);
				}
				TERADYNE_TRACE_CALL(iStatus = GRM_delete_relation(tRelation), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(AOM_save_without_extensions(tPrimary), TD_LOG_ERROR_AND_THROW);
				if (!bisverdict)
				{
					TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tPrimary, false), TD_LOG_ERROR_AND_THROW);
				}
			}
		}

	}
	catch (...) {

		if (iStatus == ITK_ok)
		{
			
		}
	}

	TERADYNE_TRACE_LEAVE(iStatus);
	return iStatus;
}

void create_batch(std::string pathName, std::string fileName) {

	/**ofstream batch;
	std::string bPath = "J";
	bPath = bPath.append(":/");

	bPath = bPath.append("TC_UTILITY_MERLIN_EXPORT_LLA");
	bPath = bPath.append("/");
	bPath = bPath.append("UA_Merlin_Export.bat");
	TC_write_syslog("00000000000000000000000000000  Creating Batch", bPath);
	batch.open(bPath, ofstream::out | ofstream::app);
	TC_write_syslog("2222222222222222  Creating Batch /n");
	cout << "11111111111111" << endl;
	//batch.open("UA_Merlin_Export.bat", ios::out);
	//batch << pathName + ":\n";
	//batch << "cd " + pathName + "\n";
	batch << "echo open SAREK.CORP.TERADYNE.COM > ftp.txt\n";
	batch << "echo TEAMCENTER >> ftp.txt\n";
	batch << "echo TC_MERLIN >> ftp.txt\n";
	batch << "echo lcd / D MerlinImport >> ftp.txt\n";
	batch << "echo ascii >> ftp.txt\n";
	batch << "echo cd LLA_REPAIR_ORDER_TC >> ftp.txt\n";
	batch << "echo put " + pathName + " >> ftp.txt\n";
	batch << "echo disconnect >> ftp.txt\n";
	batch << "echo quit >> ftp.txt\n";
	batch << "ftp -i -s:ftp.txt >> temp.txt\n";
	batch << "EXIT\n";

	batch.close();

	system(bPath.c_str());
	TC_write_syslog("1111111111111111111111111111  running");
	//remove(bPath.c_str());
	TC_write_syslog("2222222222222233333333333333  Finished");*/
}

// int teradyne_split(std::string str, char delimiter, std::vector<std::string> &vResult)
// {
	// int iStatus = ITK_ok;

	// std::stringstream ss(str); // Turn the string into a stream.
	// std::string tok;

	// while (getline(ss, tok, delimiter))
	// {
		// vResult.push_back(tok);
	// }

	// return iStatus;
// }
