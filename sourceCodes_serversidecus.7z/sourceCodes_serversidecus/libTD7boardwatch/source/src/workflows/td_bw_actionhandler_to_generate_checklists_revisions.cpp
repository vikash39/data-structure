/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_actionhandler_to_generate_checklists_revisions.cpp
#      Module          :           libTD7_teradyne_workflows.dll
#      Project         :           libTD7_teradyne_workflows
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  15-Nov-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/
#include <workflows/teradyne_workflows.h>

int td7_generate_checklists_revisions_execute(EPM_action_message_t msg) {

	int    iStatus = ITK_ok;
	bool bIsNull = false;
	int iAttachmentCount = 0;
	tag_t tRootTask = NULLTAG;
	tag_t tPrevioustask = NULLTAG;
	tag_t *tpAttachments = NULL;
	tag_t *tpReferencedObject = NULL;

	std::string sEnggEvalutionTaskStatus("");
	std::string sDebugAndRepairTaskStatus("");
	std::string sReworkTaskStatus("");
	std::string sFinalInsTaskStatus("");
	std::string sCurrentTaskName("");

	const char * __function__ = "td7_generate_checklists_revisions_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		// Get root task from the current task.
		TERADYNE_TRACE_CALL(EMH_clear_errors(), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);

		//Get all the target attachments from the workflow task.
		TERADYNE_TRACE_CALL(EPM_ask_attachments(tRootTask, EPM_target_attachment, &iAttachmentCount, &tpAttachments), TD_LOG_ERROR_AND_THROW);
		
		if (iAttachmentCount > 0) {
			BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderRevBORef(tpAttachments[0]);
			TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_CURRENT_TASK_NAME, sCurrentTaskName, bIsNull), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_ENGG_EVALUATION_STATUS, sEnggEvalutionTaskStatus, bIsNull), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_DEBUG_AND_REAPIR_TASK_STATUS, sDebugAndRepairTaskStatus, bIsNull), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_REWORK_STATUS, sReworkTaskStatus, bIsNull), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_FINAL_INS_STAUTS, sFinalInsTaskStatus, bIsNull), TD_LOG_ERROR_AND_THROW);

			if (tc_strcmp(sEnggEvalutionTaskStatus.c_str(), "") != 0 && tc_strcmp(sCurrentTaskName.c_str(), "Engg Evaluation") == 0) {
				TERADYNE_TRACE_CALL(validate_engg_evaluation_checklists_revisions(tpAttachments[0]), TD_LOG_ERROR_AND_THROW);
			}
			if (tc_strcmp(sDebugAndRepairTaskStatus.c_str(), "") != 0 && tc_strcmp(sCurrentTaskName.c_str(), "Debug and Repair") == 0) {
				TERADYNE_TRACE_CALL(validate_debug_and_repair_checklists_revisions(tpAttachments[0]), TD_LOG_ERROR_AND_THROW);
			}
			if (tc_strcmp(sReworkTaskStatus.c_str(), "") != 0 && tc_strcmp(sCurrentTaskName.c_str(), "Rework") == 0) {
				TERADYNE_TRACE_CALL(validate_rework_checklists_revisions(tpAttachments[0]), TD_LOG_ERROR_AND_THROW);
			}
			if (tc_strcmp(sFinalInsTaskStatus.c_str(), "") != 0 && tc_strcmp(sCurrentTaskName.c_str(), "Final Inspection") == 0) {
				TERADYNE_TRACE_CALL(validate_final_inspection_checklists_revisions(tpAttachments[0]), TD_LOG_ERROR_AND_THROW);
			}
		}

	}
	catch (exception exp) {}
	TERADYNE_MEM_FREE(tpAttachments);
	TERADYNE_MEM_FREE(tpReferencedObject);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_engg_evaluation_checklists_revisions(tag_t tRepairOrderRev) {

	int iStatus = ITK_ok;
	tag_t* tSecondaryObjects = NULLTAG;
	tag_t tRelation = NULLTAG;

	char* cpComments = NULL;

	int iCount = 0;
	int iEECount = 1;

	const char * __function__ = "validate_engg_evaluation_checklists_revisions";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(GRM_find_relation_type(IMAN_SPECIFICATION, &tRelation), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelation, &iCount, &tSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		if (tRepairOrderRev != NULLTAG) {
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tRepairOrderRev, TD7_INFO_FROM_SENDER, &cpComments), TD_LOG_ERROR_AND_THROW);
		}

		if (iCount > 0) {
			for (int i = 0; i < iCount; i++) {

				// check object type
				logical bIsNull = false;
				TERADYNE_TRACE_ENTER();
				BusinessObjectRef<Teamcenter::BusinessObject> checkListObj(tSecondaryObjects[i]);

				std::string sCheckListObjType("");

				TERADYNE_TRACE_CALL(checkListObj->getString(OBJECT_TYPE, sCheckListObjType, bIsNull), TD_LOG_ERROR_AND_THROW);

				if (sCheckListObjType.compare(TD7_ENGG_EVALUATION_FORM) == 0) {
					iEECount++;
				}
			}

			// generete checklists forms
			string formName = "";
			formName = formName.append("Engg Evaluation");
			formName = formName.append("_");
			formName = formName.append("v");
			formName = formName.append(to_string(iEECount));
			TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_ENGG_EVALUATION_FORM, "Engg Evaluation", formName), TD_LOG_ERROR_AND_THROW);

			if ((tc_strcmp(cpComments, "") != 0) || (tc_strcmp(cpComments, NULL) != 0)) {
				TERADYNE_TRACE_CALL(update_sender_value_from_previous_task(tRepairOrderRev, cpComments), TD_LOG_ERROR_AND_THROW);
			}

		}
	}
	catch (exception exp) {}
	TERADYNE_MEM_FREE(tSecondaryObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int update_sender_value_from_previous_task(tag_t tRepairOrderRev, string comments) {

	int iStatus = ITK_ok;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t  tRelation = NULLTAG;

	const char * __function__ = "update_sender_value_from_previous_task";
	TERADYNE_TRACE_ENTER();
	try {
		if (tRepairOrderRev == NULLTAG)
		{
			return iStatus;
		}
		tag_t tRelationType = NULLTAG;

		TERADYNE_TRACE_CALL(iStatus = GRM_find_relation_type(IMAN_SPECIFICATION, &tRelationType), TD_LOG_ERROR_AND_THROW);

		int iSecondaryCnt = 0;
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iSecondaryCnt; i++)
		{
			std::string sObjectType("");
			BusinessObjectRef<Teamcenter::BusinessObject> tCheckListFormBORef(tpSecondaryObjects[i]);
			TERADYNE_TRACE_CALL(tCheckListFormBORef->getString(OBJECT_TYPE, sObjectType, bIsNull), TD_LOG_ERROR_AND_THROW);

			if (tc_strcmp(sObjectType.c_str(), TD7_ENGG_EVALUATION_FORM) == 0) {
				bool isLatest = false;
				TERADYNE_TRACE_CALL(AOM_ask_value_logical(tpSecondaryObjects[i], TD7_IS_LATEST_VERSION, &isLatest), TD_LOG_ERROR_AND_THROW);
				if (isLatest) {
					BusinessObjectRef< Teamcenter::BusinessObject > boEnggEvaluationForm(tpSecondaryObjects[i]);
					AcquireLock lockOnEnngEvaluationForm(boEnggEvaluationForm);

					if (tc_strcmp(comments.c_str(), "") != 0 && tc_strcmp(comments.c_str(), NULL) != 0) {
						TERADYNE_TRACE_CALL((boEnggEvaluationForm->setString(TD7_INFO_FROM_SENDER, comments, false)), TD_LOG_ERROR_AND_THROW);
					}
					TERADYNE_TRACE_CALL(AOM_save(tpSecondaryObjects[i]), TD_LOG_ERROR_AND_THROW);

				}
			}

		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_debug_and_repair_checklists_revisions(tag_t tRepairOrderRev) {

	int iStatus = ITK_ok;
	tag_t* tSecondaryObjects = NULLTAG;
	tag_t tRelation = NULLTAG;

	int iCount = 0;
	int iPreInspectionCount = 0;
	int iPreTestCount = 0;
	int iRepairCount = 0;
	int iRepairVerificationCount = 0;
	int iPostTestCount = 0;

	const char * __function__ = "validate_debug_and_repair_checklists_revisions";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(GRM_find_relation_type(IMAN_SPECIFICATION, &tRelation), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelation, &iCount, &tSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		if (iCount > 0) {
			for (int i = 0; i < iCount; i++) {

				// check object type
				logical bIsNull = false;
				TERADYNE_TRACE_ENTER();
				BusinessObjectRef<Teamcenter::BusinessObject> checkListObj(tSecondaryObjects[i]);

				std::string sCheckListObjType("");

				TERADYNE_TRACE_CALL(checkListObj->getString(OBJECT_TYPE, sCheckListObjType, bIsNull), TD_LOG_ERROR_AND_THROW);

				//if (sCheckListObjType.compare(TD7_PRE_INSPECTION_FORM) == 0) {
				//	iPreInspectionCount++;
				//}
				//if (sCheckListObjType.compare(TD7_PRE_TEST_FORM) == 0) {
				//	iPreTestCount++;
				//}
				if (sCheckListObjType.compare(TD7_REPAIR_FORM) == 0) {
					iRepairCount++;
				}
				if (sCheckListObjType.compare(TD7_REPAIR_VERIFICATION_FORM) == 0) {
					iRepairVerificationCount++;
				}
				if (sCheckListObjType.compare(TD7_POST_TEST_FORM) == 0) {
					iPostTestCount++;
				}

			}

			// generete checklists forms
			TERADYNE_TRACE_CALL(generate_checklists_revisions_while_running_workflow(tRepairOrderRev, iRepairCount, iRepairVerificationCount, iPostTestCount), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (exception exp) {}
	TERADYNE_MEM_FREE(tSecondaryObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_rework_checklists_revisions(tag_t tRepairOrderRev) {

	int iStatus = ITK_ok;
	tag_t* tSecondaryObjects = NULLTAG;
	tag_t tRelation = NULLTAG;

	int iCount = 0;
	int iReworkCount = 1;

	const char * __function__ = "validate_rework_checklists_revisions";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(GRM_find_relation_type(IMAN_SPECIFICATION, &tRelation), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelation, &iCount, &tSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		if (iCount > 0) {
			for (int i = 0; i < iCount; i++) {

				// check object type
				logical bIsNull = false;
				TERADYNE_TRACE_ENTER();
				BusinessObjectRef<Teamcenter::BusinessObject> checkListObj(tSecondaryObjects[i]);

				std::string sCheckListObjType("");

				TERADYNE_TRACE_CALL(checkListObj->getString(OBJECT_TYPE, sCheckListObjType, bIsNull), TD_LOG_ERROR_AND_THROW);

				if (sCheckListObjType.compare(TD7_REPAIR_REWORK_FORM) == 0) {
					iReworkCount++;
				}
			}

			// generete checklists forms
			string formName = "";
			formName = formName.append("Rework");
			formName = formName.append("_");
			formName = formName.append("v");
			formName = formName.append(to_string(iReworkCount));
			TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_REPAIR_REWORK_FORM, "Rework", formName), TD_LOG_ERROR_AND_THROW);
			
		}
	}
	catch (exception exp) {}
	TERADYNE_MEM_FREE(tSecondaryObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int validate_final_inspection_checklists_revisions(tag_t tRepairOrderRev) {

	int iStatus = ITK_ok;
	tag_t* tSecondaryObjects = NULLTAG;
	tag_t tRelation = NULLTAG;

	int iCount = 0;
	int iFinalInspectionCount = 1;

	const char * __function__ = "validate_final_inspection_checklists_revisions";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(GRM_find_relation_type(IMAN_SPECIFICATION, &tRelation), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelation, &iCount, &tSecondaryObjects), TD_LOG_ERROR_AND_THROW);

		if (iCount > 0) {
			for (int i = 0; i < iCount; i++) {

				// check object type
				logical bIsNull = false;
				TERADYNE_TRACE_ENTER();
				BusinessObjectRef<Teamcenter::BusinessObject> checkListObj(tSecondaryObjects[i]);

				std::string sCheckListObjType("");

				TERADYNE_TRACE_CALL(checkListObj->getString(OBJECT_TYPE, sCheckListObjType, bIsNull), TD_LOG_ERROR_AND_THROW);

				if (sCheckListObjType.compare(TD7_QUALITY_INSPECTION_FORM) == 0) {
					iFinalInspectionCount++;
				}
			}

			// generete checklists forms
			string formName = "";
			formName = formName.append("Final Inspection");
			formName = formName.append("_");
			formName = formName.append("v");
			formName = formName.append(to_string(iFinalInspectionCount));
			TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_QUALITY_INSPECTION_FORM, "Final Inspection", formName), TD_LOG_ERROR_AND_THROW);

		}
	}
	catch (exception exp) {}
	TERADYNE_MEM_FREE(tSecondaryObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int generate_checklists_revisions_while_running_workflow(tag_t tRepairOrderRev, int iRepairCount, int iRepairVerificationCount, int iPostTestCount) {

	int iStatus = 0;
	logical bIsNull = false;
	tag_t tFormTypeTag = NULLTAG;
	tag_t tCreateInputTag = NULLTAG;
	tag_t tForm = NULLTAG;

	string formName = "";

	const char * __function__ = "generate_checklists_revisions_while_running_workflow";
	TERADYNE_TRACE_ENTER();
	try {
		string checkListStatus;
		BusinessObjectRef<Teamcenter::BusinessObject> tRepairOrderRevBORef(tRepairOrderRev);
		TERADYNE_TRACE_CALL(tRepairOrderRevBORef->getString(TD7_BAT_CHECKLIST, checkListStatus, bIsNull), TD_LOG_ERROR_AND_THROW);
		if (tc_strcmp(checkListStatus.c_str(), "Pre Inspection") == 0) {
			/**iPreInspectionCount++;
			formName = formName.append("Pre Inspection");
			formName = formName.append("_");
			formName = formName.append("v");
			formName = formName.append(to_string(iPreInspectionCount));
			TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_PRE_INSPECTION_FORM, "Pre Inspection", formName));
			*/
		}
		if (tc_strcmp(checkListStatus.c_str(), "Pre Test") == 0) {
			/**iPreTestCount++;
			formName = formName.append("Pre Test");
			formName = formName.append("_");
			formName = formName.append("v");
			formName = formName.append(to_string(iPreTestCount));
			TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_PRE_TEST_FORM, "Pre Test", formName));
			*/
		}
		if (tc_strcmp(checkListStatus.c_str(), "Repair") == 0) {
			iRepairCount++;
			formName = formName.append("Repair");
			formName = formName.append("_");
			formName = formName.append("v");
			formName = formName.append(to_string(iRepairCount));
			TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_REPAIR_FORM, "Repair", formName), TD_LOG_ERROR_AND_THROW);
		}
		if (tc_strcmp(checkListStatus.c_str(), "Repair Verification") == 0) {
			iRepairVerificationCount++;
			formName = formName.append("Repair Verification");
			formName = formName.append("_");
			formName = formName.append("v");
			formName = formName.append(to_string(iRepairVerificationCount));
			TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_REPAIR_VERIFICATION_FORM, "Repair Verification", formName), TD_LOG_ERROR_AND_THROW);
		}
		if (tc_strcmp(checkListStatus.c_str(), "Post Test") == 0) {
			iPostTestCount++;
			formName = formName.append("Post Test");
			formName = formName.append("_");
			formName = formName.append("v");
			formName = formName.append(to_string(iPostTestCount));
			TERADYNE_TRACE_CALL(create_checklist_form(tRepairOrderRev, TD7_POST_TEST_FORM, "Post Test", formName), TD_LOG_ERROR_AND_THROW);
		}
	}
	catch (exception exp) {}
	TERADYNE_TRACE_LEAVE();
	return iStatus;

}