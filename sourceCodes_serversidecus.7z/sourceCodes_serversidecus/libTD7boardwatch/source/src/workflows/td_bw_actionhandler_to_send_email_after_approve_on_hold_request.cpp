/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_actionhandler_to_send_email_after_approve_on_hold_request.cpp
#      Module          :           libTD7_teradyne_workflows.dll
#      Project         :           libTD7_teradyne_workflows
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  10-Jun-2020                       Sundarraj                    	        Initial Code
#  =================================================================================================*/
#include <workflows/teradyne_workflows.h>

int td_bw_actionhandler_to_send_email_after_approve_on_hold_request_execute(EPM_action_message_t msg)
{
	int    iStatus = ITK_ok;
	bool bIsNull = false;
	int iAttachmentCount = 0;
	tag_t tRootTask = NULLTAG;
	tag_t *tpAttachments = NULL;
	tag_t *tpReferencedObject = NULL;

	char *cpDatasetName = NULL;
	int namedreferencedCount = 0;
	char *cpNrPathname = NULL;
	fstream Readingfile;

	const char * __function__ = "td_bw_actionhandler_to_send_email_after_approve_on_hold_request_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		// Get root task from the current task.
		TERADYNE_TRACE_CALL(EMH_clear_errors(), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);

		//Get all the target attachments from the workflow task.
		TERADYNE_TRACE_CALL(EPM_ask_attachments(tRootTask, EPM_target_attachment, &iAttachmentCount, &tpAttachments), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(send_email_task_is_approved(msg.task, tpAttachments[0]), TD_LOG_ERROR_AND_THROW);
	}
	catch (exception exp) {}
	return iStatus;
}


int send_email_task_is_approved(tag_t tcurrentTask, tag_t tRepairOrderRev) {
	int iStatus = ITK_ok;
	bool bIsNull = false;

	int server_name_count = 0;
	int server_port_count = 0;

	char *mail_body_FilePath = NULL;
	char *mail_list_FilePath = NULL;
	char** server_name_pref_value = NULL;
	char** server_port_pref_value = NULL;

	ofstream outfile;
	ofstream out_mail_file;

	string uti_exec_path = "";
	string mailBody = "";
	int 	users_count = 0;
	tag_t* 	list_users = NULLTAG;

	const char * __function__ = "send_email_task_is_approved";
	TERADYNE_TRACE_ENTER();
	try
	{

		// get current task
		//tag_t tSubTask = NULLTAG;

		//EPM_ask_sub_task(tRunningWorkflows[0], task.c_str(), &tSubTask);
		// get process_name
		BusinessObjectRef< Teamcenter::BusinessObject > boWorkflowProcessRev(tcurrentTask);
		AcquireLock lockOnWorkflow(tcurrentTask);
		std::string sProcessName("");
		boWorkflowProcessRev->getString("job_name", sProcessName, bIsNull);

		std::string sTaskName("");
		boWorkflowProcessRev->getString("object_name", sTaskName, bIsNull);

		BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);
		AcquireLock lockOnLLApartNum(tRepairOrderRev);
		std::string sItemId("");
		boRepairOrderRev->getString(ITEM_ID, sItemId, bIsNull);

		std::string mailSubject = "";
		mailSubject = mailSubject.append("Request For On Hold Approved:");
		mailSubject = mailSubject.append(sProcessName);
		mailSubject = mailSubject.append(":");
		mailSubject = mailSubject.append(sTaskName);

		vector<tag_t> vValidReceipants;
		
		tag_t tpFinalInsAssignee = NULLTAG;

		TERADYNE_TRACE_CALL(AOM_ask_value_tag(tRepairOrderRev, TD7_CLAIMED_MEMBER, &tpFinalInsAssignee), TD_LOG_ERROR_AND_THROW);
		if (tpFinalInsAssignee != NULLTAG) {
			vValidReceipants.push_back(tpFinalInsAssignee);
		}

		// get all the receipants
		mail_list_FilePath = USER_new_file_name("Mail_list", "TEXT", "txt", 1);
		out_mail_file.open(mail_list_FilePath);


		for (int i = 0; i < vValidReceipants.size(); i++)
		{
			char* 	userEmailValue = NULL;
			tag_t tPerson = NULLTAG;
			tag_t tUser = NULLTAG;
			SA_ask_groupmember_user(vValidReceipants[i], &tUser);
			SA_ask_user_person(tUser, &tPerson);
			if (tPerson != NULLTAG)
			{
				SA_ask_person_email_address(tPerson, &userEmailValue);
			}

			TC_write_syslog(" charEmailID : %s\n", userEmailValue);
			if (userEmailValue != NULL)
			{
				// write inputted data into the file.
				out_mail_file << userEmailValue << endl;
				TERADYNE_MEM_FREE(userEmailValue);
			}

		}

		// close the opened file.
		out_mail_file.close();

		// generate the mail body
		mailBody = generate_mail_body(tRepairOrderRev, tcurrentTask);

		mail_body_FilePath = USER_new_file_name("Mail_Body", "TEXT", "html", 1);
		outfile.open(mail_body_FilePath);

		// write inputted data into the file.
		outfile << mailBody << endl;

		// close the opened file.
		outfile.close();

		// email notification
		PREF_ask_char_values("Mail_server_name", &server_name_count, &server_name_pref_value);
		PREF_ask_char_values("Mail_server_port", &server_port_count, &server_port_pref_value);

		uti_exec_path.append("tc_mail_smtp.exe -to_list_file=").append(mail_list_FilePath).append(" -subject=\"").append(mailSubject).append("\" -server=\"").append(*server_name_pref_value).append("\" -port=\"").append(*server_port_pref_value).append("\" -body=\"").append(mail_body_FilePath);

		system(uti_exec_path.c_str());
		TC_write_syslog(" \n email notification sent!!\n");

		DeleteFileA(mail_body_FilePath);//Deleting the file after sending the mail
		DeleteFileA(mail_list_FilePath);//Deleting the file after sending the mail

	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

string generate_mail_body(tag_t tRepairOrderRev, tag_t tcurrentTask) {
	int iStatus = ITK_ok;
	bool bIsNull = false;

	char *jobName = NULL,
		*currentTask = NULL,
		*description = NULL,
		*pcDueDate = NULL;

	date_t due_date;

	string bufferHTMLContent = "<html><head></head><body>";

	const char * __function__ = "generate_mail_body";
	TERADYNE_TRACE_ENTER();
	try {
		// prepare mail body
		BusinessObjectRef< Teamcenter::BusinessObject > boRepairOrderRev(tRepairOrderRev);
		AcquireLock lockOnLLApartNum(tRepairOrderRev);
		std::string sRepairOrderID("");
		std::string sServiceType("");
		std::string sRepaiGroup("");
		boRepairOrderRev->getString(ITEM_ID, sRepairOrderID, bIsNull);
		boRepairOrderRev->getString(TD7_BAT_SERVICE_TYPE, sServiceType, bIsNull);
		boRepairOrderRev->getString(TD7_DIV_PART_REPAIR_GROUP, sRepaiGroup, bIsNull);
		if (tc_strcmp(sRepaiGroup.c_str(), "") == 0) {
			boRepairOrderRev->getString(TD7_COMM_PART_REPAIR_GROUP, sRepaiGroup, bIsNull);
		}
		else if (tc_strcmp(sRepaiGroup.c_str(), "") == 0) {
			boRepairOrderRev->getString(TD7_RMP_REPAIR_GROUP, sRepaiGroup, bIsNull);
		}

		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tcurrentTask, "job_name", &jobName), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tcurrentTask, "object_string", &currentTask), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_date(tcurrentTask, "due_date", &due_date), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(iStatus = AOM_ask_value_string(tcurrentTask, "object_desc", &description), TD_LOG_ERROR_AND_THROW);

		if (due_date.year == 0 && due_date.month == 0 && due_date.day == 0)
		{
			pcDueDate = (char *)MEM_alloc(sizeof(char) * 2);
			strcpy(pcDueDate, "None");
		}
		else
		{
			DATE_date_to_string(due_date, "%d-%b-%Y %H:%M", &pcDueDate); // convert the date to string 
		}

		bufferHTMLContent.append("<font size=\"3\" color=\"#4181c0\" face=\"Arial\" ><b>Overview:</b></font>\r\n");
		bufferHTMLContent.append("<table  style=\"border-collapse:collapse;\"><tbody>\r\n"); //start table

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">\r\n");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Current Task: </font>");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(currentTask).append(" in ").append(jobName).append("</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Process Name: </font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(sRepairOrderID).append("-").append(sServiceType).append("-").append(sRepaiGroup).append("</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Due Date: </font>");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append(pcDueDate).append("</font>");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Comments:</font>");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append("(none)").append("</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("<tr valign=\"top\" height=\"8\">");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\">Instructions:</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("<td  style=\"border-style:none none none none;border-color:#000000;border-width:0px 0px 0px 0px;padding:1px 1px;\">\r\n");
		bufferHTMLContent.append("<font size=\"3\" face=\"Arial\">").append("Go to your Worklist, expand Task to Perform, Select ").append(jobName).append("</font>\r\n");
		bufferHTMLContent.append("</td>");
		bufferHTMLContent.append("</tr>");

		bufferHTMLContent.append("</tbody></table>\r\n"); //end table
		bufferHTMLContent.append("<br><br>");

		bufferHTMLContent.append("<font size=\"3\" color=\"#808080\" face=\"Arial\"><b>This email was sent from Teamcenter.</b></font>");

		bufferHTMLContent.append("</body></html>\r\n");
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return bufferHTMLContent;
}