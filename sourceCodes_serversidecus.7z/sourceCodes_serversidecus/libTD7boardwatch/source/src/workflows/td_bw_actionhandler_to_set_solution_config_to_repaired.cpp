/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_actionhandler_to_set_solution_config_to_repaired.cpp
#      Module          :           libTD7_teradyne_workflows.dll
#      Project         :           libTD7_teradyne_workflows
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  20-Aug-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <workflows/teradyne_workflows.h>

int td7_set_solutionconfig_to_repaired_execute(EPM_action_message_t msg)
{
	int iStatus = ITK_ok;
	int iAttachmentCount = 0;
	tag_t tRootTask = NULLTAG;
	tag_t *tpAttachments = NULL;
	bool bIsNull = false;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t tRelationType = NULLTAG;

	const char * __function__ = "td7_set_solutionconfig_to_repaired_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		// Get root task from the current task.
		TERADYNE_TRACE_CALL(EMH_clear_errors(), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(EPM_ask_root_task(msg.task, &tRootTask), TD_LOG_ERROR_AND_THROW);

		//Get all the target attachments from the workflow task.
		TERADYNE_TRACE_CALL(EPM_ask_attachments(tRootTask, EPM_target_attachment, &iAttachmentCount, &tpAttachments), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(set_config_objects_to_repaired(tpAttachments[0], TD7_REPAIRS_SERIAL_NO_REL), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(set_config_objects_to_repaired(tpAttachments[0], TD7_INCOMING_CONFIG_REL), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(set_config_objects_to_repaired(tpAttachments[0], TD7_SOLUTION_CONFIG_REL), TD_LOG_ERROR_AND_THROW);
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int set_config_objects_to_repaired(int tRepairOrderRev, string relationType) {

	int iStatus = ITK_ok;
	int iSecondaryCnt = 0;
	tag_t * tpSecondaryObjects = NULLTAG;
	tag_t tRelationType = NULLTAG;
	bool bisverdict = false;

	const char * __function__ = "set_config_objects_to_repaired";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(GRM_find_relation_type(relationType.c_str(), &tRelationType), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tRepairOrderRev, tRelationType, &iSecondaryCnt, &tpSecondaryObjects), TD_LOG_ERROR_AND_THROW);
		for (int i = 0; i < iSecondaryCnt; i++) {
			POM_AM__set_application_bypass(true);
			TERADYNE_TRACE_CALL(iStatus = POM_modifiable(tpSecondaryObjects[i], &bisverdict), TD_LOG_ERROR_AND_THROW);
			if (!bisverdict)
			{
				TERADYNE_TRACE_CALL(AOM_load(tpSecondaryObjects[i]), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tpSecondaryObjects[i], true), TD_LOG_ERROR_AND_THROW);
			}
			TERADYNE_TRACE_CALL(AOM_set_value_string(tpSecondaryObjects[i], TD7_SERIAL_NUMBER_STATUS, "Repaired"), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(AOM_save_without_extensions(tpSecondaryObjects[i]), TD_LOG_ERROR_AND_THROW);
			if (!bisverdict)
			{
				TERADYNE_TRACE_CALL(AOM_unload(tpSecondaryObjects[i]), TD_LOG_ERROR_AND_THROW);
				TERADYNE_TRACE_CALL(iStatus = AOM_refresh(tpSecondaryObjects[i], false), TD_LOG_ERROR_AND_THROW);
			}
			POM_AM__set_application_bypass(false);
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}