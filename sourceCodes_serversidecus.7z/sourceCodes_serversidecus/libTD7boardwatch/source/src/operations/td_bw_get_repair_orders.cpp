/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_get_repair_orders.cpp
#      Module          :           libTD7_teradyne_operations.dll
#      Project         :           libTD7_teradyne_operations
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  17-Feb-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <operations/td_bw_get_repair_components.h>


int td_bw_get_repair_orders_execute(tag_t tCustomerRev, vector<tag_t> &vRepairOrders, vector<int> &vIsNull)
{
	int iStatus = ITK_ok;
	int iCustomerorderCount = 0;
	int iRepairOrderObjectCount = 0;
	tag_t tCustomerOrderRelationTag = NULLTAG;
	tag_t tCreatedByCustomerOrderRelationTag = NULLTAG;
	tag_t *tpCustomerOrderObjects = NULL;
	tag_t *tpRepairOrderObjects = NULL;

	const char * __function__ = "td_bw_get_repair_orders_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_CUSTOMER_ORDER_REL, &tCustomerOrderRelationTag), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_CREATED_BY_CUSTOMER_ORDER, &tCreatedByCustomerOrderRelationTag), TD_LOG_ERROR_AND_THROW);

		
		TERADYNE_TRACE_CALL(GRM_list_primary_objects_only(tCustomerRev, tCustomerOrderRelationTag, &iCustomerorderCount, &tpCustomerOrderObjects), TD_LOG_ERROR_AND_THROW);

		if (iCustomerorderCount > 0) {
			for (int i = 0; i < iCustomerorderCount; i++) {
				TERADYNE_TRACE_CALL(GRM_list_primary_objects_only(tpCustomerOrderObjects[i], tCreatedByCustomerOrderRelationTag, &iRepairOrderObjectCount, &tpRepairOrderObjects), TD_LOG_ERROR_AND_THROW);

				for (int j = 0; j < iRepairOrderObjectCount; j++) {
					vRepairOrders.push_back(tpRepairOrderObjects[j]);
					vIsNull.push_back(0);
				}
			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_MEM_FREE(tpCustomerOrderObjects);
	TERADYNE_MEM_FREE(tpRepairOrderObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

