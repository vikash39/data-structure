/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_get_incoming_configs.cpp
#      Module          :           libTD7_teradyne_operations.dll
#      Project         :           libTD7_teradyne_operations
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  17-Feb-2019                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <operations/td_bw_get_repair_components.h>


int td_bw_get_incoming_configs_execute(tag_t tPartSerialNumRev, vector<tag_t> &vIncomingConfigs, vector<int> &vIsNull)
{
	int iStatus = ITK_ok;
	int iPartSerialCount = 0;
	int iRepairOrderCount = 0;
	tag_t tPartSerialNum = NULLTAG;
	tag_t tIncomngRel = NULLTAG;
	tag_t *tpPartSerialRevs = NULL;
	tag_t *tpRepairOrderObjects = NULL;

	const char * __function__ = "td_bw_get_incoming_configs_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(ITEM_ask_item_of_rev(tPartSerialNumRev, &tPartSerialNum), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(ITEM_list_all_revs(tPartSerialNum, &iPartSerialCount, &tpPartSerialRevs), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iPartSerialCount; i ++) {
			TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_INCOMING_CONFIG_REL, &tIncomngRel), TD_LOG_ERROR_AND_THROW);
			
			TERADYNE_TRACE_CALL(GRM_list_primary_objects_only(tpPartSerialRevs[i], tIncomngRel, &iRepairOrderCount, &tpRepairOrderObjects), TD_LOG_ERROR_AND_THROW);

					if (iRepairOrderCount > 0) {
						vIncomingConfigs.push_back(tpPartSerialRevs[i]);
						vIsNull.push_back(0);
					}
				}		
	}
	catch (...)
	{
	}

	TERADYNE_MEM_FREE(tpPartSerialRevs);
	TERADYNE_MEM_FREE(tpRepairOrderObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int td_bw_get_solution_configs_execute(tag_t tPartSerialNumRev, vector<tag_t> &vSolutionConfigs, vector<int> &vIsNull)
{
	int iStatus = ITK_ok;
	int iPartSerialCount = 0;
	int iRepairOrderCount = 0;
	tag_t tPartSerialNum = NULLTAG;
	tag_t tSolutionRel = NULLTAG;
	tag_t *tpPartSerialRevs = NULL;
	tag_t *tpRepairOrderObjects = NULL;
	const char * __function__ = "td_bw_get_solution_configs_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(ITEM_ask_item_of_rev(tPartSerialNumRev, &tPartSerialNum), TD_LOG_ERROR_AND_THROW);
		TERADYNE_TRACE_CALL(ITEM_list_all_revs(tPartSerialNum, &iPartSerialCount, &tpPartSerialRevs), TD_LOG_ERROR_AND_THROW);

		for (int i = 0; i < iPartSerialCount; i++) {
			TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tSolutionRel), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(GRM_list_primary_objects_only(tpPartSerialRevs[i], tSolutionRel, &iRepairOrderCount, &tpRepairOrderObjects), TD_LOG_ERROR_AND_THROW);

			if (iRepairOrderCount > 0) {
				vSolutionConfigs.push_back(tpPartSerialRevs[i]);
				vIsNull.push_back(0);
			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_MEM_FREE(tpPartSerialRevs);
	TERADYNE_MEM_FREE(tpRepairOrderObjects);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}