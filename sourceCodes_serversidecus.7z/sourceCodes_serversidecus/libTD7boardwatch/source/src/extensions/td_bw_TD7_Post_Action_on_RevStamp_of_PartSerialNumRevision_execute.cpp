/*=================================================================================================
#                Copyright (c) 2015 Teradyne
#                Unpublished - All Rights Reserved
#  =================================================================================================
#      Filename        :           td_bw_TD7_Post_Action_on_RevStamp_of_PartSerialNumRevision_execute.cpp
#      Module          :           libTD7_teradyne_extensions.dll
#      Project         :           libTD7_teradyne_extensions
#      Author          :           Sundarraj- INTELIZIGN
#  =================================================================================================
#  Date                              Name                               Description of Change
#  18-Nov-2020                       Sundarraj                    	        Initial Code
#  =================================================================================================*/

#include <extensions/teradyne_extensions.h>

int td_bw_TD7_Post_Action_on_RevStamp_of_PartSerialNumRevision_execute(tag_t tPartSerialNum)
{
	int iStatus = ITK_ok;
	int iSecondaryCount = 0;
	int iSolutionConfigCount = 0;
	tag_t* tSecondaryObjects = NULLTAG;
	tag_t* tPrimaryObjects = NULLTAG;
	tag_t tLLPartNum = NULLTAG;
	tag_t tSecondayObj = NULLTAG;
	tag_t tRelationType = NULLTAG;
	tag_t tSolutionConfigRelationType = NULLTAG;
	vector<tag_t> vtLLPartNum;
	logical bIsNull = false;
	char* sUserRevStamp = NULL;
	string sCurrentStep;
	const char * __function__ = "td_bw_TD7_Post_Action_on_RevStamp_of_PartSerialNumRevision_execute";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_SOLUTION_CONFIG_REL, &tSolutionConfigRelationType), TD_LOG_ERROR_AND_THROW);

		TERADYNE_TRACE_CALL(GRM_list_primary_objects_only(tPartSerialNum, tSolutionConfigRelationType, &iSolutionConfigCount, &tPrimaryObjects), TD_LOG_ERROR_AND_THROW);

		if (iSolutionConfigCount > 0) {

			TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_PART_SERIAL_REL, &tRelationType), TD_LOG_ERROR_AND_THROW);

			TERADYNE_TRACE_CALL(GRM_list_secondary_objects_only(tPartSerialNum, tRelationType, &iSecondaryCount, &tSecondaryObjects), TD_LOG_ERROR_AND_THROW);

			if (iSecondaryCount > 0) {
				for (int i = 0; i < iSecondaryCount; i++) {

					TERADYNE_TRACE_CALL(ITEM_ask_item_of_rev(tSecondaryObjects[i], &tLLPartNum), TD_LOG_ERROR_AND_THROW);
					vtLLPartNum.push_back(tLLPartNum);

					char* sLLAPartId = NULL;
					TERADYNE_TRACE_CALL(AOM_ask_value_string(tSecondaryObjects[i], ITEM_ID, &sLLAPartId), TD_LOG_ERROR_AND_THROW);
					char* sLLAPartType = NULL;
					TERADYNE_TRACE_CALL(AOM_ask_value_string(tSecondaryObjects[i], OBJECT_TYPE, &sLLAPartType), TD_LOG_ERROR_AND_THROW);

					// Remove this Relation Object from Part Serial Number.
					//TERADYNE_TRACE_CALL(AOM_refresh(tPartSerialNum, true));
					tag_t tRelationTag = NULLTAG;
					TERADYNE_TRACE_CALL(GRM_find_relation(tPartSerialNum, tSecondaryObjects[i], tRelationType, &tRelationTag), TD_LOG_ERROR_AND_THROW);
					if (tRelationTag != NULLTAG) {
						TERADYNE_TRACE_CALL(GRM_delete_relation(tRelationTag), TD_LOG_ERROR_AND_THROW);
						///TERADYNE_TRACE_CALL(AOM_refresh(tPartSerialNum, false));
					}
					TERADYNE_TRACE_CALL(AOM_save(tPartSerialNum), TD_LOG_ERROR_AND_THROW);

					TERADYNE_TRACE_CALL(AOM_ask_value_string(tPartSerialNum, TD7_REV_STAMP, &sUserRevStamp), TD_LOG_ERROR_AND_THROW);
					TERADYNE_TRACE_CALL(update_latest_part_number_into_solution_config(sLLAPartId, sUserRevStamp, sLLAPartType, tPartSerialNum), TD_LOG_ERROR_AND_THROW);
				}

			}
		}
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int update_latest_part_number_into_solution_config(string sLLAPartNumber, string sLLARevStamp, string sLLAPartType, tag_t tPartSerialNum) {
	int iStatus = ITK_ok;
	tag_t tLLAPartRev = NULLTAG;
	const char * __function__ = "update_latest_part_number_into_solution_config";
	TERADYNE_TRACE_ENTER();
	try
	{
		
		TERADYNE_TRACE_CALL(get_hla_part_number_post_action(sLLAPartNumber, sLLARevStamp, sLLAPartType, tLLAPartRev), TD_LOG_ERROR_AND_THROW);
		if (tPartSerialNum != NULLTAG && tLLAPartRev != NULLTAG) {
			tag_t tRelationTag = NULLTAG;
			TERADYNE_TRACE_CALL(GRM_find_relation_type(TD7_PART_SERIAL_REL, &tRelationTag), TD_LOG_ERROR_AND_THROW);
			tag_t tRelation = NULLTAG;
			TERADYNE_TRACE_CALL(GRM_create_relation(tPartSerialNum, tLLAPartRev, tRelationTag, NULLTAG, &tRelation), TD_LOG_ERROR_AND_THROW);
			TERADYNE_TRACE_CALL(GRM_save_relation(tRelation), TD_LOG_ERROR_AND_THROW);
			
		}
		TERADYNE_TRACE_CALL(AOM_save(tPartSerialNum), TD_LOG_ERROR_AND_THROW);
	}
	catch (...)
	{
	}

	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int get_hla_part_number_post_action(string sLLAPartNumber, string sLLARevStamp, string sLLAPartType, tag_t& tQueriedDivPartRev) {

	int iStatus = ITK_ok;
	int iDivCount = 0;
	int iCommercialPartRevCount = 0;
	tag_t tDivPart = NULLTAG;
	tag_t tCustomerRev = NULLTAG;
	tag_t tRepairOrderRev = NULLTAG;
	tag_t tCustomerOrderRev = NULLTAG;
	tag_t tSerialNum = NULLTAG;
	tag_t tSerialNumRev = NULLTAG;
	tag_t tDivPartRev = NULLTAG;
	tag_t tQueriedRepManagePart = NULLTAG;
	tag_t tQueriedRepManagePartRev = NULLTAG;
	tag_t tRepairMenagePartRev = NULLTAG;
	tag_t tRevisedObject = NULLTAG;
	tag_t tRepairOrder = NULLTAG;

	tag_t tCommercialPart = NULLTAG;
	tag_t tCommercilaPartRev = NULLTAG;
	tag_t tLatestRevTag = NULLTAG;
	tag_t* tCommercilaPartRevs = NULLTAG;
	char* cpCommercialType = NULL;
	char* cpCommercialRevType = NULL;

	// get the div part repair group
	int iProjectCount = 0;
	tag_t* tProjectList = NULLTAG;

	const char * __function__ = "get_hla_part_number_post_action";
	TERADYNE_TRACE_ENTER();
	try {
		if (tc_strcmp(sLLAPartType.c_str(), TD4_DIVISIONAL_PART_REVISION) == 0) {
			TERADYNE_TRACE_CALL(get_divisionla_part_with_revstamp_post_action(sLLAPartNumber, sLLARevStamp, tDivPartRev), TD_LOG_ERROR_AND_THROW);
		}
		// Validate Commercial Part.
		if (tc_strcmp(sLLAPartType.c_str(), TD4_COMMERCIAL_PART_REVISION) == 0) {
			TERADYNE_TRACE_CALL(ITEM_find_item(sLLAPartNumber.c_str(), &tCommercialPart), TD_LOG_ERROR_AND_THROW);

			if (tCommercialPart != NULLTAG) {
				TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tCommercialPart, &tLatestRevTag), TD_LOG_ERROR_AND_THROW);
				tDivPartRev = tLatestRevTag;
			}
		}

		if (tDivPartRev == NULLTAG) {

			int iRepCount = 0;

			TERADYNE_TRACE_CALL(query_item(sLLAPartNumber, REP_MANAGED_PART, iRepCount, tQueriedRepManagePart), TD_LOG_ERROR_AND_THROW);
			if (tQueriedRepManagePart != NULLTAG) {
				TERADYNE_TRACE_CALL(query_div_and_rep_mang_part_revs(sLLAPartNumber, sLLARevStamp, TERADYNE_THIRD_PART_REV, iRepCount, tRepairMenagePartRev), TD_LOG_ERROR_AND_THROW);
				if (tRepairMenagePartRev != NULLTAG) {
					tDivPartRev = tRepairMenagePartRev;
				}
				else {
					//revise_object(tQueriedRepManagePart, tRevisedObject);
					TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tQueriedRepManagePart, &tRevisedObject), TD_LOG_ERROR_AND_THROW);
					tDivPartRev = tRevisedObject;
				}
				// Update repair revision property for Repair Managed Part
				BusinessObjectRef< Teamcenter::BusinessObject > boRepairManagedPartRev(tDivPartRev);
				AcquireLock lockOnRepairManagedPart(boRepairManagedPartRev);

				if (tc_strcmp(sLLARevStamp.c_str(), "") != 0 && tc_strcmp(sLLARevStamp.c_str(), NULL) != 0) {
					TERADYNE_TRACE_CALL((boRepairManagedPartRev->setString(TD7_REV_STAMP, sLLARevStamp, false)), TD_LOG_ERROR_AND_THROW);
				}
				TERADYNE_TRACE_CALL(AOM_save(tDivPartRev), TD_LOG_ERROR_AND_THROW);
			}
		}

		tQueriedDivPartRev = tDivPartRev;
	}
	catch (...)
	{
	}
	TERADYNE_MEM_FREE(cpCommercialType);
	TERADYNE_MEM_FREE(cpCommercialRevType);
	TERADYNE_MEM_FREE(tProjectList);
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}

int get_divisionla_part_with_revstamp_post_action(string sPartNumber, string sPartRevStamp, tag_t& tQueriedPartRev) {
	int iStatus = ITK_ok;
	int iDivisionalPartRevCount = 0;
	char* cpDivisionalPartType = NULL;
	char* cpRevStamp = NULL;
	tag_t tDivisionalPart = NULLTAG;
	tag_t* tDivisionalPartRevs = NULLTAG;
	tag_t tLatestRevTag = NULLTAG;
	tag_t tDivPartRevTag = NULLTAG;

	const char * __function__ = "get_divisionla_part_with_revstamp_post_action";
	TERADYNE_TRACE_ENTER();
	try
	{
		TERADYNE_TRACE_CALL(ITEM_find_item(sPartNumber.c_str(), &tDivisionalPart), TD_LOG_ERROR_AND_THROW);
		if (tDivisionalPart != NULLTAG) {
			TERADYNE_TRACE_CALL(AOM_ask_value_string(tDivisionalPart, OBJECT_TYPE, &cpDivisionalPartType), TD_LOG_ERROR_AND_THROW);
			if (tc_strcmp(cpDivisionalPartType, TD4_DIVISIONAL_PART) == 0) {
				TERADYNE_TRACE_CALL(ITEM_list_all_revs(tDivisionalPart, &iDivisionalPartRevCount, &tDivisionalPartRevs), TD_LOG_ERROR_AND_THROW);
				if (iDivisionalPartRevCount > 0) {
					for (int i = 0; i < iDivisionalPartRevCount; i++) {
						TERADYNE_TRACE_CALL(AOM_ask_value_string(tDivisionalPartRevs[i], TD4_TERADYNE_REV_STAMP, &cpRevStamp), TD_LOG_ERROR_AND_THROW);
						if (tc_strcmp(sPartRevStamp.c_str(), cpRevStamp) == 0) {
							tDivPartRevTag = tDivisionalPartRevs[i];
						}
					}
					// if there is no Rev Stamp matches, get the latest revision
					if (tDivPartRevTag == NULLTAG) {
						TERADYNE_TRACE_CALL(ITEM_ask_latest_rev(tDivisionalPart, &tLatestRevTag), TD_LOG_ERROR_AND_THROW);
						tDivPartRevTag = tLatestRevTag;
					}
					tQueriedPartRev = tDivPartRevTag;
				}
			}
		}
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE();
	return iStatus;
}
