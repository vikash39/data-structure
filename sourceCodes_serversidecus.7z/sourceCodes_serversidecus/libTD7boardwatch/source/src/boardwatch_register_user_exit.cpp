
#include <workflows/teradyne_workflows.h>
//#include <teradyne_register_user_exit.h>
#include <extensions/teradyne_extensions.h>
#include <operations/teradyne_operations.h>
#include <services/teradyne_services.h>


int libTD7boardwatch_register_callbacks()
{
	int iStatus = ITK_ok;
	const char * __function__ = "libTD7boardwatch_register_callbacks";
	TERADYNE_TRACE_ENTER();
	try
	{
		TC_write_syslog("Successfully registered the dll libTD7boardwatch. Build on %s %s \n", __DATE__, __TIME__);

		TERADYNE_TRACE_AND_THROW(CUSTOM_register_exit("libTD7boardwatch", "USER_gs_shell_init_module", (CUSTOM_EXIT_ftn_t)teradyne_register_handlers));

	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE_RVAL("%d", iStatus);
	return iStatus;
}

int teradyne_register_handlers(int* decision, va_list args)
{
	int iStatus = ITK_ok;
	const char * __function__ = "teradyne_register_handlers";
	TERADYNE_TRACE_ENTER();
	try
	{
		*decision = ALL_CUSTOMIZATIONS;

		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("td7_repair_config_uploder_workflow", "Repair Config Uploder Workflow", (EPM_action_handler_t)repair_config_uploader_workflow));

		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("td7_assign_tc_projects_team_to_debug_and_repair", "Assign Project Team To Debug & Repair", (EPM_action_handler_t)td7_assign_tc_projects_team_to_debug_and_repair));


		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("td7_export_lla_part_number", "Export LLA Part Number", (EPM_action_handler_t)td7_export_lla_part_number));

		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("plmxml_export_and_attach_to_target", "Export target and attach exported xml to that Target", plmxml_export_and_attach_to_target_execute));

		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("td7_generate_checklists_revisions", "Generate Checklists Revisions", td7_generate_checklists_revisions_execute));

		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("td7_validate_user_location", "Validate the User's location", td7_validate_user_location_execute));

		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("td7_set_solution_config_as_repaired", "Set Solution Config As Repaired", td7_set_solutionconfig_to_repaired_execute));

		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("td_bw_actionhandler_to_set_config_objects_to_scrapped", "Set Solution Config As Scrapped", td_bw_actionhandler_to_set_config_objects_to_scrapped_execute));

		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("td_bw_actionhandler_to_assign_custom_participants", "Assign Custom Participants", td_bw_actionhandler_to_assign_custom_participants_execute));

		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("td_bw_actionhandler_to_send_email_after_approve_on_hold_request", "Send Email Once On Hold Approved", td_bw_actionhandler_to_send_email_after_approve_on_hold_request_execute));

		// Register Action handlers here
		TERADYNE_TRACE_AND_THROW(EPM_register_action_handler("td_bw_actionhandler_to_replace_hla_partno_from_sln_con", "Replace HLA Part Number If Solution Config change Part Number", td_bw_actionhandler_to_replace_hla_part_number_from_solution_config_execute));


		
	}
	catch (...)
	{
	}
	TERADYNE_TRACE_LEAVE_RVAL("%d", iStatus);
	return iStatus;
}

int libTD7_teradyne_extensions_register_callbacks()
{
	int iStatus = ITK_ok;

	try
	{
		TC_write_syslog("Successfully registered the dll libTD7_teradyne_extensions. Build on %s %s \n", __DATE__, __TIME__);
	}
	catch (...)
	{
	}
	return iStatus;
}

int libTD7_teradyne_operations_register_callbacks()
{
	int iStatus = ITK_ok;
	try
	{
		TC_write_syslog("Successfully registered the dll libTD7_teradyne_operations. Build on %s %s \n", __DATE__, __TIME__);
	}
	catch (...)
	{
	}
	return iStatus;
}

int libTD7_teradyne_services_register_callbacks()
{
	int iStatus = ITK_ok;
	try
	{
		TC_write_syslog("Successfully registered the dll libTD7_teradyne_services. Build on %s %s \n", __DATE__, __TIME__);
	}
	catch (...)
	{
	}
	return iStatus;
}