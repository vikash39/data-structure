# ifndef TD_BW_COMPLETE_DEBUG_AND_REPAIR_H
# define TD_BW_COMPLETE_DEBUG_AND_REPAIR_H

#include <common/teradyne_common.h>
#include <common/TeradyneUtils.hxx>
#include "teradyne_services_exports.h"

#ifdef __cplusplus
extern "C" {
#endif

	TERADYNE_SERVICE_EXPORT int validate_checkListName(string uid, string checkListName);

	TERADYNE_SERVICE_EXPORT int validate_checklist_properties(tag_t tRepairOrderRev, vector<string> vCheckListInput, logical bIsPropertyFilled);

	//TERADYNE_SERVICE_EXPORT int set_as_older_versions_for_checklists(tag_t tPrimaryObj, string sRelation, string tFormType);

	//TERADYNE_SERVICE_EXPORT int create_checklist_form(tag_t tRepairOrderRev, string tFormType, string sobjName, string sFormName);

	TERADYNE_SERVICE_EXPORT int generate_checklists_revisions_complete_debug_and_repair(tag_t tRepairOrderRev, int iPreInspectionCount, int iPreTestCount,
		int iRepairCount, int iRepairVerificationCount, int iPostTestCount);

	TERADYNE_SERVICE_EXPORT int is_need_to_generate_checklist_version(tag_t tPrimaryObj, string sRelation, string sFormType, string sRequiredValue, bool &isNeedToGenerate);

	TERADYNE_SERVICE_EXPORT int teradyne_attach_checklist_with_repair_order(tag_t tPrimObj, tag_t tSecObj, string sAttachRel);

	TERADYNE_SERVICE_EXPORT int complete_review_task(string uid, string decision, string comments, string task);

	TERADYNE_SERVICE_EXPORT int complete_repair_routing(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows);

	TERADYNE_SERVICE_EXPORT int complete_vendor_repair_order(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows);

	TERADYNE_SERVICE_EXPORT int complete_normal_repair_routing(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows);

	TERADYNE_SERVICE_EXPORT int complete_engg_evaluation(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows);

	TERADYNE_SERVICE_EXPORT int complete_debug_and_repair(tag_t tRepairOrderRev, bool isValidTask, bool bValidErrorMessage, bool bIsRepairChecklistUpdated, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows);

	TERADYNE_SERVICE_EXPORT int complete_vendor_repair_order(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows);

	TERADYNE_SERVICE_EXPORT int complete_rework(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows);

	TERADYNE_SERVICE_EXPORT int complete_vendor(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows);

	TERADYNE_SERVICE_EXPORT int complete_final_inspection(tag_t tRepairOrderRev, bool isValidTask, int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows);

	TERADYNE_SERVICE_EXPORT int perform_task(int iNumOfWorkflows, string task, string comments, tag_t * tRunningWorkflows);

	TERADYNE_SERVICE_EXPORT int claim_unclaim_debug_and_repair(string isClaim, string uid);

	TERADYNE_SERVICE_EXPORT int validate_repair_components_exist(tag_t tPrimaryObject, bool &bValidReparOrder);

	TERADYNE_SERVICE_EXPORT int update_sender_value_to_engg_evaluation_form(tag_t tRepairOrderRev, string comments);

	TERADYNE_SERVICE_EXPORT int update_sender_value_from_routing_task(tag_t tRepairOrderRev, string comments);

	TERADYNE_SERVICE_EXPORT int validate_engg_evaluation_checklists(tag_t tRepairOrderRev, bool &bValidReparOrder);

	TERADYNE_SERVICE_EXPORT int validate_engg_evaluation_checklists_complete_stage(tag_t tRepairOrderRev, bool &bValidReparOrder);

	TERADYNE_SERVICE_EXPORT int validate_debug_and_repair_checklists(tag_t tRepairOrderRev, bool &bValidReparOrder);

	TERADYNE_SERVICE_EXPORT int validate_repair_checklists(tag_t tRepairOrderRev, bool &bValidReparOrder);

	TERADYNE_SERVICE_EXPORT int validate_debug_and_repair_checklists_for_engg_evaluation(tag_t tRepairOrderRev, bool &bValidReparOrder);

	TERADYNE_SERVICE_EXPORT int validate_rework_checklists(tag_t tRepairOrderRev, bool &bValidReparOrder);

	TERADYNE_SERVICE_EXPORT int validate_final_inspection_checklists(tag_t tRepairOrderRev, bool &bValidReparOrder);

	TERADYNE_SERVICE_EXPORT int validate_final_inspection_checklists_when_complete(tag_t tRepairOrderRev, bool &bValidReparOrder);

	TERADYNE_SERVICE_EXPORT int generate_email_to_specified_users(tag_t tRepairOrderRev, std::string mailSubject, tag_t tcurrentTask, vector<tag_t> vValidReceipants);

	TERADYNE_SERVICE_EXPORT int is_same_hla_sn_and_hla_pn_complete_wf(tag_t tRepairOrderRev, bool &isSameHLASNAndPN);
	TERADYNE_SERVICE_EXPORT int validate_main_root_ause_value(tag_t tRepairOrderRev, bool &isMainRootCauseUpdated);
	TERADYNE_SERVICE_EXPORT int release_all_serial_number_objects(tag_t tRepairOrderRev);
#ifdef __cplusplus
}
TERADYNE_SERVICE_EXPORT std::string generate_mail_body(tag_t tRepairOrderRev, tag_t tcurrentTask);

#endif

#endif
