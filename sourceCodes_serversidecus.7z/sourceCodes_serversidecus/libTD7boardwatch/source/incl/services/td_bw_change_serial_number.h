#pragma once
# ifndef TD_BW_CHANGE_SERIAL_NUMBER
# define TD_BW_CHANGE_SERIAL_NUMBER

#include <common/teradyne_common.h>
#include <common/TeradyneUtils.hxx>
#include "teradyne_services_exports.h"

#ifdef __cplusplus
extern "C" {
#endif

	// change_serial_number
	TERADYNE_SERVICE_EXPORT int change_serial_number(std::string sNewSerialNumber, std::string sNewSerialNumberName, std::string repairOrderUID);

	TERADYNE_SERVICE_EXPORT int create_new_serial_number(string sSerialNumberId, string sObjectName, tag_t tPartRev, tag_t& tSerialNumRev);

	TERADYNE_SERVICE_EXPORT int attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel);

#ifdef __cplusplus
}
#endif

#endif