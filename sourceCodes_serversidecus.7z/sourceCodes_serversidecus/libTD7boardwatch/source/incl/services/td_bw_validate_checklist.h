# ifndef TD_BW_REPAIR_ORDER_CREATION_H
# define TD_BW_REPAIR_ORDER_CREATION_H

#include <common/teradyne_common.h>
#include <common/TeradyneUtils.hxx>
#include "teradyne_services_exports.h"

#ifdef __cplusplus
extern "C" {
#endif
	
	//Initiate Repair order creation
	int td_bw_validate_checklist_execute(string uid, string checkListName);

#ifdef __cplusplus
}
#endif

#endif 