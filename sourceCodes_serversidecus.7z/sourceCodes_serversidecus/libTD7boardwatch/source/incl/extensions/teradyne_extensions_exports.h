
#ifndef TERADYNE_EXTENSIONS_EXPORTS_H
#define TERADYNE_EXTENSIONS_EXPORTS_H


#if defined(EXTENSIONS_EXPORTS)
# if defined(_WIN32)
#       define TERADYNE_EXTENSION_EXPORT     __declspec(dllexport)
#   else
#       define TERADYNE_EXTENSION_EXPORT
#   endif
#else
#  if defined(_WIN32)
#       define TERADYNE_EXTENSION_EXPORT      __declspec(dllimport)
#   else
#       define TERADYNE_EXTENSION_EXPORT
#   endif
#endif

#endif  //TERADYNE_EXTENSIONS_EXPORTS_H


