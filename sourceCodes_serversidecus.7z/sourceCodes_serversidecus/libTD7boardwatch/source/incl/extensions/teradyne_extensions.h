
# ifndef TERADYNE_EXTENSIONS_H
# define TERADYNE_EXTENSIONS_H

#include <common/teradyne_constants.h>
#include "teradyne_extensions_exports.h"
#include <common/TeradyneUtils.hxx>

using namespace std;
using namespace Teamcenter;
using namespace TERADYNE::COMMON;

#ifdef __cplusplus
extern "C" {
#endif

	TERADYNE_EXTENSION_EXPORT int libTD7_teradyne_extensions_register_callbacks();

	/**Pre-Conditions**/

	//Extension to validate serial number to add solution config.
	TERADYNE_EXTENSION_EXPORT int td_bw_pre_condition_on_iman_save_to_set_serial_number_status_execute(va_list localArgs);

	/**Pre-Actions**/


	/**Post-Actions**/

	////Extension to set current checklsit value on repair order.
	TERADYNE_EXTENSION_EXPORT int td_bw_post_action_on_grm_create_of_td7_checklist_to_set_current_step_execute(va_list localArgs);

	TERADYNE_EXTENSION_EXPORT int td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute(va_list localArgs);

	TERADYNE_EXTENSION_EXPORT int td_bw_postaction_on_save_repaircomprevision_execute(va_list localArgs);

	TERADYNE_EXTENSION_EXPORT int td_bw_post_action_on_repairs_rel_to_validate_ref_desig_execute(tag_t tPrimary, tag_t tSecondary);

	TERADYNE_EXTENSION_EXPORT int td_bw_TD7_Post_Action_on_RevStamp_of_PartSerialNumRevision_execute(tag_t tPartSerialNum);


	// helper funtions

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	TERADYNE_EXTENSION_EXPORT int read_record_postaction_on_repairconfigcsv(string sRepairOrderNumber, vector<string> inputValues, int &strErroCode, string &strItemId);

	TERADYNE_EXTENSION_EXPORT int query_repair_order(string sROID, string sType, int iCount, tag_t& tRepairOrder);

	TERADYNE_EXTENSION_EXPORT int validate_serial_number_status_of_all_the_sn_revisions(tag_t tLLASerial, string sLLARevStamp, bool& isSerialNumValid);

	TERADYNE_EXTENSION_EXPORT int get_serial_number_revision_based_on_revstamp(tag_t tLLASerial, string sLLARevStamp, tag_t& tLLASerialRev);

	TERADYNE_EXTENSION_EXPORT int is_new_lla_config(string sLLASerialNumberID, string sLLASerialNumber, string sLLARevStamp, string sDivPart, tag_t tRepairOrderRev, tag_t tPartNumberRev);

	TERADYNE_EXTENSION_EXPORT int attach_all_lla_into_config_objects(tag_t tLLASerialRev, string sLLARevStamp, bool isSameHLASNAndPN, tag_t tPartNumberRev, tag_t tRepairOrderRev, string sDivPart);

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	TERADYNE_EXTENSION_EXPORT int validate_closure_value_of_existing_repair_orders_repair_config_csv(tag_t tSecondaryObj, bool &bValidClosureValue);

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	TERADYNE_EXTENSION_EXPORT int validate_previous_configs_in_same_ro(tag_t tRepairOrderRev, tag_t tLLASerialRev, tag_t tLLAPartNumberRev, bool &isExistingConfigObjects);

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	//TERADYNE_EXTENSION_EXPORT int query_lla_serial_number_revs(string sLlaSerialNumber, string sType, int iCount, tag_t& tQueriedSerialRev);

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	TERADYNE_EXTENSION_EXPORT int traverse_BOM_repaircomprevision(tag_t tBomLineRevisionTag, string sPartNumber, bool &bCompFound);

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	//TERADYNE_EXTENSION_EXPORT int teradyne_create_custom_object(string sObjType, string sItemdId, string sItemRevId, string sObject_name, tag_t &tNewlyCreatedObj);

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	//int teradyne_attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel);

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	TERADYNE_EXTENSION_EXPORT int is_psn_attched_with_lla_repairconfigcsv(tag_t tPrimaryObj, string sRelation, tag_t tSecondaryObj, bool &bObjectFound);

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	TERADYNE_EXTENSION_EXPORT int is_same_hla_sn_and_hla_pn(tag_t tRepairOrderRev, tag_t tLLASerialRev, string sLLARevStamp, tag_t tLLAPartNumberRev, bool &isSameHLASNAndPN);

	TERADYNE_EXTENSION_EXPORT int is_same_hla_sn_and_hla_pn_to_set_rev_Stamp(string sRepairOrderNumber, bool &isSameHLASNAndPN);

	TERADYNE_EXTENSION_EXPORT int validation_to_remove_part_number_if_revstamp_mismtach(tag_t tRepairOrderRev, tag_t tLLAPartNumRev, string sLLASerialNumber, string sLLAPartNumber, string sLLARevStamp, bool &isValidateToRemoveExistingPartNumber);

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	TERADYNE_EXTENSION_EXPORT int get_divisionla_part_with_revstamp(string sPartNumber, string sPartRevStamp, tag_t& tQueriedPartRev);

	// Helper function for td_bw_postaction_on_aeimport_of_repairconfigcsv_to_initiate_workflow_execute
	TERADYNE_EXTENSION_EXPORT int create_attach_serial_number_repairconfigcsv(string sSerialNumberId, string sObjectName, tag_t tPartRev, tag_t& tSerialNumRev);

	TERADYNE_EXTENSION_EXPORT int create_repair_managed_part_repairconfigcsv(string sLLAPartNumber, string sPartNumberRev, string sHLAPartNumber, tag_t& tRepManagePartRev);

	// Helper function for td_bw_postaction_on_aesave_of_repairconfigcsv_to_initiate_workflow_execute
	TERADYNE_EXTENSION_EXPORT int validate_repair_order_availability(tag_t tTargetObject, char* cpDatasetName, logical &lRoFound);

	// Helper function for td_bw_postaction_on_save_repaircomprevision_execute
	TERADYNE_EXTENSION_EXPORT int get_hla_part_number_repairconfigcsv(string sLLAPartNumber, string sLLARevStamp, string sLLAPartType, string sDivPart, tag_t& tQueriedDivPartRev);

	// Helper function for td_bw_postaction_on_save_repaircomprevision_execute
	TERADYNE_EXTENSION_EXPORT int set_present_in_bom_status(tag_t tLLAPartNumberRev, tag_t tRepairCompRev);

	// Helper function for td_bw_postaction_on_save_repaircomprevision_execute
	TERADYNE_EXTENSION_EXPORT int traverse_BOM(tag_t tBomLineRevisionTag, string sPartNumber, bool &bCompFound);

	// Helper function for td_bw_postaction_on_save_repaircomprevision_execute
	TERADYNE_EXTENSION_EXPORT int validation_to_set_repair_comp_desc(tag_t tRepairCompRev);

	// Helper function for td_bw_postaction_on_save_repaircomprevision_execute
	TERADYNE_EXTENSION_EXPORT int query_div_and_rep_mang_part(string sPartNumber, string sType, tag_t& tQueriedPartRev);

	// Helper function for td_bw_postaction_on_save_repaircomprevision_execute
	TERADYNE_EXTENSION_EXPORT int set_repair_comp_desc(tag_t tRepairCompRev, tag_t tPartRev, bool& bIsCompDescUpdated);

	// Helper function for td_bw_postaction_on_save_repaircomprevision_execute
	TERADYNE_EXTENSION_EXPORT char *NumericValues(char *inputLine);

	// Helper function for td_bw_postaction_on_save_repaircomprevision_execute
	TERADYNE_EXTENSION_EXPORT char* Charactervalues(char *inputLine);

	// Helper function for td_bw_postaction_on_save_repaircomprevision_execute
	TERADYNE_EXTENSION_EXPORT void tostring(char str[], int num);

	TERADYNE_EXTENSION_EXPORT int query_lla_serial_number_revs_repair_config_csv(string sLLASerialNumberID, string sType, int iCount, tag_t& tQueriedSerialRev);

	TERADYNE_EXTENSION_EXPORT int update_latest_part_number_into_solution_config(string sLLAPartNumber, string sLLARevStamp, string sLLAPartType, tag_t tPartSerialNum);

	TERADYNE_EXTENSION_EXPORT int get_hla_part_number_post_action(string sLLAPartNumber, string sLLARevStamp, string sLLAPartType, tag_t& tQueriedDivPartRev);

	TERADYNE_EXTENSION_EXPORT int get_divisionla_part_with_revstamp_post_action(string sPartNumber, string sPartRevStamp, tag_t& tQueriedPartRev);

#ifdef __cplusplus
}

// " Becuase it has C linkage specified"
// Helper function for td_bw_postaction_on_save_repaircomprevision_execute
TERADYNE_EXTENSION_EXPORT string split_reference_designator(std::string originalReferenceDesignator);

#endif

#endif //TERADYNE_EXTENSIONS_H