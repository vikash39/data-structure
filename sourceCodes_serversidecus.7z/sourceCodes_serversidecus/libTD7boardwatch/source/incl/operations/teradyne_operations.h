

# ifndef TERADYNE_OPERATIONS_H
# define TERADYNE_OPERATIONS_H

#include <common/teradyne_common.h>
#include <operations/teradyne_operations_exports.h>
#include <common/teradyne_constants.h>
#include <common/TeradyneUtils.hxx>

#ifdef __cplusplus
extern "C" {
#endif

	TERADYNE_OPERATION_EXPORT int libTD7_teradyne_operations_register_callbacks();

#ifdef __cplusplus
}
#endif

#endif //TERADYNE_OPERATIONS_H