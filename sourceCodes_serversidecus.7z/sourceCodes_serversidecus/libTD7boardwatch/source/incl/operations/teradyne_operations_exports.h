

#ifndef TERADYNE_OPERATIONS_EXPORTS_H
#define TERADYNE_OPERATIONS_EXPORTS_H


#if defined(OPERATIONS_EXPORTS)
# if defined(_WIN32)
#       define TERADYNE_OPERATION_EXPORT     __declspec(dllexport)
#   else
#       define TERADYNE_OPERATION_EXPORT
#   endif
#else
#  if defined(_WIN32)
#       define TERADYNE_OPERATION_EXPORT      __declspec(dllimport)
#   else
#       define TERADYNE_OPERATION_EXPORT
#   endif
#endif

#endif  //TERADYNE_OPERATIONS_EXPORTS_H


