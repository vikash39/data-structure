
# ifndef HTML_LOGGER_HXX
# define HTML_LOGGER_HXX

#include "teradyne_common_exports.h"
#include "teradyne_common.h"
#include "teradyne_constants.h"
#include "teradyne_trace_handling.h"
#include "TeradyneUtils.hxx"
#include <stdio.h>

#include <iostream>
#include <string.h>
#include <vector>
#include <map>

#include <metaframework/BusinessObjectRef.hxx>
#include <base_utils\Timer.hxx>
#include <common/Logger.hxx>

using namespace std;
using namespace Teamcenter;
using namespace TERADYNE;
using namespace TERADYNE::COMMON;

namespace TERADYNE {
	namespace COMMON {
		class TERADYNECOMEXPCLASS HTMLLogger : public Logger 
		{
		public:

			/**
			* \file  HTMLLogger.hxx
			* \ingroup libAP4_dnvgl_common
			* \par  Description :
			This function is costructor of HTMLLogger Class.
			* \verbatim
			\endverbatim        
			* \param [in]         string log File name.			
			* \par Algorithm:
			* \verbatim  
			1.Constructor call for Logger Class which Gets the absolute File path and extention and check file is present or not.			
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			*/
			HTMLLogger(string sFileNameWithoutExt);


			/**
			* \file  HTMLLogger.hxx
			* \ingroup libAP4_dnvgl_common
			* \par  Description :
			This function is for adding header data in log file.
			* \verbatim
			\endverbatim        
			* \param [in]         vector<string> of header data to add in log file.	
			* \par Algorithm:
			* \verbatim  
			1.Get the header data and add it into logger file.			
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			*/
			int addLogHeader(vector<string> logHeader);

			/**
			* \file  HTMLLogger.hxx
			* \ingroup libAP4_dnvgl_common
			* \par  Description :
			This function is for adding column data in log file.
			* \verbatim
			\endverbatim        
			* \param [in]         vector<string> of column data to add in log file.	
			* \par Algorithm:
			* \verbatim  
			1.Get the column data and add it into logger file.			
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			*/			
			int addColumnData(vector<string> columnHeaders ); 

			/**
			* \file  HTMLLogger.hxx
			* \ingroup libAP4_dnvgl_common
			* \par  Description :
			This function is for adding row data in log file.
			* \verbatim
			\endverbatim        
			* \param [in]         vector<string> of row data to add in log file.	
			* \par Algorithm:
			* \verbatim  
			1.Get the row data and add it into logger file.			
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			*/
			int addRowData(vector<string> rowData);	
			

			/**
			* \file HTMLLogger.hxx
			* \ingroup libAP4_dnvgl_common
			* \par  Description :
			This function is for closing log file.
			* \verbatim
			\endverbatim
			* \par Algorithm:
			* \verbatim  
			1.Close the logger file.			
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			*/
			int closeHTMLLog();
						
		};
	}
}

#endif //HTML_LOGGER_HXX