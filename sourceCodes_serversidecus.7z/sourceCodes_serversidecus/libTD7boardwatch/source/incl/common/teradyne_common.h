
# ifndef TERADYNE_COMMON_H
# define TERADYNE_COMMON_H

/*************************************************
* Disable warnings
**************************************************/
#pragma warning(disable:4251)


/*************************************************
* System Header Files
**************************************************/
#include <algorithm>
#include <winsock2.h>
#include <Windows.h>
#include <ctype.h>
#include <fstream>
#include <iomanip>
#include <locale>
#include <map>
#include <math.h>
#include <stdlib.h>
#include <string>
#include <sys/stat.h> 
#include <sys/timeb.h>
#include <sys/types.h>
#include <time.h>
#include <vector>
#include <iostream>
#include <string>
#include <sstream>
#include <direct.h>
#include <set>
#include <unordered_map>
#include <climits>
#include <regex>
#include <functional> 
#include <cctype>
#include <locale>
#include <pie/pie.h>
#include <iostream>
#include <vector>
#include <map>
#include <strstream>
#include <fstream>
#include <tchar.h>
#include <algorithm>
#include <cfm/cfm.h>
#include <common/teradyne_constants.h>
#include <list>

#pragma comment(lib, "rpcrt4.lib")
#include<rpc.h>
#include<iomanip>
/*************************************************
* Teamcenter Header Files
**************************************************/
#include <ae/ae.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <ae/shell_util.h>
#include <ae/vm_errors.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <common/emh_const.h>
#include <constants/constants.h>
#include <ctype.h>
#include <errno.h>
#include <epm/cr.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <epm/releasestatus.h>
#include <epm/signoff.h>
#include <fclasses/tc_date.h>
#include <itk/bmf.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <me/me.h>
#include <metaframework/BusinessObjectRef.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <cxpom/attributeaccessor.hxx>
#include <nls\nls.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <Fnd0Participant/participant.h>
#include <property/propdesc.h>
#include <property/prop_errors.h>
#include <ps/ps.h>
#include <ps/ps_tokens.h>
#include <ps/vrule.h>
#include <qry/crf.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <sa/am.h>
#include <sa/user.h>
#include <sa/tcfile.h>
#include <sa/tcvolume.h>
#include <schmgt/schmgt_bridge_itk.h>
#include <schmgt/schmgt_itk.h>
#include <sub_mgr/standardtceventtypes.h>
#include <sub_mgr/subscription.h>
#include <sub_mgr/tceventtype.h>
#include <tc/emh.h>
#include <tc\emh_errors.h>
#include <tc/folder.h>
#include <tc/iman_arguments.h>
#include <tc/preferences.h>
#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <textsrv/textserver.h>	
#include <tccore\aom.h>
#include <tccore\aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/iman_msg.h>
#include <tccore/item.h>
#include <tccore/item_msg.h>
#include <tccore/license.h>
#include <tccore/method.h>
#include <tccore/project.h>
#include <tccore/project_errors.h>
#include <tccore/tc_msg.h>	
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h> 
#include <tccoreext/gde.h>
#include <ug_va_copy.h>
#include <cxpom/attributeaccessor.hxx>
#include <fclasses\AcquireLock.hxx>
/*************************************************
* Custom Header Files
**************************************************/
//#include "teradyne_constants.h"
#include "teradyne_common_exports.h"

using namespace std;

//Macro to free the memory
#define TERADYNE_MEM_FREE(x) if(x != NULL) {MEM_free(x); x = NULL;}

#ifdef __cplusplus
extern "C" {
#endif

	//Register the libAP4_dnvgl_common.dll
	TERADYNECOMEXP int libTD7_teradyne_common_register_callbacks();

	// define this function because this is not exposed API; Basically we are cheating the Tc :)
	TERADYNECOMEXP void AM__set_application_bypass(logical setBypass);
	TERADYNECOMEXP void POM_AM__set_application_bypass(logical setBypass);
	
	int teradyne_attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel);
	
	int revise_object(tag_t tItem, tag_t& tItemReviseTag);

	int remove_secondary_objects(tag_t tPrimaryObject, string sRelationType);
	
	int query_div_and_rep_mang_part_revs(string sPartNumber, string sPartNumberRev, string sType, int iCount, tag_t& tQueriedPartRev);
	
	int query_item(string sItemId, string sType, int iCount, tag_t& tItemRev);
	
	int teradyne_split(std::string str, char delimiter, std::vector<std::string> &vResult);
	
	int set_as_older_versions_for_checklists(tag_t tPrimaryObj, string sRelation, string tFormType);
	
	int create_checklist_form(tag_t tRepairOrderRev, string tFormType, string sobjName, string sFormName);
	
	int teradyne_create_solution_config(string sItemdId, tag_t tRepairOrderRev, tag_t &tNewlyCreatedObj);
	
	int td7_override_part_serial_relation_create_post(tag_t tLLApartNumber, tag_t tPrimaryObject, tag_t tSecondaryObject);
	
	int teradyne_create_custom_object(string sObjType, string sItemdId, string sItemRevId, string sObject_name, tag_t &tNewlyCreatedObj);

	int query_lla_serial_number_revs(string sLlaSerialNumber, string sType, int iCount, tag_t& tQueriedSerialRev);

	int teradyne_dataset_attach_with_relation(tag_t tPrimObj, tag_t tSecObj, string sAttachRel);

	int teradyne_current_timestamp(string strFormat, string &strTimeStamp, date_t &curDate);

	


#ifdef __cplusplus
}
#endif

std::vector<std::string> splitString(std::string theString, string delim, bool splitQuotes);
std::string &ltrim(std::string &s);
std::string &rtrim(std::string &s);
std::string &trim(std::string &s);
bool isDigitWSAllowed(std::string str);
bool isAlphaWSAllowed(std::string str);
bool isAlphaNumericWSAllowed(std::string str);
bool isAlphaNumericStrict(std::string str);
std::string incrementedAlpha(std::string str);
void getNextAlpha(string &buf, int pos, bool alphaNum);
string removeSpecialCharactors(string inputString);

template <typename T>
string toString(T Number)
{
	ostringstream ss;
	ss << Number;
	return ss.str();
}

#endif //TERADYNE_COMMON_H