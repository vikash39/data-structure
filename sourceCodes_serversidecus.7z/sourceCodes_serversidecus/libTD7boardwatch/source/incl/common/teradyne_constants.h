
# ifndef TERADYNE_CONSTANTS_H
# define TERADYNE_CONSTANTS_H

//Error Types
#define TERADYNE_ERROR_MSG                       "TERADYNE_ERROR_MSG"
#define TERADYNE_WARNING_MSG                     "TERADYNE_WARNING_MSG"
#define TERADYNE_INFORMATION_MSG                 "TERADYNE_INFORMATION_MSG"

//Relations
#define TD7_PART_SERIAL_REL						"TD7PartSerialRel"
#define TD7_REPAIR_SERIAL_NO_REL				"TD7RepairSerialNoRel"
#define TD7_OUTGOING_SERIAL_REL					"TD7OutgoingHLASerialNumber"
#define TD7_INCOMING_CONFIG_REL					"TD7IncomingConfigRel"
#define TD7_SOLUTION_CONFIG_REL					"TD7SolutionConfigRel"
#define TD7_REPAIRS_REL							"TD7RepairsRel"
#define TD7_REPAIRS_SERIAL_NO_REL				"TD7RepairSerialNoRel"
#define TD7_CUSTOMER_ORDER_REL					"TD7CustomerOrderRel"
#define TD7_CREATED_BY_CUSTOMER_ORDER			"TD7CreatedByCustomerOrder"


//OOTB Relations
#define TC_ATTACHES_RELATION					"TC_Attaches"
#define IMAN_REFERENCE_RELATION					"IMAN_reference"
#define IMAN_SPECIFICATION_RELATION				"IMAN_specification"
#define IMANRELATION							"ImanRelation"
#define TC_NEW_RELATION							"TC_Attaches"
#define AP4_COMMCHAINVERIFTASK_RELATION			"AP4_ComChainVerifTaskRel"

//OOTB Object Types
#define SIGNOFF                                 "Signoff"
#define SCHEDULE							    "Schedule"
#define SCHEDULETASK							"ScheduleTask"
#define TASKTYPE_S								"S"
#define TASKTYPE_SS								"SS"
#define ITEM_REVISION                           "ItemRevision"
#define WORKSPACEOBJECT                         "WorkspaceObject"
#define EPMDOTASK								"EPMDoTask"
#define EPMREVIEWTASK                           "EPMReviewTask"
#define EPMPERFORMSIGNOFFTASK                   "EPMPerformSignoffTask"
#define POM_GROUP								"POM_group"
#define POM_USER								"POM_user"
#define POM_APPLICATION_OBJECT					"POM_application_object"
#define POM_OBJECT								"POM_object"
#define POM_CLASS								"POM_class"
#define POM_MEMBER								"POM_member"
#define PUSER									"User"
#define PPERSON									"Person"




//OOTB Attributes
#define OBJECT_TYPE								"object_type"
#define ITEM_ID									"item_id"
#define ITEM_REVISION_ID						"item_revision_id"
#define PRIMARY_OBJECT							"primary_object"
#define SECONDARY_OBJECT						"secondary_object"
#define ASSIGNEE								"assignee"
#define USER									"user"
#define OBJECT_NAME							    "object_name"
#define OBJECT_DESC							    "object_desc"
#define IS_TEMPLATE								"is_template"
#define IMAN_BASED_ON							"IMAN_based_on"
#define CREATION_DATE							"creation_date"
#define ORIGINAL_FILE_NAME						"original_file_name"
#define FILE_NAME								"file_name"
#define SD_PATH_NAME							"sd_path_name"
#define OWNING_USER								"owning_user"
#define OWNING_GROUP							"owning_group"
#define USER_NAME								"user_name"
#define USER_ID								    "user_id"
#define HAS_PARTICIPANT							"HasParticipant"
#define WORKSPACE_OBJECT						"WorkspaceObject"
#define RELEASE_STATUS_LIST					 	"release_status_list"
#define PROJECT_LIST							"project_list"
#define FINISH_DATE								"finish_date"
#define FND0_ASSIGNEE							"fnd0Assignee"
#define FND0_ASSIGNEE_USER						"fnd0AssigneeUser"
#define FND0_ASSIGNEE_GROUP						"fnd0AssigneeGroup"
#define FND0_ASSIGNEE_GROUP_ROLE				"fnd0AssigneeGroupRole"
#define FND0_ASSIGNEE_EMAIL                     "fnd0AssigneeEmail"
#define PA6										"PA6"
#define PA7										"PA7"
#define PA9										"PA9"
#define PA10									"PA10"
#define PERSON									"person"
#define PARTICIPANT								"Participant"
#define FND0TASKTYPESTRING						"fnd0TaskTypeString"
#define FND0WORKFLOWINITIATOR					"fnd0WorkflowInitiator"
#define WORKFLOW_TEMPLATE						"workflow_template"
#define WORKFLOW_TRIGGER_TYPE					"workflow_trigger_type"
#define ITEM_ID									"item_id"
#define AP4_TEMPLATETYPE						"ap4_templatetype"
#define AP4_TEMPLATETYPEREV						"ap4_templatetype_rev"
#define FND0SUMMARYTASK							"fnd0SummaryTask"
#define START_DATE								"start_date"
#define FINISH_DATE								"finish_date"
#define CHILD_TASK_TAGLIST						"child_task_taglist"
#define FND0INPROCESS							"fnd0InProcess"
#define FND0ENDDATE								"fnd0EndDate"
#define RELEASESTATUS							"ReleaseStatus"
#define OBJECT_TYPE								"object_type"
#define OBJECT_STRING							"object_string"
#define ITEMS_TAG								"items_tag"
#define PROCESS_STAGE_LIST						"process_stage_list"
#define CHILD_TASKS								"child_tasks"
#define SCHEDULE_TAG							"schedule_tag"
#define LAST_RELEASE_STATUS						"last_release_status"
#define FND0STARTEDWORKFLOWTASKS                "fnd0StartedWorkflowTasks"
#define WORK_ESTIMATE			                "work_estimate"
#define FND0PARENTTASK			                "fnd0ParentTask"	
#define EPMTASK			                        "EPMTask"
#define PARENT_TASK			                    "parent_task"
#define PARENT_NAME			                    "parent_name"		
#define CHECKED_OUT								"checked_out"
#define IP_CLASSIFICATION                       "ip_classification"
#define IMANTYPE								"ImanType"
#define TYPE_NAME								"type_name"
#define RELATION_TYPE							"relation_type"
#define EPM_SELECT_SIGNOFF_TASK					"EPMSelectSignoffTask"
#define GROUP_PROPERTY							"group"
#define GROUPMEMBER								"GroupMember"
#define REVISION_LIST							"revision_list"
#define RESOURCE_TAG							"resource_tag"
#define FND0SCHEDULEMEMBER_TAGLIST				"fnd0Schedulemember_taglist"
#define DATE_RELEASED                           "date_released"
#define DOCUMENT_TITLE							"DocumentTitle"
#define	LAST_MOD_DATE							"last_mod_date"
#define AWP0_ITEM_ID							"awp0Item_item_id"
#define OSUSERNAME								"os_username"
#define STRUCTURE_REVISIONS						"structure_revisions"
#define LATEST_WORKING							"Latest Working"
#define PRODUCT_TEMPLATE_CLONING				"Product.Template.Cloning"
#define BL_ITEM_OBJECT_TYPE						"bl_item_object_type"
#define VIEW									"view"
#define BL_ITEM_ITEM_ID							"bl_item_item_id"
#define BL_REFERENCE_DESIGNATOR					"bl_ref_designator"
#define REVISION								"revision"

//Object types
#define DATASET                                 "Dataset"
#define ITEM									"Item"
#define TD4_COMMERCIAL_PART						"TD4CommPart"
#define TD4_COMMERCIAL_PART_REVISION			"TD4CommPartRevision"
#define TD7_REPAIR_ORDER						"TD7RepairOrder"
#define TD4_DIVISIONAL_PART						"TD4DivPart"
#define TD4_DIVISIONAL_PART_REVISION			"TD4DivPartRevision"
#define TD4_TERADYNE_REV_STAMP					"td4TeradyneRevStamp"
#define TD7_REPAIR_ORDER_REVISION				"TD7RepairOrderRevision"
#define TD7_REPAIR_MANAGED_PART					"TD7RepManagePart"
#define TD7_REPAIR_MANAGED_PART_REVISION		"TD7RepManagePartRevision"
#define TD7_PART_SERIAL_NUM						"TD7PartSerialNum"
#define TD7_SOLUTION_CONFIG						"TD7SolConfig"
#define TD7_SOLUTION_CONFIG_REVISION			"TD7SolConfigRevision"
#define TD7_PART_SERIAL_NUM_REVISION			"TD7PartSerialNumRevision"
#define TD7_REPAIR_COMP							"TD7RepairComp"
#define TD7_REPAIR_COMP_REVISION				"TD7RepairCompRevision"
#define TD7_CUSTOMER							"TD7Customer"
#define TD7_CUSTOMER_REVISION					"TD7CustomerRevision"
#define TD7_CUSTOMER_ORDER						"TD7CustomerOrder"
#define TD7_CUSTOMER_ORDER_REL					"TD7CustomerOrderRel"
#define TD7_CREATED_BY_CUSTOMER_ORDER			"TD7CreatedByCustomerOrder"
#define TD7_POST_TEST_FORM						"TD7PostTestForm"
#define TD7_PRE_INSPECTION_FORM					"TD7PreInspectionForm"
#define TD7_ENGG_EVALUATION_FORM				"TD7EnggEvalForm"
#define TD7_PRE_TEST_FORM						"TD7PreTestForm"
#define TD7_QUALITY_INSPECTION_FORM				"TD7QualityInsForm"
#define TD7_REPAIR_REWORK_FORM					"TD7ReworkForm"
#define TD7_REPAIR_FORM							"TD7RepairForm"
#define TD7_REPAIR_VERIFICATION_FORM			"TD7RepairVerifyForm"
#define TD7_VENDOR_REPAIR_FORM					"TD7VendorRepair"
#define TD7_REPAIR_CONFIG_CSV					"TD7RepairConfigCSV"

// Ter Layer
#define TD_REL_STATUS_NAME						"TD4Released"


//Custom Attributes
#define TD7_FORM_NAME							"td7_object_name"
#define TD7_IS_LATEST_VERSION					"td7IsLatestVersion"
#define IS_DEB_AND_REPAIR_CLAIMED				"td7_is_deb_and_rep_claimed"
#define IS_ENGG_EVALUATION_CLAIMED				"td7_is_engg_eval_claimed"
#define IS_CLAIMED_USER							"td7_claimed_user"
#define TD7_CLAIMED_MEMBER						"td7_claimed_member"
#define IS_REWORK_CLAIMED						"td7_is_rework_claimed"
#define IS_FINAL_INS_CLAIMED					"td7_is_final_ins_claimed"
#define TD7_ORDER_TYPE							"td7_order_type"
#define TD7_BAT_ORDER_TYPE						"td7_bat_order_type"
#define TD7_BAT_MATURITY						"td7_bat_maturity"
#define TD7_HLA_SERIAL_NUM_STATUS				"td7_serial_number_status"
#define TD7_BAT_ORDER_CATEGORY					"td7_bat_order_category"
#define TD7_BAT_CLOSURE							"td7_bat_closure"
#define TD7_BAT_DISPOSITION						"td7_bat_disposition"
#define TD7_NORMAL_REPAIR_ORDER_STATUS			"td7_val_normal_repair_order"
#define TD7_ENGG_EVALUATION_STATUS				"td7_engg_eval_task_status"
#define TD7_DEBUG_AND_REAPIR_TASK_STATUS		"td7_deb_and_rep_task_status"
#define TD7_REWORK_STATUS						"td7_rework_status"
#define TD7_FINAL_INS_STAUTS					"td7_final_ins_status"
#define TD7_SERVICE_TYPE						"td7_service_type"
#define TD7_BAT_SERVICE_TYPE					"td7_bat_service_type"
#define TD7_BAT_REPAIR_LOCATION					"td7_bat_repair_location"
#define TD7_SCRSP_REASON						"td7_scrap_resaon"
#define TD7_SPR_FLAG							"td7_spr_flag"
#define TD7_E_SUSPENSE_FLAG						"td7_e_suspense_flag"
#define TD7_MERLIN_ORDER_CREATION				"td7_merlin_order_creation"
#define TD7_REPAIR_ORDER_DUE_DATE				"td7_repair_order_due_date"
#define TD7_CUSTOMER_ORDER_DUE_DATE				"td7_customer_order_due_date"
#define TD7_SERIAL_NUMBER						"td7_serial_number"
#define TD7_PART_NUMBER							"td7_part_number"
#define TD7_PART_REVISION						"td7_part_revision"
#define TD7_DIV_PART_REV_STAMP					"td7_part_rev_stamp"
#define TD7_COMM_PART_NUMBER					"td7_comm_part"
#define TD7_COMM_PART_REVISION					"td7_comm_part_revision"
#define TD7_REP_MANAGE_PART						"td7_repair_managed_part"
#define TD7_REP_MANAGE_PART_REVISION			"td7_repair_managed_part_rev"
#define TD7_REP_MANAGE_REV_STAMP				"td7_rmp_revstamp"
#define TD7_DIV_PART_REPAIR_GROUP				"td7_part_repair_group"
#define TD7_COMM_PART_REPAIR_GROUP				"td7_comm_part_repair_group"
#define TD7_RMP_REPAIR_GROUP					"td7_rmp_repair_group"
#define TD7_PRESENT_IN_BOM						"td7_present_in_bom"
#define TD7_CHECKLIST_ID						"td7_checklist_id"
#define TD7_BAT_CHECKLIST						"td7_bat_checklist"
#define TD7_CUSTOMER_SITE						"td7_customer_site"
#define TD7_CUSTOMER_ID							"td7_customer_id"
#define TD7_CUSTOMER_NAME						"td7_customer_name"
#define TD7_CUSTOMER_LOCATION					"td7_customer_location"
#define TD7_CUSTOMER_PROGRAM					"td7_customer_program"
#define TD7_CUSTOMER_PGM						"td7_customer_pgm"
#define TD7_CUSTOMER_SITE_CONTACT				"td7_customer_site_contact"
#define TD7_CUSTOMER_EMAIL_ADDRESS				"td7_customer_email_address"
#define TD7_CUSTOMER_FAILURE_DATA				"td7_customer_failure_data"
#define TD7_CUSTOMER_DATALOG_RATING				"td7_customer_datalog_rating"
#define TD7_SYS_SERIAL_NUMBER					"td7_system_serial_number"
#define TD7_REPAIR_ORDER_REV_STAMP				"td7_ro_rev_stamp"
#define TD7_PROJECT_ID							"project_id"
#define TD7_PROJECT_LIST						"project_list"
#define TD7_DEBUG_AND_REPAIR_TASK_STATUS		"td7_deb_and_rep_task_status"
#define TD7_INFO_FROM_SENDER					"td7_info_from_sender"
#define TD7_ENGG_EVALUATION_DISPOSITION			"td7_disposition"
#define TD7_SCRAP_CRITERIA						"td7_scrap_criteria"
#define TD7_SCRAP_CODE							"td7_scrap_code"
#define TD7_POST_TEST_RESULT					"td7_post_test_result"
#define TD7_POST_TEST_FAILURE_DETAILS			"td7_post_test_failure_det"
#define TD7_PRE_INSPECTION_TEST_RESULT			"td7_pre_ins_test_result"
#define TD7_PRE_TEST_TEST_RESULT				"td7_pre_test_test_result"
#define TD7_PRE_TEST_FINDING					"td7_repair_finding"
#define TD7_REPAIR_REWORK_RESULT				"td7_rework_status"
#define TD7_REPAIR_VERIFICATION_STATUS			"td7_repair_verifica_status"
#define TD7_REPAIR_VERIFICATION_RESULTS			"td7_repair_verifi_results"
#define TD7_REPAIR_RESULT						"td7_repair_result"
#define TD7_REPAIR_DETAILS						"td7_repair_details"
#define TD7_REPAIR_REVISION						"td7_part_revision"
#define TD7_SERIAL_NUMBER_STATUS				"td7_lla_serial_num_status"
#define TD7_IS_ALLOW_INPROGRESS_SN				"td7_is_allow_inprogress_sn"
#define TD7_ENGG_EVALUATION_ASSIGNEES			"td7_engg_eval_assignees"
#define TD7_DEBUG_AND_REPAIR_ASSIGNEES			"td7_deb_and_rep_assignee"
#define TD7_REWORK_ASSIGNEES					"td7_rework_assignees"
#define TD7_FINAL_INSPECTION_ASSIGNEES			"td7_final_ins_assignees"
#define TD7_CURRENT_TASK_NAME					"td7_current_task_name"
#define TD7_REV_STAMP							"td7_rev_stamp"
#define TD7_PRE_INSPECTION_FAILURE_COMMENTS		"td7_pre_ins_failure_commets"
#define TD7_BATTERY								"td7_battery"
#define TD7_PCBA_STATUS							"td7_psba_status"
#define TD7_CABLES								"td7_cables"
#define TD7_COOLING								"td7_cooling"
#define TD7_COMPUTERS							"td7_computers"
#define TD7_CONNECTORS							"td7_connectors"
#define TD7_DISCRETE_PARTS						"td7_discrete_parts"
#define TD7_DOCUMENT							"td7_document"
#define TD7_INTEGRATED_CIRCUITS       			"td7_integrated_circuits"
#define TD7_METAL_PARTS							"td7_metal_parts"
#define TD7_PLASTIC_RUBBER_PARTS				"td7_plastic_rubber_parts"
#define TD7_POWER_PRODUCTS						"td7_power_products"
#define TD7_TAMPERED							"td7_tampered"
#define TD7_COMP_PART_NUMBER					"td7_component_part_number"
#define TD7_REFERENCE_DESIGNATOR				"td7_reference_designator"
#define TD7_REFERENCE_DESIGNATOR_STATUS			"td7_ref_design_status"
#define TD7_ENGG_EVALUATION_TASK_STATUS		    "td7_task_status"
#define TD7_REWORK_RESULTS						"td7_rework_results"
#define TD7_REWORK_STATUS						"td7_rework_status"
#define TD7_QUALITY_INSPECTION_TEST_RESULT		"td7_quality_ins_test_result"
#define TD7_QUALITY_INSPECTION_FAILURE_DETAILS	"td7_quality_ins_failure_com"
#define TD7_MAIN_ROOT_CAUSE						"td7_main_root_cause"
#define TD7_HLA_REVSTAMP_IN						"td7_hla_rev_stamp_in"
#define TD7_HLA_REVSTAMP_OUT					"td7_hla_rev_stamp_out"


//Custom attribute values
#define MANA_COMMLETTERTEMPLATE					"MANA_CommLetterTemplate"
#define MANA_PROJCOMMLETTERTEMPLATE				"MANA_ProjCommLetterTemplate"
#define DELI_COMMLETTER							"Comment Letter"
#define DELI_PROJECTSUMMARYLETTER				"Project Summary Letter"
#define ACTIVITY_BASED_APPROVAL					"Activity Based Approval"
#define MARINE_WARRANTY_SERVICES				"Marine Warranty Services"
#define ABA_TASK								"ABA Task"
#define REVIEW_TASK								"Review Task"
#define DISCIPLINE								"DISCIPLINE"
#define EXTERNALPROJECT							"External Project" 
#define INTERNALPROJECT							"Internal Project"
#define DESIGN_VERIFICATION						"Design Verification"
#define STANDALONECL							"StandAlone"
#define GROUPCL									"GroupCL"


//Field Revision lov values
#define DELI_COC								"Certificate of Conformity"
#define DELI_VCARECO                            "Recommendation"
#define DELI_VCAMEMO                            "Memorandum"

//LOV Values
#define LEAD									"Lead"
#define OPPORTUNITY								"Opportunity"

//Roles
#define CUSTOMER								"Customer"

//Groups
#define PROJECT_ADMINISTRATION					"Project Administration"
#define CUSTOMER_GROUP							"Customer.TERADYNE"
#define DBA										"dba"


//Participant Types
#define AP4_BIDMANAGER							"AP4_BidManager"

//Address Types
#define INVOICE									"Invoice"
#define OFFICE									"Office"
#define POSTAL									"Postal"

//Handler arguments
#define CONVERT_TO								"-convert_to"
#define PROPERTY								"property"
#define INCLUDE_TYPE							"include_type"
#define ATTACHMENT								"attachment"
#define INVOICE_TYPE							"invoice_type"
#define INVOICE_NAME							"invoice_name"
#define APPEND_COUNTER							"append_counter"
#define ATTACHMENT_TYPE							"attachment_type"
#define IS_FINAL								"IsFinal"
#define TASK_TYPE								"task_type"
#define ACKNOWLEGDE_TASK						"ack_task"
#define DO_TASK									"do_task"
#define ASSIGNEE_SET							"assignee_set"
#define ASSIGNEE_REMOVE							"assignee_remove"
#define ASSIGNEE_ROLE							"assignee_role"
#define APPROVAL_ENG_ROLE						"Approval Engineer"
#define PRIMARYOBJECTTYPE						"primaryObjectType"
#define SECONDARYOBJECTTYPE						"secondaryObjectType"
#define RELATIONTYPE							"relationType"
#define ALLOWEDLIMIT							"allowedLimit"
#define SIGNOFF_QUORUM							"signoff_quorum"
#define IS_ENTERED_BY_PM						"-is_entered_by_pm"
#define TEMPLATE_ID								"template_id"
//Preferences
#define TERADYNE_RESTRICTED_WORKFLOWS			"TERADYNE_Restricted_Workflows"
#define MAIL_SERVER_NAME                        "Mail_server_name"
#define TERADYNE_WIPEOUT_TEMP_DIRECTORY			"TERADYNE_WIPEOUT_TEMP_DIRECTORY"


//Utils
#define TC_ROOT_ENV_VAR							""
#define TERADYNE_FORMDATASET					""
#define APS_DEFAULT_ADMIN_USERS					""
#define ACTIVEWORKSPACE_URL					""



//Release Statuses
#define OBSOLETE								"Obsolete"
#define IMPORTED								"Imported"
//Others	
#define FUNCTIONAL_ELEMENT							"Functional Element"
#define STANDALONE_SUMMARY_LETTER_TEMPLATE			"Standalone Summary Letter Template"
#define COMMENT_LETTER_TEMPLATE						"Comment Letter Template"
#define IN_CREATION									"In Creation"
#define QUERY_ITEM									"Item..."
#define QUERY_ITEM_REVISION							"Item Revision..."
#define QUERY_DATASET								"Dataset Name"
#define TERADYNE_ON									TRUE
#define TERADYNE_OFF								FALSE
#define SERIALNUMBER								"Serial Number"
#define CUSTOMER_ORDER								"Customer Order"
#define LLA_SERIAL_NUMBER							"LLA Serial Number"
#define REP_MANAGED_PART							"Repair Managed Part"
#define REP_MANAGED_PART_REVISION					"Repair Managed Part Revision"
#define COMMERCIAL_PART							    "Commercial Part"
#define DIVISIONAL_PART							    "Divisional Part"
#define DIVISIONAL_PART_REVISION				    "Divisional Part Revision"
#define PRE_INSPECTION								"Pre Inspection"
#define PRE_TEST									"Pre Test"
#define REPAIR										"Repair"
#define REPAIR_VERIFICATION							"Repair Verification"
#define POST_TEST									"Post Test"
#define REWORK										"Rework"
#define QUALITY_INSPECTION							"Quality Inspection"
#define TEMPLATE_DATASET							"Template"


#define TERADYNE_ITEM_ID_ATTR						"item_id"
#define TERADYNE_ITEM_REVISION_ID_ATTR				"item_revision_id"
#define IMAN_SPECIFICATION							"IMAN_specification"
#define TEMP										"TEMP"
#define TERADYNE_REPAIR_ORDER_INPUTFILE_ENV_VAR		"TC_UTILITY_MERLIN"
#define TERADYNE_CUSTOMER_INPUTFILE_ENV_VAR			"TC_UTILITY_MERLIN_CUSTOMER"
#define TERADYNE_TC_PROJECTS_INPUTFILE_ENV_VAR		"TC_UTILITY_MERLIN_PROJECT"
#define TERADYNE_LLA_PART_EXPORT_LOCATION		    "TC_UTILITY_MERLIN_EXPORT_LLA"
#define TERADYNE_MERLIN_ORDER_INTERFACE_SUMMARY	    "TC_UTILITY_MERLIN_SUMMARY"
#define  QUERY_INPUT_ITEM_ID						"Item ID"
#define  QUERY_INPUT_REVISION						"Revision"
#define  QUERY_INPUT_NAME							"Name"
#define  QUERY_INPUT_TYPE							"Type"
#define REPAIR_ORDER								"Repair Order"
#define  QUERY_DATASET_NAME							"Dataset Name"	

#define TERADYNE_DIVISIONAL_PART_REV				"Divisional Part Revision"
#define TERADYNE_THIRD_PART_REV						"Repair Managed Part Revision"

// Workflow Names
#define WF_TERADYNE_REPAIR_ORDER					"TER_RepairOrder_WF"
#define WF_TERADYNE_REPAIR_CONFIG_UPLOADER			"TER_RepairConfigUploader"


// Special characters
#define DELIMITER									"/"
#define COMMA_DELIMITER								","

//Switch case parameter
#define REJECT_COMMENT							1
#define UPDATE_COMMENT							2
#define CREATE_COMMENT							3


//Validation Values
#define YES											"Yes"
#define NO											"No"
#define INFO										"INFO"
//#define ERROR										"ERROR"
//#define FAILED										"FAILED"
//#define SUCCESS										"SUCCESS"

//Error Codes
//#define EMH_USER_error_base(OOTB)						919000
#define TERADYNE_CUSTOMER_NOT_FOUND					(EMH_USER_error_base + 207)// Customer not found
#define TERADYNE_REPAIR_MANAGE_PART_FAILED			(EMH_USER_error_base + 210)// Repair Managed part not found
#define TERADYNE_DIVPART_NOT_FOUND					(EMH_USER_error_base + 211)// Divisional part not found
#define TERADYNE_REPAIR_ORDER_CSV_FAILED			(EMH_USER_error_base + 264)// Repair config csv failed to create as repair order does not exist
#define TERADYNE_INVALID_TASK_STATUS				(EMH_USER_error_base + 212)// Task Status property value should not ne 'None'
#define TERADYNE_PROJECT_MEMBER_NOT_FOUND			(EMH_USER_error_base + 213)// The Project team doesn't have any members'
#define TERADYNE_PROJECT_NOT_FOUND					(EMH_USER_error_base + 214)// The Divisional part is not assigned any projects'
#define TERADYNE_CHECKLIST_ERROR					(EMH_USER_error_base + 215)// Check the previous checklist form result.
#define TERADYNE_VALIDATE_CLOSURE_VALUE_ERROR		(EMH_USER_error_base + 216)// Validate the closure vlaue for the existing Repair orders.
#define TERADYNE_CURRENT_USER_IS_NOT_VALID			(EMH_USER_error_base + 217)// The Current User is not belongs to Repair Location.
#define TERADYNE_SERIAL_NUMBER_IS_NOT_VALID			(EMH_USER_error_base + 218)// Thie Serial Number is not valid to add Repair Order.
#define TERADYNE_REPAIR_ORDER_ALREADY_EXISTS		(EMH_USER_error_base + 219)// Repair Order Already Exists.
#define TERADYNE_INCOMING_CONFIG_OBJECTS_NOT_UPLOAD	(EMH_USER_error_base + 220)// There is no incoming Objects for this Repair Order.
#define TERADYNE_REPAIR_COMPONENTS_NOT_ADD			(EMH_USER_error_base + 221)// There is no Repair Components for this Repair Order.
#define TERADYNE_VALIDATE_CHECKLIST_STAGE			(EMH_USER_error_base + 222)// This Repair Order is not in 'Post Test', please fill all the checklists to continue..
#define TERADYNE_FINAL_INSPECTION_VALIDATION		(EMH_USER_error_base + 223)// This Repair Order couldn't bale to complete, before enter quality inspection checklist..
#define TERADYNE_MAIN_ROOT_CAUSE_VALIDATION			(EMH_USER_error_base + 224)// Atleast any one of the repair components should have 'Main RootCause' as Yes
#define TERADYNE_DUPLICATE_CONFIG_LINE				(EMH_USER_error_base + 225)// Duplicate Config line found
#define TERADYNE_INVALID_SCRAP_REASON				(EMH_USER_error_base + 226)// Invalid Scrap Reason
#define TERADYNE_REPAIR_CHECKLIST_IS_NOT_UPDATED	(EMH_USER_error_base + 227)// Repair Checklist is not updated
#define TERADYNE_PART_NUMBER_DOES_NOT_EXIST			(EMH_USER_error_base + 260)// Repair Checklist is not updated
#define TERADYNE_NOT_ALL_CONFIG_OBJ_CREATED			(EMH_USER_error_base + 261)// Repair Checklist is not updated
#define TERADYNE_INPUT_LINE_OF_CSV_NOT_VALID		(EMH_USER_error_base + 262)// Repair Checklist is not updated
#define TERADYNE_CONFIG_CSV_FILE_NOT_GETTING_LOAD	(EMH_USER_error_base + 263)// Repair Checklist is not updated


#define TERADYNE_NON_REPAIR_ORDER					(EMH_USER_error_base + 222)// Workflow initiatted on NON REPAIRORDER object

#define ERROR_919238								919238	// Logger related error
#define ERROR_919237								919237	// Logger related error
#define ERROR_919239								919239	// HTML Logger related error
#define ERROR_919204								919204	// relation not found
//#define ERROR_919168								919168  // Given element:%1$ not found in input xml.
//#define ERROR_919219								919219  // Activity(s) "%1$" already sent for review to "%2$".

#endif //TERADYNE_CONSTANTS_H
