
#include "teradyne_error_handling.h"
#include "teradyne_trace_handling.h"
#include "teradyne_common.h"
#include "TeradyneUtils.hxx"

namespace TERALOG {

	class TERADYNECOMEXPCLASS LogMangement {
	private:

		char sdate[9];
		char stime[9];
		fstream logfile;
		string teradyne_getDateandTime();

	public:

		

		static int teradyne_openLogFile(string logFile);
		static void teradyne_writeToLogFile(string sMsgType, string sMsg, string sItemId, string sAction);
	

	};
}
