
#ifndef TERADYNE_ERRORHANDLING_H
#define TERADYNE_ERRORHANDLING_H

#include "teradyne_common.h"
#include "teradyne_trace_handling.h"
#include "teradyne_constants.h"
#ifdef _WIN32
/* on MS Windows ignore deprecation warnings: */ 
#define _CRT_SECURE_NO_DEPRECATE 1
#endif

#ifdef __cplusplus
extern "C"
{
#endif

	TERADYNECOMEXP void teradyne_log_error_syslog(int  iStatus, int  ierrorType, const char * szFileName, int ilineNumber, const char* szCustomMsg);

	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the iStatus with severity warning.
	This also sets iStatus back to ITK_ok.
	*/

#define TERADYNE_LOG_WARNING {\
	if (iStatus != ITK_ok) {\
	teradyne_log_error_syslog( iStatus, EMH_severity_warning , __FILE__, __LINE__ , NULL); \
	iStatus = ITK_ok;\
	}\
	}


	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the iStatus with severity error.
	<BR>
	Example:
	\image html LogErrorExample.jpg
	*/
#define TERADYNE_LOG_ERROR {\
	if (iStatus != ITK_ok) {\
	teradyne_log_error_syslog( iStatus, EMH_severity_error , __FILE__, __LINE__ , NULL); \
	}\
	}

	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the iStatus with severity error and return iStatus/error code.
	<BR>
	Example:
	\image html LogErrorAndReturnExample.jpg
	*/
#define TERADYNE_LOG_ERROR_AND_RETURN {\
	if (iStatus != ITK_ok) {\
	teradyne_log_error_syslog( iStatus, EMH_severity_error , __FILE__, __LINE__ , NULL); \
	return iStatus;\
	}\
	}

	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the iStatus with severity error and throw the iStatus/error code.
	<BR>
	Example:
	\image html LogErrorAndThrowStatusExample.jpg
	*/
#define  TERADYNE_LOG_ERROR_AND_THROW_STATUS {\
	if (iStatus != ITK_ok) {\
	teradyne_log_error_syslog( iStatus, EMH_severity_error , __FILE__, __LINE__ , NULL); \
	throw iStatus;\
	}\
	}

	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the iStatus with severity warning for ITK method calls.
	*/ 
#define TERADYNE_ITK_CALL(func) {\
	if(iStatus == ITK_ok){\
	(iStatus) = (func);\
	if (iStatus != ITK_ok) {\
	teradyne_log_error_syslog( iStatus, EMH_severity_error , __FILE__, __LINE__ , NULL); \
	}\
	}\
	}

	/**
	*\ingroup ErrorHandling
	*\par Description:
	This macro logs the information.
	This also sets iStatus back to ITK_ok.
	*/
#define TERADYNE_LOG_INFORMATION {\
	teradyne_log_error_syslog( iStatus, EMH_severity_information , __FILE__, __LINE__ , NULL); \
	EMH_clear_errors(); \
	iStatus = ITK_ok;\
	}


#ifdef __cplusplus
}
#endif

#endif // TERADYNE_ERROR_HANDLING_H
