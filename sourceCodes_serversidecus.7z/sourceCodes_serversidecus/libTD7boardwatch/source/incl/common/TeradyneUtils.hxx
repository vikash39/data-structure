
# ifndef TERADYNE_UTILS_HXX
# define TERADYNE_UTILS_HXX

#include "teradyne_common.h"
#include "teradyne_trace_handling.h"
#include "teradyne_constants.h"
#include <metaframework/BusinessObjectRef.hxx>
#include <tc/LoggedInUser.hxx>
#include <base_utils/DateTime.hxx>
#include <base_utils/Timer.hxx>
#include <base_utils/OSEnvironment.hxx>
#include <fclasses/OSFile.hxx>
#include <fclasses/OSDirectory.hxx>

using namespace std;
using namespace Teamcenter;

namespace TERADYNE {
	namespace COMMON
	{ 
		class TERADYNECOMEXPCLASS TeradyneUtils
		{
		private:
			std::string m_date;
			date_t m_currentDate;
		public:
			// constructor
			TeradyneUtils();

			typedef struct S_TeradyneUtils_CreateObjectInfo
			{
				tag_t tCreatedObject;
				std::string  sObjectTypeName;	
				std::map<std::string ,std::string > mPropertiesToSet;
				S_TeradyneUtils_CreateObjectInfo():sObjectTypeName(""),tCreatedObject(NULLTAG){}
			}S_TeradyneUtils_CreateObjectInfo_t;


			//macros starts
#define TERADYNE_STRCPY(destiStr,sourceStr){\
	int sourceStrLen = (int) tc_strlen(sourceStr);\
	destiStr = (char*)MEM_alloc((sourceStrLen + 1)* sizeof(char));\
	tc_strcpy(destiStr, sourceStr);\
			}

#define TERADYNE_STRCAT(destiStr,sourceStr){\
	int sourceStrLen = (int) tc_strlen(sourceStr);\
	int destiStrLen = 0;\
	if(destiStr != NULL)\
	destiStrLen = (int) tc_strlen (destiStr);\
	destiStr = (char*)MEM_realloc(destiStr, (sourceStrLen + destiStrLen + 1)* sizeof(char));\
	if(destiStrLen == 0)\
	tc_strcpy(destiStr, sourceStr);\
	else\
	tc_strcat(destiStr, sourceStr);\
			}

#define TERADYNE_IS_STRING_EMPTY(STRING) ((STRING == NULL) || (tc_strlen(STRING) <= 0))



			/**
			* \file teradyne_utils.cxx
			* \par Description:
			* \verbatim
			This function reads all the arguments and returns the values of all the arguments.
			* \endverbatim


			*/
			static void teradyne_get_handler_opts( IMAN_argument_list_t* givenArgList, char* pcGivenOptions, ... );

			static int teradyne_dataset_attach( char* cpDatasetType, char* cpRefName, char* cpFileName, char* cpFilePath, char* cpRelationName, tag_t tDocumentRevTag, tag_t *opDatasetTag );

			//static int teradyne_split( std::string str, char delimiter, std::vector<std::string> &vResult );

			//static int teradyne_form_delimited_string_from_vector( std::vector<std::string> vResult, char delimiter, std::stringstream &oss );

			static int teradyne_find_and_replace( string& source, string const& find, string const& replace );
			/**
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			* \verbatim
			Change the ownership of input object to given user and group.
			\endverbatim          
			* \par Algorithm:
			* \verbatim  

			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			* \par History:
			*/
			static int teradyne_change_ownership( tag_t tInputObject,const char* cpUserName,const char* cpGroupName );
			//Compare dates.
			static int teradyne_compare_dates( date_t targetDate, date_t inputCompareDate, logical compareDateOnly );
			/**
			* \file teradyne_utils.cxx
			* \par Description:
			* \verbatim
			This function retuns current date.
			* \endverbatim
			*/
			static int teradyne_get_current_date_time( date_t* valueDate );
			/**
			* \file teradyne_utils.cxx
			* \par  Description :
			This function will unzip the given zip to the given location input parameter. It will iterate in the extracted folder and 
			get the file list present in the folder
			* \verbatim
			\endverbatim     
			* \param[in]   pcZipFileNm		    Path of the exported zip dataset
			* \param[in]   pcUnZipFolderNM		Path where zip need to be extracted
			* \param[out]   vFiles		        List of the files present in zip folder
			* \par Algorithm:
			* \verbatim  
			a. Unzip the given zip file
			b. Iterate on the folder files and get the files name
			c. Delete the given zip file
			* \endverbatim
			* \par Returns :
			* int : 0/error code
			*/
			static int teradyne_get_files_name_from_zip(const char* pcZipFileNm, const char * pcUnZipFolderNM, std::vector<std::string> &vFiles);

			static int teradyne_generate_fullpath(char* sDirName, char* sFileName, char* sCreationDate, char** sFullPath);
			/**
			* \file teradyne_utils.cxx
			* \par  Description :
			This function will create a dataset based on the type of the file. Attach the file as named reference to the dataset. Then create a project document. 
			Attach the created dataset to Folder with custom relation. 

			* \verbatim
			\endverbatim     
			* \param[in]   cpFilePath		    File path
			* \param[in]   cpDocName		    Name of the document
			* \param[in]   tProjectFolderTag    Project Folder tag
			* \par Algorithm:
			* \verbatim  
			a. Get the file name and extension of file from the filepath 
			b. From the extension using custom preference to get the dataset type
			c. Create dataset and attach the file given in input parameter
			d. Create Project document ,attach teh created dataset with project document revision
			e. Attach the created project document with given project folder in input param with custom document relation
			* \endverbatim
			* \par Returns :
			* int : 0/error code
			*/
			static int teradyne_create_dataset( const char* cpFilePath, tag_t* tDataset );

			static int TERADYNE_current_get_time_stamp(char* format, char** timestamp);

			static int teradyne_grm_get_secondary_obj_of_type_with_relation ( tag_t tPrimaryObj, char*   pszRelationTypeName, char*   pszSecondaryObjType, tag_t** pptSecondaryObjects, tag_t** pptRelationObjects, int* piObjectCount );
			/**
			* \file teradyne_utils.cxx
			* \par  Description :
			This function will add given number of days to the given date.
			* \verbatim
			\endverbatim     
			* \param[in]   dInpDate		    Input date
			* \param[in]   days				Number of days to be added to the input date
			* \param[out]  dOutDate			New date with added days to the input date
			* \par Algorithm:
			* \verbatim  
			a. Add days to a given date.
			* \endverbatim
			* \par Returns :
			* int : 0/error code
			*/
			static int dnvg_add_days_to_date( date_t dInpDate , int days, date_t* dOutDate );
			/**
			* \file teradyne_utils.cxx
			* \par Description:
			* \verbatim
			This function adds participant to project revision
			* \endverbatim

			* \par Owner:
			*  Chetan kekade 
			* \param[in]    tag_t		tProjectRev
			* \param[in]    tag_t		tGroupMember
			* \param[out]   char*		cpParticipantType
			* \par History:
			*/
			static int teradyne_add_participant( tag_t tProjectRev, tag_t tGroupMember, char* cpParticipantType );
			/**
			* \file teradyne_utils.cxx
			* \par Description:
			* \verbatim
			This function removes participant from given target object
			* \endverbatim

			* \par Owner:
			*  Chetan kekade 
			* \param[in]    tag_t		tTargetObj
			* \param[in]   char*		cpParticipantType
			* \par History:
			*/
			static int teradyne_remove_participant( tag_t tTargetObj, char* cpParticipantType );

			static int teradyne_grm_get_secondary_obj_of_type(tag_t tPrimaryObj, std::string sRelationTypeName, std::string sSecondaryObjType, std::vector<tag_t>& secondaryObjects);

			static int checkIsInstanceOf(tag_t& inputTag, const char* expectedType, bool& isTypeOf);
			/**
			* \file teradyne_utils.cxx
			* \par  Description :
			This method will find the default users from preference.
			* \verbatim
			*   <description of function>.
			\endverbatim     
			* \param[in/out]   <vector>    vtUser
			* \param[in/out]   <vector>    vGroupmembers
			*
			* \par Algorithm:
			* \verbatim  
			* \endverbatim
			* \par Returns :
			* int : 0/error code
			*
			*--------------------------------------------------------------------------------
			* Date         	Name			    Description of Change
			* 08-01-2018    Srushti Hanjage		Initial Creation
			*--------------------------------------------------------------------------------
			*/
			static int teradyne_find_default_admin_user( std::vector<tag_t>&vtUser, std::vector<tag_t>&vGroupmembers  );
			/**
			* \ingroup libAP4_teradyne_services
			* \par  Description :
			* \verbatim
			Save as the given object.
			\endverbatim     
			* \param[in]	tag_t		Tag of the Object
			* \param[in]	tag_t		Tag of the Save as object
			* \param[in]	string          Type of object 
			* \verbatim  

			1. Find the type tag.
			2. Construct the create input.
			3. Add deepcopy data.
			4. Sve as the object.

			\endverbatim
			* \par Returns :
			* int : 0/error code
			*/
			static int teradyne_copy_object( tag_t &tObject, tag_t &tSveAsInput);
			/**
			* \ingroup libAP4_teradyne_services
			* \par  Description :
			* \verbatim
			This is for creating the relation between primary and secondary.
			\endverbatim     
			* \param[in]	tag_t		Tag of the Primary
			* \param[in]	tag_t		Tag of the Secondary   
			* \verbatim  

			1. Find the type of relation.
			2. Create the relation in primary and secondary.
			3. Save the relation

			\endverbatim
			* \par Returns :
			* int : 0/error code
			*/
			static int teradyne_create_relation( tag_t &tPrimary, tag_t &tScondary, std::string sRelationName );
			/**
			* \ingroup libAP4_teradyne_services
			* \par  Description :
			* \verbatim
			This is for getting the primary of secondary.
			\endverbatim     
			* \param[in]	tag_t		Tag of the Primary
			* \param[in]	string		Relation Name
			* \param[in]	string		Object Type
			* \param[out]	vector		Secondary objects  
			* \verbatim  

			1. Get all the secondary objects associated to primary with specific relation.
			\endverbatim
			* \par Returns :
			* int : 0/error code
			*/
			static int teradyne_grm_get_primary_obj_of_type(tag_t tSecondaryObj, std::string sRelationTypeName, std::string sPrimaryObjType, std::vector<tag_t>& secondaryObjects);
			/**
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			* \verbatim
			Call the utility to delete the existing relation between primary object and secondary object.
			\endverbatim     
			* \param[in]	tag_t    Tag of the primary object.
			* \param[in]	tag_t    Tag of the secondary object.
			* \param[in]	char*    Relation Name
			* \param[out]   None       
			* \par Algorithm:
			* \verbatim  
			1. Provide primary and secondary object.
			2. Using system call, call the utility function to delete the relation
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			*/
			static int teradyne_delete_relation( tag_t tPrimary, tag_t tSecondary, char* cpRelationName );
			/**
			* \
			* \par  Description :
			This function will create new revision for the given. it will release old revision and pdf dataset.
			* \verbatim
			\endverbatim     
			* \param[in]   tTechDocRevision			Input Technical document revision
			* \param[out]   tNewRevision			New Technical document revision
			* \par Algorithm:
			* \verbatim  
			a.Release Input revision.
			b.Create new revision.
			* \endverbatim
			* \par Returns :
			* int : 0/error code
			*/
			int teradyne_create_latest_rev(tag_t tItemRevision , tag_t &tNewRevision );
			/**
			* \file teradyne_utils.cxx
			* \par  Description :
			This function will create release status for given object.
			* \verbatim
			\endverbatim     
			* \param[in]   tObject				File path
			* \param[in]   sReleaseStatus		Created object

			* \par Algorithm:
			* \verbatim  
			a.Create release status
			b.Add release status to am object
			* \endverbatim
			* \par Returns :
			* int : 0/error code
			*/
			static int teradyne_create_release_status(tag_t twvs,char* sReleaseStatus);
			/**
			* \
			* \par  Description :
			This function will get the property type.
			* \verbatim
			\endverbatim     
			* \param[in]   sObjectType			Object Type
			* \param[in]   spropertyName		Property Name
			* \param[out]   valueType			Value type
			* \par Algorithm:
			* \verbatim  
			a.Get Object Type
			b.Return the property type
			* \endverbatim
			* \par Returns :
			* int : 0/error code
			*/
			static int teradyne_find_property_type(string sObjectType,string spropertyName,PROP_value_type_t &valueType);
			/**
			* \
			* \par  Description :
			This function will get the property length.
			* \verbatim
			\endverbatim     
			* \param[in]   sObjectType			Object Type
			* \param[in]   spropertyName		Property Name
			* \param[out]   iMaxEleCount		iMaxEleCount
			* \par Algorithm:
			* \verbatim  
			a.Get Object Type
			b.Return the property type
			* \endverbatim
			* \par Returns :
			* int : 0/error code
			*/
			static int teradyne_find_property_max_length(string sObjectType,string spropertyName,int &iMaxEleCount); 
			/**
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			* \verbatim
			This function converts boolean to string
			\endverbatim     
			* \param[in]		tTargetObject		    tag_t            Target Object
			* \param[out]		tProjrev		        tag_t			 Project revision Tag
			*
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			*/
			inline const char * const BoolToString(bool b);
			/**
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			* \verbatim
			This function creates URL from the tag.
			\endverbatim     
			* \param[in]		tTargetObject		    tag_t            Target Object
			* \param[out]		tProjrev		        string			 Object URL
			*
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			*/
			static int teradyne_create_URL_from_tag (tag_t tTargetObject, string& sObjectURL );
			/**	* \file TeradyneUtils.cxx
			* \par  Description :
			This function the relation between the input object exists.
			* \verbatim
			\endverbatim     
			* \par Algorithm:
			* \verbatim  
			* \endverbatim
			* \param[in]		tPrimaryObject			Tag of primary object
			* \param[in]		tSecondaryObject 		Tag of secondary object
			* \param[in]		sRelationName 			Relation object class name
			* \param[out]		lExists 				boolean check
			* \par Returns :
			* int : 0/error code
			*/
			static int checkIfRelationExists( tag_t tPrimaryObject, tag_t tSecondaryObject, std::string sRelationName, logical &lExists );
			/**	* \file TeradyneUtils.cxx
			* \par  Description :
			This function is used to get the latest revision of the input revision object
			* \verbatim
			\endverbatim     
			* \par Algorithm:
			* \verbatim  
			* \endverbatim
			* \param[in]		tInputObject		Tag of input object
			* \param[out]		tLatestRevision		Tag of latest revision
			* \par Returns :
			* int : 0/error code
			*/
			static int getLatestRevision( tag_t tOldRevision, tag_t &tLatestRevision );
			/**
			* \file TeradyneUtils.cxx
			* \par  Description :
			* \verbatim
			This function gets the attached primary object of the input secondary object.
			\endverbatim     
			* \param[in]	tTargetObject		Tag of the input object.
			* \param[in]	instanceClass		Input class name
			* \param[in]	sPrimaryObjType		Target primary object type
			* \param[out]   vPrimaryObject		vector of primary objects      
			* \par Algorithm:
			* \verbatim  
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			* \par History:
			*/
			static int getPrimaryObjectOfType( tag_t tSecondaryObj, std::string sRelationTypeName, std::string sPrimaryObjType, std::vector<tag_t> &vPrimaryObject );
			/**
			* \file TeradyneUtils.cxx
			* \par  Description :
			* \verbatim
			This function revises the instance of the item revision.
			\endverbatim     
			* \param[in]	tItemRevision			Tag of the input item revision.
			* \param[out]   tNewItemRevision		Tag of revised instance     
			* \par Algorithm:
			* \verbatim  
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			* \par History:
			*/
			static int reviseInputObject( tag_t tItemRevision, tag_t &tNewItemRevision );
			/**
			* \file TeradyneUtils.cxx
			* \par  Description :
			* \verbatim
			This function is used to trim the input string if it contains blank whitespaces.
			\endverbatim     
			* \param[in]	strInputString			Input string.  
			* \par Algorithm:
			* \verbatim  
			\endverbatim
			* \par Returns :
			* \par History:
			*/
			static string trim( std::string &strInputString );
			/**
			* \file TeradyneUtils.cxx
			* \par  Description :
			* \verbatim
			This function is used to fetch the secondary objects attached to the primary with the defined relation.
			\endverbatim     
			param[in]	S_TeradyneUtils_CreateObjectInfo_t		Structure containing info of object to be created.
			par Algorithm:
			* \verbatim  
			\endverbatim
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			*/
			static int createObject(S_TeradyneUtils_CreateObjectInfo_t &structCreateObjectInfo);
			/**
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			* \verbatim
			This function will check if the object is locked by any user
			\endverbatim     
			* \param[in]		tTargetObject		    tag_t            Target Object
			* \param[in]		IsLockedBySameUser		bool			 output result for same user
			* \param[in]		IsLockedByOtherUser		bool			 output result for other user
			*
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			* \par History:
			*/
			static int teradyne_is_object_locked( tag_t inputObject, bool &IsLockedBySameUser,bool &IsLockedByOtherUser );

			/**
			* \ingroup libAP4_teradyne_common
			* \par  Description :
			* \verbatim
			This function abort workflow on input tag.
			\endverbatim     
			* \param[in]		tTargetObject		    tag_t            Target Object
			* \param[in]		strComment		        char*			 input comment
			*
			* \par Returns :
			* int : Returns iStatus i.e. the error code if any error else returns 0
			*/

			static int teradyne_abort_workflow(tag_t tTargetObject , char*  strComment );


		};
	}
}

#endif //TERADYNE_UTILS_HXX